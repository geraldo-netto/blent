#!/bin/sh
set -eu
base=/backups/disk2/blent-work/2026-10-09-evdi-second
sdk=/var/lib/flatpak/runtime/org.gnome.Sdk/x86_64/51/9283544305146d753f620e8b92976537033a439a942687c7c601e4b0a12a2df9/files
gl=/home/netto/.local/share/flatpak/runtime/org.freedesktop.Platform.GL.default/x86_64/26.08/badc1097c419e73781cf098413ffa8e7bf7db3528572c11712265b9193921842/files
timeout 50s qemu-system-x86_64 -name blent-mutter-isolated -machine q35,accel=kvm -cpu host -m 2048 -smp 2 -nodefaults -drive if=pflash,format=raw,readonly=on,file=/usr/share/OVMF/OVMF_CODE_4M.fd -drive if=pflash,format=raw,file=/backups/disk2/blent-work/2026-10-09-evdi-fixes/guest-vars.fd -kernel /backups/disk2/blent-work/t700-fix/kernel/boot/vmlinuz-7.0.0-34-generic -initrd "$base/mutter-guest.cpio.gz" -append 'console=ttyS0 rdinit=/init loglevel=4 blent-evdi-review=1' -device virtio-vga-gl -display egl-headless,rendernode=/dev/dri/renderD128 -serial "file:$base/$1.log" -virtfs "local,path=$sdk,mount_tag=sdk,security_model=none,readonly=on" -virtfs "local,path=$base,mount_tag=work,security_model=none,readonly=on" -virtfs "local,path=$gl,mount_tag=gl,security_model=none,readonly=on" -no-reboot > "$base/$1-qemu.log" 2>&1
