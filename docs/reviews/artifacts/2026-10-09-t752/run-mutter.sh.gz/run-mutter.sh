#!/bin/sh
base=/backups/disk2/blent-work/2026-10-09-evdi-second
export PATH=/usr/bin:/bin
export LD_LIBRARY_PATH="$base/deps/usr/lib:$base/deps/usr/lib/x86_64-linux-gnu:/gl/lib:$base/mutter-build/src:$base/mutter-build/clutter/clutter:$base/mutter-build/cogl/cogl:$base/mutter-build/mtk"
export PYTHONPATH="$base/python"
export LIBGL_DRIVERS_PATH=/gl/lib/dri
export GBM_BACKENDS_PATH=/gl/lib/gbm
export __EGL_VENDOR_LIBRARY_DIRS=/gl/glvnd/egl_vendor.d
export XDG_DATA_DIRS=/usr/share
export GSETTINGS_SCHEMA_DIR=/tmp/schemas
export MUTTER_DEBUG_MULTI_GPU_FORCE_COPY_MODE=primary-gpu-cpu
export MUTTER_DEBUG=1
export MUTTER_VERBOSE=1
export META_DBUS_RUNNER_DISABLE_LOGIND_PASSTHROUGH=1
mkdir -p /tmp/schemas
cp /usr/share/glib-2.0/schemas/*.xml /tmp/schemas/
cp "$base"/mutter-build/data/*.xml /tmp/schemas/
glib-compile-schemas /tmp/schemas
python3 "$base/mutter-51/src/tests/meta-dbus-runner.py" -- env LD_PRELOAD="$base/trace-fb.so" timeout 18 "$base/mutter-build/src/mutter" --wayland --display-server --mutter-plugin="$base/mutter-build/src/compositor/plugins/libdefault.so"
