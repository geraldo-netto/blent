#!/bin/sh
set -eu
base=/backups/disk2/blent-work/2026-10-09-evdi-second
export PATH="$base/python/bin:$base/deps/usr/bin:$PATH"
export PYTHONPATH="$base/python"
export LD_LIBRARY_PATH="$base/deps/usr/lib:$base/deps/usr/lib/x86_64-linux-gnu"
export PKG_CONFIG_PATH="$base/deps/usr/lib/x86_64-linux-gnu/pkgconfig:$base/deps/usr/lib/pkgconfig"
meson setup "$base/mutter-build" "$base/mutter-51" -Dtests=disabled -Ddocs=false -Dintrospection=false -Dprofiler=false -Dlibgnome_desktop=false -Dlibwacom=false -Dsound_player=false -Dxwayland=false -Dbash_completion=false
meson compile -C "$base/mutter-build" -j 6
