#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdio.h>
#include <stdint.h>
#include <xf86drmMode.h>
int drmModeAddFB2(int fd,uint32_t w,uint32_t h,uint32_t format,const uint32_t handles[4],const uint32_t pitches[4],const uint32_t offsets[4],uint32_t *id,uint32_t flags) {
    int (*real)(int,uint32_t,uint32_t,uint32_t,const uint32_t*,const uint32_t*,const uint32_t*,uint32_t*,uint32_t)=dlsym(RTLD_NEXT,"drmModeAddFB2");
    int result=real(fd,w,h,format,handles,pitches,offsets,id,flags);
    fprintf(stderr,"T752 ADDFB2 fd=%d %ux%u format=%.4s result=%d id=%u\n",fd,w,h,(char*)&format,result,result?0:*id);return result;
}
int drmModeAddFB2WithModifiers(int fd,uint32_t w,uint32_t h,uint32_t format,const uint32_t handles[4],const uint32_t pitches[4],const uint32_t offsets[4],const uint64_t modifiers[4],uint32_t *id,uint32_t flags) {
    int (*real)(int,uint32_t,uint32_t,uint32_t,const uint32_t*,const uint32_t*,const uint32_t*,const uint64_t*,uint32_t*,uint32_t)=dlsym(RTLD_NEXT,"drmModeAddFB2WithModifiers");
    int result=real(fd,w,h,format,handles,pitches,offsets,modifiers,id,flags);
    fprintf(stderr,"T752 ADDFB2_MOD fd=%d %ux%u format=%.4s result=%d id=%u\n",fd,w,h,(char*)&format,result,result?0:*id);return result;
}
