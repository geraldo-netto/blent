from pathlib import Path
import gzip,hashlib,json,shutil,sys,xml.etree.ElementTree as ET
sys.path.insert(0,'scripts/coverage')
from report import collect
from kotlin_report import read
root=Path.cwd();base=Path('/tmp/blent-t1011-evidence')
expected=json.loads((base/'final-sources.json').read_text())
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in expected.items())
counts=dict(tests=0,failures=0,errors=0,skipped=0)
for path in Path('android/app/build/test-results/testDebugUnitTest').glob('TEST-*.xml'):
    suite=ET.parse(path).getroot()
    for key in counts:counts[key]+=int(suite.get(key,0))
assert counts['tests']==2234 and not any(counts[k] for k in ['failures','errors','skipped']),counts
(base/'suite-summary.json').write_text(json.dumps(counts,indent=2)+'\n')
report=root/'android/app/build/reports/jacoco/profileCoverage/profileCoverage.xml'
assert report.stat().st_mtime >= (base/'final-sources.json').stat().st_mtime
inventory=json.loads(Path('/tmp/blent-t1061-evidence/inventory.json').read_text())
rows=collect({'functions':inventory},{},read(report,root/'android/app/src/main/java',root),[])
assert len(rows)==39 and all(row['passes'] for row in rows),rows
(base/'per-function.json').write_text(json.dumps({'passes':True,'functions':rows},indent=2)+'\n')
(base/'native-classes.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(Path('android/app/build/tmp/kotlin-classes/debug').rglob('*.class'))},indent=2)+'\n')
original=json.loads(Path('/tmp/blent-t1061-evidence/sources.json').read_text())
main=lambda mapping:{k:v for k,v in mapping.items() if k.startswith('android/app/src/main/')}
assert main(expected)==main(original),'Production changed since original audited function scope'
(base/'production-sources.json').write_text(json.dumps(main(expected),indent=2)+'\n')
output=Path('docs/reviews/artifacts/2026-10-19-t1011');output.mkdir(exist_ok=True)
for path in base.iterdir():
    if path.suffix not in ['.json','.log','.py']:continue
    with path.open('rb') as source,gzip.open(output/(path.name+'.gz'),'wb') as target:shutil.copyfileobj(source,target)
for name,path in [('profileCoverage.xml',report),('testDebugUnitTest.exec',Path('android/app/build/jacoco/testDebugUnitTest.exec'))]:
    with path.open('rb') as source,gzip.open(output/(name+'.gz'),'wb') as target:shutil.copyfileobj(source,target)
base=Path('/tmp/blent-t1078-evidence');(base/'suite-summary.json').write_text(json.dumps(counts,indent=2)+'\n')
output=Path('docs/reviews/artifacts/2026-10-19-t1078');output.mkdir(exist_ok=True)
for path in base.iterdir():
    with path.open('rb') as source,gzip.open(output/(path.name+'.gz'),'wb') as target:shutil.copyfileobj(source,target)
print(counts);print('39 current changed production methods each pass native counters',min(row['percent'] for row in rows))
