"""T1095 bounded metadata-only fault; keep every native ownership transition."""
from pathlib import Path
import os,sys
sys.path.insert(0,'scripts/tests')
import test_secure_connection_interop as interop
base=Path('/tmp/blent-t1095-evidence')
source=Path('android/app/src/main/java/com/blent/connection/LocalMediaResource.kt')
original=source.read_text()
(base/'media-before-fault.kt').write_text(original)
start=original.index('    override fun nextDeadline():')
head,body=original[:start],original[start:]
assert body.count('consumerPossible && !consumerGone')==1
try:
    source.write_text(head+body.replace('consumerPossible && !consumerGone','consumerPossible && consumerGone'))
    try:
        interop.SecureConnectionInteropTest().command([
            str(Path('android/gradlew').resolve()),'-p',str(Path('android').resolve()),
            '--offline','--no-daemon','--max-workers=2','-I',str(Path('scripts/coverage/android.init.gradle').resolve()),
            ':app:testDebugUnitTest','--tests','com.blent.connection.ConnectionLocalDeadlineTest',
            '--tests','com.blent.connection.ConnectionRuntimeDeadlineTest',
        ],dict(os.environ),base/'consumer-fault-red.log')
    except AssertionError:
        log=(base/'consumer-fault-red.log').read_text()
        assert '11 tests completed, 1 failed' in log,log[-3000:]
        assert 't1095ConsumerBudgetsSurviveNativeGroupRetirementForCameraAndSpeaker FAILED' in log
        print('Expected consumer-budget metadata fault rejected by permanent camera/speaker case')
    else:
        raise AssertionError('T1095 tests accepted a lost consumer retirement budget')
finally:
    source.write_text(original)
assert source.read_text()==original
print('Original source restored with fresh mtime; native behavior never modified')
