"""Deliberate old-cadence and long-wait faults; exact original restoration."""
from pathlib import Path
import os
import sys
sys.path.insert(0,str(Path.cwd()/'scripts/benchmarks'))
import profile_process as owned
ROOT=Path.cwd().resolve();BASE=Path('/tmp/blent-t1119-evidence')

def fault(path,old,new,test,label):
    source=ROOT/path;original=source.read_bytes()
    assert original.count(old.encode())==1,label
    (BASE/('correct-'+source.name)).write_bytes(original)
    try:
        source.write_bytes(original.replace(old.encode(),new.encode()))
        command=['cargo','test','--offline','--locked','-p','blent','--test','evdi_helper',test]
        status=owned.logged(command,dict(os.environ),BASE/(label+'.log'),ROOT)
        assert status!=0,label+' fault escaped permanent regression'
        print(label,'fault rejected',flush=True)
    finally:
        source.write_bytes(original)
        assert source.read_bytes()==original

fault('host/evdi/idle_control.c','(fields[4] != 500 && fields[4] != 1000)',
      'fields[4] != 500','t1119_one_second_request','fault-interval')
fault('host/evdi/writer.c','    if (due > recheck)\n        due = recheck;',
      '    (void)recheck;', 't1119_sparse_writer','fault-deadline')
