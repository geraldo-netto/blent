from pathlib import Path
import hashlib
import json
import re

BASE=Path('/tmp/blent-t1119-evidence')
ns={};exec(compile((BASE/'audit.py').read_text().split("for name in ['writer'")[0], 'source-count-definitions', 'exec'),ns)
rows=[]
for file,names in [('host/tests/idle_capture.c',['t492_invalid_control','t492_file_restrictions']),('host/tests/c_boundary_fuzz.c',['fuzz_text_fields']),('host/tests/evdi_helper_test.c',['main'])]:
    text=Path(file).read_text();clean=ns['clean'](text)
    for name in names:
        m=re.search(r'\b'+name+r'\([^)]*\)\s*\{',clean)
        assert m,(file,name)
        begin=clean.index('{',m.start());depth=1;end=begin+1
        while depth:
            depth+=(clean[end]=='{')-(clean[end]=='}');end+=1
        rows.append(dict(file=file,name=name,complexity=ns['count'](text[m.start():end])))
# Rust coverage remains test-only; audit every function in both changed test files.
ns={};exec(compile(Path('/tmp/blent-t1118-evidence/collect.py').read_text().split('\nBASE =')[0],'cached-rust-audit','exec'),ns)
import syntax
for file in ['host/tests/evdi_helper.rs','host/tests/evdi_modules.rs']:
    rows.extend(dict(file=file,name=name,line=line,complexity=score) for line,name,score in syntax.syntax_scores(Path(file).read_text(),'rust'))
rows.append(dict(file='packaging/arch/PKGBUILD',name='build',complexity=1,method='source inspection: five sequential commands; no branches/loops/short circuits'))
assert all(row['complexity']<=9 for row in rows)
(BASE/'extra-complexity.json').write_text(json.dumps(dict(tool='Cached Rust grammar/repository rules; explicit C lexical count and Bash approved standard source count; not native SonarQube (T1019)',functions=rows),indent=2)+'\n')
# Original byte-identical Bash source, actual DEBUG events. All five executable
# commands in changed build() are seeded independently, including uncovered ones.
file='packaging/arch/PKGBUILD';path=Path(file);digest=hashlib.sha256(path.read_bytes()).hexdigest();lines=[20,21,22,25,26];counts={line:0 for line in lines}
for trace in (BASE/'shell').glob('trace-*.bin'):
    fields=trace.read_bytes().split(b'\0');assert fields.pop()==b''
    assert len(fields)%3==0
    for index in range(0,len(fields),3):
        checksum,name,line=fields[index:index+3]
        if checksum.decode()==digest and int(line) in counts:counts[int(line)]+=1
report=dict(file=file,name='build',tool='GNU Bash 5.2.21 DEBUG source line events, repository trace.sh',source_sha256=digest,executable_commands=lines,counts=counts,percent=100*sum(n>0 for n in counts.values())/len(lines))
assert report['percent']>=80
(BASE/'bash-per-function.json').write_text(json.dumps(report,indent=2)+'\n')
print('extra functions',len(rows),'max',max(row['complexity'] for row in rows),'Bash build',report['percent'])
