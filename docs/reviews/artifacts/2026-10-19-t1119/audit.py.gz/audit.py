"""Offline source estimates, never native SonarQube evidence (T1019)."""
import ast
import json
from pathlib import Path
import re
import subprocess

ROOT=Path.cwd().resolve()
BASE=Path('/tmp/blent-t1119-evidence')
rows=[]

def clean(text):
    pattern=r'/\*[\s\S]*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\''
    return re.sub(pattern, lambda match:' '*len(match[0]), text)

def count(text):
    return 1+len(re.findall(r'\b(?:if|for|while|case|default)\b|&&|\|\||\?',clean(text)))

for name in ['writer','idle_control']:
    path=Path('host/evdi')/(name+'.c');text=path.read_text()
    tree=json.loads(subprocess.check_output(['clang-18','-std=c11','-Ihost/evdi','-Xclang','-ast-dump=json','-fsyntax-only',str(path)]))
    for node in tree['inner']:
        if node['kind']!='FunctionDecl' or 'includedFrom' in node.get('loc',{}):
            continue
        if not any(child['kind']=='CompoundStmt' for child in node.get('inner',[])):
            continue
        start=node['range']['begin']['offset'];end=node['range']['end']['offset']+1
        rows.append(dict(file=str(path),name=node['name'],complexity=count(text[start:end])))
# New test functions have Allman definitions and no nested braces in their signature.
path=Path('host/tests/idle_recheck.c');text=path.read_text()
starts=list(re.finditer(r'^static (?:void|int) (\w+)\([^\n]*\)\n\{',text,re.M))
for index,match in enumerate(starts):
    end=starts[index+1].start() if index+1<len(starts) else len(text)
    rows.append(dict(file=str(path),name=match[1],complexity=count(text[match.start():end])))
for name in ['scripts/benchmarks/idle-writer.py','scripts/tests/test_idle_writer_native.py']:
    source=Path(name).read_text();module=ast.parse(source)
    for node in ast.walk(module):
        if not isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
            continue
        score=1
        for child in ast.walk(node):
            if isinstance(child,(ast.If,ast.For,ast.While,ast.IfExp,ast.AsyncFor)):score+=1
            if isinstance(child,ast.BoolOp):score+=len(child.values)-1
            if isinstance(child,ast.comprehension):score+=len(child.ifs)
        rows.append(dict(file=name,name=node.name,complexity=score))
report=dict(tool='Clang 18.1.3 definition inventory + explicit source C branch count; Python 3 ast',
            native_sonarqube=False,missing='T1019',functions=rows)
(BASE/'complexity.json').write_text(json.dumps(report,indent=2)+'\n')
print('functions',len(rows),'max',max(row['complexity'] for row in rows))
assert rows and all(row['complexity']<=9 for row in rows)
