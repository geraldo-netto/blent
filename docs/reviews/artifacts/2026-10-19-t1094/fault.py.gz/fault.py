"""T1094 bounded MAX-as-idle fault; restore after the original child joins."""
from pathlib import Path
import os, sys
sys.path.insert(0, 'scripts/tests')
import test_secure_connection_interop as interop
base=Path('/tmp/blent-t1094-evidence')
setup=Path('android/app/src/main/java/com/blent/connection/ConnectionSetupOwner.kt')
admission=Path('android/app/src/main/java/com/blent/connection/AccessoryAdmissionOwner.kt')
originals={path:path.read_text() for path in [setup,admission]}
for path,body in originals.items(): (base/(path.stem+'-before-fault.kt')).write_text(body)
try:
    for path,body in originals.items():
        value='deadline' if path==setup else 'minOf(deadline, nativeDeadline)'
        old='!stopped -> ConnectionDeadline.at('+value+')'
        assert body.count(old)==1
        new='!stopped -> if ('+value+' == Long.MAX_VALUE) ConnectionDeadline.IDLE else ConnectionDeadline.at('+value+')'
        path.write_text(body.replace(old,new))
    try:
        interop.SecureConnectionInteropTest().command([
            str(Path('android/gradlew').resolve()),'-p',str(Path('android').resolve()),
            '--offline','--no-daemon','--max-workers=2','-I',str(Path('scripts/coverage/android.init.gradle').resolve()),
            ':app:testDebugUnitTest','--tests','com.blent.connection.ConnectionSetupDeadlineTest',
            '--tests','com.blent.connection.AccessoryAdmissionDeadlineTest',
        ],dict(os.environ),base/'maximum-fault-red.log')
    except AssertionError:
        log=(base/'maximum-fault-red.log').read_text()
        assert '11 tests completed, 4 failed' in log,log[-3000:]
        assert 't1094ActualMaximumSetupBudgetIsNeverMisreportedAsIdle FAILED' in log
        assert 't1094MaximumHumanPermissionDeadlineIsNeverAnIdleSentinel FAILED' in log
        print('Expected faulty MAX-as-idle control rejected by four permanent cases')
    else:
        raise AssertionError('T1094 tests accepted MAX-as-idle fault')
finally:
    for path,body in originals.items(): path.write_text(body)
assert all(path.read_text()==body for path,body in originals.items())
print('Both original sources restored with fresh mtimes')
