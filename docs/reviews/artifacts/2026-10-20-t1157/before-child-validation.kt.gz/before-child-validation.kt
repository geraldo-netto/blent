package com.blent.connection

import java.io.File
import java.io.RandomAccessFile
import java.nio.channels.FileLock
import java.nio.file.Files
import java.nio.file.LinkOption.NOFOLLOW_LINKS
import java.nio.file.attribute.BasicFileAttributes

/** One original identity-lock file in a stable application-private directory.
 * All in-process opens of that lock must use this adapter. Unknown native close
 * keeps its bounded slot until original process exit; logical close is no proof.
 * The injected opener owns failed acquisition and must not abandon an unreturned
 * descriptor. The production opener is the stock RandomAccessFile constructor. */
internal class IdentityFileLock private constructor(
    private val file: RandomAccessFile,
    private val lock: FileLock,
    private val ownership: TrustDirectoryOwnership.Lease,
) : AutoCloseable {
    private var closed = false

    companion object {
        private val directories = TrustDirectoryOwnership()
        fun open(
            directory: File,
            owners: TrustDirectoryOwnership = directories,
            openFile: (File) -> RandomAccessFile = { RandomAccessFile(it, "rw") },
        ): IdentityFileLock {
            val attributes = Files.readAttributes(directory.toPath(), BasicFileAttributes::class.java, NOFOLLOW_LINKS)
            require(attributes.isDirectory)
            val ownership = owners.reserve(checkNotNull(attributes.fileKey()) { "Stable identity directory unavailable" })
            val file = try { openFile(File(directory, "accessory-identity.lock")) }
            catch (failure: Exception) { ownership.close(); throw failure }
            return try {
                val lock = checkNotNull(file.channel.tryLock()) { "Client identity is owned by another worker" }
                IdentityFileLock(file, lock, ownership)
            } catch (failure: Exception) { abandon(file, ownership, failure) }
        }

        private fun abandon(file: RandomAccessFile, ownership: TrustDirectoryOwnership.Lease, failure: Exception): Nothing {
            try { file.close() }
            catch (cleanup: Exception) { failure.addSuppressed(cleanup); throw failure }
            ownership.close()
            throw failure
        }
    }

    @Synchronized override fun close() {
        if (closed) return
        closed = true
        try { lock.release() }
        finally {
            file.close() // Actual original file/channel close also fences a failed lock release.
            ownership.close()
        }
    }
}
