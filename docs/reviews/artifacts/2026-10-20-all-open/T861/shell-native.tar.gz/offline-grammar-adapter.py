# Offline grammar adapter: local ABI14 exports, unchanged repository collectors.
import ctypes
import sys
import types
sys.path.insert(0, '/home/netto/.cache/uv/archive-v0/nOds33o--6Q7Ze_u')
from tree_sitter import Language
_native = ctypes.CDLL('/home/netto/.cache/uv/archive-v0/idiMltAos9Z6_cbD/tree_sitter_languages/languages.so')
_capsule = ctypes.pythonapi.PyCapsule_New
_capsule.restype = ctypes.py_object
_capsule.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_void_p]
for _module, _export in [('tree_sitter_bash','tree_sitter_bash'),('tree_sitter_c','tree_sitter_c'),('tree_sitter_rust','tree_sitter_rust')]:
    _function = getattr(_native, _export); _function.restype = ctypes.c_void_p
    _pointer = _function()
    sys.modules[_module] = types.SimpleNamespace(language=lambda pointer=_pointer: _capsule(pointer,b'tree_sitter.Language',None))
