"""Offline native GCC counters; complete Clang 18 definition inventory, no gcov-only omissions."""
from dataclasses import asdict
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys

ROOT = Path.cwd().resolve()
BASE = Path('/tmp/blent-t1121-evidence')
sys.path.insert(0, str(ROOT/'scripts/coverage'))
sys.path.insert(0, str(ROOT/'scripts/benchmarks'))
from compiler import export_reports
from model import Function, fingerprint, result, verify_sources
from readers import gcov_json
import profile_process as owned

FILES = ['host/evdi/idle_control.c']

def definitions(path):
    command = ['clang-18', '-std=c11', '-Ihost/evdi', '-Xclang', '-ast-dump=json',
               '-fsyntax-only', str(path)]
    tree = json.loads(owned.output(command))
    source = path.read_text()
    for node in tree['inner']:
        bodies = [child for child in node.get('inner', []) if child['kind'] == 'CompoundStmt']
        if node['kind'] != 'FunctionDecl' or not bodies or 'includedFrom' in node['loc']:
            continue
        first = source.count('\n', 0, node['range']['begin']['offset']) + 1
        last = source.count('\n', 0, node['range']['end']['offset']) + 1
        body = source.count('\n', 0, bodies[0]['range']['begin']['offset']) + 1
        yield Function(str(path), node['name'], first, last, 'c', body=body)

out = BASE/'native-final'
out.mkdir()
functions = [function for file in FILES for function in definitions(Path(file))]
# Attest every native source/header, fixture, caller and compiler-wrapper input.
paths = list((ROOT/'host/evdi').glob('*.[ch]')) + list((ROOT/'host/tests').glob('*.[ch]'))
paths += [ROOT/'host/tests/evdi_helper.rs', ROOT/'host/tests/evdi_modules.rs',
          ROOT/'scripts/coverage/compiler.py', ROOT/'scripts/coverage/readers.py',
          ROOT/'scripts/coverage/model.py']
sources = {str(path.relative_to(ROOT)): fingerprint(path) for path in paths}
manifest = dict(tool='Clang 18.1.3 definition inventory; GCC/gcov 13.3.0 native counters',
                sources=sources, functions=[asdict(function) for function in functions])
(out/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
wrappers=out/'tools';wrappers.mkdir()
compiler=shutil.which('cc')
wrapper=wrappers/'cc'
wrapper.write_text('#!/bin/sh\nexec '+shlex.join([sys.executable,str(ROOT/'scripts/coverage/compiler.py')])+' "$@"\n')
wrapper.chmod(0o700)
env=dict(os.environ,BLENT_C_COVERAGE=str(out/'raw'),BLENT_REAL_CC=compiler,
         PATH=str(wrappers)+os.pathsep+os.environ['PATH'])
command=['cargo','test','--offline','--locked','-p','blent','--test','evdi_helper',
         '--test','evdi_modules','--test','frame_retirement','--','--test-threads=4']
status=owned.logged(command,env,out/'tests.log',ROOT)
verify_sources(ROOT,sources)
assert status==0, f'normal native suite failed: {out / "tests.log"}'
data={}
for report in export_reports(out/'raw'):
    gcov_json(report,ROOT,data)
rows=[result(function,data) for function in functions]
(out/'per-function.json').write_text(json.dumps(dict(passes=all(row['passes'] for row in rows),functions=rows),indent=2)+'\n')
for row in rows:
    print(row['name'],row['percent'],row['missing'],flush=True)
assert rows and all(row['passes'] for row in rows), 'missing/low individual native counters'
