from pathlib import Path
import os
import sys
sys.path.insert(0,str(Path.cwd()/'scripts/benchmarks'))
import profile_process as owned
root=Path.cwd();base=Path('/tmp/blent-t1121-evidence');source=root/'host/evdi/idle_control.c';original=source.read_bytes()
old=b'idle_fields(text, fields) != text + count';assert original.count(old)==1
(base/'correct-idle_control.c').write_bytes(original)
try:
    source.write_bytes(original.replace(old,b'!idle_fields(text, fields)'))
    status=owned.logged(['cargo','test','--offline','--locked','-p','blent','--test','evdi_helper','t1121'],dict(os.environ),base/'fault.log',root)
    assert status!=0,'T1121 consumption-length fault escaped permanent regression'
    print('T1121 length fault rejected',flush=True)
finally:
    source.write_bytes(original)
    assert source.read_bytes()==original
