"""Offline source estimates only; native SonarQube remains T1019."""
import json
from pathlib import Path
import re
import subprocess

BASE=Path('/tmp/blent-t1121-evidence')

def clean(text):
    pattern=r'/\*[\s\S]*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\''
    return re.sub(pattern,lambda match:' '*len(match[0]),text)

def score(text):
    return 1+len(re.findall(r'\b(?:if|for|while|case|default)\b|&&|\|\||\?',clean(text)))

rows=[]
path=Path('host/evdi/idle_control.c');text=path.read_text()
tree=json.loads(subprocess.check_output(['clang-18','-std=c11','-Ihost/evdi','-Xclang','-ast-dump=json','-fsyntax-only',str(path)]))
for node in tree['inner']:
    if node['kind']!='FunctionDecl' or 'includedFrom' in node.get('loc',{}):continue
    if not any(child['kind']=='CompoundStmt' for child in node.get('inner',[])):continue
    start=node['range']['begin']['offset'];end=node['range']['end']['offset']+1
    rows.append(dict(file=str(path),name=node['name'],complexity=score(text[start:end])))
for file,names in [('host/tests/idle_record.c',['t1121_write','t1121_hidden_suffix','t1121_prefix_mutations','test_t1121_exact_record']),('host/tests/evdi_helper_test.c',['main'])]:
    text=Path(file).read_text();source=clean(text)
    for name in names:
        match=re.search(r'\b'+name+r'\([^)]*\)\s*\{',source);assert match,name
        start=source.index('{',match.start());depth=1;end=start+1
        while depth:
            depth+=(source[end]=='{')-(source[end]=='}');end+=1
        rows.append(dict(file=file,name=name,complexity=score(text[match.start():end])))
ns={};exec(compile(Path('/tmp/blent-t1118-evidence/collect.py').read_text().split('\nBASE =')[0],'cached-rust-audit','exec'),ns)
import syntax
file='host/tests/evdi_helper.rs'
rows.extend(dict(file=file,name=name,line=line,complexity=value) for line,name,value in syntax.syntax_scores(Path(file).read_text(),'rust'))
assert all(row['complexity']<=9 for row in rows)
(BASE/'complexity.json').write_text(json.dumps(dict(native_sonarqube=False,missing='T1019',tool='Clang 18.1.3 inventory, explicit C source branch count; tree-sitter-rust 0.24.2/tree-sitter 0.25.2 repository rules',functions=rows),indent=2)+'\n')
print(len(rows),'functions; max',max(row['complexity'] for row in rows))
