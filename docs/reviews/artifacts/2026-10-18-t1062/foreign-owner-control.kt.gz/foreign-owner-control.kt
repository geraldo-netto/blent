package com.blent

/** One latest desired policy and one original queued notice. Native transport
 * receipt only settles notice admission, never lock/decoder ownership. */
internal class DisplayPowerRequests {
    class Owner internal constructor()
    class Request internal constructor(val owner: Owner, val power: StreamingPower?)
    class Notice internal constructor(val original: Request)
    class Admission internal constructor(val owner: Owner, val notice: Notice?)
    class Delivery internal constructor(val accepted: Boolean, val request: Request?, val next: Notice?)

    private var latest: Request? = null
    private var queued: Notice? = null
    private var dirty = false

    @Synchronized fun open(power: StreamingPower): Admission {
        val owner = Owner()
        latest = Request(owner, power)
        dirty = true
        return Admission(owner, admit())
    }

    @Synchronized fun publish(owner: Owner, power: StreamingPower): Notice? {
        if (!owns(owner)) return null
        latest = Request(owner, power)
        dirty = true
        return admit()
    }

    @Synchronized fun close(owner: Owner): Notice? {
        if (!owns(owner)) return null
        latest = Request(owner, null)
        dirty = true
        return admit()
    }

    @Synchronized fun owns(owner: Owner): Boolean = latest?.let { it.owner === owner && it.power != null } == true
    @Synchronized fun current(request: Request): Boolean = latest === request

    @Synchronized fun receive(notice: Notice): Delivery {
        if (queued !== notice) return Delivery(false, null, null)
        queued = null
        val request = take(notice.original.owner)
        return Delivery(true, request, admit())
    }

    private fun take(owner: Owner): Request? {
        // Deliberately faulty T1062 control: applies a replacement owner's view.
        val request = latest ?: return null
        dirty = false
        return request
    }

    private fun admit(): Notice? {
        if (queued != null || !dirty) return null
        val request = latest ?: return null
        return Notice(request).also { queued = it }
    }
}
