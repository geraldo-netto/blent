
/tmp/blent-adaptive-20261009/t778-after:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

0000000000006e40 <convert_job>:
    6e40:	f3 0f 1e fa          	endbr64
    6e44:	41 57                	push   %r15
    6e46:	41 56                	push   %r14
    6e48:	41 55                	push   %r13
    6e4a:	41 54                	push   %r12
    6e4c:	55                   	push   %rbp
    6e4d:	53                   	push   %rbx
    6e4e:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    6e55:	8b 5f 30             	mov    0x30(%rdi),%ebx
    6e58:	44 8b 7f 2c          	mov    0x2c(%rdi),%r15d
    6e5c:	48 89 7c 24 b8       	mov    %rdi,-0x48(%rsp)
    6e61:	8b 57 34             	mov    0x34(%rdi),%edx
    6e64:	89 5c 24 88          	mov    %ebx,-0x78(%rsp)
    6e68:	41 83 ff 03          	cmp    $0x3,%r15d
    6e6c:	0f 84 45 0e 00 00    	je     7cb7 <convert_job+0xe77>
    6e72:	0f 8f f8 03 00 00    	jg     7270 <convert_job+0x430>
    6e78:	41 83 ff 01          	cmp    $0x1,%r15d
    6e7c:	0f 84 6d 10 00 00    	je     7eef <convert_job+0x10af>
    6e82:	41 89 da             	mov    %ebx,%r10d
    6e85:	41 83 ff 02          	cmp    $0x2,%r15d
    6e89:	0f 85 bd 06 00 00    	jne    754c <convert_job+0x70c>
    6e8f:	41 89 df             	mov    %ebx,%r15d
    6e92:	39 d3                	cmp    %edx,%ebx
    6e94:	0f 8d c4 03 00 00    	jge    725e <convert_job+0x41e>
    6e9a:	4c 63 eb             	movslq %ebx,%r13
    6e9d:	49 89 f8             	mov    %rdi,%r8
    6ea0:	44 8d 24 9d 00 00 00 	lea    0x0(,%rbx,4),%r12d
    6ea7:	00 
    6ea8:	4c 89 6c 24 b0       	mov    %r13,-0x50(%rsp)
    6ead:	49 8b 48 38          	mov    0x38(%r8),%rcx
    6eb1:	48 85 c9             	test   %rcx,%rcx
    6eb4:	74 1b                	je     6ed1 <convert_job+0x91>
    6eb6:	44 89 f8             	mov    %r15d,%eax
    6eb9:	c1 f8 03             	sar    $0x3,%eax
    6ebc:	48 98                	cltq
    6ebe:	0f b6 0c 01          	movzbl (%rcx,%rax,1),%ecx
    6ec2:	44 89 f8             	mov    %r15d,%eax
    6ec5:	83 e0 07             	and    $0x7,%eax
    6ec8:	0f a3 c1             	bt     %eax,%ecx
    6ecb:	0f 83 76 03 00 00    	jae    7247 <convert_job+0x407>
    6ed1:	49 8b 40 40          	mov    0x40(%r8),%rax
    6ed5:	4d 63 70 24          	movslq 0x24(%r8),%r14
    6ed9:	48 85 c0             	test   %rax,%rax
    6edc:	0f 84 23 2c 00 00    	je     9b05 <convert_job+0x2cc5>
    6ee2:	48 8b 4c 24 b0       	mov    -0x50(%rsp),%rcx
    6ee7:	48 c1 e1 04          	shl    $0x4,%rcx
    6eeb:	48 01 c8             	add    %rcx,%rax
    6eee:	44 8b 08             	mov    (%rax),%r9d
    6ef1:	8b 40 04             	mov    0x4(%rax),%eax
    6ef4:	89 44 24 98          	mov    %eax,-0x68(%rsp)
    6ef8:	48 8b 5c 24 b0       	mov    -0x50(%rsp),%rbx
    6efd:	47 8d 1c 3f          	lea    (%r15,%r15,1),%r11d
    6f01:	49 63 70 20          	movslq 0x20(%r8),%rsi
    6f05:	4d 63 db             	movslq %r11d,%r11
    6f08:	49 8b 68 10          	mov    0x10(%r8),%rbp
    6f0c:	4d 0f af de          	imul   %r14,%r11
    6f10:	4d 03 58 08          	add    0x8(%r8),%r11
    6f14:	49 0f af de          	imul   %r14,%rbx
    6f18:	44 39 4c 24 98       	cmp    %r9d,-0x68(%rsp)
    6f1d:	0f 8e 24 03 00 00    	jle    7247 <convert_job+0x407>
    6f23:	41 8d 7c 24 01       	lea    0x1(%r12),%edi
    6f28:	41 8d 4c 24 02       	lea    0x2(%r12),%ecx
    6f2d:	49 63 c4             	movslq %r12d,%rax
    6f30:	4d 01 de             	add    %r11,%r14
    6f33:	48 63 ff             	movslq %edi,%rdi
    6f36:	48 63 c9             	movslq %ecx,%rcx
    6f39:	41 8d 54 24 03       	lea    0x3(%r12),%edx
    6f3e:	4c 89 74 24 a8       	mov    %r14,-0x58(%rsp)
    6f43:	48 0f af c6          	imul   %rsi,%rax
    6f47:	48 63 d2             	movslq %edx,%rdx
    6f4a:	44 89 7c 24 d8       	mov    %r15d,-0x28(%rsp)
    6f4f:	4c 8d 6c 1d 00       	lea    0x0(%rbp,%rbx,1),%r13
    6f54:	48 0f af fe          	imul   %rsi,%rdi
    6f58:	44 89 64 24 b8       	mov    %r12d,-0x48(%rsp)
    6f5d:	48 0f af ce          	imul   %rsi,%rcx
    6f61:	48 0f af d6          	imul   %rsi,%rdx
    6f65:	49 63 f1             	movslq %r9d,%rsi
    6f68:	45 01 c9             	add    %r9d,%r9d
    6f6b:	48 29 c7             	sub    %rax,%rdi
    6f6e:	4d 63 c9             	movslq %r9d,%r9
    6f71:	48 29 c1             	sub    %rax,%rcx
    6f74:	48 89 7c 24 90       	mov    %rdi,-0x70(%rsp)
    6f79:	49 c1 e1 02          	shl    $0x2,%r9
    6f7d:	48 89 4c 24 88       	mov    %rcx,-0x78(%rsp)
    6f82:	48 29 c2             	sub    %rax,%rdx
    6f85:	4e 8d 14 08          	lea    (%rax,%r9,1),%r10
    6f89:	4e 8d 4c 08 08       	lea    0x8(%rax,%r9,1),%r9
    6f8e:	49 89 d4             	mov    %rdx,%r12
    6f91:	49 8b 10             	mov    (%r8),%rdx
    6f94:	4a 8d 04 12          	lea    (%rdx,%r10,1),%rax
    6f98:	0f b6 48 04          	movzbl 0x4(%rax),%ecx
    6f9c:	0f b6 18             	movzbl (%rax),%ebx
    6f9f:	0f b6 78 05          	movzbl 0x5(%rax),%edi
    6fa3:	01 cb                	add    %ecx,%ebx
    6fa5:	0f b6 48 01          	movzbl 0x1(%rax),%ecx
    6fa9:	01 f9                	add    %edi,%ecx
    6fab:	0f b6 78 02          	movzbl 0x2(%rax),%edi
    6faf:	0f b6 40 06          	movzbl 0x6(%rax),%eax
    6fb3:	01 f8                	add    %edi,%eax
    6fb5:	48 8b 7c 24 90       	mov    -0x70(%rsp),%rdi
    6fba:	4c 01 d7             	add    %r10,%rdi
    6fbd:	48 01 fa             	add    %rdi,%rdx
    6fc0:	0f b6 3a             	movzbl (%rdx),%edi
    6fc3:	01 df                	add    %ebx,%edi
    6fc5:	0f b6 5a 01          	movzbl 0x1(%rdx),%ebx
    6fc9:	01 cb                	add    %ecx,%ebx
    6fcb:	0f b6 4a 02          	movzbl 0x2(%rdx),%ecx
    6fcf:	01 c1                	add    %eax,%ecx
    6fd1:	0f b6 42 04          	movzbl 0x4(%rdx),%eax
    6fd5:	01 c7                	add    %eax,%edi
    6fd7:	0f b6 42 05          	movzbl 0x5(%rdx),%eax
    6fdb:	c1 ff 02             	sar    $0x2,%edi
    6fde:	01 d8                	add    %ebx,%eax
    6fe0:	89 c5                	mov    %eax,%ebp
    6fe2:	0f b6 42 06          	movzbl 0x6(%rdx),%eax
    6fe6:	c1 fd 02             	sar    $0x2,%ebp
    6fe9:	01 c1                	add    %eax,%ecx
    6feb:	69 c5 9d 00 00 00    	imul   $0x9d,%ebp,%eax
    6ff1:	c1 f9 02             	sar    $0x2,%ecx
    6ff4:	6b d1 2f             	imul   $0x2f,%ecx,%edx
    6ff7:	01 d0                	add    %edx,%eax
    6ff9:	89 fa                	mov    %edi,%edx
    6ffb:	c1 e2 04             	shl    $0x4,%edx
    6ffe:	8d 84 10 80 00 00 00 	lea    0x80(%rax,%rdx,1),%eax
    7005:	c1 f8 08             	sar    $0x8,%eax
    7008:	83 c0 10             	add    $0x10,%eax
    700b:	41 88 04 33          	mov    %al,(%r11,%rsi,1)
    700f:	4d 8b 30             	mov    (%r8),%r14
    7012:	4b 8d 04 0e          	lea    (%r14,%r9,1),%rax
    7016:	0f b6 50 04          	movzbl 0x4(%rax),%edx
    701a:	44 0f b6 38          	movzbl (%rax),%r15d
    701e:	0f b6 58 05          	movzbl 0x5(%rax),%ebx
    7022:	41 01 d7             	add    %edx,%r15d
    7025:	0f b6 50 01          	movzbl 0x1(%rax),%edx
    7029:	01 da                	add    %ebx,%edx
    702b:	0f b6 58 02          	movzbl 0x2(%rax),%ebx
    702f:	0f b6 40 06          	movzbl 0x6(%rax),%eax
    7033:	01 c3                	add    %eax,%ebx
    7035:	48 8b 44 24 90       	mov    -0x70(%rsp),%rax
    703a:	4c 01 c8             	add    %r9,%rax
    703d:	4c 01 f0             	add    %r14,%rax
    7040:	44 0f b6 30          	movzbl (%rax),%r14d
    7044:	45 01 fe             	add    %r15d,%r14d
    7047:	44 0f b6 78 01       	movzbl 0x1(%rax),%r15d
    704c:	41 01 d7             	add    %edx,%r15d
    704f:	0f b6 50 02          	movzbl 0x2(%rax),%edx
    7053:	01 da                	add    %ebx,%edx
    7055:	0f b6 58 04          	movzbl 0x4(%rax),%ebx
    7059:	41 01 de             	add    %ebx,%r14d
    705c:	0f b6 58 05          	movzbl 0x5(%rax),%ebx
    7060:	0f b6 40 06          	movzbl 0x6(%rax),%eax
    7064:	41 c1 fe 02          	sar    $0x2,%r14d
    7068:	44 01 fb             	add    %r15d,%ebx
    706b:	c1 fb 02             	sar    $0x2,%ebx
    706e:	01 c2                	add    %eax,%edx
    7070:	44 01 f7             	add    %r14d,%edi
    7073:	c1 fa 02             	sar    $0x2,%edx
    7076:	69 c3 9d 00 00 00    	imul   $0x9d,%ebx,%eax
    707c:	44 6b fa 2f          	imul   $0x2f,%edx,%r15d
    7080:	01 d1                	add    %edx,%ecx
    7082:	44 01 f8             	add    %r15d,%eax
    7085:	45 89 f7             	mov    %r14d,%r15d
    7088:	41 c1 e7 04          	shl    $0x4,%r15d
    708c:	42 8d 84 38 80 00 00 	lea    0x80(%rax,%r15,1),%eax
    7093:	00 
    7094:	c1 f8 08             	sar    $0x8,%eax
    7097:	83 c0 10             	add    $0x10,%eax
    709a:	41 88 44 33 01       	mov    %al,0x1(%r11,%rsi,1)
    709f:	8d 44 1d 00          	lea    0x0(%rbp,%rbx,1),%eax
    70a3:	48 8b 5c 24 88       	mov    -0x78(%rsp),%rbx
    70a8:	49 8b 28             	mov    (%r8),%rbp
    70ab:	4a 8d 14 13          	lea    (%rbx,%r10,1),%rdx
    70af:	48 01 ea             	add    %rbp,%rdx
    70b2:	44 0f b6 3a          	movzbl (%rdx),%r15d
    70b6:	0f b6 5a 04          	movzbl 0x4(%rdx),%ebx
    70ba:	44 0f b6 72 01       	movzbl 0x1(%rdx),%r14d
    70bf:	41 01 df             	add    %ebx,%r15d
    70c2:	0f b6 5a 05          	movzbl 0x5(%rdx),%ebx
    70c6:	41 01 de             	add    %ebx,%r14d
    70c9:	0f b6 5a 02          	movzbl 0x2(%rdx),%ebx
    70cd:	0f b6 52 06          	movzbl 0x6(%rdx),%edx
    70d1:	01 d3                	add    %edx,%ebx
    70d3:	4b 8d 14 14          	lea    (%r12,%r10,1),%rdx
    70d7:	48 01 ea             	add    %rbp,%rdx
    70da:	0f b6 2a             	movzbl (%rdx),%ebp
    70dd:	44 01 fd             	add    %r15d,%ebp
    70e0:	44 0f b6 7a 01       	movzbl 0x1(%rdx),%r15d
    70e5:	45 01 f7             	add    %r14d,%r15d
    70e8:	44 0f b6 72 02       	movzbl 0x2(%rdx),%r14d
    70ed:	41 01 de             	add    %ebx,%r14d
    70f0:	0f b6 5a 04          	movzbl 0x4(%rdx),%ebx
    70f4:	01 dd                	add    %ebx,%ebp
    70f6:	0f b6 5a 05          	movzbl 0x5(%rdx),%ebx
    70fa:	0f b6 52 06          	movzbl 0x6(%rdx),%edx
    70fe:	c1 fd 02             	sar    $0x2,%ebp
    7101:	44 01 fb             	add    %r15d,%ebx
    7104:	44 01 f2             	add    %r14d,%edx
    7107:	01 ef                	add    %ebp,%edi
    7109:	c1 fb 02             	sar    $0x2,%ebx
    710c:	c1 fa 02             	sar    $0x2,%edx
    710f:	44 6b fa 2f          	imul   $0x2f,%edx,%r15d
    7113:	01 d8                	add    %ebx,%eax
    7115:	44 69 f3 9d 00 00 00 	imul   $0x9d,%ebx,%r14d
    711c:	48 8b 5c 24 88       	mov    -0x78(%rsp),%rbx
    7121:	45 01 fe             	add    %r15d,%r14d
    7124:	41 89 ef             	mov    %ebp,%r15d
    7127:	41 c1 e7 04          	shl    $0x4,%r15d
    712b:	47 8d b4 3e 80 00 00 	lea    0x80(%r14,%r15,1),%r14d
    7132:	00 
    7133:	4c 8b 7c 24 a8       	mov    -0x58(%rsp),%r15
    7138:	41 c1 fe 08          	sar    $0x8,%r14d
    713c:	41 83 c6 10          	add    $0x10,%r14d
    7140:	01 d1                	add    %edx,%ecx
    7142:	4a 8d 14 0b          	lea    (%rbx,%r9,1),%rdx
    7146:	45 88 34 37          	mov    %r14b,(%r15,%rsi,1)
    714a:	49 8b 28             	mov    (%r8),%rbp
    714d:	48 01 ea             	add    %rbp,%rdx
    7150:	0f b6 5a 04          	movzbl 0x4(%rdx),%ebx
    7154:	44 0f b6 3a          	movzbl (%rdx),%r15d
    7158:	44 0f b6 72 01       	movzbl 0x1(%rdx),%r14d
    715d:	41 01 df             	add    %ebx,%r15d
    7160:	0f b6 5a 05          	movzbl 0x5(%rdx),%ebx
    7164:	41 01 de             	add    %ebx,%r14d
    7167:	0f b6 5a 02          	movzbl 0x2(%rdx),%ebx
    716b:	0f b6 52 06          	movzbl 0x6(%rdx),%edx
    716f:	01 d3                	add    %edx,%ebx
    7171:	4b 8d 14 0c          	lea    (%r12,%r9,1),%rdx
    7175:	48 01 ea             	add    %rbp,%rdx
    7178:	0f b6 2a             	movzbl (%rdx),%ebp
    717b:	44 01 fd             	add    %r15d,%ebp
    717e:	44 0f b6 7a 01       	movzbl 0x1(%rdx),%r15d
    7183:	45 01 f7             	add    %r14d,%r15d
    7186:	44 0f b6 72 02       	movzbl 0x2(%rdx),%r14d
    718b:	41 01 de             	add    %ebx,%r14d
    718e:	0f b6 5a 04          	movzbl 0x4(%rdx),%ebx
    7192:	01 dd                	add    %ebx,%ebp
    7194:	0f b6 5a 05          	movzbl 0x5(%rdx),%ebx
    7198:	0f b6 52 06          	movzbl 0x6(%rdx),%edx
    719c:	c1 fd 02             	sar    $0x2,%ebp
    719f:	44 01 fb             	add    %r15d,%ebx
    71a2:	44 01 f2             	add    %r14d,%edx
    71a5:	01 ef                	add    %ebp,%edi
    71a7:	c1 fb 02             	sar    $0x2,%ebx
    71aa:	c1 fa 02             	sar    $0x2,%edx
    71ad:	44 6b fa 2f          	imul   $0x2f,%edx,%r15d
    71b1:	01 d8                	add    %ebx,%eax
    71b3:	01 ca                	add    %ecx,%edx
    71b5:	c1 ff 02             	sar    $0x2,%edi
    71b8:	c1 f8 02             	sar    $0x2,%eax
    71bb:	c1 fa 02             	sar    $0x2,%edx
    71be:	44 69 f3 9d 00 00 00 	imul   $0x9d,%ebx,%r14d
    71c5:	6b c8 aa             	imul   $0xffffffaa,%eax,%ecx
    71c8:	6b da e6             	imul   $0xffffffe6,%edx,%ebx
    71cb:	45 01 fe             	add    %r15d,%r14d
    71ce:	41 89 ef             	mov    %ebp,%r15d
    71d1:	41 c1 e7 04          	shl    $0x4,%r15d
    71d5:	01 d9                	add    %ebx,%ecx
    71d7:	6b df 70             	imul   $0x70,%edi,%ebx
    71da:	47 8d b4 3e 80 00 00 	lea    0x80(%r14,%r15,1),%r14d
    71e1:	00 
    71e2:	4c 8b 7c 24 a8       	mov    -0x58(%rsp),%r15
    71e7:	41 c1 fe 08          	sar    $0x8,%r14d
    71eb:	41 83 c6 10          	add    $0x10,%r14d
    71ef:	8d 8c 19 80 00 00 00 	lea    0x80(%rcx,%rbx,1),%ecx
    71f6:	45 88 74 37 01       	mov    %r14b,0x1(%r15,%rsi,1)
    71fb:	c1 f9 08             	sar    $0x8,%ecx
    71fe:	83 e9 80             	sub    $0xffffff80,%ecx
    7201:	6b d2 70             	imul   $0x70,%edx,%edx
    7204:	49 83 c2 10          	add    $0x10,%r10
    7208:	49 83 c1 10          	add    $0x10,%r9
    720c:	6b c0 9a             	imul   $0xffffff9a,%eax,%eax
    720f:	41 88 4c 35 00       	mov    %cl,0x0(%r13,%rsi,1)
    7214:	6b ff f6             	imul   $0xfffffff6,%edi,%edi
    7217:	01 d0                	add    %edx,%eax
    7219:	8d 84 38 80 00 00 00 	lea    0x80(%rax,%rdi,1),%eax
    7220:	c1 f8 08             	sar    $0x8,%eax
    7223:	83 e8 80             	sub    $0xffffff80,%eax
    7226:	41 88 44 35 01       	mov    %al,0x1(%r13,%rsi,1)
    722b:	48 83 c6 02          	add    $0x2,%rsi
    722f:	39 74 24 98          	cmp    %esi,-0x68(%rsp)
    7233:	0f 8f 58 fd ff ff    	jg     6f91 <convert_job+0x151>
    7239:	44 8b 7c 24 d8       	mov    -0x28(%rsp),%r15d
    723e:	44 8b 64 24 b8       	mov    -0x48(%rsp),%r12d
    7243:	41 8b 50 34          	mov    0x34(%r8),%edx
    7247:	41 83 c7 01          	add    $0x1,%r15d
    724b:	48 83 44 24 b0 01    	addq   $0x1,-0x50(%rsp)
    7251:	41 83 c4 04          	add    $0x4,%r12d
    7255:	41 39 d7             	cmp    %edx,%r15d
    7258:	0f 8c 4f fc ff ff    	jl     6ead <convert_job+0x6d>
    725e:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    7265:	5b                   	pop    %rbx
    7266:	5d                   	pop    %rbp
    7267:	41 5c                	pop    %r12
    7269:	41 5d                	pop    %r13
    726b:	41 5e                	pop    %r14
    726d:	41 5f                	pop    %r15
    726f:	c3                   	ret
    7270:	41 89 da             	mov    %ebx,%r10d
    7273:	41 83 ff 04          	cmp    $0x4,%r15d
    7277:	0f 85 cf 02 00 00    	jne    754c <convert_job+0x70c>
    727d:	39 d3                	cmp    %edx,%ebx
    727f:	7d dd                	jge    725e <convert_job+0x41e>
    7281:	49 89 fc             	mov    %rdi,%r12
    7284:	48 63 f3             	movslq %ebx,%rsi
    7287:	49 8b 4c 24 38       	mov    0x38(%r12),%rcx
    728c:	48 85 c9             	test   %rcx,%rcx
    728f:	74 1b                	je     72ac <convert_job+0x46c>
    7291:	44 89 d0             	mov    %r10d,%eax
    7294:	c1 f8 03             	sar    $0x3,%eax
    7297:	48 98                	cltq
    7299:	0f b6 0c 01          	movzbl (%rcx,%rax,1),%ecx
    729d:	44 89 d0             	mov    %r10d,%eax
    72a0:	83 e0 07             	and    $0x7,%eax
    72a3:	0f a3 c1             	bt     %eax,%ecx
    72a6:	0f 83 25 28 00 00    	jae    9ad1 <convert_job+0x2c91>
    72ac:	49 8b 4c 24 40       	mov    0x40(%r12),%rcx
    72b1:	49 63 44 24 24       	movslq 0x24(%r12),%rax
    72b6:	48 85 c9             	test   %rcx,%rcx
    72b9:	0f 84 3c 28 00 00    	je     9afb <convert_job+0x2cbb>
    72bf:	48 89 f7             	mov    %rsi,%rdi
    72c2:	48 c1 e7 04          	shl    $0x4,%rdi
    72c6:	48 01 f9             	add    %rdi,%rcx
    72c9:	44 8b 01             	mov    (%rcx),%r8d
    72cc:	8b 49 04             	mov    0x4(%rcx),%ecx
    72cf:	43 8d 1c 12          	lea    (%r10,%r10,1),%ebx
    72d3:	49 89 c3             	mov    %rax,%r11
    72d6:	4d 63 4c 24 20       	movslq 0x20(%r12),%r9
    72db:	48 63 fb             	movslq %ebx,%rdi
    72de:	89 5c 24 90          	mov    %ebx,-0x70(%rsp)
    72e2:	4c 0f af de          	imul   %rsi,%r11
    72e6:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    72eb:	48 0f af f8          	imul   %rax,%rdi
    72ef:	49 03 7c 24 08       	add    0x8(%r12),%rdi
    72f4:	48 89 7c 24 a8       	mov    %rdi,-0x58(%rsp)
    72f9:	49 89 fe             	mov    %rdi,%r14
    72fc:	44 39 c1             	cmp    %r8d,%ecx
    72ff:	0f 8e cc 27 00 00    	jle    9ad1 <convert_job+0x2c91>
    7305:	4c 01 f0             	add    %r14,%rax
    7308:	44 89 54 24 c8       	mov    %r10d,-0x38(%rsp)
    730d:	49 63 f8             	movslq %r8d,%rdi
    7310:	48 89 44 24 98       	mov    %rax,-0x68(%rsp)
    7315:	4a 8d 04 1b          	lea    (%rbx,%r11,1),%rax
    7319:	89 4c 24 b8          	mov    %ecx,-0x48(%rsp)
    731d:	48 89 74 24 e0       	mov    %rsi,-0x20(%rsp)
    7322:	48 89 44 24 b0       	mov    %rax,-0x50(%rsp)
    7327:	89 7c 24 88          	mov    %edi,-0x78(%rsp)
    732b:	45 31 db             	xor    %r11d,%r11d
    732e:	31 ed                	xor    %ebp,%ebp
    7330:	31 db                	xor    %ebx,%ebx
    7332:	48 89 7c 24 d8       	mov    %rdi,-0x28(%rsp)
    7337:	45 31 c0             	xor    %r8d,%r8d
    733a:	8b 44 24 88          	mov    -0x78(%rsp),%eax
    733e:	44 89 c6             	mov    %r8d,%esi
    7341:	44 89 c2             	mov    %r8d,%edx
    7344:	49 8b 3c 24          	mov    (%r12),%rdi
    7348:	83 e6 01             	and    $0x1,%esi
    734b:	d1 fa                	sar    $1,%edx
    734d:	01 c6                	add    %eax,%esi
    734f:	8b 44 24 90          	mov    -0x70(%rsp),%eax
    7353:	8d 0c b5 00 00 00 00 	lea    0x0(,%rsi,4),%ecx
    735a:	48 63 f6             	movslq %esi,%rsi
    735d:	01 c2                	add    %eax,%edx
    735f:	48 63 c9             	movslq %ecx,%rcx
    7362:	c1 e2 02             	shl    $0x2,%edx
    7365:	48 c1 e1 02          	shl    $0x2,%rcx
    7369:	48 63 c2             	movslq %edx,%rax
    736c:	49 0f af c1          	imul   %r9,%rax
    7370:	48 01 c8             	add    %rcx,%rax
    7373:	48 01 f8             	add    %rdi,%rax
    7376:	44 0f b6 50 04       	movzbl 0x4(%rax),%r10d
    737b:	44 0f b6 38          	movzbl (%rax),%r15d
    737f:	44 0f b6 70 01       	movzbl 0x1(%rax),%r14d
    7384:	44 0f b6 68 02       	movzbl 0x2(%rax),%r13d
    7389:	45 01 d7             	add    %r10d,%r15d
    738c:	44 0f b6 50 05       	movzbl 0x5(%rax),%r10d
    7391:	45 01 d6             	add    %r10d,%r14d
    7394:	44 0f b6 50 06       	movzbl 0x6(%rax),%r10d
    7399:	45 01 d5             	add    %r10d,%r13d
    739c:	44 0f b6 50 08       	movzbl 0x8(%rax),%r10d
    73a1:	45 01 fa             	add    %r15d,%r10d
    73a4:	44 0f b6 78 09       	movzbl 0x9(%rax),%r15d
    73a9:	45 01 f7             	add    %r14d,%r15d
    73ac:	44 0f b6 70 0a       	movzbl 0xa(%rax),%r14d
    73b1:	45 01 ee             	add    %r13d,%r14d
    73b4:	44 0f b6 68 0c       	movzbl 0xc(%rax),%r13d
    73b9:	45 01 d5             	add    %r10d,%r13d
    73bc:	44 0f b6 50 0d       	movzbl 0xd(%rax),%r10d
    73c1:	45 01 fa             	add    %r15d,%r10d
    73c4:	44 0f b6 78 0e       	movzbl 0xe(%rax),%r15d
    73c9:	8d 42 01             	lea    0x1(%rdx),%eax
    73cc:	48 98                	cltq
    73ce:	49 0f af c1          	imul   %r9,%rax
    73d2:	45 01 f7             	add    %r14d,%r15d
    73d5:	48 8d 14 01          	lea    (%rcx,%rax,1),%rdx
    73d9:	48 01 fa             	add    %rdi,%rdx
    73dc:	44 0f b6 32          	movzbl (%rdx),%r14d
    73e0:	45 01 ee             	add    %r13d,%r14d
    73e3:	44 0f b6 6a 01       	movzbl 0x1(%rdx),%r13d
    73e8:	45 01 d5             	add    %r10d,%r13d
    73eb:	44 0f b6 52 02       	movzbl 0x2(%rdx),%r10d
    73f0:	45 01 fa             	add    %r15d,%r10d
    73f3:	44 0f b6 7a 04       	movzbl 0x4(%rdx),%r15d
    73f8:	45 01 f7             	add    %r14d,%r15d
    73fb:	44 0f b6 72 05       	movzbl 0x5(%rdx),%r14d
    7400:	45 01 ee             	add    %r13d,%r14d
    7403:	44 0f b6 6a 06       	movzbl 0x6(%rdx),%r13d
    7408:	45 01 d5             	add    %r10d,%r13d
    740b:	44 0f b6 52 08       	movzbl 0x8(%rdx),%r10d
    7410:	45 01 fa             	add    %r15d,%r10d
    7413:	44 0f b6 7a 09       	movzbl 0x9(%rdx),%r15d
    7418:	45 01 f7             	add    %r14d,%r15d
    741b:	44 0f b6 72 0a       	movzbl 0xa(%rdx),%r14d
    7420:	45 01 ee             	add    %r13d,%r14d
    7423:	44 0f b6 6a 0c       	movzbl 0xc(%rdx),%r13d
    7428:	45 01 d5             	add    %r10d,%r13d
    742b:	44 0f b6 52 0d       	movzbl 0xd(%rdx),%r10d
    7430:	0f b6 52 0e          	movzbl 0xe(%rdx),%edx
    7434:	45 01 fa             	add    %r15d,%r10d
    7437:	41 01 d6             	add    %edx,%r14d
    743a:	4c 01 c8             	add    %r9,%rax
    743d:	48 8d 14 01          	lea    (%rcx,%rax,1),%rdx
    7441:	4c 01 c8             	add    %r9,%rax
    7444:	48 01 fa             	add    %rdi,%rdx
    7447:	48 01 c8             	add    %rcx,%rax
    744a:	44 0f b6 3a          	movzbl (%rdx),%r15d
    744e:	48 01 f8             	add    %rdi,%rax
    7451:	45 01 ef             	add    %r13d,%r15d
    7454:	44 0f b6 6a 01       	movzbl 0x1(%rdx),%r13d
    7459:	45 01 ea             	add    %r13d,%r10d
    745c:	44 0f b6 6a 02       	movzbl 0x2(%rdx),%r13d
    7461:	45 01 ee             	add    %r13d,%r14d
    7464:	44 0f b6 6a 04       	movzbl 0x4(%rdx),%r13d
    7469:	45 01 fd             	add    %r15d,%r13d
    746c:	44 0f b6 7a 05       	movzbl 0x5(%rdx),%r15d
    7471:	45 01 d7             	add    %r10d,%r15d
    7474:	44 0f b6 52 06       	movzbl 0x6(%rdx),%r10d
    7479:	0f b6 38             	movzbl (%rax),%edi
    747c:	0f b6 48 02          	movzbl 0x2(%rax),%ecx
    7480:	45 01 f2             	add    %r14d,%r10d
    7483:	44 0f b6 72 08       	movzbl 0x8(%rdx),%r14d
    7488:	45 01 ee             	add    %r13d,%r14d
    748b:	44 0f b6 6a 09       	movzbl 0x9(%rdx),%r13d
    7490:	45 01 fd             	add    %r15d,%r13d
    7493:	44 0f b6 7a 0a       	movzbl 0xa(%rdx),%r15d
    7498:	45 01 d7             	add    %r10d,%r15d
    749b:	44 0f b6 52 0c       	movzbl 0xc(%rdx),%r10d
    74a0:	45 01 d6             	add    %r10d,%r14d
    74a3:	44 0f b6 52 0d       	movzbl 0xd(%rdx),%r10d
    74a8:	0f b6 52 0e          	movzbl 0xe(%rdx),%edx
    74ac:	44 01 f7             	add    %r14d,%edi
    74af:	45 01 ea             	add    %r13d,%r10d
    74b2:	44 0f b6 68 01       	movzbl 0x1(%rax),%r13d
    74b7:	44 01 fa             	add    %r15d,%edx
    74ba:	01 d1                	add    %edx,%ecx
    74bc:	0f b6 50 06          	movzbl 0x6(%rax),%edx
    74c0:	45 01 d5             	add    %r10d,%r13d
    74c3:	44 0f b6 50 04       	movzbl 0x4(%rax),%r10d
    74c8:	01 ca                	add    %ecx,%edx
    74ca:	0f b6 48 08          	movzbl 0x8(%rax),%ecx
    74ce:	41 01 fa             	add    %edi,%r10d
    74d1:	0f b6 78 05          	movzbl 0x5(%rax),%edi
    74d5:	44 01 d1             	add    %r10d,%ecx
    74d8:	44 01 ef             	add    %r13d,%edi
    74db:	44 0f b6 68 09       	movzbl 0x9(%rax),%r13d
    74e0:	41 01 fd             	add    %edi,%r13d
    74e3:	0f b6 78 0a          	movzbl 0xa(%rax),%edi
    74e7:	01 d7                	add    %edx,%edi
    74e9:	0f b6 50 0c          	movzbl 0xc(%rax),%edx
    74ed:	01 ca                	add    %ecx,%edx
    74ef:	0f b6 48 0d          	movzbl 0xd(%rax),%ecx
    74f3:	0f b6 40 0e          	movzbl 0xe(%rax),%eax
    74f7:	41 89 d2             	mov    %edx,%r10d
    74fa:	01 f8                	add    %edi,%eax
    74fc:	44 01 e9             	add    %r13d,%ecx
    74ff:	41 c1 fa 04          	sar    $0x4,%r10d
    7503:	c1 f9 04             	sar    $0x4,%ecx
    7506:	c1 f8 04             	sar    $0x4,%eax
    7509:	44 6b e8 2f          	imul   $0x2f,%eax,%r13d
    750d:	81 e2 f0 ff 7f 00    	and    $0x7ffff0,%edx
    7513:	69 f9 9d 00 00 00    	imul   $0x9d,%ecx,%edi
    7519:	44 01 ef             	add    %r13d,%edi
    751c:	8d 94 17 80 00 00 00 	lea    0x80(%rdi,%rdx,1),%edx
    7523:	c1 fa 08             	sar    $0x8,%edx
    7526:	83 c2 10             	add    $0x10,%edx
    7529:	41 83 f8 01          	cmp    $0x1,%r8d
    752d:	0f 8f ed 24 00 00    	jg     9a20 <convert_job+0x2be0>
    7533:	48 8b 7c 24 a8       	mov    -0x58(%rsp),%rdi
    7538:	44 01 d3             	add    %r10d,%ebx
    753b:	01 cd                	add    %ecx,%ebp
    753d:	41 01 c3             	add    %eax,%r11d
    7540:	41 83 c0 01          	add    $0x1,%r8d
    7544:	88 14 37             	mov    %dl,(%rdi,%rsi,1)
    7547:	e9 ee fd ff ff       	jmp    733a <convert_job+0x4fa>
    754c:	41 39 d2             	cmp    %edx,%r10d
    754f:	0f 8d 09 fd ff ff    	jge    725e <convert_job+0x41e>
    7555:	44 89 f8             	mov    %r15d,%eax
    7558:	41 8d 5f ff          	lea    -0x1(%r15),%ebx
    755c:	66 45 0f ef ff       	pxor   %xmm15,%xmm15
    7561:	4d 63 da             	movslq %r10d,%r11
    7564:	41 0f af c7          	imul   %r15d,%eax
    7568:	89 5c 24 90          	mov    %ebx,-0x70(%rsp)
    756c:	66 44 0f 6f 2d 0b 7d 	movdqa 0x7d0b(%rip),%xmm13        # f280 <__PRETTY_FUNCTION__.4+0xd>
    7573:	00 00 
    7575:	f3 44 0f 7e 05 02 7d 	movq   0x7d02(%rip),%xmm8        # f280 <__PRETTY_FUNCTION__.4+0xd>
    757c:	00 00 
    757e:	89 44 24 4c          	mov    %eax,0x4c(%rsp)
    7582:	89 d8                	mov    %ebx,%eax
    7584:	83 e3 f0             	and    $0xfffffff0,%ebx
    7587:	c1 e8 04             	shr    $0x4,%eax
    758a:	89 5c 24 b0          	mov    %ebx,-0x50(%rsp)
    758e:	48 c1 e0 06          	shl    $0x6,%rax
    7592:	48 89 44 24 d8       	mov    %rax,-0x28(%rsp)
    7597:	48 8b 44 24 b8       	mov    -0x48(%rsp),%rax
    759c:	48 8b 48 38          	mov    0x38(%rax),%rcx
    75a0:	48 85 c9             	test   %rcx,%rcx
    75a3:	74 1b                	je     75c0 <convert_job+0x780>
    75a5:	44 89 d0             	mov    %r10d,%eax
    75a8:	c1 f8 03             	sar    $0x3,%eax
    75ab:	48 98                	cltq
    75ad:	0f b6 0c 01          	movzbl (%rcx,%rax,1),%ecx
    75b1:	44 89 d0             	mov    %r10d,%eax
    75b4:	83 e0 07             	and    $0x7,%eax
    75b7:	0f a3 c1             	bt     %eax,%ecx
    75ba:	0f 83 27 24 00 00    	jae    99e7 <convert_job+0x2ba7>
    75c0:	48 8b 44 24 b8       	mov    -0x48(%rsp),%rax
    75c5:	48 8b 70 40          	mov    0x40(%rax),%rsi
    75c9:	48 63 40 24          	movslq 0x24(%rax),%rax
    75cd:	48 85 f6             	test   %rsi,%rsi
    75d0:	0f 84 3f 24 00 00    	je     9a15 <convert_job+0x2bd5>
    75d6:	4c 89 d9             	mov    %r11,%rcx
    75d9:	48 c1 e1 04          	shl    $0x4,%rcx
    75dd:	48 01 ce             	add    %rcx,%rsi
    75e0:	8b 0e                	mov    (%rsi),%ecx
    75e2:	44 8b 66 04          	mov    0x4(%rsi),%r12d
    75e6:	48 8b 5c 24 b8       	mov    -0x48(%rsp),%rbx
    75eb:	43 8d 34 12          	lea    (%r10,%r10,1),%esi
    75ef:	89 74 24 e0          	mov    %esi,-0x20(%rsp)
    75f3:	48 63 f6             	movslq %esi,%rsi
    75f6:	48 0f af f0          	imul   %rax,%rsi
    75fa:	8b 7b 20             	mov    0x20(%rbx),%edi
    75fd:	48 03 73 08          	add    0x8(%rbx),%rsi
    7601:	48 89 34 24          	mov    %rsi,(%rsp)
    7605:	49 89 f6             	mov    %rsi,%r14
    7608:	48 89 c6             	mov    %rax,%rsi
    760b:	4c 8b 43 10          	mov    0x10(%rbx),%r8
    760f:	89 7c 24 c8          	mov    %edi,-0x38(%rsp)
    7613:	49 0f af f3          	imul   %r11,%rsi
    7617:	41 39 cc             	cmp    %ecx,%r12d
    761a:	0f 8e c7 23 00 00    	jle    99e7 <convert_job+0x2ba7>
    7620:	4d 8d 2c 30          	lea    (%r8,%rsi,1),%r13
    7624:	4c 01 f0             	add    %r14,%rax
    7627:	44 89 54 24 50       	mov    %r10d,0x50(%rsp)
    762c:	48 63 f9             	movslq %ecx,%rdi
    762f:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7634:	66 45 0f ef f6       	pxor   %xmm14,%xmm14
    7639:	44 89 64 24 58       	mov    %r12d,0x58(%rsp)
    763e:	4c 89 5c 24 68       	mov    %r11,0x68(%rsp)
    7643:	4c 89 6c 24 38       	mov    %r13,0x38(%rsp)
    7648:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
    764f:	00 
    7650:	89 fe                	mov    %edi,%esi
    7652:	31 c9                	xor    %ecx,%ecx
    7654:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    765b:	00 
    765c:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
    7663:	00 
    7664:	48 89 7c 24 78       	mov    %rdi,0x78(%rsp)
    7669:	89 c8                	mov    %ecx,%eax
    766b:	41 89 c8             	mov    %ecx,%r8d
    766e:	83 e0 01             	and    $0x1,%eax
    7671:	41 d1 f8             	sar    $1,%r8d
    7674:	8d 3c 30             	lea    (%rax,%rsi,1),%edi
    7677:	8b 44 24 e0          	mov    -0x20(%rsp),%eax
    767b:	41 01 c0             	add    %eax,%r8d
    767e:	45 85 ff             	test   %r15d,%r15d
    7681:	0f 8e 79 23 00 00    	jle    9a00 <convert_job+0x2bc0>
    7687:	45 0f af c7          	imul   %r15d,%r8d
    768b:	45 89 fd             	mov    %r15d,%r13d
    768e:	48 63 5c 24 c8       	movslq -0x38(%rsp),%rbx
    7693:	89 7c 24 e8          	mov    %edi,-0x18(%rsp)
    7697:	44 0f af ef          	imul   %edi,%r13d
    769b:	48 8b 44 24 b8       	mov    -0x48(%rsp),%rax
    76a0:	89 4c 24 f0          	mov    %ecx,-0x10(%rsp)
    76a4:	45 31 db             	xor    %r11d,%r11d
    76a7:	89 74 24 f8          	mov    %esi,-0x8(%rsp)
    76ab:	45 31 e4             	xor    %r12d,%r12d
    76ae:	66 45 0f ef e4       	pxor   %xmm12,%xmm12
    76b3:	66 45 0f ef c9       	pxor   %xmm9,%xmm9
    76b8:	4d 63 c0             	movslq %r8d,%r8
    76bb:	4c 8b 30             	mov    (%rax),%r14
    76be:	48 89 5c 24 98       	mov    %rbx,-0x68(%rsp)
    76c3:	4c 0f af c3          	imul   %rbx,%r8
    76c7:	4d 63 ed             	movslq %r13d,%r13
    76ca:	31 db                	xor    %ebx,%ebx
    76cc:	4a 8d 04 ad 00 00 00 	lea    0x0(,%r13,4),%rax
    76d3:	00 
    76d4:	49 01 c0             	add    %rax,%r8
    76d7:	4c 01 f0             	add    %r14,%rax
    76da:	48 89 44 24 a8       	mov    %rax,-0x58(%rsp)
    76df:	4d 01 f0             	add    %r14,%r8
    76e2:	31 c0                	xor    %eax,%eax
    76e4:	0f 1f 40 00          	nopl   0x0(%rax)
    76e8:	48 8b 74 24 a8       	mov    -0x58(%rsp),%rsi
    76ed:	4c 89 c5             	mov    %r8,%rbp
    76f0:	48 29 f5             	sub    %rsi,%rbp
    76f3:	83 7c 24 90 0f       	cmpl   $0xf,-0x70(%rsp)
    76f8:	0f 86 1a 22 00 00    	jbe    9918 <convert_job+0x2ad8>
    76fe:	48 8b 74 24 d8       	mov    -0x28(%rsp),%rsi
    7703:	66 0f ef ed          	pxor   %xmm5,%xmm5
    7707:	4c 89 c2             	mov    %r8,%rdx
    770a:	66 0f 6f e5          	movdqa %xmm5,%xmm4
    770e:	66 0f 6f dd          	movdqa %xmm5,%xmm3
    7712:	49 8d 0c 30          	lea    (%r8,%rsi,1),%rcx
    7716:	f3 0f 6f 12          	movdqu (%rdx),%xmm2
    771a:	f3 0f 6f 42 10       	movdqu 0x10(%rdx),%xmm0
    771f:	66 41 0f 6f f5       	movdqa %xmm13,%xmm6
    7724:	48 83 c2 40          	add    $0x40,%rdx
    7728:	f3 0f 6f 4a f0       	movdqu -0x10(%rdx),%xmm1
    772d:	f3 0f 6f 7a f0       	movdqu -0x10(%rdx),%xmm7
    7732:	66 41 0f db c5       	pand   %xmm13,%xmm0
    7737:	66 41 0f db d5       	pand   %xmm13,%xmm2
    773c:	66 0f 67 d0          	packuswb %xmm0,%xmm2
    7740:	f3 0f 6f 42 e0       	movdqu -0x20(%rdx),%xmm0
    7745:	66 41 0f db cd       	pand   %xmm13,%xmm1
    774a:	66 0f db f2          	pand   %xmm2,%xmm6
    774e:	66 0f 71 d2 08       	psrlw  $0x8,%xmm2
    7753:	66 41 0f db c5       	pand   %xmm13,%xmm0
    7758:	66 0f 71 d7 08       	psrlw  $0x8,%xmm7
    775d:	66 0f 67 c1          	packuswb %xmm1,%xmm0
    7761:	66 41 0f 6f cd       	movdqa %xmm13,%xmm1
    7766:	66 0f db c8          	pand   %xmm0,%xmm1
    776a:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    776f:	66 0f 67 f1          	packuswb %xmm1,%xmm6
    7773:	66 0f 67 d0          	packuswb %xmm0,%xmm2
    7777:	f3 0f 6f 4a d0       	movdqu -0x30(%rdx),%xmm1
    777c:	f3 0f 6f 42 c0       	movdqu -0x40(%rdx),%xmm0
    7781:	66 0f 71 d1 08       	psrlw  $0x8,%xmm1
    7786:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    778b:	66 0f 67 c1          	packuswb %xmm1,%xmm0
    778f:	f3 0f 6f 4a e0       	movdqu -0x20(%rdx),%xmm1
    7794:	66 41 0f db c5       	pand   %xmm13,%xmm0
    7799:	66 0f 71 d1 08       	psrlw  $0x8,%xmm1
    779e:	66 0f 67 cf          	packuswb %xmm7,%xmm1
    77a2:	66 0f 6f fe          	movdqa %xmm6,%xmm7
    77a6:	66 41 0f 68 f4       	punpckhbw %xmm12,%xmm6
    77ab:	66 41 0f db cd       	pand   %xmm13,%xmm1
    77b0:	66 41 0f 60 fc       	punpcklbw %xmm12,%xmm7
    77b5:	66 0f 67 c1          	packuswb %xmm1,%xmm0
    77b9:	66 0f 6f cf          	movdqa %xmm7,%xmm1
    77bd:	66 41 0f 69 f9       	punpckhwd %xmm9,%xmm7
    77c2:	66 41 0f 61 c9       	punpcklwd %xmm9,%xmm1
    77c7:	66 0f fe d9          	paddd  %xmm1,%xmm3
    77cb:	66 0f 6f ce          	movdqa %xmm6,%xmm1
    77cf:	66 41 0f 69 f1       	punpckhwd %xmm9,%xmm6
    77d4:	66 41 0f 61 c9       	punpcklwd %xmm9,%xmm1
    77d9:	66 0f fe df          	paddd  %xmm7,%xmm3
    77dd:	66 0f fe d9          	paddd  %xmm1,%xmm3
    77e1:	66 0f fe de          	paddd  %xmm6,%xmm3
    77e5:	66 0f 6f f0          	movdqa %xmm0,%xmm6
    77e9:	66 41 0f 68 c4       	punpckhbw %xmm12,%xmm0
    77ee:	66 41 0f 60 f4       	punpcklbw %xmm12,%xmm6
    77f3:	66 0f 6f ce          	movdqa %xmm6,%xmm1
    77f7:	66 41 0f 69 f1       	punpckhwd %xmm9,%xmm6
    77fc:	66 41 0f 61 c9       	punpcklwd %xmm9,%xmm1
    7801:	66 0f fe e1          	paddd  %xmm1,%xmm4
    7805:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    7809:	66 41 0f 69 c1       	punpckhwd %xmm9,%xmm0
    780e:	66 41 0f 61 c9       	punpcklwd %xmm9,%xmm1
    7813:	66 0f fe e6          	paddd  %xmm6,%xmm4
    7817:	66 0f fe e1          	paddd  %xmm1,%xmm4
    781b:	66 0f 6f ca          	movdqa %xmm2,%xmm1
    781f:	66 41 0f 68 d4       	punpckhbw %xmm12,%xmm2
    7824:	66 41 0f 60 cc       	punpcklbw %xmm12,%xmm1
    7829:	66 0f fe e0          	paddd  %xmm0,%xmm4
    782d:	66 0f 6f c1          	movdqa %xmm1,%xmm0
    7831:	66 41 0f 69 c9       	punpckhwd %xmm9,%xmm1
    7836:	66 41 0f 61 c1       	punpcklwd %xmm9,%xmm0
    783b:	66 0f fe e8          	paddd  %xmm0,%xmm5
    783f:	66 0f 6f c2          	movdqa %xmm2,%xmm0
    7843:	66 41 0f 69 d1       	punpckhwd %xmm9,%xmm2
    7848:	66 0f fe e9          	paddd  %xmm1,%xmm5
    784c:	66 41 0f 61 c1       	punpcklwd %xmm9,%xmm0
    7851:	66 0f fe e8          	paddd  %xmm0,%xmm5
    7855:	66 0f fe ea          	paddd  %xmm2,%xmm5
    7859:	48 39 d1             	cmp    %rdx,%rcx
    785c:	0f 85 b4 fe ff ff    	jne    7716 <convert_job+0x8d6>
    7862:	66 0f 6f c5          	movdqa %xmm5,%xmm0
    7866:	66 0f 6f fb          	movdqa %xmm3,%xmm7
    786a:	44 0f 12 d5          	movhlps %xmm5,%xmm10
    786e:	44 8b 54 24 b0       	mov    -0x50(%rsp),%r10d
    7873:	66 0f 73 d8 08       	psrldq $0x8,%xmm0
    7878:	66 44 0f fe d5       	paddd  %xmm5,%xmm10
    787d:	66 0f fe c5          	paddd  %xmm5,%xmm0
    7881:	44 89 d7             	mov    %r10d,%edi
    7884:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    7888:	66 0f 73 d9 04       	psrldq $0x4,%xmm1
    788d:	66 0f fe c1          	paddd  %xmm1,%xmm0
    7891:	66 0f 7e c2          	movd   %xmm0,%edx
    7895:	66 0f 6f c4          	movdqa %xmm4,%xmm0
    7899:	66 0f 73 d8 08       	psrldq $0x8,%xmm0
    789e:	01 c2                	add    %eax,%edx
    78a0:	66 0f fe c4          	paddd  %xmm4,%xmm0
    78a4:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    78a8:	66 0f 73 d9 04       	psrldq $0x4,%xmm1
    78ad:	66 0f fe c1          	paddd  %xmm1,%xmm0
    78b1:	66 0f 7e c1          	movd   %xmm0,%ecx
    78b5:	66 0f 6f c3          	movdqa %xmm3,%xmm0
    78b9:	66 0f 73 d8 08       	psrldq $0x8,%xmm0
    78be:	01 d9                	add    %ebx,%ecx
    78c0:	66 0f fe c3          	paddd  %xmm3,%xmm0
    78c4:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    78c8:	66 0f 73 d9 04       	psrldq $0x4,%xmm1
    78cd:	66 0f fe c1          	paddd  %xmm1,%xmm0
    78d1:	66 0f 7e c6          	movd   %xmm0,%esi
    78d5:	0f 12 c3             	movhlps %xmm3,%xmm0
    78d8:	66 0f fe f8          	paddd  %xmm0,%xmm7
    78dc:	0f 12 c4             	movhlps %xmm4,%xmm0
    78df:	44 01 de             	add    %r11d,%esi
    78e2:	66 0f fe e0          	paddd  %xmm0,%xmm4
    78e6:	66 0f d6 7c 24 88    	movq   %xmm7,-0x78(%rsp)
    78ec:	44 8b 4c 24 90       	mov    -0x70(%rsp),%r9d
    78f1:	41 29 f9             	sub    %edi,%r9d
    78f4:	41 83 f9 07          	cmp    $0x7,%r9d
    78f8:	0f 86 e3 01 00 00    	jbe    7ae1 <convert_job+0xca1>
    78fe:	4c 01 ef             	add    %r13,%rdi
    7901:	66 41 0f 6f c8       	movdqa %xmm8,%xmm1
    7906:	66 41 0f 6f e8       	movdqa %xmm8,%xmm5
    790b:	41 83 e1 f8          	and    $0xfffffff8,%r9d
    790f:	48 8d 54 bd 00       	lea    0x0(%rbp,%rdi,4),%rdx
    7914:	66 41 0f 6f f0       	movdqa %xmm8,%xmm6
    7919:	66 41 0f 6f d8       	movdqa %xmm8,%xmm3
    791e:	45 01 ca             	add    %r9d,%r10d
    7921:	4c 01 f2             	add    %r14,%rdx
    7924:	f3 0f 7e 12          	movq   (%rdx),%xmm2
    7928:	f3 44 0f 7e 5a 08    	movq   0x8(%rdx),%xmm11
    792e:	f3 0f 7e 7a 10       	movq   0x10(%rdx),%xmm7
    7933:	f3 0f 7e 42 18       	movq   0x18(%rdx),%xmm0
    7938:	66 41 0f db eb       	pand   %xmm11,%xmm5
    793d:	66 41 0f 71 d3 08    	psrlw  $0x8,%xmm11
    7943:	66 0f db ca          	pand   %xmm2,%xmm1
    7947:	66 0f 67 cd          	packuswb %xmm5,%xmm1
    794b:	66 41 0f 6f e8       	movdqa %xmm8,%xmm5
    7950:	66 0f db f7          	pand   %xmm7,%xmm6
    7954:	66 0f db e8          	pand   %xmm0,%xmm5
    7958:	66 0f 71 d2 08       	psrlw  $0x8,%xmm2
    795d:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    7962:	66 0f 67 f5          	packuswb %xmm5,%xmm6
    7966:	66 41 0f 6f e8       	movdqa %xmm8,%xmm5
    796b:	66 41 0f 67 d3       	packuswb %xmm11,%xmm2
    7970:	66 0f 70 f6 08       	pshufd $0x8,%xmm6,%xmm6
    7975:	66 0f db e9          	pand   %xmm1,%xmm5
    7979:	66 0f 70 d2 08       	pshufd $0x8,%xmm2,%xmm2
    797e:	66 0f db de          	pand   %xmm6,%xmm3
    7982:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    7987:	66 41 0f db d0       	pand   %xmm8,%xmm2
    798c:	66 0f 71 d7 08       	psrlw  $0x8,%xmm7
    7991:	66 0f 71 d6 08       	psrlw  $0x8,%xmm6
    7996:	66 0f 67 eb          	packuswb %xmm3,%xmm5
    799a:	f3 0f 7e 5c 24 88    	movq   -0x78(%rsp),%xmm3
    79a0:	66 0f 70 ed 08       	pshufd $0x8,%xmm5,%xmm5
    79a5:	66 0f 71 d1 08       	psrlw  $0x8,%xmm1
    79aa:	66 0f 67 f8          	packuswb %xmm0,%xmm7
    79ae:	66 0f 6f c2          	movdqa %xmm2,%xmm0
    79b2:	66 0f 6f d5          	movdqa %xmm5,%xmm2
    79b6:	66 0f 67 ce          	packuswb %xmm6,%xmm1
    79ba:	66 41 0f 60 d7       	punpcklbw %xmm15,%xmm2
    79bf:	66 41 0f 60 ef       	punpcklbw %xmm15,%xmm5
    79c4:	66 0f 70 ff 08       	pshufd $0x8,%xmm7,%xmm7
    79c9:	66 0f 6f f2          	movdqa %xmm2,%xmm6
    79cd:	66 41 0f 61 d6       	punpcklwd %xmm14,%xmm2
    79d2:	66 0f 70 ed 4e       	pshufd $0x4e,%xmm5,%xmm5
    79d7:	66 41 0f 61 f6       	punpcklwd %xmm14,%xmm6
    79dc:	66 0f 70 d2 4e       	pshufd $0x4e,%xmm2,%xmm2
    79e1:	66 41 0f db f8       	pand   %xmm8,%xmm7
    79e6:	66 0f fe de          	paddd  %xmm6,%xmm3
    79ea:	66 0f 67 c7          	packuswb %xmm7,%xmm0
    79ee:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    79f3:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    79f8:	66 0f fe da          	paddd  %xmm2,%xmm3
    79fc:	66 0f 6f d5          	movdqa %xmm5,%xmm2
    7a00:	66 41 0f 61 ee       	punpcklwd %xmm14,%xmm5
    7a05:	66 41 0f 61 d6       	punpcklwd %xmm14,%xmm2
    7a0a:	66 0f 70 ed 4e       	pshufd $0x4e,%xmm5,%xmm5
    7a0f:	66 0f fe da          	paddd  %xmm2,%xmm3
    7a13:	66 0f 6f d0          	movdqa %xmm0,%xmm2
    7a17:	66 41 0f 60 c7       	punpcklbw %xmm15,%xmm0
    7a1c:	66 41 0f 60 d7       	punpcklbw %xmm15,%xmm2
    7a21:	66 0f 70 c0 4e       	pshufd $0x4e,%xmm0,%xmm0
    7a26:	66 0f fe eb          	paddd  %xmm3,%xmm5
    7a2a:	66 0f 6f da          	movdqa %xmm2,%xmm3
    7a2e:	66 41 0f 61 d6       	punpcklwd %xmm14,%xmm2
    7a33:	66 41 0f 61 de       	punpcklwd %xmm14,%xmm3
    7a38:	66 0f 70 d2 4e       	pshufd $0x4e,%xmm2,%xmm2
    7a3d:	66 0f fe e3          	paddd  %xmm3,%xmm4
    7a41:	66 0f fe e2          	paddd  %xmm2,%xmm4
    7a45:	66 0f 6f d0          	movdqa %xmm0,%xmm2
    7a49:	66 41 0f 61 c6       	punpcklwd %xmm14,%xmm0
    7a4e:	66 41 0f 61 d6       	punpcklwd %xmm14,%xmm2
    7a53:	66 0f 70 c0 4e       	pshufd $0x4e,%xmm0,%xmm0
    7a58:	66 0f fe e2          	paddd  %xmm2,%xmm4
    7a5c:	66 0f 6f d1          	movdqa %xmm1,%xmm2
    7a60:	66 41 0f 60 cf       	punpcklbw %xmm15,%xmm1
    7a65:	66 41 0f 60 d7       	punpcklbw %xmm15,%xmm2
    7a6a:	66 0f 70 c9 4e       	pshufd $0x4e,%xmm1,%xmm1
    7a6f:	66 0f 6f da          	movdqa %xmm2,%xmm3
    7a73:	66 41 0f 61 d6       	punpcklwd %xmm14,%xmm2
    7a78:	66 41 0f 61 de       	punpcklwd %xmm14,%xmm3
    7a7d:	66 0f 70 d2 4e       	pshufd $0x4e,%xmm2,%xmm2
    7a82:	66 0f fe c4          	paddd  %xmm4,%xmm0
    7a86:	66 44 0f fe d3       	paddd  %xmm3,%xmm10
    7a8b:	66 0f 70 e0 e5       	pshufd $0xe5,%xmm0,%xmm4
    7a90:	66 44 0f fe d2       	paddd  %xmm2,%xmm10
    7a95:	66 0f 6f d1          	movdqa %xmm1,%xmm2
    7a99:	66 41 0f 61 ce       	punpcklwd %xmm14,%xmm1
    7a9e:	66 41 0f 61 d6       	punpcklwd %xmm14,%xmm2
    7aa3:	66 0f 70 c9 4e       	pshufd $0x4e,%xmm1,%xmm1
    7aa8:	66 44 0f fe d2       	paddd  %xmm2,%xmm10
    7aad:	66 41 0f fe ca       	paddd  %xmm10,%xmm1
    7ab2:	66 0f 7e c9          	movd   %xmm1,%ecx
    7ab6:	66 0f 70 f9 e5       	pshufd $0xe5,%xmm1,%xmm7
    7abb:	66 0f 7e fa          	movd   %xmm7,%edx
    7abf:	66 0f 70 fd e5       	pshufd $0xe5,%xmm5,%xmm7
    7ac4:	01 ca                	add    %ecx,%edx
    7ac6:	66 0f 7e e1          	movd   %xmm4,%ecx
    7aca:	66 0f 7e fe          	movd   %xmm7,%esi
    7ace:	01 c2                	add    %eax,%edx
    7ad0:	66 0f 7e c0          	movd   %xmm0,%eax
    7ad4:	01 c1                	add    %eax,%ecx
    7ad6:	66 0f 7e e8          	movd   %xmm5,%eax
    7ada:	01 c6                	add    %eax,%esi
    7adc:	01 d9                	add    %ebx,%ecx
    7ade:	44 01 de             	add    %r11d,%esi
    7ae1:	42 8d 3c 95 00 00 00 	lea    0x0(,%r10,4),%edi
    7ae8:	00 
    7ae9:	48 63 c7             	movslq %edi,%rax
    7aec:	45 0f b6 1c 00       	movzbl (%r8,%rax,1),%r11d
    7af1:	41 0f b6 5c 00 01    	movzbl 0x1(%r8,%rax,1),%ebx
    7af7:	41 0f b6 44 00 02    	movzbl 0x2(%r8,%rax,1),%eax
    7afd:	41 01 f3             	add    %esi,%r11d
    7b00:	01 cb                	add    %ecx,%ebx
    7b02:	01 d0                	add    %edx,%eax
    7b04:	41 8d 52 01          	lea    0x1(%r10),%edx
    7b08:	41 39 d7             	cmp    %edx,%r15d
    7b0b:	0f 8e 14 01 00 00    	jle    7c25 <convert_job+0xde5>
    7b11:	8d 57 04             	lea    0x4(%rdi),%edx
    7b14:	48 63 d2             	movslq %edx,%rdx
    7b17:	41 0f b6 0c 10       	movzbl (%r8,%rdx,1),%ecx
    7b1c:	41 01 cb             	add    %ecx,%r11d
    7b1f:	41 0f b6 4c 10 01    	movzbl 0x1(%r8,%rdx,1),%ecx
    7b25:	41 0f b6 54 10 02    	movzbl 0x2(%r8,%rdx,1),%edx
    7b2b:	01 d0                	add    %edx,%eax
    7b2d:	41 8d 52 02          	lea    0x2(%r10),%edx
    7b31:	01 cb                	add    %ecx,%ebx
    7b33:	41 39 d7             	cmp    %edx,%r15d
    7b36:	0f 8e e9 00 00 00    	jle    7c25 <convert_job+0xde5>
    7b3c:	8d 57 08             	lea    0x8(%rdi),%edx
    7b3f:	48 63 d2             	movslq %edx,%rdx
    7b42:	41 0f b6 0c 10       	movzbl (%r8,%rdx,1),%ecx
    7b47:	41 01 cb             	add    %ecx,%r11d
    7b4a:	41 0f b6 4c 10 01    	movzbl 0x1(%r8,%rdx,1),%ecx
    7b50:	41 0f b6 54 10 02    	movzbl 0x2(%r8,%rdx,1),%edx
    7b56:	01 d0                	add    %edx,%eax
    7b58:	41 8d 52 03          	lea    0x3(%r10),%edx
    7b5c:	01 cb                	add    %ecx,%ebx
    7b5e:	41 39 d7             	cmp    %edx,%r15d
    7b61:	0f 8e be 00 00 00    	jle    7c25 <convert_job+0xde5>
    7b67:	8d 57 0c             	lea    0xc(%rdi),%edx
    7b6a:	48 63 d2             	movslq %edx,%rdx
    7b6d:	41 0f b6 0c 10       	movzbl (%r8,%rdx,1),%ecx
    7b72:	41 01 cb             	add    %ecx,%r11d
    7b75:	41 0f b6 4c 10 01    	movzbl 0x1(%r8,%rdx,1),%ecx
    7b7b:	41 0f b6 54 10 02    	movzbl 0x2(%r8,%rdx,1),%edx
    7b81:	01 d0                	add    %edx,%eax
    7b83:	41 8d 52 04          	lea    0x4(%r10),%edx
    7b87:	01 cb                	add    %ecx,%ebx
    7b89:	41 39 d7             	cmp    %edx,%r15d
    7b8c:	0f 8e 93 00 00 00    	jle    7c25 <convert_job+0xde5>
    7b92:	8d 57 10             	lea    0x10(%rdi),%edx
    7b95:	48 63 d2             	movslq %edx,%rdx
    7b98:	41 0f b6 0c 10       	movzbl (%r8,%rdx,1),%ecx
    7b9d:	41 01 cb             	add    %ecx,%r11d
    7ba0:	41 0f b6 4c 10 01    	movzbl 0x1(%r8,%rdx,1),%ecx
    7ba6:	41 0f b6 54 10 02    	movzbl 0x2(%r8,%rdx,1),%edx
    7bac:	01 d0                	add    %edx,%eax
    7bae:	41 8d 52 05          	lea    0x5(%r10),%edx
    7bb2:	01 cb                	add    %ecx,%ebx
    7bb4:	41 39 d7             	cmp    %edx,%r15d
    7bb7:	7e 6c                	jle    7c25 <convert_job+0xde5>
    7bb9:	8d 57 14             	lea    0x14(%rdi),%edx
    7bbc:	48 63 d2             	movslq %edx,%rdx
    7bbf:	41 0f b6 0c 10       	movzbl (%r8,%rdx,1),%ecx
    7bc4:	41 01 cb             	add    %ecx,%r11d
    7bc7:	41 0f b6 4c 10 01    	movzbl 0x1(%r8,%rdx,1),%ecx
    7bcd:	41 0f b6 54 10 02    	movzbl 0x2(%r8,%rdx,1),%edx
    7bd3:	01 d0                	add    %edx,%eax
    7bd5:	41 8d 52 06          	lea    0x6(%r10),%edx
    7bd9:	01 cb                	add    %ecx,%ebx
    7bdb:	41 39 d7             	cmp    %edx,%r15d
    7bde:	7e 45                	jle    7c25 <convert_job+0xde5>
    7be0:	8d 57 18             	lea    0x18(%rdi),%edx
    7be3:	41 83 c2 07          	add    $0x7,%r10d
    7be7:	48 63 d2             	movslq %edx,%rdx
    7bea:	41 0f b6 0c 10       	movzbl (%r8,%rdx,1),%ecx
    7bef:	41 01 cb             	add    %ecx,%r11d
    7bf2:	41 0f b6 4c 10 01    	movzbl 0x1(%r8,%rdx,1),%ecx
    7bf8:	41 0f b6 54 10 02    	movzbl 0x2(%r8,%rdx,1),%edx
    7bfe:	01 cb                	add    %ecx,%ebx
    7c00:	01 d0                	add    %edx,%eax
    7c02:	45 39 d7             	cmp    %r10d,%r15d
    7c05:	7e 1e                	jle    7c25 <convert_job+0xde5>
    7c07:	8d 57 1c             	lea    0x1c(%rdi),%edx
    7c0a:	48 63 d2             	movslq %edx,%rdx
    7c0d:	41 0f b6 0c 10       	movzbl (%r8,%rdx,1),%ecx
    7c12:	41 01 cb             	add    %ecx,%r11d
    7c15:	41 0f b6 4c 10 01    	movzbl 0x1(%r8,%rdx,1),%ecx
    7c1b:	41 0f b6 54 10 02    	movzbl 0x2(%r8,%rdx,1),%edx
    7c21:	01 cb                	add    %ecx,%ebx
    7c23:	01 d0                	add    %edx,%eax
    7c25:	48 8b 7c 24 98       	mov    -0x68(%rsp),%rdi
    7c2a:	41 83 c4 01          	add    $0x1,%r12d
    7c2e:	49 01 f8             	add    %rdi,%r8
    7c31:	45 39 e7             	cmp    %r12d,%r15d
    7c34:	0f 85 ae fa ff ff    	jne    76e8 <convert_job+0x8a8>
    7c3a:	44 8b 4c 24 4c       	mov    0x4c(%rsp),%r9d
    7c3f:	99                   	cltd
    7c40:	8b 7c 24 e8          	mov    -0x18(%rsp),%edi
    7c44:	8b 4c 24 f0          	mov    -0x10(%rsp),%ecx
    7c48:	8b 74 24 f8          	mov    -0x8(%rsp),%esi
    7c4c:	41 f7 f9             	idiv   %r9d
    7c4f:	41 89 c4             	mov    %eax,%r12d
    7c52:	89 d8                	mov    %ebx,%eax
    7c54:	44 01 64 24 28       	add    %r12d,0x28(%rsp)
    7c59:	99                   	cltd
    7c5a:	45 6b c4 2f          	imul   $0x2f,%r12d,%r8d
    7c5e:	41 f7 f9             	idiv   %r9d
    7c61:	89 c3                	mov    %eax,%ebx
    7c63:	44 89 d8             	mov    %r11d,%eax
    7c66:	01 5c 24 18          	add    %ebx,0x18(%rsp)
    7c6a:	99                   	cltd
    7c6b:	41 f7 f9             	idiv   %r9d
    7c6e:	69 d3 9d 00 00 00    	imul   $0x9d,%ebx,%edx
    7c74:	44 01 c2             	add    %r8d,%edx
    7c77:	01 44 24 30          	add    %eax,0x30(%rsp)
    7c7b:	41 89 c0             	mov    %eax,%r8d
    7c7e:	41 c1 e0 04          	shl    $0x4,%r8d
    7c82:	42 8d 94 02 80 00 00 	lea    0x80(%rdx,%r8,1),%edx
    7c89:	00 
    7c8a:	c1 fa 08             	sar    $0x8,%edx
    7c8d:	83 c2 10             	add    $0x10,%edx
    7c90:	48 63 c7             	movslq %edi,%rax
    7c93:	83 f9 01             	cmp    $0x1,%ecx
    7c96:	0f 8e 9e 1c 00 00    	jle    993a <convert_job+0x2afa>
    7c9c:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    7ca1:	88 14 03             	mov    %dl,(%rbx,%rax,1)
    7ca4:	83 f9 03             	cmp    $0x3,%ecx
    7ca7:	0f 84 9c 1c 00 00    	je     9949 <convert_job+0x2b09>
    7cad:	b9 03 00 00 00       	mov    $0x3,%ecx
    7cb2:	e9 b2 f9 ff ff       	jmp    7669 <convert_job+0x829>
    7cb7:	41 89 d8             	mov    %ebx,%r8d
    7cba:	39 d3                	cmp    %edx,%ebx
    7cbc:	0f 8d 9c f5 ff ff    	jge    725e <convert_job+0x41e>
    7cc2:	49 89 fd             	mov    %rdi,%r13
    7cc5:	48 63 f3             	movslq %ebx,%rsi
    7cc8:	49 8b 4d 38          	mov    0x38(%r13),%rcx
    7ccc:	48 85 c9             	test   %rcx,%rcx
    7ccf:	74 1b                	je     7cec <convert_job+0xeac>
    7cd1:	44 89 c0             	mov    %r8d,%eax
    7cd4:	c1 f8 03             	sar    $0x3,%eax
    7cd7:	48 98                	cltq
    7cd9:	0f b6 0c 01          	movzbl (%rcx,%rax,1),%ecx
    7cdd:	44 89 c0             	mov    %r8d,%eax
    7ce0:	83 e0 07             	and    $0x7,%eax
    7ce3:	0f a3 c1             	bt     %eax,%ecx
    7ce6:	0f 83 64 20 00 00    	jae    9d50 <convert_job+0x2f10>
    7cec:	49 8b 4d 40          	mov    0x40(%r13),%rcx
    7cf0:	49 63 45 24          	movslq 0x24(%r13),%rax
    7cf4:	48 85 c9             	test   %rcx,%rcx
    7cf7:	0f 84 7d 20 00 00    	je     9d7a <convert_job+0x2f3a>
    7cfd:	48 89 f7             	mov    %rsi,%rdi
    7d00:	48 c1 e7 04          	shl    $0x4,%rdi
    7d04:	48 01 f9             	add    %rdi,%rcx
    7d07:	4c 63 09             	movslq (%rcx),%r9
    7d0a:	8b 49 04             	mov    0x4(%rcx),%ecx
    7d0d:	43 8d 1c 00          	lea    (%r8,%r8,1),%ebx
    7d11:	4d 63 65 20          	movslq 0x20(%r13),%r12
    7d15:	4d 8b 55 10          	mov    0x10(%r13),%r10
    7d19:	48 63 fb             	movslq %ebx,%rdi
    7d1c:	89 5c 24 90          	mov    %ebx,-0x70(%rsp)
    7d20:	49 8b 5d 08          	mov    0x8(%r13),%rbx
    7d24:	48 0f af f8          	imul   %rax,%rdi
    7d28:	48 01 fb             	add    %rdi,%rbx
    7d2b:	48 89 c7             	mov    %rax,%rdi
    7d2e:	48 89 5c 24 a8       	mov    %rbx,-0x58(%rsp)
    7d33:	48 0f af fe          	imul   %rsi,%rdi
    7d37:	44 39 c9             	cmp    %r9d,%ecx
    7d3a:	0f 8e 10 20 00 00    	jle    9d50 <convert_job+0x2f10>
    7d40:	48 01 d8             	add    %rbx,%rax
    7d43:	44 89 44 24 c8       	mov    %r8d,-0x38(%rsp)
    7d48:	48 89 44 24 98       	mov    %rax,-0x68(%rsp)
    7d4d:	49 8d 04 3a          	lea    (%r10,%rdi,1),%rax
    7d51:	89 4c 24 b8          	mov    %ecx,-0x48(%rsp)
    7d55:	48 89 74 24 e0       	mov    %rsi,-0x20(%rsp)
    7d5a:	48 89 44 24 b0       	mov    %rax,-0x50(%rsp)
    7d5f:	44 89 4c 24 88       	mov    %r9d,-0x78(%rsp)
    7d64:	45 31 db             	xor    %r11d,%r11d
    7d67:	31 ed                	xor    %ebp,%ebp
    7d69:	31 db                	xor    %ebx,%ebx
    7d6b:	4c 89 4c 24 d8       	mov    %r9,-0x28(%rsp)
    7d70:	31 ff                	xor    %edi,%edi
    7d72:	8b 44 24 88          	mov    -0x78(%rsp),%eax
    7d76:	89 fe                	mov    %edi,%esi
    7d78:	8b 4c 24 90          	mov    -0x70(%rsp),%ecx
    7d7c:	83 e6 01             	and    $0x1,%esi
    7d7f:	4d 8b 4d 00          	mov    0x0(%r13),%r9
    7d83:	01 c6                	add    %eax,%esi
    7d85:	89 f8                	mov    %edi,%eax
    7d87:	d1 f8                	sar    $1,%eax
    7d89:	01 c8                	add    %ecx,%eax
    7d8b:	8d 0c 76             	lea    (%rsi,%rsi,2),%ecx
    7d8e:	48 63 f6             	movslq %esi,%rsi
    7d91:	8d 14 40             	lea    (%rax,%rax,2),%edx
    7d94:	48 63 c9             	movslq %ecx,%rcx
    7d97:	48 63 c2             	movslq %edx,%rax
    7d9a:	48 c1 e1 02          	shl    $0x2,%rcx
    7d9e:	49 0f af c4          	imul   %r12,%rax
    7da2:	48 01 c8             	add    %rcx,%rax
    7da5:	4c 01 c8             	add    %r9,%rax
    7da8:	44 0f b6 50 04       	movzbl 0x4(%rax),%r10d
    7dad:	44 0f b6 00          	movzbl (%rax),%r8d
    7db1:	44 0f b6 70 01       	movzbl 0x1(%rax),%r14d
    7db6:	44 0f b6 78 02       	movzbl 0x2(%rax),%r15d
    7dbb:	45 01 d0             	add    %r10d,%r8d
    7dbe:	44 0f b6 50 05       	movzbl 0x5(%rax),%r10d
    7dc3:	45 01 d6             	add    %r10d,%r14d
    7dc6:	44 0f b6 50 06       	movzbl 0x6(%rax),%r10d
    7dcb:	45 01 d7             	add    %r10d,%r15d
    7dce:	44 0f b6 50 08       	movzbl 0x8(%rax),%r10d
    7dd3:	45 01 c2             	add    %r8d,%r10d
    7dd6:	44 0f b6 40 09       	movzbl 0x9(%rax),%r8d
    7ddb:	45 01 f0             	add    %r14d,%r8d
    7dde:	44 0f b6 70 0a       	movzbl 0xa(%rax),%r14d
    7de3:	8d 42 01             	lea    0x1(%rdx),%eax
    7de6:	48 98                	cltq
    7de8:	49 0f af c4          	imul   %r12,%rax
    7dec:	45 01 fe             	add    %r15d,%r14d
    7def:	48 8d 14 01          	lea    (%rcx,%rax,1),%rdx
    7df3:	4c 01 e0             	add    %r12,%rax
    7df6:	4c 01 ca             	add    %r9,%rdx
    7df9:	48 01 c8             	add    %rcx,%rax
    7dfc:	44 0f b6 3a          	movzbl (%rdx),%r15d
    7e00:	4c 01 c8             	add    %r9,%rax
    7e03:	44 0f b6 48 01       	movzbl 0x1(%rax),%r9d
    7e08:	0f b6 08             	movzbl (%rax),%ecx
    7e0b:	45 01 fa             	add    %r15d,%r10d
    7e0e:	44 0f b6 7a 01       	movzbl 0x1(%rdx),%r15d
    7e13:	45 01 c7             	add    %r8d,%r15d
    7e16:	44 0f b6 42 02       	movzbl 0x2(%rdx),%r8d
    7e1b:	45 01 f0             	add    %r14d,%r8d
    7e1e:	44 0f b6 72 04       	movzbl 0x4(%rdx),%r14d
    7e23:	45 01 d6             	add    %r10d,%r14d
    7e26:	44 0f b6 52 05       	movzbl 0x5(%rdx),%r10d
    7e2b:	45 01 fa             	add    %r15d,%r10d
    7e2e:	44 0f b6 7a 06       	movzbl 0x6(%rdx),%r15d
    7e33:	45 01 c7             	add    %r8d,%r15d
    7e36:	44 0f b6 42 08       	movzbl 0x8(%rdx),%r8d
    7e3b:	45 01 c6             	add    %r8d,%r14d
    7e3e:	44 0f b6 42 09       	movzbl 0x9(%rdx),%r8d
    7e43:	0f b6 52 0a          	movzbl 0xa(%rdx),%edx
    7e47:	44 01 f1             	add    %r14d,%ecx
    7e4a:	45 01 d0             	add    %r10d,%r8d
    7e4d:	44 01 fa             	add    %r15d,%edx
    7e50:	45 01 c8             	add    %r9d,%r8d
    7e53:	44 0f b6 48 02       	movzbl 0x2(%rax),%r9d
    7e58:	44 01 ca             	add    %r9d,%edx
    7e5b:	44 0f b6 48 04       	movzbl 0x4(%rax),%r9d
    7e60:	41 01 c9             	add    %ecx,%r9d
    7e63:	0f b6 48 05          	movzbl 0x5(%rax),%ecx
    7e67:	44 01 c1             	add    %r8d,%ecx
    7e6a:	44 0f b6 40 06       	movzbl 0x6(%rax),%r8d
    7e6f:	41 01 d0             	add    %edx,%r8d
    7e72:	0f b6 50 08          	movzbl 0x8(%rax),%edx
    7e76:	44 01 ca             	add    %r9d,%edx
    7e79:	44 0f b6 48 09       	movzbl 0x9(%rax),%r9d
    7e7e:	0f b6 40 0a          	movzbl 0xa(%rax),%eax
    7e82:	48 69 d2 39 8e e3 38 	imul   $0x38e38e39,%rdx,%rdx
    7e89:	44 01 c9             	add    %r9d,%ecx
    7e8c:	44 01 c0             	add    %r8d,%eax
    7e8f:	48 69 c9 39 8e e3 38 	imul   $0x38e38e39,%rcx,%rcx
    7e96:	48 69 c0 39 8e e3 38 	imul   $0x38e38e39,%rax,%rax
    7e9d:	48 c1 ea 21          	shr    $0x21,%rdx
    7ea1:	48 c1 e9 21          	shr    $0x21,%rcx
    7ea5:	48 c1 e8 21          	shr    $0x21,%rax
    7ea9:	44 69 c1 9d 00 00 00 	imul   $0x9d,%ecx,%r8d
    7eb0:	44 6b c8 2f          	imul   $0x2f,%eax,%r9d
    7eb4:	45 01 c8             	add    %r9d,%r8d
    7eb7:	41 89 d1             	mov    %edx,%r9d
    7eba:	41 c1 e1 04          	shl    $0x4,%r9d
    7ebe:	47 8d 84 08 80 00 00 	lea    0x80(%r8,%r9,1),%r8d
    7ec5:	00 
    7ec6:	41 c1 f8 08          	sar    $0x8,%r8d
    7eca:	41 83 c0 10          	add    $0x10,%r8d
    7ece:	83 ff 01             	cmp    $0x1,%edi
    7ed1:	0f 8f c9 1d 00 00    	jg     9ca0 <convert_job+0x2e60>
    7ed7:	4c 8b 74 24 a8       	mov    -0x58(%rsp),%r14
    7edc:	01 d3                	add    %edx,%ebx
    7ede:	01 cd                	add    %ecx,%ebp
    7ee0:	41 01 c3             	add    %eax,%r11d
    7ee3:	83 c7 01             	add    $0x1,%edi
    7ee6:	45 88 04 36          	mov    %r8b,(%r14,%rsi,1)
    7eea:	e9 83 fe ff ff       	jmp    7d72 <convert_job+0xf32>
    7eef:	89 d8                	mov    %ebx,%eax
    7ef1:	8d 1c 1b             	lea    (%rbx,%rbx,1),%ebx
    7ef4:	89 5c 24 4c          	mov    %ebx,0x4c(%rsp)
    7ef8:	48 63 d8             	movslq %eax,%rbx
    7efb:	48 89 5c 24 e0       	mov    %rbx,-0x20(%rsp)
    7f00:	39 d0                	cmp    %edx,%eax
    7f02:	0f 8d 56 f3 ff ff    	jge    725e <convert_job+0x41e>
    7f08:	66 44 0f 6f 2d 6f 73 	movdqa 0x736f(%rip),%xmm13        # f280 <__PRETTY_FUNCTION__.4+0xd>
    7f0f:	00 00 
    7f11:	4c 8b 64 24 b8       	mov    -0x48(%rsp),%r12
    7f16:	49 8b 4c 24 38       	mov    0x38(%r12),%rcx
    7f1b:	48 85 c9             	test   %rcx,%rcx
    7f1e:	74 1d                	je     7f3d <convert_job+0x10fd>
    7f20:	8b 5c 24 88          	mov    -0x78(%rsp),%ebx
    7f24:	89 d8                	mov    %ebx,%eax
    7f26:	c1 f8 03             	sar    $0x3,%eax
    7f29:	48 98                	cltq
    7f2b:	0f b6 0c 01          	movzbl (%rcx,%rax,1),%ecx
    7f2f:	89 d8                	mov    %ebx,%eax
    7f31:	83 e0 07             	and    $0x7,%eax
    7f34:	0f a3 c1             	bt     %eax,%ecx
    7f37:	0f 83 b6 19 00 00    	jae    98f3 <convert_job+0x2ab3>
    7f3d:	49 8b 44 24 40       	mov    0x40(%r12),%rax
    7f42:	49 63 7c 24 24       	movslq 0x24(%r12),%rdi
    7f47:	48 85 c0             	test   %rax,%rax
    7f4a:	0f 84 40 1d 00 00    	je     9c90 <convert_job+0x2e50>
    7f50:	48 8b 4c 24 e0       	mov    -0x20(%rsp),%rcx
    7f55:	48 c1 e1 04          	shl    $0x4,%rcx
    7f59:	48 01 c8             	add    %rcx,%rax
    7f5c:	8b 08                	mov    (%rax),%ecx
    7f5e:	8b 68 04             	mov    0x4(%rax),%ebp
    7f61:	4c 63 44 24 4c       	movslq 0x4c(%rsp),%r8
    7f66:	49 63 74 24 20       	movslq 0x20(%r12),%rsi
    7f6b:	4d 8b 0c 24          	mov    (%r12),%r9
    7f6f:	4c 89 c0             	mov    %r8,%rax
    7f72:	4d 89 c3             	mov    %r8,%r11
    7f75:	48 0f af c6          	imul   %rsi,%rax
    7f79:	4c 0f af df          	imul   %rdi,%r11
    7f7d:	48 89 44 24 e8       	mov    %rax,-0x18(%rsp)
    7f82:	4c 01 c8             	add    %r9,%rax
    7f85:	48 89 44 24 f0       	mov    %rax,-0x10(%rsp)
    7f8a:	41 8d 40 01          	lea    0x1(%r8),%eax
    7f8e:	48 98                	cltq
    7f90:	48 0f af f0          	imul   %rax,%rsi
    7f94:	48 0f af c7          	imul   %rdi,%rax
    7f98:	49 8d 1c 31          	lea    (%r9,%rsi,1),%rbx
    7f9c:	48 89 74 24 f8       	mov    %rsi,-0x8(%rsp)
    7fa1:	49 8b 74 24 08       	mov    0x8(%r12),%rsi
    7fa6:	48 89 44 24 a8       	mov    %rax,-0x58(%rsp)
    7fab:	4c 8d 2c 06          	lea    (%rsi,%rax,1),%r13
    7faf:	48 8b 44 24 e0       	mov    -0x20(%rsp),%rax
    7fb4:	48 89 1c 24          	mov    %rbx,(%rsp)
    7fb8:	4a 8d 1c 1e          	lea    (%rsi,%r11,1),%rbx
    7fbc:	48 89 5c 24 90       	mov    %rbx,-0x70(%rsp)
    7fc1:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7fc6:	48 0f af c7          	imul   %rdi,%rax
    7fca:	48 89 44 24 b0       	mov    %rax,-0x50(%rsp)
    7fcf:	39 cd                	cmp    %ecx,%ebp
    7fd1:	0f 8e 1c 19 00 00    	jle    98f3 <convert_job+0x2ab3>
    7fd7:	8d 45 ff             	lea    -0x1(%rbp),%eax
    7fda:	29 c8                	sub    %ecx,%eax
    7fdc:	89 44 24 38          	mov    %eax,0x38(%rsp)
    7fe0:	83 f8 0f             	cmp    $0xf,%eax
    7fe3:	0f 86 29 1b 00 00    	jbe    9b12 <convert_job+0x2cd2>
    7fe9:	4c 8b 74 24 e8       	mov    -0x18(%rsp),%r14
    7fee:	41 89 c2             	mov    %eax,%r10d
    7ff1:	48 63 c1             	movslq %ecx,%rax
    7ff4:	48 8d 14 85 00 00 00 	lea    0x0(,%rax,4),%rdx
    7ffb:	00 
    7ffc:	41 d1 ea             	shr    $1,%r10d
    7fff:	49 01 c3             	add    %rax,%r11
    8002:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
    8007:	49 01 d6             	add    %rdx,%r14
    800a:	41 8d 52 01          	lea    0x1(%r10),%edx
    800e:	4c 8d 3c d5 00 00 00 	lea    0x0(,%rdx,8),%r15
    8015:	00 
    8016:	48 01 d2             	add    %rdx,%rdx
    8019:	4c 89 5c 24 30       	mov    %r11,0x30(%rsp)
    801e:	4f 8d 44 37 ff       	lea    -0x1(%r15,%r14,1),%r8
    8023:	4c 89 7c 24 d8       	mov    %r15,-0x28(%rsp)
    8028:	4d 01 ce             	add    %r9,%r14
    802b:	4f 8d 3c 01          	lea    (%r9,%r8,1),%r15
    802f:	4e 8d 04 1a          	lea    (%rdx,%r11,1),%r8
    8033:	4c 89 74 24 98       	mov    %r14,-0x68(%rsp)
    8038:	4c 89 7c 24 c8       	mov    %r15,-0x38(%rsp)
    803d:	4e 8d 3c 1e          	lea    (%rsi,%r11,1),%r15
    8041:	4e 8d 1c 06          	lea    (%rsi,%r8,1),%r11
    8045:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    804a:	4c 8b 5c 24 a8       	mov    -0x58(%rsp),%r11
    804f:	49 01 c3             	add    %rax,%r11
    8052:	4d 8d 04 13          	lea    (%r11,%rdx,1),%r8
    8056:	4e 8d 34 1e          	lea    (%rsi,%r11,1),%r14
    805a:	4c 89 5c 24 28       	mov    %r11,0x28(%rsp)
    805f:	4c 89 74 24 b8       	mov    %r14,-0x48(%rsp)
    8064:	4e 8d 34 06          	lea    (%rsi,%r8,1),%r14
    8068:	4c 8b 44 24 b0       	mov    -0x50(%rsp),%r8
    806d:	49 01 c0             	add    %rax,%r8
    8070:	4c 01 c2             	add    %r8,%rdx
    8073:	4e 8d 1c 03          	lea    (%rbx,%r8,1),%r11
    8077:	4c 89 44 24 50       	mov    %r8,0x50(%rsp)
    807c:	4c 8d 04 13          	lea    (%rbx,%rdx,1),%r8
    8080:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    8085:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    808a:	4c 8b 44 24 f8       	mov    -0x8(%rsp),%r8
    808f:	4c 01 c2             	add    %r8,%rdx
    8092:	4d 8d 04 11          	lea    (%r9,%rdx,1),%r8
    8096:	4c 89 44 24 a8       	mov    %r8,-0x58(%rsp)
    809b:	4c 8b 44 24 d8       	mov    -0x28(%rsp),%r8
    80a0:	4a 8d 54 02 ff       	lea    -0x1(%rdx,%r8,1),%rdx
    80a5:	4d 8d 04 11          	lea    (%r9,%rdx,1),%r8
    80a9:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
    80ae:	4c 89 44 24 d8       	mov    %r8,-0x28(%rsp)
    80b3:	4c 8d 44 16 02       	lea    0x2(%rsi,%rdx,1),%r8
    80b8:	4c 89 da             	mov    %r11,%rdx
    80bb:	4c 29 c2             	sub    %r8,%rdx
    80be:	48 83 c2 01          	add    $0x1,%rdx
    80c2:	48 83 fa 1e          	cmp    $0x1e,%rdx
    80c6:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    80cb:	0f 97 44 24 58       	seta   0x58(%rsp)
    80d0:	4c 8d 44 16 02       	lea    0x2(%rsi,%rdx,1),%r8
    80d5:	4c 89 da             	mov    %r11,%rdx
    80d8:	4c 29 c2             	sub    %r8,%rdx
    80db:	48 83 c2 01          	add    $0x1,%rdx
    80df:	48 83 fa 1e          	cmp    $0x1e,%rdx
    80e3:	0f 97 c2             	seta   %dl
    80e6:	48 83 ef 01          	sub    $0x1,%rdi
    80ea:	22 54 24 58          	and    0x58(%rsp),%dl
    80ee:	4c 89 74 24 58       	mov    %r14,0x58(%rsp)
    80f3:	48 83 ff 1e          	cmp    $0x1e,%rdi
    80f7:	40 0f 97 c7          	seta   %dil
    80fb:	21 fa                	and    %edi,%edx
    80fd:	48 8b 7c 24 c8       	mov    -0x38(%rsp),%rdi
    8102:	41 89 d0             	mov    %edx,%r8d
    8105:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    810a:	48 39 54 24 98       	cmp    %rdx,-0x68(%rsp)
    810f:	0f 93 c2             	setae  %dl
    8112:	49 39 ff             	cmp    %rdi,%r15
    8115:	40 0f 93 c7          	setae  %dil
    8119:	09 fa                	or     %edi,%edx
    811b:	48 8b 7c 24 c8       	mov    -0x38(%rsp),%rdi
    8120:	41 21 d0             	and    %edx,%r8d
    8123:	4c 39 74 24 98       	cmp    %r14,-0x68(%rsp)
    8128:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    812d:	0f 93 c2             	setae  %dl
    8130:	48 39 7c 24 b8       	cmp    %rdi,-0x48(%rsp)
    8135:	40 0f 93 c7          	setae  %dil
    8139:	09 fa                	or     %edi,%edx
    813b:	48 8b 7c 24 c8       	mov    -0x38(%rsp),%rdi
    8140:	41 21 d0             	and    %edx,%r8d
    8143:	4c 39 74 24 98       	cmp    %r14,-0x68(%rsp)
    8148:	0f 93 c2             	setae  %dl
    814b:	49 39 fb             	cmp    %rdi,%r11
    814e:	40 0f 93 c7          	setae  %dil
    8152:	09 fa                	or     %edi,%edx
    8154:	41 21 d0             	and    %edx,%r8d
    8157:	48 8b 54 24 d8       	mov    -0x28(%rsp),%rdx
    815c:	4c 8b 74 24 18       	mov    0x18(%rsp),%r14
    8161:	49 39 d7             	cmp    %rdx,%r15
    8164:	0f 93 c2             	setae  %dl
    8167:	4c 39 74 24 a8       	cmp    %r14,-0x58(%rsp)
    816c:	4c 8b 74 24 58       	mov    0x58(%rsp),%r14
    8171:	40 0f 93 c7          	setae  %dil
    8175:	09 fa                	or     %edi,%edx
    8177:	48 8b 7c 24 d8       	mov    -0x28(%rsp),%rdi
    817c:	41 21 d0             	and    %edx,%r8d
    817f:	4c 39 74 24 a8       	cmp    %r14,-0x58(%rsp)
    8184:	0f 93 c2             	setae  %dl
    8187:	48 39 7c 24 b8       	cmp    %rdi,-0x48(%rsp)
    818c:	40 0f 93 c7          	setae  %dil
    8190:	09 fa                	or     %edi,%edx
    8192:	41 84 d0             	test   %dl,%r8b
    8195:	0f 84 7a 19 00 00    	je     9b15 <convert_job+0x2cd5>
    819b:	4c 8b 44 24 d8       	mov    -0x28(%rsp),%r8
    81a0:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    81a5:	4c 39 74 24 a8       	cmp    %r14,-0x58(%rsp)
    81aa:	40 0f 93 c7          	setae  %dil
    81ae:	4d 39 c3             	cmp    %r8,%r11
    81b1:	0f 93 c2             	setae  %dl
    81b4:	40 08 fa             	or     %dil,%dl
    81b7:	0f 84 58 19 00 00    	je     9b15 <convert_job+0x2cd5>
    81bd:	44 8b 44 24 38       	mov    0x38(%rsp),%r8d
    81c2:	41 83 f8 1f          	cmp    $0x1f,%r8d
    81c6:	0f 86 b8 1b 00 00    	jbe    9d84 <convert_job+0x2f44>
    81cc:	41 c1 e8 05          	shr    $0x5,%r8d
    81d0:	48 8b 54 24 98       	mov    -0x68(%rsp),%rdx
    81d5:	4c 8b 74 24 b8       	mov    -0x48(%rsp),%r14
    81da:	44 89 44 24 d8       	mov    %r8d,-0x28(%rsp)
    81df:	49 c1 e0 05          	shl    $0x5,%r8
    81e3:	48 8b 7c 24 a8       	mov    -0x58(%rsp),%rdi
    81e8:	4c 89 44 24 a8       	mov    %r8,-0x58(%rsp)
    81ed:	45 31 c0             	xor    %r8d,%r8d
    81f0:	f3 0f 6f 1a          	movdqu (%rdx),%xmm3
    81f4:	f3 0f 6f 42 10       	movdqu 0x10(%rdx),%xmm0
    81f9:	66 41 0f 6f f5       	movdqa %xmm13,%xmm6
    81fe:	66 45 0f 6f c5       	movdqa %xmm13,%xmm8
    8203:	f3 0f 6f 52 20       	movdqu 0x20(%rdx),%xmm2
    8208:	f3 0f 6f 4a 40       	movdqu 0x40(%rdx),%xmm1
    820d:	66 45 0f 6f d5       	movdqa %xmm13,%xmm10
    8212:	66 45 0f 6f cd       	movdqa %xmm13,%xmm9
    8217:	66 41 0f db c5       	pand   %xmm13,%xmm0
    821c:	66 41 0f db dd       	pand   %xmm13,%xmm3
    8221:	f3 0f 6f 62 70       	movdqu 0x70(%rdx),%xmm4
    8226:	f3 0f 6f 7a 70       	movdqu 0x70(%rdx),%xmm7
    822b:	66 0f 67 d8          	packuswb %xmm0,%xmm3
    822f:	f3 0f 6f 42 30       	movdqu 0x30(%rdx),%xmm0
    8234:	66 41 0f db d5       	pand   %xmm13,%xmm2
    8239:	66 41 0f db cd       	pand   %xmm13,%xmm1
    823e:	66 41 0f db e5       	pand   %xmm13,%xmm4
    8243:	66 0f db f3          	pand   %xmm3,%xmm6
    8247:	66 44 0f 6f 1d e0 70 	movdqa 0x70e0(%rip),%xmm11        # f330 <__PRETTY_FUNCTION__.4+0xbd>
    824e:	00 00 
    8250:	48 83 ef 80          	sub    $0xffffffffffffff80,%rdi
    8254:	66 41 0f db c5       	pand   %xmm13,%xmm0
    8259:	66 0f 71 d3 08       	psrlw  $0x8,%xmm3
    825e:	48 83 ea 80          	sub    $0xffffffffffffff80,%rdx
    8262:	66 0f 67 d0          	packuswb %xmm0,%xmm2
    8266:	f3 0f 6f 42 d0       	movdqu -0x30(%rdx),%xmm0
    826b:	66 0f 6f eb          	movdqa %xmm3,%xmm5
    826f:	66 41 0f 6f dd       	movdqa %xmm13,%xmm3
    8274:	66 0f 71 d7 08       	psrlw  $0x8,%xmm7
    8279:	66 41 0f db c5       	pand   %xmm13,%xmm0
    827e:	66 0f 67 c8          	packuswb %xmm0,%xmm1
    8282:	f3 0f 6f 42 e0       	movdqu -0x20(%rdx),%xmm0
    8287:	66 0f db d9          	pand   %xmm1,%xmm3
    828b:	66 0f 71 d1 08       	psrlw  $0x8,%xmm1
    8290:	66 41 0f db c5       	pand   %xmm13,%xmm0
    8295:	66 0f 67 c4          	packuswb %xmm4,%xmm0
    8299:	66 41 0f 6f e5       	movdqa %xmm13,%xmm4
    829e:	66 0f db e2          	pand   %xmm2,%xmm4
    82a2:	66 0f 71 d2 08       	psrlw  $0x8,%xmm2
    82a7:	66 0f 67 ea          	packuswb %xmm2,%xmm5
    82ab:	66 41 0f 6f d5       	movdqa %xmm13,%xmm2
    82b0:	66 0f 67 f4          	packuswb %xmm4,%xmm6
    82b4:	66 0f db d0          	pand   %xmm0,%xmm2
    82b8:	66 0f 6f e1          	movdqa %xmm1,%xmm4
    82bc:	f3 0f 6f 4a b0       	movdqu -0x50(%rdx),%xmm1
    82c1:	66 44 0f db c6       	pand   %xmm6,%xmm8
    82c6:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    82cb:	66 0f 67 da          	packuswb %xmm2,%xmm3
    82cf:	f3 0f 6f 52 80       	movdqu -0x80(%rdx),%xmm2
    82d4:	66 0f 67 e0          	packuswb %xmm0,%xmm4
    82d8:	f3 0f 6f 42 90       	movdqu -0x70(%rdx),%xmm0
    82dd:	66 0f 71 d1 08       	psrlw  $0x8,%xmm1
    82e2:	66 0f 71 d2 08       	psrlw  $0x8,%xmm2
    82e7:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    82ec:	66 0f 67 d0          	packuswb %xmm0,%xmm2
    82f0:	f3 0f 6f 42 a0       	movdqu -0x60(%rdx),%xmm0
    82f5:	66 41 0f db d5       	pand   %xmm13,%xmm2
    82fa:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    82ff:	66 0f 67 c1          	packuswb %xmm1,%xmm0
    8303:	f3 0f 6f 4a d0       	movdqu -0x30(%rdx),%xmm1
    8308:	66 41 0f db c5       	pand   %xmm13,%xmm0
    830d:	66 0f 67 d0          	packuswb %xmm0,%xmm2
    8311:	f3 0f 6f 42 c0       	movdqu -0x40(%rdx),%xmm0
    8316:	66 0f 71 d1 08       	psrlw  $0x8,%xmm1
    831b:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    8320:	66 0f 67 c1          	packuswb %xmm1,%xmm0
    8324:	f3 0f 6f 4a e0       	movdqu -0x20(%rdx),%xmm1
    8329:	66 41 0f db c5       	pand   %xmm13,%xmm0
    832e:	66 0f 71 d1 08       	psrlw  $0x8,%xmm1
    8333:	66 0f 67 cf          	packuswb %xmm7,%xmm1
    8337:	66 41 0f 6f fd       	movdqa %xmm13,%xmm7
    833c:	66 41 0f db cd       	pand   %xmm13,%xmm1
    8341:	66 0f db fa          	pand   %xmm2,%xmm7
    8345:	66 0f 67 c1          	packuswb %xmm1,%xmm0
    8349:	66 0f 71 d2 08       	psrlw  $0x8,%xmm2
    834e:	66 41 0f 6f cd       	movdqa %xmm13,%xmm1
    8353:	66 0f db cb          	pand   %xmm3,%xmm1
    8357:	66 0f 71 d3 08       	psrlw  $0x8,%xmm3
    835c:	66 44 0f 67 c1       	packuswb %xmm1,%xmm8
    8361:	66 0f 6f ce          	movdqa %xmm6,%xmm1
    8365:	66 41 0f 6f f5       	movdqa %xmm13,%xmm6
    836a:	66 0f 71 d1 08       	psrlw  $0x8,%xmm1
    836f:	66 0f db f5          	pand   %xmm5,%xmm6
    8373:	66 45 0f 6f f8       	movdqa %xmm8,%xmm15
    8378:	66 0f 67 cb          	packuswb %xmm3,%xmm1
    837c:	66 0f 71 d5 08       	psrlw  $0x8,%xmm5
    8381:	66 41 0f 6f dd       	movdqa %xmm13,%xmm3
    8386:	66 0f db d8          	pand   %xmm0,%xmm3
    838a:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    838f:	66 0f 67 fb          	packuswb %xmm3,%xmm7
    8393:	66 0f 6f da          	movdqa %xmm2,%xmm3
    8397:	66 0f 6f 15 81 6f 00 	movdqa 0x6f81(%rip),%xmm2        # f320 <__PRETTY_FUNCTION__.4+0xad>
    839e:	00 
    839f:	66 0f 67 d8          	packuswb %xmm0,%xmm3
    83a3:	66 41 0f 6f c5       	movdqa %xmm13,%xmm0
    83a8:	66 44 0f 6f e7       	movdqa %xmm7,%xmm12
    83ad:	66 0f db c4          	pand   %xmm4,%xmm0
    83b1:	66 0f 71 d4 08       	psrlw  $0x8,%xmm4
    83b6:	66 0f 67 f0          	packuswb %xmm0,%xmm6
    83ba:	66 0f 67 ec          	packuswb %xmm4,%xmm5
    83be:	66 0f ef e4          	pxor   %xmm4,%xmm4
    83c2:	66 0f 6f c6          	movdqa %xmm6,%xmm0
    83c6:	66 44 0f 60 e4       	punpcklbw %xmm4,%xmm12
    83cb:	66 44 0f 60 fc       	punpcklbw %xmm4,%xmm15
    83d0:	66 0f 60 c4          	punpcklbw %xmm4,%xmm0
    83d4:	66 41 0f d5 d4       	pmullw %xmm12,%xmm2
    83d9:	66 0f 68 fc          	punpckhbw %xmm4,%xmm7
    83dd:	66 44 0f d5 d8       	pmullw %xmm0,%xmm11
    83e2:	0f 29 44 24 98       	movaps %xmm0,-0x68(%rsp)
    83e7:	66 0f 68 f4          	punpckhbw %xmm4,%xmm6
    83eb:	66 0f 6f 05 cd 6e 00 	movdqa 0x6ecd(%rip),%xmm0        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    83f2:	00 
    83f3:	0f 29 7c 24 b8       	movaps %xmm7,-0x48(%rsp)
    83f8:	0f 29 74 24 c8       	movaps %xmm6,-0x38(%rsp)
    83fd:	66 41 0f fd d3       	paddw  %xmm11,%xmm2
    8402:	66 44 0f 6f 1d 05 6f 	movdqa 0x6f05(%rip),%xmm11        # f310 <__PRETTY_FUNCTION__.4+0x9d>
    8409:	00 00 
    840b:	66 45 0f d5 df       	pmullw %xmm15,%xmm11
    8410:	66 41 0f fd c3       	paddw  %xmm11,%xmm0
    8415:	66 44 0f 6f 1d 02 6f 	movdqa 0x6f02(%rip),%xmm11        # f320 <__PRETTY_FUNCTION__.4+0xad>
    841c:	00 00 
    841e:	66 0f fd d0          	paddw  %xmm0,%xmm2
    8422:	66 44 0f d5 df       	pmullw %xmm7,%xmm11
    8427:	66 0f 71 d2 08       	psrlw  $0x8,%xmm2
    842c:	66 0f 6f fc          	movdqa %xmm4,%xmm7
    8430:	66 0f 6f 25 f8 6e 00 	movdqa 0x6ef8(%rip),%xmm4        # f330 <__PRETTY_FUNCTION__.4+0xbd>
    8437:	00 
    8438:	66 44 0f 68 c7       	punpckhbw %xmm7,%xmm8
    843d:	66 41 0f db d5       	pand   %xmm13,%xmm2
    8442:	66 44 0f 6f f7       	movdqa %xmm7,%xmm14
    8447:	66 0f d5 e6          	pmullw %xmm6,%xmm4
    844b:	66 41 0f 6f c3       	movdqa %xmm11,%xmm0
    8450:	66 44 0f 6f 1d d7 6e 	movdqa 0x6ed7(%rip),%xmm11        # f330 <__PRETTY_FUNCTION__.4+0xbd>
    8457:	00 00 
    8459:	66 0f fd c4          	paddw  %xmm4,%xmm0
    845d:	66 0f 6f 25 ab 6e 00 	movdqa 0x6eab(%rip),%xmm4        # f310 <__PRETTY_FUNCTION__.4+0x9d>
    8464:	00 
    8465:	66 41 0f d5 e0       	pmullw %xmm8,%xmm4
    846a:	66 0f fd 25 4e 6e 00 	paddw  0x6e4e(%rip),%xmm4        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    8471:	00 
    8472:	66 0f fd c4          	paddw  %xmm4,%xmm0
    8476:	66 0f 6f e3          	movdqa %xmm3,%xmm4
    847a:	66 41 0f 68 de       	punpckhbw %xmm14,%xmm3
    847f:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    8484:	66 0f 60 e7          	punpcklbw %xmm7,%xmm4
    8488:	66 41 0f db c5       	pand   %xmm13,%xmm0
    848d:	66 0f 67 d0          	packuswb %xmm0,%xmm2
    8491:	66 0f 6f c4          	movdqa %xmm4,%xmm0
    8495:	66 0f 6f 25 83 6e 00 	movdqa 0x6e83(%rip),%xmm4        # f320 <__PRETTY_FUNCTION__.4+0xad>
    849c:	00 
    849d:	66 0f fc 15 0b 6e 00 	paddb  0x6e0b(%rip),%xmm2        # f2b0 <__PRETTY_FUNCTION__.4+0x3d>
    84a4:	00 
    84a5:	66 0f d5 e0          	pmullw %xmm0,%xmm4
    84a9:	66 41 0f fd c4       	paddw  %xmm12,%xmm0
    84ae:	66 0f 6f f4          	movdqa %xmm4,%xmm6
    84b2:	66 0f 6f e5          	movdqa %xmm5,%xmm4
    84b6:	66 41 0f 68 ee       	punpckhbw %xmm14,%xmm5
    84bb:	66 0f 60 e7          	punpcklbw %xmm7,%xmm4
    84bf:	66 44 0f d5 dc       	pmullw %xmm4,%xmm11
    84c4:	0f 29 64 24 08       	movaps %xmm4,0x8(%rsp)
    84c9:	66 41 0f fd f3       	paddw  %xmm11,%xmm6
    84ce:	66 44 0f 6f d9       	movdqa %xmm1,%xmm11
    84d3:	66 41 0f 68 ce       	punpckhbw %xmm14,%xmm1
    84d8:	66 44 0f 60 df       	punpcklbw %xmm7,%xmm11
    84dd:	66 41 0f 6f e3       	movdqa %xmm11,%xmm4
    84e2:	66 44 0f 6f 1d 25 6e 	movdqa 0x6e25(%rip),%xmm11        # f310 <__PRETTY_FUNCTION__.4+0x9d>
    84e9:	00 00 
    84eb:	66 0f 6f 3d cd 6d 00 	movdqa 0x6dcd(%rip),%xmm7        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    84f2:	00 
    84f3:	0f 29 5c 24 18       	movaps %xmm3,0x18(%rsp)
    84f8:	0f 29 6c 24 38       	movaps %xmm5,0x38(%rsp)
    84fd:	66 44 0f d5 dc       	pmullw %xmm4,%xmm11
    8502:	66 41 0f fd e7       	paddw  %xmm15,%xmm4
    8507:	66 41 0f fd fb       	paddw  %xmm11,%xmm7
    850c:	66 44 0f 6f 1d 0b 6e 	movdqa 0x6e0b(%rip),%xmm11        # f320 <__PRETTY_FUNCTION__.4+0xad>
    8513:	00 00 
    8515:	66 0f fd f7          	paddw  %xmm7,%xmm6
    8519:	66 44 0f d5 db       	pmullw %xmm3,%xmm11
    851e:	66 0f 71 d6 08       	psrlw  $0x8,%xmm6
    8523:	66 41 0f 6f db       	movdqa %xmm11,%xmm3
    8528:	66 44 0f 6f 1d ff 6d 	movdqa 0x6dff(%rip),%xmm11        # f330 <__PRETTY_FUNCTION__.4+0xbd>
    852f:	00 00 
    8531:	66 44 0f d5 dd       	pmullw %xmm5,%xmm11
    8536:	66 0f 6f 2d 82 6d 00 	movdqa 0x6d82(%rip),%xmm5        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    853d:	00 
    853e:	66 41 0f fd db       	paddw  %xmm11,%xmm3
    8543:	66 44 0f 6f 1d c4 6d 	movdqa 0x6dc4(%rip),%xmm11        # f310 <__PRETTY_FUNCTION__.4+0x9d>
    854a:	00 00 
    854c:	66 44 0f d5 d9       	pmullw %xmm1,%xmm11
    8551:	66 41 0f fd c8       	paddw  %xmm8,%xmm1
    8556:	66 41 0f fd eb       	paddw  %xmm11,%xmm5
    855b:	66 44 0f 6f de       	movdqa %xmm6,%xmm11
    8560:	66 0f fd dd          	paddw  %xmm5,%xmm3
    8564:	66 45 0f db dd       	pand   %xmm13,%xmm11
    8569:	66 0f 71 d3 08       	psrlw  $0x8,%xmm3
    856e:	66 41 0f 6f eb       	movdqa %xmm11,%xmm5
    8573:	66 44 0f 6f 1d 34 6d 	movdqa 0x6d34(%rip),%xmm11        # f2b0 <__PRETTY_FUNCTION__.4+0x3d>
    857a:	00 00 
    857c:	66 41 0f db dd       	pand   %xmm13,%xmm3
    8581:	66 0f 67 eb          	packuswb %xmm3,%xmm5
    8585:	66 44 0f fc dd       	paddb  %xmm5,%xmm11
    858a:	66 41 0f 6f db       	movdqa %xmm11,%xmm3
    858f:	66 44 0f 6f da       	movdqa %xmm2,%xmm11
    8594:	66 44 0f 60 db       	punpcklbw %xmm3,%xmm11
    8599:	66 0f 68 d3          	punpckhbw %xmm3,%xmm2
    859d:	47 0f 11 1c 07       	movups %xmm11,(%r15,%r8,1)
    85a2:	66 45 0f 6f dd       	movdqa %xmm13,%xmm11
    85a7:	43 0f 11 54 07 10    	movups %xmm2,0x10(%r15,%r8,1)
    85ad:	f3 0f 6f 57 80       	movdqu -0x80(%rdi),%xmm2
    85b2:	66 41 0f db d5       	pand   %xmm13,%xmm2
    85b7:	66 0f 6f da          	movdqa %xmm2,%xmm3
    85bb:	f3 0f 6f 57 90       	movdqu -0x70(%rdi),%xmm2
    85c0:	66 41 0f db d5       	pand   %xmm13,%xmm2
    85c5:	66 0f 67 da          	packuswb %xmm2,%xmm3
    85c9:	f3 0f 6f 57 a0       	movdqu -0x60(%rdi),%xmm2
    85ce:	66 41 0f db d5       	pand   %xmm13,%xmm2
    85d3:	66 0f 6f fa          	movdqa %xmm2,%xmm7
    85d7:	f3 0f 6f 57 b0       	movdqu -0x50(%rdi),%xmm2
    85dc:	66 41 0f db d5       	pand   %xmm13,%xmm2
    85e1:	66 0f 67 fa          	packuswb %xmm2,%xmm7
    85e5:	f3 0f 6f 57 c0       	movdqu -0x40(%rdi),%xmm2
    85ea:	66 44 0f db cf       	pand   %xmm7,%xmm9
    85ef:	66 0f 71 d7 08       	psrlw  $0x8,%xmm7
    85f4:	66 41 0f db d5       	pand   %xmm13,%xmm2
    85f9:	66 0f 6f f2          	movdqa %xmm2,%xmm6
    85fd:	f3 0f 6f 57 d0       	movdqu -0x30(%rdi),%xmm2
    8602:	66 41 0f db d5       	pand   %xmm13,%xmm2
    8607:	66 0f 67 f2          	packuswb %xmm2,%xmm6
    860b:	f3 0f 6f 57 e0       	movdqu -0x20(%rdi),%xmm2
    8610:	66 44 0f db d6       	pand   %xmm6,%xmm10
    8615:	66 0f 71 d6 08       	psrlw  $0x8,%xmm6
    861a:	66 41 0f db d5       	pand   %xmm13,%xmm2
    861f:	66 0f 6f ea          	movdqa %xmm2,%xmm5
    8623:	f3 0f 6f 57 f0       	movdqu -0x10(%rdi),%xmm2
    8628:	66 41 0f db d5       	pand   %xmm13,%xmm2
    862d:	66 0f 67 ea          	packuswb %xmm2,%xmm5
    8631:	66 41 0f 6f d5       	movdqa %xmm13,%xmm2
    8636:	66 44 0f db dd       	pand   %xmm5,%xmm11
    863b:	66 0f 71 d5 08       	psrlw  $0x8,%xmm5
    8640:	66 0f db d3          	pand   %xmm3,%xmm2
    8644:	66 45 0f 67 d3       	packuswb %xmm11,%xmm10
    8649:	f3 44 0f 6f 5f 80    	movdqu -0x80(%rdi),%xmm11
    864f:	66 0f 71 d3 08       	psrlw  $0x8,%xmm3
    8654:	66 0f 67 f5          	packuswb %xmm5,%xmm6
    8658:	66 0f 67 df          	packuswb %xmm7,%xmm3
    865c:	66 41 0f 67 d1       	packuswb %xmm9,%xmm2
    8661:	66 41 0f 71 d3 08    	psrlw  $0x8,%xmm11
    8667:	66 41 0f 6f fb       	movdqa %xmm11,%xmm7
    866c:	f3 44 0f 6f 5f 90    	movdqu -0x70(%rdi),%xmm11
    8672:	66 44 0f 6f cf       	movdqa %xmm7,%xmm9
    8677:	66 41 0f 71 d3 08    	psrlw  $0x8,%xmm11
    867d:	66 45 0f 67 cb       	packuswb %xmm11,%xmm9
    8682:	f3 44 0f 6f 5f a0    	movdqu -0x60(%rdi),%xmm11
    8688:	66 41 0f 71 d3 08    	psrlw  $0x8,%xmm11
    868e:	66 41 0f 6f fb       	movdqa %xmm11,%xmm7
    8693:	f3 44 0f 6f 5f b0    	movdqu -0x50(%rdi),%xmm11
    8699:	66 41 0f 71 d3 08    	psrlw  $0x8,%xmm11
    869f:	66 41 0f 67 fb       	packuswb %xmm11,%xmm7
    86a4:	66 45 0f 6f d9       	movdqa %xmm9,%xmm11
    86a9:	f3 44 0f 6f 4f c0    	movdqu -0x40(%rdi),%xmm9
    86af:	66 45 0f db dd       	pand   %xmm13,%xmm11
    86b4:	66 41 0f db fd       	pand   %xmm13,%xmm7
    86b9:	66 41 0f 6f eb       	movdqa %xmm11,%xmm5
    86be:	f3 44 0f 6f 5f d0    	movdqu -0x30(%rdi),%xmm11
    86c4:	66 41 0f 71 d1 08    	psrlw  $0x8,%xmm9
    86ca:	66 0f 67 ef          	packuswb %xmm7,%xmm5
    86ce:	66 41 0f 71 d3 08    	psrlw  $0x8,%xmm11
    86d4:	66 41 0f 6f fb       	movdqa %xmm11,%xmm7
    86d9:	66 45 0f 6f d9       	movdqa %xmm9,%xmm11
    86de:	f3 44 0f 6f 4f e0    	movdqu -0x20(%rdi),%xmm9
    86e4:	66 44 0f 67 df       	packuswb %xmm7,%xmm11
    86e9:	66 41 0f 71 d1 08    	psrlw  $0x8,%xmm9
    86ef:	66 41 0f 6f f9       	movdqa %xmm9,%xmm7
    86f4:	f3 44 0f 6f 4f f0    	movdqu -0x10(%rdi),%xmm9
    86fa:	66 41 0f 71 d1 08    	psrlw  $0x8,%xmm9
    8700:	66 41 0f 67 f9       	packuswb %xmm9,%xmm7
    8705:	66 45 0f 6f cb       	movdqa %xmm11,%xmm9
    870a:	66 45 0f 6f dd       	movdqa %xmm13,%xmm11
    870f:	66 44 0f db da       	pand   %xmm2,%xmm11
    8714:	66 41 0f db fd       	pand   %xmm13,%xmm7
    8719:	66 45 0f db cd       	pand   %xmm13,%xmm9
    871e:	66 44 0f 67 cf       	packuswb %xmm7,%xmm9
    8723:	66 0f 71 d2 08       	psrlw  $0x8,%xmm2
    8728:	66 41 0f 6f fb       	movdqa %xmm11,%xmm7
    872d:	66 45 0f 6f dd       	movdqa %xmm13,%xmm11
    8732:	66 45 0f db da       	pand   %xmm10,%xmm11
    8737:	66 41 0f 71 d2 08    	psrlw  $0x8,%xmm10
    873d:	66 41 0f 67 fb       	packuswb %xmm11,%xmm7
    8742:	66 41 0f 67 d2       	packuswb %xmm10,%xmm2
    8747:	66 45 0f 6f dd       	movdqa %xmm13,%xmm11
    874c:	66 45 0f 6f d5       	movdqa %xmm13,%xmm10
    8751:	66 45 0f db d9       	pand   %xmm9,%xmm11
    8756:	66 44 0f db d5       	pand   %xmm5,%xmm10
    875b:	66 41 0f 71 d1 08    	psrlw  $0x8,%xmm9
    8761:	66 0f 71 d5 08       	psrlw  $0x8,%xmm5
    8766:	66 45 0f 67 d3       	packuswb %xmm11,%xmm10
    876b:	66 45 0f 6f dd       	movdqa %xmm13,%xmm11
    8770:	66 41 0f 67 e9       	packuswb %xmm9,%xmm5
    8775:	66 45 0f 6f cd       	movdqa %xmm13,%xmm9
    877a:	66 44 0f db de       	pand   %xmm6,%xmm11
    877f:	66 44 0f db cb       	pand   %xmm3,%xmm9
    8784:	66 0f 71 d6 08       	psrlw  $0x8,%xmm6
    8789:	66 0f 71 d3 08       	psrlw  $0x8,%xmm3
    878e:	66 45 0f 67 cb       	packuswb %xmm11,%xmm9
    8793:	66 45 0f 6f da       	movdqa %xmm10,%xmm11
    8798:	66 0f 67 de          	packuswb %xmm6,%xmm3
    879c:	66 0f 6f 35 7c 6b 00 	movdqa 0x6b7c(%rip),%xmm6        # f320 <__PRETTY_FUNCTION__.4+0xad>
    87a3:	00 
    87a4:	66 45 0f 60 de       	punpcklbw %xmm14,%xmm11
    87a9:	44 0f 29 5c 24 58    	movaps %xmm11,0x58(%rsp)
    87af:	66 41 0f d5 f3       	pmullw %xmm11,%xmm6
    87b4:	66 45 0f 6f d9       	movdqa %xmm9,%xmm11
    87b9:	66 45 0f 60 de       	punpcklbw %xmm14,%xmm11
    87be:	44 0f 29 5c 24 68    	movaps %xmm11,0x68(%rsp)
    87c4:	66 44 0f d5 1d 63 6b 	pmullw 0x6b63(%rip),%xmm11        # f330 <__PRETTY_FUNCTION__.4+0xbd>
    87cb:	00 00 
    87cd:	66 41 0f fd f3       	paddw  %xmm11,%xmm6
    87d2:	66 44 0f 6f df       	movdqa %xmm7,%xmm11
    87d7:	66 45 0f 60 de       	punpcklbw %xmm14,%xmm11
    87dc:	66 45 0f 6f f3       	movdqa %xmm11,%xmm14
    87e1:	66 44 0f 6f 1d 26 6b 	movdqa 0x6b26(%rip),%xmm11        # f310 <__PRETTY_FUNCTION__.4+0x9d>
    87e8:	00 00 
    87ea:	66 45 0f d5 de       	pmullw %xmm14,%xmm11
    87ef:	66 44 0f fd 1d c8 6a 	paddw  0x6ac8(%rip),%xmm11        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    87f6:	00 00 
    87f8:	66 41 0f fd f3       	paddw  %xmm11,%xmm6
    87fd:	66 0f 71 d6 08       	psrlw  $0x8,%xmm6
    8802:	66 44 0f 6f de       	movdqa %xmm6,%xmm11
    8807:	66 41 0f 6f f2       	movdqa %xmm10,%xmm6
    880c:	66 45 0f ef d2       	pxor   %xmm10,%xmm10
    8811:	66 41 0f 68 f2       	punpckhbw %xmm10,%xmm6
    8816:	66 45 0f 68 ca       	punpckhbw %xmm10,%xmm9
    881b:	66 41 0f 68 fa       	punpckhbw %xmm10,%xmm7
    8820:	0f 29 74 24 78       	movaps %xmm6,0x78(%rsp)
    8825:	66 0f d5 35 f3 6a 00 	pmullw 0x6af3(%rip),%xmm6        # f320 <__PRETTY_FUNCTION__.4+0xad>
    882c:	00 
    882d:	44 0f 29 8c 24 88 00 	movaps %xmm9,0x88(%rsp)
    8834:	00 00 
    8836:	66 44 0f d5 0d f1 6a 	pmullw 0x6af1(%rip),%xmm9        # f330 <__PRETTY_FUNCTION__.4+0xbd>
    883d:	00 00 
    883f:	66 41 0f fd f1       	paddw  %xmm9,%xmm6
    8844:	66 44 0f 6f 0d c3 6a 	movdqa 0x6ac3(%rip),%xmm9        # f310 <__PRETTY_FUNCTION__.4+0x9d>
    884b:	00 00 
    884d:	66 44 0f d5 cf       	pmullw %xmm7,%xmm9
    8852:	66 44 0f fd 0d 65 6a 	paddw  0x6a65(%rip),%xmm9        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    8859:	00 00 
    885b:	66 44 0f fd ce       	paddw  %xmm6,%xmm9
    8860:	66 41 0f 6f f3       	movdqa %xmm11,%xmm6
    8865:	66 45 0f 6f da       	movdqa %xmm10,%xmm11
    886a:	66 41 0f 71 d1 08    	psrlw  $0x8,%xmm9
    8870:	66 41 0f db f5       	pand   %xmm13,%xmm6
    8875:	66 45 0f db cd       	pand   %xmm13,%xmm9
    887a:	66 41 0f 67 f1       	packuswb %xmm9,%xmm6
    887f:	66 44 0f 6f cd       	movdqa %xmm5,%xmm9
    8884:	66 0f fc 35 24 6a 00 	paddb  0x6a24(%rip),%xmm6        # f2b0 <__PRETTY_FUNCTION__.4+0x3d>
    888b:	00 
    888c:	66 45 0f 60 ca       	punpcklbw %xmm10,%xmm9
    8891:	44 0f 29 8c 24 98 00 	movaps %xmm9,0x98(%rsp)
    8898:	00 00 
    889a:	66 45 0f 6f d1       	movdqa %xmm9,%xmm10
    889f:	66 44 0f d5 15 78 6a 	pmullw 0x6a78(%rip),%xmm10        # f320 <__PRETTY_FUNCTION__.4+0xad>
    88a6:	00 00 
    88a8:	66 45 0f 6f ca       	movdqa %xmm10,%xmm9
    88ad:	66 44 0f 6f d3       	movdqa %xmm3,%xmm10
    88b2:	66 45 0f 60 d3       	punpcklbw %xmm11,%xmm10
    88b7:	44 0f 29 94 24 a8 00 	movaps %xmm10,0xa8(%rsp)
    88be:	00 00 
    88c0:	66 44 0f d5 15 67 6a 	pmullw 0x6a67(%rip),%xmm10        # f330 <__PRETTY_FUNCTION__.4+0xbd>
    88c7:	00 00 
    88c9:	66 45 0f fd ca       	paddw  %xmm10,%xmm9
    88ce:	66 44 0f 6f d2       	movdqa %xmm2,%xmm10
    88d3:	66 45 0f 60 d3       	punpcklbw %xmm11,%xmm10
    88d8:	66 44 0f 6f 1d 2f 6a 	movdqa 0x6a2f(%rip),%xmm11        # f310 <__PRETTY_FUNCTION__.4+0x9d>
    88df:	00 00 
    88e1:	66 45 0f d5 da       	pmullw %xmm10,%xmm11
    88e6:	66 45 0f fd d6       	paddw  %xmm14,%xmm10
    88eb:	66 44 0f fd 1d cc 69 	paddw  0x69cc(%rip),%xmm11        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    88f2:	00 00 
    88f4:	66 41 0f fd e2       	paddw  %xmm10,%xmm4
    88f9:	66 44 0f 6f fc       	movdqa %xmm4,%xmm15
    88fe:	66 0f 6f 64 24 08    	movdqa 0x8(%rsp),%xmm4
    8904:	66 0f fd 64 24 98    	paddw  -0x68(%rsp),%xmm4
    890a:	66 45 0f fd cb       	paddw  %xmm11,%xmm9
    890f:	66 41 0f 71 d7 02    	psrlw  $0x2,%xmm15
    8915:	66 45 0f ef db       	pxor   %xmm11,%xmm11
    891a:	66 41 0f 68 eb       	punpckhbw %xmm11,%xmm5
    891f:	66 41 0f 71 d1 08    	psrlw  $0x8,%xmm9
    8925:	66 41 0f 68 db       	punpckhbw %xmm11,%xmm3
    892a:	44 0f 29 8c 24 b8 00 	movaps %xmm9,0xb8(%rsp)
    8931:	00 00 
    8933:	66 44 0f 6f db       	movdqa %xmm3,%xmm11
    8938:	66 44 0f 6f cd       	movdqa %xmm5,%xmm9
    893d:	66 0f 6f 1d eb 69 00 	movdqa 0x69eb(%rip),%xmm3        # f330 <__PRETTY_FUNCTION__.4+0xbd>
    8944:	00 
    8945:	66 0f 6f 2d d3 69 00 	movdqa 0x69d3(%rip),%xmm5        # f320 <__PRETTY_FUNCTION__.4+0xad>
    894c:	00 
    894d:	66 41 0f d5 db       	pmullw %xmm11,%xmm3
    8952:	66 41 0f d5 e9       	pmullw %xmm9,%xmm5
    8957:	66 44 0f fd 4c 24 78 	paddw  0x78(%rsp),%xmm9
    895e:	66 0f fd dd          	paddw  %xmm5,%xmm3
    8962:	66 0f ef ed          	pxor   %xmm5,%xmm5
    8966:	66 0f 68 d5          	punpckhbw %xmm5,%xmm2
    896a:	66 0f 6f 2d 9e 69 00 	movdqa 0x699e(%rip),%xmm5        # f310 <__PRETTY_FUNCTION__.4+0x9d>
    8971:	00 
    8972:	66 0f d5 ea          	pmullw %xmm2,%xmm5
    8976:	66 0f fd d7          	paddw  %xmm7,%xmm2
    897a:	66 0f fd 2d 3e 69 00 	paddw  0x693e(%rip),%xmm5        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    8981:	00 
    8982:	66 0f fd ca          	paddw  %xmm2,%xmm1
    8986:	66 0f 6f 94 24 98 00 	movdqa 0x98(%rsp),%xmm2
    898d:	00 00 
    898f:	66 0f fd 54 24 58    	paddw  0x58(%rsp),%xmm2
    8995:	66 0f 71 d1 02       	psrlw  $0x2,%xmm1
    899a:	66 0f fd dd          	paddw  %xmm5,%xmm3
    899e:	66 0f 6f ac 24 b8 00 	movdqa 0xb8(%rsp),%xmm5
    89a5:	00 00 
    89a7:	66 0f 71 d3 08       	psrlw  $0x8,%xmm3
    89ac:	66 0f fd c2          	paddw  %xmm2,%xmm0
    89b0:	66 0f 6f 54 24 18    	movdqa 0x18(%rsp),%xmm2
    89b6:	66 0f fd 54 24 b8    	paddw  -0x48(%rsp),%xmm2
    89bc:	66 41 0f db dd       	pand   %xmm13,%xmm3
    89c1:	66 0f 71 d0 02       	psrlw  $0x2,%xmm0
    89c6:	66 41 0f db ed       	pand   %xmm13,%xmm5
    89cb:	66 0f 67 eb          	packuswb %xmm3,%xmm5
    89cf:	66 0f 6f 1d d9 68 00 	movdqa 0x68d9(%rip),%xmm3        # f2b0 <__PRETTY_FUNCTION__.4+0x3d>
    89d6:	00 
    89d7:	66 41 0f fd d1       	paddw  %xmm9,%xmm2
    89dc:	66 0f 71 d2 02       	psrlw  $0x2,%xmm2
    89e1:	66 0f fc dd          	paddb  %xmm5,%xmm3
    89e5:	66 0f 6f ee          	movdqa %xmm6,%xmm5
    89e9:	66 0f 60 eb          	punpcklbw %xmm3,%xmm5
    89ed:	66 0f 68 f3          	punpckhbw %xmm3,%xmm6
    89f1:	66 41 0f 6f df       	movdqa %xmm15,%xmm3
    89f6:	43 0f 11 2c 06       	movups %xmm5,(%r14,%r8,1)
    89fb:	66 0f 6f ec          	movdqa %xmm4,%xmm5
    89ff:	66 0f 6f a4 24 a8 00 	movdqa 0xa8(%rsp),%xmm4
    8a06:	00 00 
    8a08:	66 0f fd 64 24 68    	paddw  0x68(%rsp),%xmm4
    8a0e:	43 0f 11 74 06 10    	movups %xmm6,0x10(%r14,%r8,1)
    8a14:	66 0f fd ec          	paddw  %xmm4,%xmm5
    8a18:	66 0f 6f 64 24 38    	movdqa 0x38(%rsp),%xmm4
    8a1e:	66 0f fd 64 24 c8    	paddw  -0x38(%rsp),%xmm4
    8a24:	66 44 0f fd 9c 24 88 	paddw  0x88(%rsp),%xmm11
    8a2b:	00 00 00 
    8a2e:	66 0f 71 d5 02       	psrlw  $0x2,%xmm5
    8a33:	66 0f 6f 3d 95 68 00 	movdqa 0x6895(%rip),%xmm7        # f2d0 <__PRETTY_FUNCTION__.4+0x5d>
    8a3a:	00 
    8a3b:	66 0f 6f f4          	movdqa %xmm4,%xmm6
    8a3f:	66 0f 6f 25 99 68 00 	movdqa 0x6899(%rip),%xmm4        # f2e0 <__PRETTY_FUNCTION__.4+0x6d>
    8a46:	00 
    8a47:	66 0f d5 fd          	pmullw %xmm5,%xmm7
    8a4b:	66 41 0f fd f3       	paddw  %xmm11,%xmm6
    8a50:	66 0f d5 e0          	pmullw %xmm0,%xmm4
    8a54:	66 0f 71 d6 02       	psrlw  $0x2,%xmm6
    8a59:	66 0f d5 05 9f 68 00 	pmullw 0x689f(%rip),%xmm0        # f300 <__PRETTY_FUNCTION__.4+0x8d>
    8a60:	00 
    8a61:	66 0f fd fc          	paddw  %xmm4,%xmm7
    8a65:	66 41 0f 6f e7       	movdqa %xmm15,%xmm4
    8a6a:	66 0f 71 f4 03       	psllw  $0x3,%xmm4
    8a6f:	66 41 0f f9 e7       	psubw  %xmm15,%xmm4
    8a74:	66 0f 71 f4 04       	psllw  $0x4,%xmm4
    8a79:	66 0f fd 25 3f 68 00 	paddw  0x683f(%rip),%xmm4        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    8a80:	00 
    8a81:	66 0f fd e7          	paddw  %xmm7,%xmm4
    8a85:	66 0f 6f 3d 43 68 00 	movdqa 0x6843(%rip),%xmm7        # f2d0 <__PRETTY_FUNCTION__.4+0x5d>
    8a8c:	00 
    8a8d:	66 0f 71 e4 08       	psraw  $0x8,%xmm4
    8a92:	66 44 0f 6f c4       	movdqa %xmm4,%xmm8
    8a97:	66 0f 6f 25 41 68 00 	movdqa 0x6841(%rip),%xmm4        # f2e0 <__PRETTY_FUNCTION__.4+0x6d>
    8a9e:	00 
    8a9f:	66 0f d5 fe          	pmullw %xmm6,%xmm7
    8aa3:	66 0f d5 e2          	pmullw %xmm2,%xmm4
    8aa7:	66 0f d5 15 51 68 00 	pmullw 0x6851(%rip),%xmm2        # f300 <__PRETTY_FUNCTION__.4+0x8d>
    8aae:	00 
    8aaf:	66 0f fd e7          	paddw  %xmm7,%xmm4
    8ab3:	66 0f 6f f9          	movdqa %xmm1,%xmm7
    8ab7:	66 0f 71 f7 03       	psllw  $0x3,%xmm7
    8abc:	66 0f f9 f9          	psubw  %xmm1,%xmm7
    8ac0:	66 0f 71 f7 04       	psllw  $0x4,%xmm7
    8ac5:	66 0f fd 3d f3 67 00 	paddw  0x67f3(%rip),%xmm7        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    8acc:	00 
    8acd:	66 0f fd e7          	paddw  %xmm7,%xmm4
    8ad1:	66 41 0f 6f f8       	movdqa %xmm8,%xmm7
    8ad6:	66 0f 71 e4 08       	psraw  $0x8,%xmm4
    8adb:	66 41 0f db fd       	pand   %xmm13,%xmm7
    8ae0:	66 41 0f db e5       	pand   %xmm13,%xmm4
    8ae5:	66 0f 67 fc          	packuswb %xmm4,%xmm7
    8ae9:	66 0f 6f 25 ff 67 00 	movdqa 0x67ff(%rip),%xmm4        # f2f0 <__PRETTY_FUNCTION__.4+0x7d>
    8af0:	00 
    8af1:	66 0f fc e7          	paddb  %xmm7,%xmm4
    8af5:	66 0f 6f fd          	movdqa %xmm5,%xmm7
    8af9:	66 0f 71 f7 03       	psllw  $0x3,%xmm7
    8afe:	66 0f f9 fd          	psubw  %xmm5,%xmm7
    8b02:	66 41 0f 6f ef       	movdqa %xmm15,%xmm5
    8b07:	66 0f 71 f5 02       	psllw  $0x2,%xmm5
    8b0c:	66 0f 71 f7 04       	psllw  $0x4,%xmm7
    8b11:	66 0f fd dd          	paddw  %xmm5,%xmm3
    8b15:	66 0f 6f 2d a3 67 00 	movdqa 0x67a3(%rip),%xmm5        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    8b1c:	00 
    8b1d:	66 0f fd c7          	paddw  %xmm7,%xmm0
    8b21:	66 0f 71 f3 01       	psllw  $0x1,%xmm3
    8b26:	66 0f f9 eb          	psubw  %xmm3,%xmm5
    8b2a:	66 0f 6f d8          	movdqa %xmm0,%xmm3
    8b2e:	66 0f 6f c2          	movdqa %xmm2,%xmm0
    8b32:	66 0f 6f d6          	movdqa %xmm6,%xmm2
    8b36:	66 0f fd dd          	paddw  %xmm5,%xmm3
    8b3a:	66 0f 71 f2 03       	psllw  $0x3,%xmm2
    8b3f:	66 0f 71 e3 08       	psraw  $0x8,%xmm3
    8b44:	66 0f f9 d6          	psubw  %xmm6,%xmm2
    8b48:	66 41 0f db dd       	pand   %xmm13,%xmm3
    8b4d:	66 0f 71 f2 04       	psllw  $0x4,%xmm2
    8b52:	66 0f fd c2          	paddw  %xmm2,%xmm0
    8b56:	66 0f 6f d1          	movdqa %xmm1,%xmm2
    8b5a:	66 0f 71 f2 02       	psllw  $0x2,%xmm2
    8b5f:	66 0f fd ca          	paddw  %xmm2,%xmm1
    8b63:	66 0f 6f 15 55 67 00 	movdqa 0x6755(%rip),%xmm2        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    8b6a:	00 
    8b6b:	66 0f 71 f1 01       	psllw  $0x1,%xmm1
    8b70:	66 0f f9 d1          	psubw  %xmm1,%xmm2
    8b74:	66 0f 6f cb          	movdqa %xmm3,%xmm1
    8b78:	66 0f fd c2          	paddw  %xmm2,%xmm0
    8b7c:	66 0f 71 e0 08       	psraw  $0x8,%xmm0
    8b81:	66 41 0f db c5       	pand   %xmm13,%xmm0
    8b86:	66 0f 67 c8          	packuswb %xmm0,%xmm1
    8b8a:	66 0f fc 0d 5e 67 00 	paddb  0x675e(%rip),%xmm1        # f2f0 <__PRETTY_FUNCTION__.4+0x7d>
    8b91:	00 
    8b92:	66 0f 6f c1          	movdqa %xmm1,%xmm0
    8b96:	66 0f 6f cc          	movdqa %xmm4,%xmm1
    8b9a:	66 0f 60 c8          	punpcklbw %xmm0,%xmm1
    8b9e:	66 0f 68 e0          	punpckhbw %xmm0,%xmm4
    8ba2:	43 0f 11 0c 03       	movups %xmm1,(%r11,%r8,1)
    8ba7:	43 0f 11 64 03 10    	movups %xmm4,0x10(%r11,%r8,1)
    8bad:	49 83 c0 20          	add    $0x20,%r8
    8bb1:	4c 39 44 24 a8       	cmp    %r8,-0x58(%rsp)
    8bb6:	0f 85 34 f6 ff ff    	jne    81f0 <convert_job+0x13b0>
    8bbc:	8b 7c 24 d8          	mov    -0x28(%rsp),%edi
    8bc0:	89 fa                	mov    %edi,%edx
    8bc2:	c1 e7 05             	shl    $0x5,%edi
    8bc5:	c1 e2 04             	shl    $0x4,%edx
    8bc8:	01 f9                	add    %edi,%ecx
    8bca:	41 29 d2             	sub    %edx,%r10d
    8bcd:	41 83 fa 07          	cmp    $0x7,%r10d
    8bd1:	0f 86 9e 0b 00 00    	jbe    9775 <convert_job+0x2935>
    8bd7:	48 01 d2             	add    %rdx,%rdx
    8bda:	48 8b 7c 24 e8       	mov    -0x18(%rsp),%rdi
    8bdf:	4c 8b 5c 24 f8       	mov    -0x8(%rsp),%r11
    8be4:	41 83 e2 f8          	and    $0xfffffff8,%r10d
    8be8:	48 01 d0             	add    %rdx,%rax
    8beb:	4c 8b 44 24 30       	mov    0x30(%rsp),%r8
    8bf0:	42 8d 0c 51          	lea    (%rcx,%r10,2),%ecx
    8bf4:	f3 0f 7e 05 84 66 00 	movq   0x6684(%rip),%xmm0        # f280 <__PRETTY_FUNCTION__.4+0xd>
    8bfb:	00 
    8bfc:	48 c1 e0 02          	shl    $0x2,%rax
    8c00:	48 01 c7             	add    %rax,%rdi
    8c03:	66 0f 6f d0          	movdqa %xmm0,%xmm2
    8c07:	66 0f 6f e8          	movdqa %xmm0,%xmm5
    8c0b:	49 01 c3             	add    %rax,%r11
    8c0e:	4c 01 cf             	add    %r9,%rdi
    8c11:	66 0f 6f f0          	movdqa %xmm0,%xmm6
    8c15:	66 44 0f 6f c8       	movdqa %xmm0,%xmm9
    8c1a:	4c 89 d8             	mov    %r11,%rax
    8c1d:	f3 44 0f 7e 07       	movq   (%rdi),%xmm8
    8c22:	f3 44 0f 7e 77 08    	movq   0x8(%rdi),%xmm14
    8c28:	4c 01 c8             	add    %r9,%rax
    8c2b:	66 44 0f 6f d8       	movdqa %xmm0,%xmm11
    8c30:	f3 0f 7e 67 10       	movq   0x10(%rdi),%xmm4
    8c35:	f3 44 0f 7e 67 18    	movq   0x18(%rdi),%xmm12
    8c3b:	49 01 d0             	add    %rdx,%r8
    8c3e:	66 44 0f 6f f8       	movdqa %xmm0,%xmm15
    8c43:	66 41 0f db ee       	pand   %xmm14,%xmm5
    8c48:	66 41 0f db d0       	pand   %xmm8,%xmm2
    8c4d:	49 01 f0             	add    %rsi,%r8
    8c50:	f3 0f 7e 4f 20       	movq   0x20(%rdi),%xmm1
    8c55:	66 0f 67 d5          	packuswb %xmm5,%xmm2
    8c59:	66 0f 6f e8          	movdqa %xmm0,%xmm5
    8c5d:	66 0f db f4          	pand   %xmm4,%xmm6
    8c61:	f3 44 0f 7e 57 28    	movq   0x28(%rdi),%xmm10
    8c67:	66 41 0f db ec       	pand   %xmm12,%xmm5
    8c6c:	f3 0f 7e 5f 30       	movq   0x30(%rdi),%xmm3
    8c71:	66 0f 70 d2 08       	pshufd $0x8,%xmm2,%xmm2
    8c76:	f3 0f 7e 7f 38       	movq   0x38(%rdi),%xmm7
    8c7b:	66 0f 67 f5          	packuswb %xmm5,%xmm6
    8c7f:	66 0f 6f e8          	movdqa %xmm0,%xmm5
    8c83:	66 45 0f db ca       	pand   %xmm10,%xmm9
    8c88:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
    8c8d:	66 0f db e9          	pand   %xmm1,%xmm5
    8c91:	66 44 0f db db       	pand   %xmm3,%xmm11
    8c96:	66 0f 70 f6 08       	pshufd $0x8,%xmm6,%xmm6
    8c9b:	66 41 0f 67 e9       	packuswb %xmm9,%xmm5
    8ca0:	66 44 0f 6f c8       	movdqa %xmm0,%xmm9
    8ca5:	66 44 0f db fe       	pand   %xmm6,%xmm15
    8caa:	49 01 d1             	add    %rdx,%r9
    8cad:	66 44 0f db cf       	pand   %xmm7,%xmm9
    8cb2:	66 0f 71 d6 08       	psrlw  $0x8,%xmm6
    8cb7:	66 0f 70 ed 08       	pshufd $0x8,%xmm5,%xmm5
    8cbc:	66 45 0f 67 d9       	packuswb %xmm9,%xmm11
    8cc1:	66 44 0f 6f c8       	movdqa %xmm0,%xmm9
    8cc6:	4e 8d 34 0e          	lea    (%rsi,%r9,1),%r14
    8cca:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
    8ccf:	66 44 0f db ca       	pand   %xmm2,%xmm9
    8cd4:	66 0f 71 d7 08       	psrlw  $0x8,%xmm7
    8cd9:	66 45 0f 70 db 08    	pshufd $0x8,%xmm11,%xmm11
    8cdf:	66 41 0f 71 d2 08    	psrlw  $0x8,%xmm10
    8ce5:	66 0f 71 d2 08       	psrlw  $0x8,%xmm2
    8cea:	66 45 0f 67 cf       	packuswb %xmm15,%xmm9
    8cef:	48 01 f2             	add    %rsi,%rdx
    8cf2:	66 0f 71 d1 08       	psrlw  $0x8,%xmm1
    8cf7:	66 0f 71 d3 08       	psrlw  $0x8,%xmm3
    8cfc:	66 0f 67 d6          	packuswb %xmm6,%xmm2
    8d00:	48 01 da             	add    %rbx,%rdx
    8d03:	66 0f 6f f0          	movdqa %xmm0,%xmm6
    8d07:	66 44 0f 6f f8       	movdqa %xmm0,%xmm15
    8d0c:	66 41 0f 67 ca       	packuswb %xmm10,%xmm1
    8d11:	66 41 0f 71 d6 08    	psrlw  $0x8,%xmm14
    8d17:	66 41 0f 71 d4 08    	psrlw  $0x8,%xmm12
    8d1d:	66 0f 67 df          	packuswb %xmm7,%xmm3
    8d21:	66 41 0f 71 d0 08    	psrlw  $0x8,%xmm8
    8d27:	66 0f 71 d4 08       	psrlw  $0x8,%xmm4
    8d2c:	66 45 0f db fb       	pand   %xmm11,%xmm15
    8d31:	66 0f db f5          	pand   %xmm5,%xmm6
    8d35:	66 45 0f 67 c6       	packuswb %xmm14,%xmm8
    8d3a:	66 41 0f 67 e4       	packuswb %xmm12,%xmm4
    8d3f:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    8d44:	66 0f 70 db 08       	pshufd $0x8,%xmm3,%xmm3
    8d49:	66 41 0f 67 f7       	packuswb %xmm15,%xmm6
    8d4e:	66 0f db d8          	pand   %xmm0,%xmm3
    8d52:	66 0f db c8          	pand   %xmm0,%xmm1
    8d56:	66 0f 70 e4 08       	pshufd $0x8,%xmm4,%xmm4
    8d5b:	66 45 0f 70 c0 08    	pshufd $0x8,%xmm8,%xmm8
    8d61:	66 0f db e0          	pand   %xmm0,%xmm4
    8d65:	66 45 0f 70 c9 08    	pshufd $0x8,%xmm9,%xmm9
    8d6b:	66 0f 70 f6 08       	pshufd $0x8,%xmm6,%xmm6
    8d70:	66 44 0f db c0       	pand   %xmm0,%xmm8
    8d75:	66 0f 67 cb          	packuswb %xmm3,%xmm1
    8d79:	66 0f 6f f8          	movdqa %xmm0,%xmm7
    8d7d:	66 0f 6f d8          	movdqa %xmm0,%xmm3
    8d81:	66 44 0f 67 c4       	packuswb %xmm4,%xmm8
    8d86:	66 0f db de          	pand   %xmm6,%xmm3
    8d8a:	66 41 0f db f9       	pand   %xmm9,%xmm7
    8d8f:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    8d94:	66 41 0f 71 d3 08    	psrlw  $0x8,%xmm11
    8d9a:	66 45 0f 70 c0 08    	pshufd $0x8,%xmm8,%xmm8
    8da0:	66 0f 67 fb          	packuswb %xmm3,%xmm7
    8da4:	66 0f 6f e0          	movdqa %xmm0,%xmm4
    8da8:	66 0f 6f d8          	movdqa %xmm0,%xmm3
    8dac:	66 0f 70 d2 08       	pshufd $0x8,%xmm2,%xmm2
    8db1:	66 0f 71 d5 08       	psrlw  $0x8,%xmm5
    8db6:	66 0f db d9          	pand   %xmm1,%xmm3
    8dba:	66 41 0f db e0       	pand   %xmm8,%xmm4
    8dbf:	66 41 0f 67 eb       	packuswb %xmm11,%xmm5
    8dc4:	66 0f 71 d1 08       	psrlw  $0x8,%xmm1
    8dc9:	66 0f 67 e3          	packuswb %xmm3,%xmm4
    8dcd:	66 41 0f 71 d0 08    	psrlw  $0x8,%xmm8
    8dd3:	66 0f 70 ed 08       	pshufd $0x8,%xmm5,%xmm5
    8dd8:	66 0f 6f d8          	movdqa %xmm0,%xmm3
    8ddc:	66 44 0f 67 c1       	packuswb %xmm1,%xmm8
    8de1:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    8de5:	66 0f db da          	pand   %xmm2,%xmm3
    8de9:	66 0f db cd          	pand   %xmm5,%xmm1
    8ded:	66 0f 70 ff 08       	pshufd $0x8,%xmm7,%xmm7
    8df2:	66 0f 70 e4 08       	pshufd $0x8,%xmm4,%xmm4
    8df7:	66 0f 67 d9          	packuswb %xmm1,%xmm3
    8dfb:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8dff:	66 44 0f 6f e7       	movdqa %xmm7,%xmm12
    8e04:	66 0f 60 f9          	punpcklbw %xmm1,%xmm7
    8e08:	66 0f 70 db 08       	pshufd $0x8,%xmm3,%xmm3
    8e0d:	66 44 0f 60 e1       	punpcklbw %xmm1,%xmm12
    8e12:	66 0f 70 ff 4e       	pshufd $0x4e,%xmm7,%xmm7
    8e17:	66 0f 71 d5 08       	psrlw  $0x8,%xmm5
    8e1c:	66 45 0f 6f d4       	movdqa %xmm12,%xmm10
    8e21:	66 44 0f d6 64 24 98 	movq   %xmm12,-0x68(%rsp)
    8e28:	66 0f 71 d2 08       	psrlw  $0x8,%xmm2
    8e2d:	66 44 0f 6f ff       	movdqa %xmm7,%xmm15
    8e32:	66 0f d6 7c 24 d8    	movq   %xmm7,-0x28(%rsp)
    8e38:	66 0f 6f fc          	movdqa %xmm4,%xmm7
    8e3c:	66 0f 67 d5          	packuswb %xmm5,%xmm2
    8e40:	66 0f 60 e1          	punpcklbw %xmm1,%xmm4
    8e44:	66 0f 6f eb          	movdqa %xmm3,%xmm5
    8e48:	f3 44 0f 7e 25 5f 64 	movq   0x645f(%rip),%xmm12        # f2b0 <__PRETTY_FUNCTION__.4+0x3d>
    8e4f:	00 00 
    8e51:	66 0f 60 e9          	punpcklbw %xmm1,%xmm5
    8e55:	66 0f 70 e4 4e       	pshufd $0x4e,%xmm4,%xmm4
    8e5a:	66 0f 60 f9          	punpcklbw %xmm1,%xmm7
    8e5e:	66 44 0f 6f dc       	movdqa %xmm4,%xmm11
    8e63:	66 0f 71 d6 08       	psrlw  $0x8,%xmm6
    8e68:	66 0f d6 64 24 c8    	movq   %xmm4,-0x38(%rsp)
    8e6e:	66 0f 6f e5          	movdqa %xmm5,%xmm4
    8e72:	66 41 0f 71 d1 08    	psrlw  $0x8,%xmm9
    8e78:	66 0f 71 f4 01       	psllw  $0x1,%xmm4
    8e7d:	66 0f 60 d9          	punpcklbw %xmm1,%xmm3
    8e81:	66 0f d6 7c 24 b8    	movq   %xmm7,-0x48(%rsp)
    8e87:	66 0f fd e5          	paddw  %xmm5,%xmm4
    8e8b:	66 44 0f 67 ce       	packuswb %xmm6,%xmm9
    8e90:	66 0f 70 db 4e       	pshufd $0x4e,%xmm3,%xmm3
    8e95:	f3 0f 7e 35 83 64 00 	movq   0x6483(%rip),%xmm6        # f320 <__PRETTY_FUNCTION__.4+0xad>
    8e9c:	00 
    8e9d:	66 41 0f 71 f2 04    	psllw  $0x4,%xmm10
    8ea3:	66 45 0f 70 c9 08    	pshufd $0x8,%xmm9,%xmm9
    8ea9:	66 45 0f 70 c0 08    	pshufd $0x8,%xmm8,%xmm8
    8eaf:	66 0f d5 fe          	pmullw %xmm6,%xmm7
    8eb3:	66 0f 70 d2 08       	pshufd $0x8,%xmm2,%xmm2
    8eb8:	66 44 0f d5 de       	pmullw %xmm6,%xmm11
    8ebd:	66 0f 71 f4 04       	psllw  $0x4,%xmm4
    8ec2:	66 0f f9 e5          	psubw  %xmm5,%xmm4
    8ec6:	66 0f fd fc          	paddw  %xmm4,%xmm7
    8eca:	f3 0f 7e 25 ee 63 00 	movq   0x63ee(%rip),%xmm4        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    8ed1:	00 
    8ed2:	66 44 0f fd d4       	paddw  %xmm4,%xmm10
    8ed7:	66 41 0f fd fa       	paddw  %xmm10,%xmm7
    8edc:	66 44 0f 6f d3       	movdqa %xmm3,%xmm10
    8ee1:	66 41 0f 71 f2 01    	psllw  $0x1,%xmm10
    8ee7:	66 44 0f fd d3       	paddw  %xmm3,%xmm10
    8eec:	66 0f 71 d7 08       	psrlw  $0x8,%xmm7
    8ef1:	66 0f db f8          	pand   %xmm0,%xmm7
    8ef5:	66 41 0f 71 f2 04    	psllw  $0x4,%xmm10
    8efb:	66 44 0f f9 d3       	psubw  %xmm3,%xmm10
    8f00:	66 45 0f fd d3       	paddw  %xmm11,%xmm10
    8f05:	66 45 0f 6f df       	movdqa %xmm15,%xmm11
    8f0a:	66 45 0f 6f f9       	movdqa %xmm9,%xmm15
    8f0f:	66 41 0f 71 f3 04    	psllw  $0x4,%xmm11
    8f15:	66 44 0f 60 f9       	punpcklbw %xmm1,%xmm15
    8f1a:	66 44 0f fd dc       	paddw  %xmm4,%xmm11
    8f1f:	66 45 0f 70 ff 4e    	pshufd $0x4e,%xmm15,%xmm15
    8f25:	66 44 0f d6 7c 24 f8 	movq   %xmm15,-0x8(%rsp)
    8f2c:	66 45 0f fd d3       	paddw  %xmm11,%xmm10
    8f31:	66 45 0f 6f d9       	movdqa %xmm9,%xmm11
    8f36:	66 45 0f 6f c8       	movdqa %xmm8,%xmm9
    8f3b:	66 44 0f 60 c1       	punpcklbw %xmm1,%xmm8
    8f40:	66 44 0f 60 c9       	punpcklbw %xmm1,%xmm9
    8f45:	66 44 0f 60 d9       	punpcklbw %xmm1,%xmm11
    8f4a:	66 45 0f 70 c0 4e    	pshufd $0x4e,%xmm8,%xmm8
    8f50:	66 44 0f d6 4c 24 08 	movq   %xmm9,0x8(%rsp)
    8f57:	66 44 0f d5 ce       	pmullw %xmm6,%xmm9
    8f5c:	66 41 0f 71 d2 08    	psrlw  $0x8,%xmm10
    8f62:	66 45 0f 6f f0       	movdqa %xmm8,%xmm14
    8f67:	66 44 0f d6 44 24 28 	movq   %xmm8,0x28(%rsp)
    8f6e:	66 44 0f db d0       	pand   %xmm0,%xmm10
    8f73:	66 44 0f d6 5c 24 e8 	movq   %xmm11,-0x18(%rsp)
    8f7a:	66 41 0f 67 fa       	packuswb %xmm10,%xmm7
    8f7f:	66 0f 70 ff 08       	pshufd $0x8,%xmm7,%xmm7
    8f84:	66 41 0f fc fc       	paddb  %xmm12,%xmm7
    8f89:	66 44 0f 6f e2       	movdqa %xmm2,%xmm12
    8f8e:	66 0f 60 d1          	punpcklbw %xmm1,%xmm2
    8f92:	66 44 0f 60 e1       	punpcklbw %xmm1,%xmm12
    8f97:	66 0f 70 d2 4e       	pshufd $0x4e,%xmm2,%xmm2
    8f9c:	66 45 0f 6f c4       	movdqa %xmm12,%xmm8
    8fa1:	66 41 0f fd ec       	paddw  %xmm12,%xmm5
    8fa6:	66 0f fd da          	paddw  %xmm2,%xmm3
    8faa:	66 41 0f 71 f0 01    	psllw  $0x1,%xmm8
    8fb0:	66 45 0f fd c4       	paddw  %xmm12,%xmm8
    8fb5:	66 41 0f 71 f0 04    	psllw  $0x4,%xmm8
    8fbb:	66 45 0f f9 c4       	psubw  %xmm12,%xmm8
    8fc0:	66 45 0f fd c1       	paddw  %xmm9,%xmm8
    8fc5:	66 45 0f 6f cb       	movdqa %xmm11,%xmm9
    8fca:	66 41 0f 71 f1 04    	psllw  $0x4,%xmm9
    8fd0:	66 44 0f fd cc       	paddw  %xmm4,%xmm9
    8fd5:	66 45 0f fd c1       	paddw  %xmm9,%xmm8
    8fda:	66 45 0f 6f ce       	movdqa %xmm14,%xmm9
    8fdf:	66 44 0f d5 ce       	pmullw %xmm6,%xmm9
    8fe4:	66 41 0f 71 d0 08    	psrlw  $0x8,%xmm8
    8fea:	66 45 0f 6f d0       	movdqa %xmm8,%xmm10
    8fef:	66 44 0f 6f c2       	movdqa %xmm2,%xmm8
    8ff4:	66 41 0f 71 f0 01    	psllw  $0x1,%xmm8
    8ffa:	66 44 0f fd c2       	paddw  %xmm2,%xmm8
    8fff:	66 41 0f 71 f0 04    	psllw  $0x4,%xmm8
    9005:	66 44 0f f9 c2       	psubw  %xmm2,%xmm8
    900a:	66 45 0f fd c1       	paddw  %xmm9,%xmm8
    900f:	66 45 0f 6f cf       	movdqa %xmm15,%xmm9
    9014:	f3 44 0f 7e 3d 93 62 	movq   0x6293(%rip),%xmm15        # f2b0 <__PRETTY_FUNCTION__.4+0x3d>
    901b:	00 00 
    901d:	66 41 0f 71 f1 04    	psllw  $0x4,%xmm9
    9023:	66 44 0f fd cc       	paddw  %xmm4,%xmm9
    9028:	66 45 0f fd c1       	paddw  %xmm9,%xmm8
    902d:	66 45 0f 6f ca       	movdqa %xmm10,%xmm9
    9032:	66 44 0f 6f d0       	movdqa %xmm0,%xmm10
    9037:	66 44 0f db c8       	pand   %xmm0,%xmm9
    903c:	66 41 0f 71 d0 08    	psrlw  $0x8,%xmm8
    9042:	66 44 0f db c0       	pand   %xmm0,%xmm8
    9047:	66 45 0f 67 c8       	packuswb %xmm8,%xmm9
    904c:	66 45 0f 70 c9 08    	pshufd $0x8,%xmm9,%xmm9
    9052:	66 45 0f fc cf       	paddb  %xmm15,%xmm9
    9057:	66 45 0f 6f c1       	movdqa %xmm9,%xmm8
    905c:	66 44 0f 6f cf       	movdqa %xmm7,%xmm9
    9061:	66 41 0f 60 f8       	punpcklbw %xmm8,%xmm7
    9066:	66 45 0f 60 c8       	punpcklbw %xmm8,%xmm9
    906b:	66 0f 70 ff 4e       	pshufd $0x4e,%xmm7,%xmm7
    9070:	66 45 0f d6 08       	movq   %xmm9,(%r8)
    9075:	66 41 0f d6 78 08    	movq   %xmm7,0x8(%r8)
    907b:	4c 8b 08             	mov    (%rax),%r9
    907e:	4c 8b 40 08          	mov    0x8(%rax),%r8
    9082:	48 8b 78 10          	mov    0x10(%rax),%rdi
    9086:	66 4d 0f 6e d9       	movq   %r9,%xmm11
    908b:	66 4d 0f 6e c0       	movq   %r8,%xmm8
    9090:	48 89 7c 24 a8       	mov    %rdi,-0x58(%rsp)
    9095:	48 8b 78 18          	mov    0x18(%rax),%rdi
    9099:	66 44 0f db c0       	pand   %xmm0,%xmm8
    909e:	66 44 0f db d8       	pand   %xmm0,%xmm11
    90a3:	f3 0f 7e 7c 24 a8    	movq   -0x58(%rsp),%xmm7
    90a9:	48 8b 70 20          	mov    0x20(%rax),%rsi
    90ad:	66 45 0f 67 d8       	packuswb %xmm8,%xmm11
    90b2:	66 4c 0f 6e c7       	movq   %rdi,%xmm8
    90b7:	f3 44 0f 7e 78 28    	movq   0x28(%rax),%xmm15
    90bd:	4c 8b 58 30          	mov    0x30(%rax),%r11
    90c1:	66 45 0f 70 db 08    	pshufd $0x8,%xmm11,%xmm11
    90c7:	66 44 0f db c0       	pand   %xmm0,%xmm8
    90cc:	66 44 0f db d7       	pand   %xmm7,%xmm10
    90d1:	4c 8b 78 38          	mov    0x38(%rax),%r15
    90d5:	66 4c 0f 6e ce       	movq   %rsi,%xmm9
    90da:	66 45 0f 67 d0       	packuswb %xmm8,%xmm10
    90df:	66 44 0f 6f c0       	movdqa %xmm0,%xmm8
    90e4:	66 44 0f db c8       	pand   %xmm0,%xmm9
    90e9:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    90ee:	66 45 0f db c7       	pand   %xmm15,%xmm8
    90f3:	66 4d 0f 6e f7       	movq   %r15,%xmm14
    90f8:	66 45 0f 70 d2 08    	pshufd $0x8,%xmm10,%xmm10
    90fe:	f3 0f 7e 15 da 61 00 	movq   0x61da(%rip),%xmm2        # f2e0 <__PRETTY_FUNCTION__.4+0x6d>
    9105:	00 
    9106:	66 45 0f 67 c8       	packuswb %xmm8,%xmm9
    910b:	66 4d 0f 6e c3       	movq   %r11,%xmm8
    9110:	66 44 0f db f0       	pand   %xmm0,%xmm14
    9115:	66 44 0f db c0       	pand   %xmm0,%xmm8
    911a:	66 45 0f 70 c9 08    	pshufd $0x8,%xmm9,%xmm9
    9120:	66 45 0f 67 c6       	packuswb %xmm14,%xmm8
    9125:	66 41 0f 71 d7 08    	psrlw  $0x8,%xmm15
    912b:	66 44 0f 6f f0       	movdqa %xmm0,%xmm14
    9130:	66 45 0f db f3       	pand   %xmm11,%xmm14
    9135:	66 41 0f 71 d3 08    	psrlw  $0x8,%xmm11
    913b:	66 45 0f 70 c0 08    	pshufd $0x8,%xmm8,%xmm8
    9141:	66 4d 0f 7e f3       	movq   %xmm14,%r11
    9146:	66 44 0f 6f f0       	movdqa %xmm0,%xmm14
    914b:	66 45 0f db f2       	pand   %xmm10,%xmm14
    9150:	66 41 0f 71 d2 08    	psrlw  $0x8,%xmm10
    9156:	66 4c 0f 7e f0       	movq   %xmm14,%rax
    915b:	66 4d 0f 6e f3       	movq   %r11,%xmm14
    9160:	66 48 0f 6e f8       	movq   %rax,%xmm7
    9165:	66 44 0f 67 f7       	packuswb %xmm7,%xmm14
    916a:	f3 0f 7e 7c 24 a8    	movq   -0x58(%rsp),%xmm7
    9170:	66 45 0f 70 f6 08    	pshufd $0x8,%xmm14,%xmm14
    9176:	66 4d 0f 7e f3       	movq   %xmm14,%r11
    917b:	66 0f 71 d7 08       	psrlw  $0x8,%xmm7
    9180:	66 45 0f 6f f3       	movdqa %xmm11,%xmm14
    9185:	66 45 0f 67 f2       	packuswb %xmm10,%xmm14
    918a:	66 44 0f 6f d8       	movdqa %xmm0,%xmm11
    918f:	66 44 0f 6f d0       	movdqa %xmm0,%xmm10
    9194:	66 45 0f db d0       	pand   %xmm8,%xmm10
    9199:	66 45 0f db d9       	pand   %xmm9,%xmm11
    919e:	66 45 0f 70 f6 08    	pshufd $0x8,%xmm14,%xmm14
    91a4:	66 41 0f 71 d0 08    	psrlw  $0x8,%xmm8
    91aa:	66 41 0f 71 d1 08    	psrlw  $0x8,%xmm9
    91b0:	66 45 0f 67 da       	packuswb %xmm10,%xmm11
    91b5:	66 45 0f 67 c8       	packuswb %xmm8,%xmm9
    91ba:	66 4d 0f 6e d0       	movq   %r8,%xmm10
    91bf:	66 4d 0f 6e c1       	movq   %r9,%xmm8
    91c4:	66 41 0f 71 d2 08    	psrlw  $0x8,%xmm10
    91ca:	66 41 0f 71 d0 08    	psrlw  $0x8,%xmm8
    91d0:	66 4c 0f 7e f0       	movq   %xmm14,%rax
    91d5:	66 45 0f 67 c2       	packuswb %xmm10,%xmm8
    91da:	66 4c 0f 6e d7       	movq   %rdi,%xmm10
    91df:	66 45 0f 70 db 08    	pshufd $0x8,%xmm11,%xmm11
    91e5:	66 41 0f 71 d2 08    	psrlw  $0x8,%xmm10
    91eb:	66 45 0f 70 c0 08    	pshufd $0x8,%xmm8,%xmm8
    91f1:	66 45 0f 70 c9 08    	pshufd $0x8,%xmm9,%xmm9
    91f7:	66 41 0f 67 fa       	packuswb %xmm10,%xmm7
    91fc:	66 44 0f db c0       	pand   %xmm0,%xmm8
    9201:	f3 44 0f 7e 54 24 18 	movq   0x18(%rsp),%xmm10
    9208:	66 0f 70 ff 08       	pshufd $0x8,%xmm7,%xmm7
    920d:	66 0f db f8          	pand   %xmm0,%xmm7
    9211:	66 41 0f 71 d2 08    	psrlw  $0x8,%xmm10
    9217:	66 44 0f 67 c7       	packuswb %xmm7,%xmm8
    921c:	66 48 0f 6e fe       	movq   %rsi,%xmm7
    9221:	66 0f 71 d7 08       	psrlw  $0x8,%xmm7
    9226:	66 45 0f 70 c0 08    	pshufd $0x8,%xmm8,%xmm8
    922c:	66 41 0f 67 ff       	packuswb %xmm15,%xmm7
    9231:	66 4d 0f 6e ff       	movq   %r15,%xmm15
    9236:	66 41 0f 71 d7 08    	psrlw  $0x8,%xmm15
    923c:	66 0f 70 ff 08       	pshufd $0x8,%xmm7,%xmm7
    9241:	66 45 0f 67 d7       	packuswb %xmm15,%xmm10
    9246:	66 0f db f8          	pand   %xmm0,%xmm7
    924a:	66 4d 0f 6e fb       	movq   %r11,%xmm15
    924f:	66 45 0f 70 d2 08    	pshufd $0x8,%xmm10,%xmm10
    9255:	66 44 0f db f8       	pand   %xmm0,%xmm15
    925a:	66 44 0f db d0       	pand   %xmm0,%xmm10
    925f:	66 41 0f 67 fa       	packuswb %xmm10,%xmm7
    9264:	66 44 0f 6f d0       	movdqa %xmm0,%xmm10
    9269:	66 45 0f db d3       	pand   %xmm11,%xmm10
    926e:	66 0f 70 ff 08       	pshufd $0x8,%xmm7,%xmm7
    9273:	66 45 0f 67 fa       	packuswb %xmm10,%xmm15
    9278:	66 4d 0f 6e d3       	movq   %r11,%xmm10
    927d:	66 41 0f 71 d2 08    	psrlw  $0x8,%xmm10
    9283:	66 45 0f 70 ff 08    	pshufd $0x8,%xmm15,%xmm15
    9289:	66 4d 0f 7e d3       	movq   %xmm10,%r11
    928e:	66 45 0f 6f d3       	movdqa %xmm11,%xmm10
    9293:	66 41 0f 71 d2 08    	psrlw  $0x8,%xmm10
    9299:	66 4d 0f 6e db       	movq   %r11,%xmm11
    929e:	66 45 0f 67 da       	packuswb %xmm10,%xmm11
    92a3:	66 44 0f 6f d0       	movdqa %xmm0,%xmm10
    92a8:	66 45 0f db d0       	pand   %xmm8,%xmm10
    92ad:	66 41 0f 71 d0 08    	psrlw  $0x8,%xmm8
    92b3:	66 45 0f 70 db 08    	pshufd $0x8,%xmm11,%xmm11
    92b9:	66 4c 0f 7e d6       	movq   %xmm10,%rsi
    92be:	66 44 0f 6f d0       	movdqa %xmm0,%xmm10
    92c3:	66 44 0f db d7       	pand   %xmm7,%xmm10
    92c8:	66 0f 71 d7 08       	psrlw  $0x8,%xmm7
    92cd:	66 4c 0f 6e f6       	movq   %rsi,%xmm14
    92d2:	66 45 0f 67 f2       	packuswb %xmm10,%xmm14
    92d7:	66 44 0f 67 c7       	packuswb %xmm7,%xmm8
    92dc:	66 44 0f 6f d0       	movdqa %xmm0,%xmm10
    92e1:	66 48 0f 6e f8       	movq   %rax,%xmm7
    92e6:	66 45 0f db d1       	pand   %xmm9,%xmm10
    92eb:	66 45 0f 70 f6 08    	pshufd $0x8,%xmm14,%xmm14
    92f1:	66 0f db f8          	pand   %xmm0,%xmm7
    92f5:	66 41 0f 71 d1 08    	psrlw  $0x8,%xmm9
    92fb:	66 45 0f 70 c0 08    	pshufd $0x8,%xmm8,%xmm8
    9301:	66 41 0f 67 fa       	packuswb %xmm10,%xmm7
    9306:	66 4c 0f 6e d0       	movq   %rax,%xmm10
    930b:	66 41 0f 71 d2 08    	psrlw  $0x8,%xmm10
    9311:	66 0f 70 ff 08       	pshufd $0x8,%xmm7,%xmm7
    9316:	66 45 0f 67 d1       	packuswb %xmm9,%xmm10
    931b:	66 45 0f 6f cf       	movdqa %xmm15,%xmm9
    9320:	66 44 0f 60 f9       	punpcklbw %xmm1,%xmm15
    9325:	66 45 0f 70 ff 4e    	pshufd $0x4e,%xmm15,%xmm15
    932b:	66 44 0f 60 c9       	punpcklbw %xmm1,%xmm9
    9330:	66 45 0f 70 d2 08    	pshufd $0x8,%xmm10,%xmm10
    9336:	66 4c 0f 7e f8       	movq   %xmm15,%rax
    933b:	66 45 0f 6f fe       	movdqa %xmm14,%xmm15
    9340:	66 44 0f 60 f9       	punpcklbw %xmm1,%xmm15
    9345:	66 4d 0f 7e f9       	movq   %xmm15,%r9
    934a:	66 45 0f 6f fe       	movdqa %xmm14,%xmm15
    934f:	66 44 0f 60 f9       	punpcklbw %xmm1,%xmm15
    9354:	66 45 0f 70 ff 4e    	pshufd $0x4e,%xmm15,%xmm15
    935a:	66 4c 0f 7e fe       	movq   %xmm15,%rsi
    935f:	66 44 0f 6f ff       	movdqa %xmm7,%xmm15
    9364:	66 0f 60 f9          	punpcklbw %xmm1,%xmm7
    9368:	66 44 0f 60 f9       	punpcklbw %xmm1,%xmm15
    936d:	66 0f 70 ff 4e       	pshufd $0x4e,%xmm7,%xmm7
    9372:	66 45 0f 6f f7       	movdqa %xmm15,%xmm14
    9377:	66 44 0f d6 7c 24 a8 	movq   %xmm15,-0x58(%rsp)
    937e:	66 41 0f 71 f7 01    	psllw  $0x1,%xmm15
    9384:	66 48 0f 7e ff       	movq   %xmm7,%rdi
    9389:	66 45 0f fd fe       	paddw  %xmm14,%xmm15
    938e:	66 49 0f 6e f9       	movq   %r9,%xmm7
    9393:	f3 44 0f 7e 74 24 a8 	movq   -0x58(%rsp),%xmm14
    939a:	66 0f d5 fe          	pmullw %xmm6,%xmm7
    939e:	66 41 0f 71 f7 04    	psllw  $0x4,%xmm15
    93a4:	66 45 0f f9 fe       	psubw  %xmm14,%xmm15
    93a9:	66 4c 0f 6e f7       	movq   %rdi,%xmm14
    93ae:	66 44 0f fd ff       	paddw  %xmm7,%xmm15
    93b3:	66 41 0f 6f f9       	movdqa %xmm9,%xmm7
    93b8:	66 0f 71 f7 04       	psllw  $0x4,%xmm7
    93bd:	66 0f fd fc          	paddw  %xmm4,%xmm7
    93c1:	66 44 0f fd ff       	paddw  %xmm7,%xmm15
    93c6:	66 48 0f 6e ff       	movq   %rdi,%xmm7
    93cb:	66 0f 71 f7 01       	psllw  $0x1,%xmm7
    93d0:	66 41 0f fd fe       	paddw  %xmm14,%xmm7
    93d5:	66 41 0f 71 d7 08    	psrlw  $0x8,%xmm15
    93db:	66 4d 0f 7e f8       	movq   %xmm15,%r8
    93e0:	66 4c 0f 6e fe       	movq   %rsi,%xmm15
    93e5:	66 44 0f d5 fe       	pmullw %xmm6,%xmm15
    93ea:	66 0f 71 f7 04       	psllw  $0x4,%xmm7
    93ef:	66 41 0f f9 fe       	psubw  %xmm14,%xmm7
    93f4:	66 41 0f fd ff       	paddw  %xmm15,%xmm7
    93f9:	66 4c 0f 6e f8       	movq   %rax,%xmm15
    93fe:	66 41 0f 71 f7 04    	psllw  $0x4,%xmm15
    9404:	66 44 0f fd fc       	paddw  %xmm4,%xmm15
    9409:	66 41 0f fd ff       	paddw  %xmm15,%xmm7
    940e:	66 4d 0f 6e f8       	movq   %r8,%xmm15
    9413:	66 44 0f db f8       	pand   %xmm0,%xmm15
    9418:	66 0f 71 d7 08       	psrlw  $0x8,%xmm7
    941d:	66 0f db f8          	pand   %xmm0,%xmm7
    9421:	66 44 0f 67 ff       	packuswb %xmm7,%xmm15
    9426:	f3 0f 7e 3d 82 5e 00 	movq   0x5e82(%rip),%xmm7        # f2b0 <__PRETTY_FUNCTION__.4+0x3d>
    942d:	00 
    942e:	66 45 0f 70 ff 08    	pshufd $0x8,%xmm15,%xmm15
    9434:	66 44 0f fc ff       	paddb  %xmm7,%xmm15
    9439:	66 41 0f 6f fb       	movdqa %xmm11,%xmm7
    943e:	66 44 0f 60 d9       	punpcklbw %xmm1,%xmm11
    9443:	66 0f 60 f9          	punpcklbw %xmm1,%xmm7
    9447:	66 45 0f 70 db 4e    	pshufd $0x4e,%xmm11,%xmm11
    944d:	66 49 0f 7e ff       	movq   %xmm7,%r15
    9452:	66 41 0f 6f f8       	movdqa %xmm8,%xmm7
    9457:	66 4d 0f 7e d8       	movq   %xmm11,%r8
    945c:	66 0f 60 f9          	punpcklbw %xmm1,%xmm7
    9460:	66 49 0f 7e fb       	movq   %xmm7,%r11
    9465:	66 41 0f 6f f8       	movdqa %xmm8,%xmm7
    946a:	66 45 0f 6f c2       	movdqa %xmm10,%xmm8
    946f:	66 44 0f 60 c1       	punpcklbw %xmm1,%xmm8
    9474:	66 0f 60 f9          	punpcklbw %xmm1,%xmm7
    9478:	66 44 0f 60 d1       	punpcklbw %xmm1,%xmm10
    947d:	66 41 0f 6f c8       	movdqa %xmm8,%xmm1
    9482:	66 4d 0f 6e db       	movq   %r11,%xmm11
    9487:	66 45 0f 70 d2 4e    	pshufd $0x4e,%xmm10,%xmm10
    948d:	66 44 0f d5 de       	pmullw %xmm6,%xmm11
    9492:	66 0f 71 f1 01       	psllw  $0x1,%xmm1
    9497:	66 0f 70 ff 4e       	pshufd $0x4e,%xmm7,%xmm7
    949c:	66 41 0f fd c8       	paddw  %xmm8,%xmm1
    94a1:	66 0f d5 f7          	pmullw %xmm7,%xmm6
    94a5:	66 0f 71 f1 04       	psllw  $0x4,%xmm1
    94aa:	66 41 0f f9 c8       	psubw  %xmm8,%xmm1
    94af:	66 41 0f fd cb       	paddw  %xmm11,%xmm1
    94b4:	66 4d 0f 6e df       	movq   %r15,%xmm11
    94b9:	66 41 0f 71 f3 04    	psllw  $0x4,%xmm11
    94bf:	66 44 0f fd dc       	paddw  %xmm4,%xmm11
    94c4:	66 44 0f fd d9       	paddw  %xmm1,%xmm11
    94c9:	66 41 0f 6f ca       	movdqa %xmm10,%xmm1
    94ce:	66 0f 71 f1 01       	psllw  $0x1,%xmm1
    94d3:	66 41 0f fd ca       	paddw  %xmm10,%xmm1
    94d8:	66 41 0f 71 d3 08    	psrlw  $0x8,%xmm11
    94de:	66 0f 71 f1 04       	psllw  $0x4,%xmm1
    94e3:	66 41 0f f9 ca       	psubw  %xmm10,%xmm1
    94e8:	66 0f fd ce          	paddw  %xmm6,%xmm1
    94ec:	66 49 0f 6e f0       	movq   %r8,%xmm6
    94f1:	66 0f 71 f6 04       	psllw  $0x4,%xmm6
    94f6:	66 0f fd f4          	paddw  %xmm4,%xmm6
    94fa:	66 0f fd ce          	paddw  %xmm6,%xmm1
    94fe:	66 41 0f 6f f3       	movdqa %xmm11,%xmm6
    9503:	66 4d 0f 6e d9       	movq   %r9,%xmm11
    9508:	66 0f db f0          	pand   %xmm0,%xmm6
    950c:	66 0f 71 d1 08       	psrlw  $0x8,%xmm1
    9511:	66 0f db c8          	pand   %xmm0,%xmm1
    9515:	66 0f 67 f1          	packuswb %xmm1,%xmm6
    9519:	f3 0f 7e 0d 8f 5d 00 	movq   0x5d8f(%rip),%xmm1        # f2b0 <__PRETTY_FUNCTION__.4+0x3d>
    9520:	00 
    9521:	66 0f 70 f6 08       	pshufd $0x8,%xmm6,%xmm6
    9526:	66 0f fc f1          	paddb  %xmm1,%xmm6
    952a:	66 41 0f 6f cf       	movdqa %xmm15,%xmm1
    952f:	66 0f 60 ce          	punpcklbw %xmm6,%xmm1
    9533:	66 44 0f 60 fe       	punpcklbw %xmm6,%xmm15
    9538:	66 49 0f 6e f7       	movq   %r15,%xmm6
    953d:	66 41 0f d6 0e       	movq   %xmm1,(%r14)
    9542:	66 44 0f fd ce       	paddw  %xmm6,%xmm9
    9547:	f3 0f 7e 4c 24 98    	movq   -0x68(%rsp),%xmm1
    954d:	f3 0f 7e 74 24 e8    	movq   -0x18(%rsp),%xmm6
    9553:	66 45 0f 70 ff 4e    	pshufd $0x4e,%xmm15,%xmm15
    9559:	66 0f fd ce          	paddw  %xmm6,%xmm1
    955d:	f3 0f 7e 74 24 f8    	movq   -0x8(%rsp),%xmm6
    9563:	66 45 0f d6 7e 08    	movq   %xmm15,0x8(%r14)
    9569:	66 4d 0f 6e f8       	movq   %r8,%xmm15
    956e:	66 44 0f fd c9       	paddw  %xmm1,%xmm9
    9573:	f3 0f 7e 4c 24 d8    	movq   -0x28(%rsp),%xmm1
    9579:	66 0f fd ce          	paddw  %xmm6,%xmm1
    957d:	66 48 0f 6e f0       	movq   %rax,%xmm6
    9582:	66 41 0f fd f7       	paddw  %xmm15,%xmm6
    9587:	f3 44 0f 7e 7c 24 08 	movq   0x8(%rsp),%xmm15
    958e:	66 41 0f 71 d1 02    	psrlw  $0x2,%xmm9
    9594:	66 0f fd ce          	paddw  %xmm6,%xmm1
    9598:	f3 0f 7e 74 24 b8    	movq   -0x48(%rsp),%xmm6
    959e:	66 41 0f fd f7       	paddw  %xmm15,%xmm6
    95a3:	66 4d 0f 6e fb       	movq   %r11,%xmm15
    95a8:	66 45 0f fd df       	paddw  %xmm15,%xmm11
    95ad:	f3 44 0f 7e 7c 24 28 	movq   0x28(%rsp),%xmm15
    95b4:	66 0f 71 d1 02       	psrlw  $0x2,%xmm1
    95b9:	66 41 0f fd f3       	paddw  %xmm11,%xmm6
    95be:	f3 44 0f 7e 5c 24 c8 	movq   -0x38(%rsp),%xmm11
    95c5:	66 45 0f fd df       	paddw  %xmm15,%xmm11
    95ca:	66 4c 0f 6e fe       	movq   %rsi,%xmm15
    95cf:	66 41 0f fd ff       	paddw  %xmm15,%xmm7
    95d4:	66 0f 71 d6 02       	psrlw  $0x2,%xmm6
    95d9:	66 44 0f fd df       	paddw  %xmm7,%xmm11
    95de:	f3 0f 7e 7c 24 a8    	movq   -0x58(%rsp),%xmm7
    95e4:	66 44 0f fd c7       	paddw  %xmm7,%xmm8
    95e9:	66 48 0f 6e ff       	movq   %rdi,%xmm7
    95ee:	66 41 0f fd fa       	paddw  %xmm10,%xmm7
    95f3:	66 41 0f 71 d3 02    	psrlw  $0x2,%xmm11
    95f9:	f3 44 0f 7e 15 ce 5c 	movq   0x5cce(%rip),%xmm10        # f2d0 <__PRETTY_FUNCTION__.4+0x5d>
    9600:	00 00 
    9602:	66 41 0f fd e8       	paddw  %xmm8,%xmm5
    9607:	66 0f fd fb          	paddw  %xmm3,%xmm7
    960b:	66 0f 6f de          	movdqa %xmm6,%xmm3
    960f:	66 0f d5 da          	pmullw %xmm2,%xmm3
    9613:	66 41 0f d5 d3       	pmullw %xmm11,%xmm2
    9618:	66 0f 71 d5 02       	psrlw  $0x2,%xmm5
    961d:	66 44 0f 6f c5       	movdqa %xmm5,%xmm8
    9622:	66 0f 71 d7 02       	psrlw  $0x2,%xmm7
    9627:	66 45 0f d5 c2       	pmullw %xmm10,%xmm8
    962c:	66 44 0f d5 d7       	pmullw %xmm7,%xmm10
    9631:	66 41 0f fd d8       	paddw  %xmm8,%xmm3
    9636:	66 45 0f 6f c1       	movdqa %xmm9,%xmm8
    963b:	66 41 0f 71 f0 03    	psllw  $0x3,%xmm8
    9641:	66 41 0f fd d2       	paddw  %xmm10,%xmm2
    9646:	66 44 0f 6f d5       	movdqa %xmm5,%xmm10
    964b:	66 45 0f f9 c1       	psubw  %xmm9,%xmm8
    9650:	66 41 0f 71 f2 03    	psllw  $0x3,%xmm10
    9656:	66 44 0f f9 d5       	psubw  %xmm5,%xmm10
    965b:	66 41 0f 71 f0 04    	psllw  $0x4,%xmm8
    9661:	66 44 0f fd c4       	paddw  %xmm4,%xmm8
    9666:	66 41 0f 6f ea       	movdqa %xmm10,%xmm5
    966b:	66 0f 71 f5 04       	psllw  $0x4,%xmm5
    9670:	66 41 0f fd d8       	paddw  %xmm8,%xmm3
    9675:	66 44 0f 6f c1       	movdqa %xmm1,%xmm8
    967a:	66 41 0f 71 f0 03    	psllw  $0x3,%xmm8
    9680:	66 44 0f f9 c1       	psubw  %xmm1,%xmm8
    9685:	66 0f 71 e3 08       	psraw  $0x8,%xmm3
    968a:	66 0f db d8          	pand   %xmm0,%xmm3
    968e:	66 41 0f 71 f0 04    	psllw  $0x4,%xmm8
    9694:	66 44 0f fd c4       	paddw  %xmm4,%xmm8
    9699:	66 41 0f fd d0       	paddw  %xmm8,%xmm2
    969e:	66 44 0f 6f c3       	movdqa %xmm3,%xmm8
    96a3:	f3 0f 7e 1d 45 5c 00 	movq   0x5c45(%rip),%xmm3        # f2f0 <__PRETTY_FUNCTION__.4+0x7d>
    96aa:	00 
    96ab:	66 0f 71 e2 08       	psraw  $0x8,%xmm2
    96b0:	66 0f db d0          	pand   %xmm0,%xmm2
    96b4:	66 44 0f 67 c2       	packuswb %xmm2,%xmm8
    96b9:	66 45 0f 70 c0 08    	pshufd $0x8,%xmm8,%xmm8
    96bf:	66 41 0f 6f d0       	movdqa %xmm8,%xmm2
    96c4:	f3 44 0f 7e 05 33 5c 	movq   0x5c33(%rip),%xmm8        # f300 <__PRETTY_FUNCTION__.4+0x8d>
    96cb:	00 00 
    96cd:	66 0f fc d3          	paddb  %xmm3,%xmm2
    96d1:	66 41 0f d5 f0       	pmullw %xmm8,%xmm6
    96d6:	66 45 0f d5 d8       	pmullw %xmm8,%xmm11
    96db:	66 0f fd ee          	paddw  %xmm6,%xmm5
    96df:	66 41 0f 6f f1       	movdqa %xmm9,%xmm6
    96e4:	66 0f 71 f6 02       	psllw  $0x2,%xmm6
    96e9:	66 41 0f fd f1       	paddw  %xmm9,%xmm6
    96ee:	66 44 0f 6f cc       	movdqa %xmm4,%xmm9
    96f3:	66 0f 71 f6 01       	psllw  $0x1,%xmm6
    96f8:	66 44 0f f9 ce       	psubw  %xmm6,%xmm9
    96fd:	66 0f 6f f7          	movdqa %xmm7,%xmm6
    9701:	66 0f 71 f6 03       	psllw  $0x3,%xmm6
    9706:	66 0f f9 f7          	psubw  %xmm7,%xmm6
    970a:	66 41 0f fd e9       	paddw  %xmm9,%xmm5
    970f:	66 0f 71 f6 04       	psllw  $0x4,%xmm6
    9714:	66 44 0f fd de       	paddw  %xmm6,%xmm11
    9719:	66 0f 71 e5 08       	psraw  $0x8,%xmm5
    971e:	66 0f 6f f1          	movdqa %xmm1,%xmm6
    9722:	66 0f 71 f6 02       	psllw  $0x2,%xmm6
    9727:	66 0f fd ce          	paddw  %xmm6,%xmm1
    972b:	66 0f 71 f1 01       	psllw  $0x1,%xmm1
    9730:	66 0f f9 e1          	psubw  %xmm1,%xmm4
    9734:	66 41 0f 6f cb       	movdqa %xmm11,%xmm1
    9739:	66 0f fd cc          	paddw  %xmm4,%xmm1
    973d:	66 0f 6f e5          	movdqa %xmm5,%xmm4
    9741:	66 0f db e0          	pand   %xmm0,%xmm4
    9745:	66 0f 71 e1 08       	psraw  $0x8,%xmm1
    974a:	66 0f db c1          	pand   %xmm1,%xmm0
    974e:	66 0f 6f ca          	movdqa %xmm2,%xmm1
    9752:	66 0f 67 e0          	packuswb %xmm0,%xmm4
    9756:	66 0f 70 e4 08       	pshufd $0x8,%xmm4,%xmm4
    975b:	66 0f fc dc          	paddb  %xmm4,%xmm3
    975f:	66 0f 60 d3          	punpcklbw %xmm3,%xmm2
    9763:	66 0f 60 cb          	punpcklbw %xmm3,%xmm1
    9767:	66 0f 70 d2 4e       	pshufd $0x4e,%xmm2,%xmm2
    976c:	66 0f d6 0a          	movq   %xmm1,(%rdx)
    9770:	66 0f d6 52 08       	movq   %xmm2,0x8(%rdx)
    9775:	48 8b 3c 24          	mov    (%rsp),%rdi
    9779:	48 63 c9             	movslq %ecx,%rcx
    977c:	4c 8b 44 24 f0       	mov    -0x10(%rsp),%r8
    9781:	48 8d 04 8d 00 00 00 	lea    0x0(,%rcx,4),%rax
    9788:	00 
    9789:	48 01 c7             	add    %rax,%rdi
    978c:	49 01 c0             	add    %rax,%r8
    978f:	48 89 f8             	mov    %rdi,%rax
    9792:	48 8b 7c 24 b0       	mov    -0x50(%rsp),%rdi
    9797:	4c 8d 0c 3b          	lea    (%rbx,%rdi,1),%r9
    979b:	41 0f b6 58 01       	movzbl 0x1(%r8),%ebx
    97a0:	45 0f b6 58 02       	movzbl 0x2(%r8),%r11d
    97a5:	45 0f b6 30          	movzbl (%r8),%r14d
    97a9:	48 8b 7c 24 90       	mov    -0x70(%rsp),%rdi
    97ae:	41 6b f3 2f          	imul   $0x2f,%r11d,%esi
    97b2:	69 d3 9d 00 00 00    	imul   $0x9d,%ebx,%edx
    97b8:	01 f2                	add    %esi,%edx
    97ba:	44 89 f6             	mov    %r14d,%esi
    97bd:	c1 e6 04             	shl    $0x4,%esi
    97c0:	8d 94 32 80 00 00 00 	lea    0x80(%rdx,%rsi,1),%edx
    97c7:	c1 fa 08             	sar    $0x8,%edx
    97ca:	83 c2 10             	add    $0x10,%edx
    97cd:	88 14 0f             	mov    %dl,(%rdi,%rcx,1)
    97d0:	41 0f b6 70 05       	movzbl 0x5(%r8),%esi
    97d5:	41 0f b6 50 06       	movzbl 0x6(%r8),%edx
    97da:	41 0f b6 78 04       	movzbl 0x4(%r8),%edi
    97df:	44 69 fe 9d 00 00 00 	imul   $0x9d,%esi,%r15d
    97e6:	01 de                	add    %ebx,%esi
    97e8:	44 6b d2 2f          	imul   $0x2f,%edx,%r10d
    97ec:	44 01 da             	add    %r11d,%edx
    97ef:	45 01 fa             	add    %r15d,%r10d
    97f2:	41 89 ff             	mov    %edi,%r15d
    97f5:	44 01 f7             	add    %r14d,%edi
    97f8:	41 c1 e7 04          	shl    $0x4,%r15d
    97fc:	47 8d 94 3a 80 00 00 	lea    0x80(%r10,%r15,1),%r10d
    9803:	00 
    9804:	4c 8b 7c 24 90       	mov    -0x70(%rsp),%r15
    9809:	41 c1 fa 08          	sar    $0x8,%r10d
    980d:	41 83 c2 10          	add    $0x10,%r10d
    9811:	45 88 54 0f 01       	mov    %r10b,0x1(%r15,%rcx,1)
    9816:	44 0f b6 50 01       	movzbl 0x1(%rax),%r10d
    981b:	44 0f b6 70 02       	movzbl 0x2(%rax),%r14d
    9820:	44 0f b6 18          	movzbl (%rax),%r11d
    9824:	45 69 fa 9d 00 00 00 	imul   $0x9d,%r10d,%r15d
    982b:	41 01 f2             	add    %esi,%r10d
    982e:	41 6b de 2f          	imul   $0x2f,%r14d,%ebx
    9832:	41 01 d6             	add    %edx,%r14d
    9835:	44 01 fb             	add    %r15d,%ebx
    9838:	45 89 df             	mov    %r11d,%r15d
    983b:	41 01 fb             	add    %edi,%r11d
    983e:	41 c1 e7 04          	shl    $0x4,%r15d
    9842:	42 8d 9c 3b 80 00 00 	lea    0x80(%rbx,%r15,1),%ebx
    9849:	00 
    984a:	c1 fb 08             	sar    $0x8,%ebx
    984d:	83 c3 10             	add    $0x10,%ebx
    9850:	41 88 5c 0d 00       	mov    %bl,0x0(%r13,%rcx,1)
    9855:	0f b6 50 05          	movzbl 0x5(%rax),%edx
    9859:	0f b6 78 06          	movzbl 0x6(%rax),%edi
    985d:	0f b6 70 04          	movzbl 0x4(%rax),%esi
    9861:	44 69 fa 9d 00 00 00 	imul   $0x9d,%edx,%r15d
    9868:	6b df 2f             	imul   $0x2f,%edi,%ebx
    986b:	44 01 fb             	add    %r15d,%ebx
    986e:	41 89 f7             	mov    %esi,%r15d
    9871:	44 01 de             	add    %r11d,%esi
    9874:	41 c1 e7 04          	shl    $0x4,%r15d
    9878:	c1 fe 02             	sar    $0x2,%esi
    987b:	42 8d 9c 3b 80 00 00 	lea    0x80(%rbx,%r15,1),%ebx
    9882:	00 
    9883:	c1 fb 08             	sar    $0x8,%ebx
    9886:	83 c3 10             	add    $0x10,%ebx
    9889:	44 01 d2             	add    %r10d,%edx
    988c:	44 01 f7             	add    %r14d,%edi
    988f:	49 83 c0 08          	add    $0x8,%r8
    9893:	c1 fa 02             	sar    $0x2,%edx
    9896:	c1 ff 02             	sar    $0x2,%edi
    9899:	41 88 5c 0d 01       	mov    %bl,0x1(%r13,%rcx,1)
    989e:	48 83 c0 08          	add    $0x8,%rax
    98a2:	44 6b df e6          	imul   $0xffffffe6,%edi,%r11d
    98a6:	44 6b d2 aa          	imul   $0xffffffaa,%edx,%r10d
    98aa:	6b ff 70             	imul   $0x70,%edi,%edi
    98ad:	6b d2 9a             	imul   $0xffffff9a,%edx,%edx
    98b0:	45 01 da             	add    %r11d,%r10d
    98b3:	44 6b de 70          	imul   $0x70,%esi,%r11d
    98b7:	6b f6 f6             	imul   $0xfffffff6,%esi,%esi
    98ba:	01 fa                	add    %edi,%edx
    98bc:	47 8d 94 1a 80 00 00 	lea    0x80(%r10,%r11,1),%r10d
    98c3:	00 
    98c4:	8d 94 32 80 00 00 00 	lea    0x80(%rdx,%rsi,1),%edx
    98cb:	41 c1 fa 08          	sar    $0x8,%r10d
    98cf:	c1 fa 08             	sar    $0x8,%edx
    98d2:	41 83 ea 80          	sub    $0xffffff80,%r10d
    98d6:	83 ea 80             	sub    $0xffffff80,%edx
    98d9:	45 88 14 09          	mov    %r10b,(%r9,%rcx,1)
    98dd:	41 88 54 09 01       	mov    %dl,0x1(%r9,%rcx,1)
    98e2:	48 83 c1 02          	add    $0x2,%rcx
    98e6:	39 cd                	cmp    %ecx,%ebp
    98e8:	0f 8f ad fe ff ff    	jg     979b <convert_job+0x295b>
    98ee:	41 8b 54 24 34       	mov    0x34(%r12),%edx
    98f3:	83 44 24 88 01       	addl   $0x1,-0x78(%rsp)
    98f8:	8b 44 24 88          	mov    -0x78(%rsp),%eax
    98fc:	83 44 24 4c 02       	addl   $0x2,0x4c(%rsp)
    9901:	48 83 44 24 e0 01    	addq   $0x1,-0x20(%rsp)
    9907:	39 d0                	cmp    %edx,%eax
    9909:	0f 8c 07 e6 ff ff    	jl     7f16 <convert_job+0x10d6>
    990f:	e9 4a d9 ff ff       	jmp    725e <convert_job+0x41e>
    9914:	0f 1f 40 00          	nopl   0x0(%rax)
    9918:	66 45 0f ef d2       	pxor   %xmm10,%xmm10
    991d:	89 c2                	mov    %eax,%edx
    991f:	89 d9                	mov    %ebx,%ecx
    9921:	44 89 de             	mov    %r11d,%esi
    9924:	66 41 0f 6f e2       	movdqa %xmm10,%xmm4
    9929:	66 44 0f d6 54 24 88 	movq   %xmm10,-0x78(%rsp)
    9930:	31 ff                	xor    %edi,%edi
    9932:	45 31 d2             	xor    %r10d,%r10d
    9935:	e9 b2 df ff ff       	jmp    78ec <convert_job+0xaac>
    993a:	48 8b 1c 24          	mov    (%rsp),%rbx
    993e:	83 c1 01             	add    $0x1,%ecx
    9941:	88 14 03             	mov    %dl,(%rbx,%rax,1)
    9944:	e9 20 dd ff ff       	jmp    7669 <convert_job+0x829>
    9949:	8b 54 24 18          	mov    0x18(%rsp),%edx
    994d:	8b 74 24 28          	mov    0x28(%rsp),%esi
    9951:	8b 4c 24 30          	mov    0x30(%rsp),%ecx
    9955:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
    995a:	c1 fa 02             	sar    $0x2,%edx
    995d:	c1 fe 02             	sar    $0x2,%esi
    9960:	44 6b c6 e6          	imul   $0xffffffe6,%esi,%r8d
    9964:	c1 f9 02             	sar    $0x2,%ecx
    9967:	6b c2 aa             	imul   $0xffffffaa,%edx,%eax
    996a:	44 01 c0             	add    %r8d,%eax
    996d:	44 6b c1 70          	imul   $0x70,%ecx,%r8d
    9971:	42 8d 84 00 80 00 00 	lea    0x80(%rax,%r8,1),%eax
    9978:	00 
    9979:	c1 f8 08             	sar    $0x8,%eax
    997c:	83 e8 80             	sub    $0xffffff80,%eax
    997f:	0f 88 89 00 00 00    	js     9a0e <convert_job+0x2bce>
    9985:	3d ff 00 00 00       	cmp    $0xff,%eax
    998a:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    9990:	41 0f 4f c0          	cmovg  %r8d,%eax
    9994:	6b f6 70             	imul   $0x70,%esi,%esi
    9997:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
    999c:	6b d2 9a             	imul   $0xffffff9a,%edx,%edx
    999f:	6b c9 f6             	imul   $0xfffffff6,%ecx,%ecx
    99a2:	88 04 3b             	mov    %al,(%rbx,%rdi,1)
    99a5:	01 f2                	add    %esi,%edx
    99a7:	8d 84 0a 80 00 00 00 	lea    0x80(%rdx,%rcx,1),%eax
    99ae:	c1 f8 08             	sar    $0x8,%eax
    99b1:	83 e8 80             	sub    $0xffffff80,%eax
    99b4:	78 54                	js     9a0a <convert_job+0x2bca>
    99b6:	3d ff 00 00 00       	cmp    $0xff,%eax
    99bb:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    99c0:	0f 4f c2             	cmovg  %edx,%eax
    99c3:	88 44 3b 01          	mov    %al,0x1(%rbx,%rdi,1)
    99c7:	48 83 c7 02          	add    $0x2,%rdi
    99cb:	39 7c 24 58          	cmp    %edi,0x58(%rsp)
    99cf:	0f 8f 73 dc ff ff    	jg     7648 <convert_job+0x808>
    99d5:	48 8b 44 24 b8       	mov    -0x48(%rsp),%rax
    99da:	44 8b 54 24 50       	mov    0x50(%rsp),%r10d
    99df:	4c 8b 5c 24 68       	mov    0x68(%rsp),%r11
    99e4:	8b 50 34             	mov    0x34(%rax),%edx
    99e7:	41 83 c2 01          	add    $0x1,%r10d
    99eb:	49 83 c3 01          	add    $0x1,%r11
    99ef:	41 39 d2             	cmp    %edx,%r10d
    99f2:	0f 8c 9f db ff ff    	jl     7597 <convert_job+0x757>
    99f8:	e9 61 d8 ff ff       	jmp    725e <convert_job+0x41e>
    99fd:	0f 1f 00             	nopl   (%rax)
    9a00:	ba 10 00 00 00       	mov    $0x10,%edx
    9a05:	e9 86 e2 ff ff       	jmp    7c90 <convert_job+0xe50>
    9a0a:	31 c0                	xor    %eax,%eax
    9a0c:	eb b5                	jmp    99c3 <convert_job+0x2b83>
    9a0e:	31 c0                	xor    %eax,%eax
    9a10:	e9 7f ff ff ff       	jmp    9994 <convert_job+0x2b54>
    9a15:	41 89 c4             	mov    %eax,%r12d
    9a18:	31 c9                	xor    %ecx,%ecx
    9a1a:	e9 c7 db ff ff       	jmp    75e6 <convert_job+0x7a6>
    9a1f:	90                   	nop
    9a20:	48 8b 7c 24 98       	mov    -0x68(%rsp),%rdi
    9a25:	44 01 d3             	add    %r10d,%ebx
    9a28:	01 cd                	add    %ecx,%ebp
    9a2a:	41 01 c3             	add    %eax,%r11d
    9a2d:	88 14 37             	mov    %dl,(%rdi,%rsi,1)
    9a30:	41 83 f8 03          	cmp    $0x3,%r8d
    9a34:	0f 85 b6 00 00 00    	jne    9af0 <convert_job+0x2cb0>
    9a3a:	c1 fd 02             	sar    $0x2,%ebp
    9a3d:	41 c1 fb 02          	sar    $0x2,%r11d
    9a41:	48 8b 7c 24 d8       	mov    -0x28(%rsp),%rdi
    9a46:	6b f5 aa             	imul   $0xffffffaa,%ebp,%esi
    9a49:	c1 fb 02             	sar    $0x2,%ebx
    9a4c:	41 6b d3 e6          	imul   $0xffffffe6,%r11d,%edx
    9a50:	01 f2                	add    %esi,%edx
    9a52:	6b f3 70             	imul   $0x70,%ebx,%esi
    9a55:	8d 94 32 80 00 00 00 	lea    0x80(%rdx,%rsi,1),%edx
    9a5c:	31 f6                	xor    %esi,%esi
    9a5e:	c1 fa 08             	sar    $0x8,%edx
    9a61:	83 ea 80             	sub    $0xffffff80,%edx
    9a64:	78 0e                	js     9a74 <convert_job+0x2c34>
    9a66:	81 fa ff 00 00 00    	cmp    $0xff,%edx
    9a6c:	be ff ff ff ff       	mov    $0xffffffff,%esi
    9a71:	0f 4e f2             	cmovle %edx,%esi
    9a74:	45 6b db 70          	imul   $0x70,%r11d,%r11d
    9a78:	48 8b 44 24 b0       	mov    -0x50(%rsp),%rax
    9a7d:	6b ed 9a             	imul   $0xffffff9a,%ebp,%ebp
    9a80:	6b db f6             	imul   $0xfffffff6,%ebx,%ebx
    9a83:	40 88 34 38          	mov    %sil,(%rax,%rdi,1)
    9a87:	31 f6                	xor    %esi,%esi
    9a89:	41 8d 14 2b          	lea    (%r11,%rbp,1),%edx
    9a8d:	8d 94 1a 80 00 00 00 	lea    0x80(%rdx,%rbx,1),%edx
    9a94:	c1 fa 08             	sar    $0x8,%edx
    9a97:	83 ea 80             	sub    $0xffffff80,%edx
    9a9a:	78 0e                	js     9aaa <convert_job+0x2c6a>
    9a9c:	81 fa ff 00 00 00    	cmp    $0xff,%edx
    9aa2:	be ff ff ff ff       	mov    $0xffffffff,%esi
    9aa7:	0f 4e f2             	cmovle %edx,%esi
    9aaa:	48 8b 44 24 b0       	mov    -0x50(%rsp),%rax
    9aaf:	40 88 74 38 01       	mov    %sil,0x1(%rax,%rdi,1)
    9ab4:	48 83 c7 02          	add    $0x2,%rdi
    9ab8:	39 7c 24 b8          	cmp    %edi,-0x48(%rsp)
    9abc:	0f 8f 65 d8 ff ff    	jg     7327 <convert_job+0x4e7>
    9ac2:	44 8b 54 24 c8       	mov    -0x38(%rsp),%r10d
    9ac7:	48 8b 74 24 e0       	mov    -0x20(%rsp),%rsi
    9acc:	41 8b 54 24 34       	mov    0x34(%r12),%edx
    9ad1:	41 83 c2 01          	add    $0x1,%r10d
    9ad5:	48 83 c6 01          	add    $0x1,%rsi
    9ad9:	41 39 d2             	cmp    %edx,%r10d
    9adc:	0f 8c a5 d7 ff ff    	jl     7287 <convert_job+0x447>
    9ae2:	e9 77 d7 ff ff       	jmp    725e <convert_job+0x41e>
    9ae7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9aee:	00 00 
    9af0:	41 b8 03 00 00 00    	mov    $0x3,%r8d
    9af6:	e9 3f d8 ff ff       	jmp    733a <convert_job+0x4fa>
    9afb:	89 c1                	mov    %eax,%ecx
    9afd:	45 31 c0             	xor    %r8d,%r8d
    9b00:	e9 ca d7 ff ff       	jmp    72cf <convert_job+0x48f>
    9b05:	44 89 74 24 98       	mov    %r14d,-0x68(%rsp)
    9b0a:	45 31 c9             	xor    %r9d,%r9d
    9b0d:	e9 e6 d3 ff ff       	jmp    6ef8 <convert_job+0xb8>
    9b12:	48 63 c1             	movslq %ecx,%rax
    9b15:	48 8b 34 24          	mov    (%rsp),%rsi
    9b19:	48 8d 14 85 00 00 00 	lea    0x0(,%rax,4),%rdx
    9b20:	00 
    9b21:	4c 8b 44 24 f0       	mov    -0x10(%rsp),%r8
    9b26:	48 8b 7c 24 b0       	mov    -0x50(%rsp),%rdi
    9b2b:	48 01 d6             	add    %rdx,%rsi
    9b2e:	49 01 d0             	add    %rdx,%r8
    9b31:	4c 8d 0c 3b          	lea    (%rbx,%rdi,1),%r9
    9b35:	48 89 f2             	mov    %rsi,%rdx
    9b38:	41 0f b6 58 01       	movzbl 0x1(%r8),%ebx
    9b3d:	45 0f b6 58 02       	movzbl 0x2(%r8),%r11d
    9b42:	45 0f b6 30          	movzbl (%r8),%r14d
    9b46:	48 8b 7c 24 90       	mov    -0x70(%rsp),%rdi
    9b4b:	41 6b f3 2f          	imul   $0x2f,%r11d,%esi
    9b4f:	69 cb 9d 00 00 00    	imul   $0x9d,%ebx,%ecx
    9b55:	01 f1                	add    %esi,%ecx
    9b57:	44 89 f6             	mov    %r14d,%esi
    9b5a:	c1 e6 04             	shl    $0x4,%esi
    9b5d:	8d 8c 31 80 00 00 00 	lea    0x80(%rcx,%rsi,1),%ecx
    9b64:	c1 f9 08             	sar    $0x8,%ecx
    9b67:	83 c1 10             	add    $0x10,%ecx
    9b6a:	88 0c 07             	mov    %cl,(%rdi,%rax,1)
    9b6d:	41 0f b6 70 05       	movzbl 0x5(%r8),%esi
    9b72:	41 0f b6 48 06       	movzbl 0x6(%r8),%ecx
    9b77:	41 0f b6 78 04       	movzbl 0x4(%r8),%edi
    9b7c:	44 69 fe 9d 00 00 00 	imul   $0x9d,%esi,%r15d
    9b83:	01 de                	add    %ebx,%esi
    9b85:	44 6b d1 2f          	imul   $0x2f,%ecx,%r10d
    9b89:	44 01 d9             	add    %r11d,%ecx
    9b8c:	45 01 fa             	add    %r15d,%r10d
    9b8f:	41 89 ff             	mov    %edi,%r15d
    9b92:	44 01 f7             	add    %r14d,%edi
    9b95:	41 c1 e7 04          	shl    $0x4,%r15d
    9b99:	47 8d 94 3a 80 00 00 	lea    0x80(%r10,%r15,1),%r10d
    9ba0:	00 
    9ba1:	4c 8b 7c 24 90       	mov    -0x70(%rsp),%r15
    9ba6:	41 c1 fa 08          	sar    $0x8,%r10d
    9baa:	41 83 c2 10          	add    $0x10,%r10d
    9bae:	45 88 54 07 01       	mov    %r10b,0x1(%r15,%rax,1)
    9bb3:	44 0f b6 52 01       	movzbl 0x1(%rdx),%r10d
    9bb8:	44 0f b6 72 02       	movzbl 0x2(%rdx),%r14d
    9bbd:	44 0f b6 1a          	movzbl (%rdx),%r11d
    9bc1:	45 69 fa 9d 00 00 00 	imul   $0x9d,%r10d,%r15d
    9bc8:	41 01 f2             	add    %esi,%r10d
    9bcb:	41 6b de 2f          	imul   $0x2f,%r14d,%ebx
    9bcf:	41 01 ce             	add    %ecx,%r14d
    9bd2:	44 01 fb             	add    %r15d,%ebx
    9bd5:	45 89 df             	mov    %r11d,%r15d
    9bd8:	41 01 fb             	add    %edi,%r11d
    9bdb:	41 c1 e7 04          	shl    $0x4,%r15d
    9bdf:	42 8d 9c 3b 80 00 00 	lea    0x80(%rbx,%r15,1),%ebx
    9be6:	00 
    9be7:	c1 fb 08             	sar    $0x8,%ebx
    9bea:	83 c3 10             	add    $0x10,%ebx
    9bed:	41 88 5c 05 00       	mov    %bl,0x0(%r13,%rax,1)
    9bf2:	0f b6 4a 05          	movzbl 0x5(%rdx),%ecx
    9bf6:	0f b6 7a 06          	movzbl 0x6(%rdx),%edi
    9bfa:	0f b6 72 04          	movzbl 0x4(%rdx),%esi
    9bfe:	44 69 f9 9d 00 00 00 	imul   $0x9d,%ecx,%r15d
    9c05:	6b df 2f             	imul   $0x2f,%edi,%ebx
    9c08:	44 01 fb             	add    %r15d,%ebx
    9c0b:	41 89 f7             	mov    %esi,%r15d
    9c0e:	44 01 de             	add    %r11d,%esi
    9c11:	41 c1 e7 04          	shl    $0x4,%r15d
    9c15:	c1 fe 02             	sar    $0x2,%esi
    9c18:	42 8d 9c 3b 80 00 00 	lea    0x80(%rbx,%r15,1),%ebx
    9c1f:	00 
    9c20:	c1 fb 08             	sar    $0x8,%ebx
    9c23:	83 c3 10             	add    $0x10,%ebx
    9c26:	44 01 d1             	add    %r10d,%ecx
    9c29:	44 01 f7             	add    %r14d,%edi
    9c2c:	49 83 c0 08          	add    $0x8,%r8
    9c30:	c1 f9 02             	sar    $0x2,%ecx
    9c33:	c1 ff 02             	sar    $0x2,%edi
    9c36:	41 88 5c 05 01       	mov    %bl,0x1(%r13,%rax,1)
    9c3b:	48 83 c2 08          	add    $0x8,%rdx
    9c3f:	44 6b df e6          	imul   $0xffffffe6,%edi,%r11d
    9c43:	44 6b d1 aa          	imul   $0xffffffaa,%ecx,%r10d
    9c47:	6b ff 70             	imul   $0x70,%edi,%edi
    9c4a:	6b c9 9a             	imul   $0xffffff9a,%ecx,%ecx
    9c4d:	45 01 da             	add    %r11d,%r10d
    9c50:	44 6b de 70          	imul   $0x70,%esi,%r11d
    9c54:	6b f6 f6             	imul   $0xfffffff6,%esi,%esi
    9c57:	01 f9                	add    %edi,%ecx
    9c59:	47 8d 94 1a 80 00 00 	lea    0x80(%r10,%r11,1),%r10d
    9c60:	00 
    9c61:	8d 8c 31 80 00 00 00 	lea    0x80(%rcx,%rsi,1),%ecx
    9c68:	41 c1 fa 08          	sar    $0x8,%r10d
    9c6c:	c1 f9 08             	sar    $0x8,%ecx
    9c6f:	41 83 ea 80          	sub    $0xffffff80,%r10d
    9c73:	83 e9 80             	sub    $0xffffff80,%ecx
    9c76:	45 88 14 01          	mov    %r10b,(%r9,%rax,1)
    9c7a:	41 88 4c 01 01       	mov    %cl,0x1(%r9,%rax,1)
    9c7f:	48 83 c0 02          	add    $0x2,%rax
    9c83:	39 c5                	cmp    %eax,%ebp
    9c85:	0f 8f ad fe ff ff    	jg     9b38 <convert_job+0x2cf8>
    9c8b:	e9 5e fc ff ff       	jmp    98ee <convert_job+0x2aae>
    9c90:	89 fd                	mov    %edi,%ebp
    9c92:	31 c9                	xor    %ecx,%ecx
    9c94:	e9 c8 e2 ff ff       	jmp    7f61 <convert_job+0x1121>
    9c99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9ca0:	4c 8b 4c 24 98       	mov    -0x68(%rsp),%r9
    9ca5:	01 d3                	add    %edx,%ebx
    9ca7:	01 cd                	add    %ecx,%ebp
    9ca9:	41 01 c3             	add    %eax,%r11d
    9cac:	45 88 04 31          	mov    %r8b,(%r9,%rsi,1)
    9cb0:	83 ff 03             	cmp    $0x3,%edi
    9cb3:	0f 85 b7 00 00 00    	jne    9d70 <convert_job+0x2f30>
    9cb9:	c1 fd 02             	sar    $0x2,%ebp
    9cbc:	41 c1 fb 02          	sar    $0x2,%r11d
    9cc0:	4c 8b 4c 24 d8       	mov    -0x28(%rsp),%r9
    9cc5:	6b fd aa             	imul   $0xffffffaa,%ebp,%edi
    9cc8:	c1 fb 02             	sar    $0x2,%ebx
    9ccb:	41 6b f3 e6          	imul   $0xffffffe6,%r11d,%esi
    9ccf:	01 fe                	add    %edi,%esi
    9cd1:	6b fb 70             	imul   $0x70,%ebx,%edi
    9cd4:	8d b4 3e 80 00 00 00 	lea    0x80(%rsi,%rdi,1),%esi
    9cdb:	31 ff                	xor    %edi,%edi
    9cdd:	c1 fe 08             	sar    $0x8,%esi
    9ce0:	83 ee 80             	sub    $0xffffff80,%esi
    9ce3:	78 0e                	js     9cf3 <convert_job+0x2eb3>
    9ce5:	81 fe ff 00 00 00    	cmp    $0xff,%esi
    9ceb:	bf ff ff ff ff       	mov    $0xffffffff,%edi
    9cf0:	0f 4e fe             	cmovle %esi,%edi
    9cf3:	45 6b db 70          	imul   $0x70,%r11d,%r11d
    9cf7:	48 8b 44 24 b0       	mov    -0x50(%rsp),%rax
    9cfc:	6b ed 9a             	imul   $0xffffff9a,%ebp,%ebp
    9cff:	6b db f6             	imul   $0xfffffff6,%ebx,%ebx
    9d02:	42 88 3c 08          	mov    %dil,(%rax,%r9,1)
    9d06:	31 ff                	xor    %edi,%edi
    9d08:	41 8d 34 2b          	lea    (%r11,%rbp,1),%esi
    9d0c:	8d b4 1e 80 00 00 00 	lea    0x80(%rsi,%rbx,1),%esi
    9d13:	c1 fe 08             	sar    $0x8,%esi
    9d16:	83 ee 80             	sub    $0xffffff80,%esi
    9d19:	78 0e                	js     9d29 <convert_job+0x2ee9>
    9d1b:	81 fe ff 00 00 00    	cmp    $0xff,%esi
    9d21:	bf ff ff ff ff       	mov    $0xffffffff,%edi
    9d26:	0f 4e fe             	cmovle %esi,%edi
    9d29:	48 8b 44 24 b0       	mov    -0x50(%rsp),%rax
    9d2e:	42 88 7c 08 01       	mov    %dil,0x1(%rax,%r9,1)
    9d33:	49 83 c1 02          	add    $0x2,%r9
    9d37:	44 39 4c 24 b8       	cmp    %r9d,-0x48(%rsp)
    9d3c:	0f 8f 1d e0 ff ff    	jg     7d5f <convert_job+0xf1f>
    9d42:	44 8b 44 24 c8       	mov    -0x38(%rsp),%r8d
    9d47:	48 8b 74 24 e0       	mov    -0x20(%rsp),%rsi
    9d4c:	41 8b 55 34          	mov    0x34(%r13),%edx
    9d50:	41 83 c0 01          	add    $0x1,%r8d
    9d54:	48 83 c6 01          	add    $0x1,%rsi
    9d58:	41 39 d0             	cmp    %edx,%r8d
    9d5b:	0f 8c 67 df ff ff    	jl     7cc8 <convert_job+0xe88>
    9d61:	e9 f8 d4 ff ff       	jmp    725e <convert_job+0x41e>
    9d66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9d6d:	00 00 00 
    9d70:	bf 03 00 00 00       	mov    $0x3,%edi
    9d75:	e9 f8 df ff ff       	jmp    7d72 <convert_job+0xf32>
    9d7a:	89 c1                	mov    %eax,%ecx
    9d7c:	45 31 c9             	xor    %r9d,%r9d
    9d7f:	e9 89 df ff ff       	jmp    7d0d <convert_job+0xecd>
    9d84:	31 d2                	xor    %edx,%edx
    9d86:	e9 4c ee ff ff       	jmp    8bd7 <convert_job+0x1d97>

Disassembly of section .fini:
