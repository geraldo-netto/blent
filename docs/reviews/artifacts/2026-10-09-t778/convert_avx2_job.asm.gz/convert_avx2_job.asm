
/tmp/blent-adaptive-20261009/t778-after:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

00000000000054b0 <convert_avx2_job>:
    54b0:	f3 0f 1e fa          	endbr64
    54b4:	55                   	push   %rbp
    54b5:	48 89 e5             	mov    %rsp,%rbp
    54b8:	41 57                	push   %r15
    54ba:	41 56                	push   %r14
    54bc:	41 55                	push   %r13
    54be:	41 54                	push   %r12
    54c0:	53                   	push   %rbx
    54c1:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
    54c5:	48 81 ec e8 02 00 00 	sub    $0x2e8,%rsp
    54cc:	48 89 bc 24 b8 02 00 	mov    %rdi,0x2b8(%rsp)
    54d3:	00 
    54d4:	8b 77 30             	mov    0x30(%rdi),%esi
    54d7:	8b 47 34             	mov    0x34(%rdi),%eax
    54da:	8d 0c 36             	lea    (%rsi,%rsi,1),%ecx
    54dd:	89 b4 24 c4 02 00 00 	mov    %esi,0x2c4(%rsp)
    54e4:	89 4c 24 64          	mov    %ecx,0x64(%rsp)
    54e8:	48 63 ce             	movslq %esi,%rcx
    54eb:	48 89 8c 24 a8 02 00 	mov    %rcx,0x2a8(%rsp)
    54f2:	00 
    54f3:	39 c6                	cmp    %eax,%esi
    54f5:	0f 8d 68 17 00 00    	jge    6c63 <convert_avx2_job+0x17b3>
    54fb:	c5 f9 6f 35 8d 9d 00 	vmovdqa 0x9d8d(%rip),%xmm6        # f290 <__PRETTY_FUNCTION__.4+0x1d>
    5502:	00 
    5503:	c5 f9 73 de 08       	vpsrldq $0x8,%xmm6,%xmm0
    5508:	c4 e2 79 30 f0       	vpmovzxbw %xmm0,%xmm6
    550d:	c5 f9 7f 74 24 68    	vmovdqa %xmm6,0x68(%rsp)
    5513:	c5 f9 6f 35 85 9d 00 	vmovdqa 0x9d85(%rip),%xmm6        # f2a0 <__PRETTY_FUNCTION__.4+0x2d>
    551a:	00 
    551b:	c5 f9 73 de 08       	vpsrldq $0x8,%xmm6,%xmm0
    5520:	c4 e2 79 30 f0       	vpmovzxbw %xmm0,%xmm6
    5525:	c5 f9 7f 74 24 a8    	vmovdqa %xmm6,-0x58(%rsp)
    552b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5530:	48 8b 8c 24 b8 02 00 	mov    0x2b8(%rsp),%rcx
    5537:	00 
    5538:	48 8b 49 38          	mov    0x38(%rcx),%rcx
    553c:	48 85 c9             	test   %rcx,%rcx
    553f:	74 1f                	je     5560 <convert_avx2_job+0xb0>
    5541:	8b b4 24 c4 02 00 00 	mov    0x2c4(%rsp),%esi
    5548:	89 f2                	mov    %esi,%edx
    554a:	83 e6 07             	and    $0x7,%esi
    554d:	c1 fa 03             	sar    $0x3,%edx
    5550:	48 63 d2             	movslq %edx,%rdx
    5553:	0f b6 0c 11          	movzbl (%rcx,%rdx,1),%ecx
    5557:	0f a3 f1             	bt     %esi,%ecx
    555a:	0f 83 db 16 00 00    	jae    6c3b <convert_avx2_job+0x178b>
    5560:	48 8b b4 24 b8 02 00 	mov    0x2b8(%rsp),%rsi
    5567:	00 
    5568:	48 8b 56 40          	mov    0x40(%rsi),%rdx
    556c:	4c 63 46 24          	movslq 0x24(%rsi),%r8
    5570:	48 85 d2             	test   %rdx,%rdx
    5573:	0f 84 a7 18 00 00    	je     6e20 <convert_avx2_job+0x1970>
    5579:	48 8b 8c 24 a8 02 00 	mov    0x2a8(%rsp),%rcx
    5580:	00 
    5581:	48 c1 e1 04          	shl    $0x4,%rcx
    5585:	48 01 ca             	add    %rcx,%rdx
    5588:	8b 0a                	mov    (%rdx),%ecx
    558a:	44 8b 7a 04          	mov    0x4(%rdx),%r15d
    558e:	89 8c 24 c0 02 00 00 	mov    %ecx,0x2c0(%rsp)
    5595:	48 63 5c 24 64       	movslq 0x64(%rsp),%rbx
    559a:	48 63 4e 20          	movslq 0x20(%rsi),%rcx
    559e:	4c 8b 26             	mov    (%rsi),%r12
    55a1:	4c 8b 76 08          	mov    0x8(%rsi),%r14
    55a5:	48 89 df             	mov    %rbx,%rdi
    55a8:	48 89 da             	mov    %rbx,%rdx
    55ab:	48 0f af f9          	imul   %rcx,%rdi
    55af:	83 c2 01             	add    $0x1,%edx
    55b2:	48 63 d2             	movslq %edx,%rdx
    55b5:	49 0f af d8          	imul   %r8,%rbx
    55b9:	48 0f af ca          	imul   %rdx,%rcx
    55bd:	48 89 7c 24 58       	mov    %rdi,0x58(%rsp)
    55c2:	4c 01 e7             	add    %r12,%rdi
    55c5:	49 0f af d0          	imul   %r8,%rdx
    55c9:	48 89 7c 24 b8       	mov    %rdi,-0x48(%rsp)
    55ce:	48 89 f7             	mov    %rsi,%rdi
    55d1:	48 8b 7f 10          	mov    0x10(%rdi),%rdi
    55d5:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
    55da:	4c 01 e1             	add    %r12,%rcx
    55dd:	48 89 4c 24 a0       	mov    %rcx,-0x60(%rsp)
    55e2:	49 8d 34 16          	lea    (%r14,%rdx,1),%rsi
    55e6:	49 8d 0c 1e          	lea    (%r14,%rbx,1),%rcx
    55ea:	48 89 bc 24 b0 02 00 	mov    %rdi,0x2b0(%rsp)
    55f1:	00 
    55f2:	48 8b bc 24 a8 02 00 	mov    0x2a8(%rsp),%rdi
    55f9:	00 
    55fa:	49 0f af f8          	imul   %r8,%rdi
    55fe:	48 89 7c 24 78       	mov    %rdi,0x78(%rsp)
    5603:	8b bc 24 c0 02 00 00 	mov    0x2c0(%rsp),%edi
    560a:	41 39 ff             	cmp    %edi,%r15d
    560d:	0f 8e 28 16 00 00    	jle    6c3b <convert_avx2_job+0x178b>
    5613:	45 8d 57 ff          	lea    -0x1(%r15),%r10d
    5617:	41 29 fa             	sub    %edi,%r10d
    561a:	44 89 94 24 28 02 00 	mov    %r10d,0x228(%rsp)
    5621:	00 
    5622:	41 83 fa 1f          	cmp    $0x1f,%r10d
    5626:	0f 86 4c 16 00 00    	jbe    6c78 <convert_avx2_job+0x17c8>
    562c:	44 89 d7             	mov    %r10d,%edi
    562f:	4c 63 94 24 c0 02 00 	movslq 0x2c0(%rsp),%r10
    5636:	00 
    5637:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    563c:	d1 ef                	shr    $1,%edi
    563e:	4e 8d 1c 95 00 00 00 	lea    0x0(,%r10,4),%r11
    5645:	00 
    5646:	89 7c 24 60          	mov    %edi,0x60(%rsp)
    564a:	8d 7f 01             	lea    0x1(%rdi),%edi
    564d:	4c 01 d3             	add    %r10,%rbx
    5650:	4c 01 d8             	add    %r11,%rax
    5653:	4c 8d 2c fd 00 00 00 	lea    0x0(,%rdi,8),%r13
    565a:	00 
    565b:	4c 89 94 24 80 00 00 	mov    %r10,0x80(%rsp)
    5662:	00 
    5663:	48 01 ff             	add    %rdi,%rdi
    5666:	4e 8d 4c 28 ff       	lea    -0x1(%rax,%r13,1),%r9
    566b:	49 89 da             	mov    %rbx,%r10
    566e:	4c 01 e0             	add    %r12,%rax
    5671:	4c 01 f3             	add    %r14,%rbx
    5674:	4d 01 e1             	add    %r12,%r9
    5677:	4c 89 54 24 48       	mov    %r10,0x48(%rsp)
    567c:	49 01 fa             	add    %rdi,%r10
    567f:	4c 89 8c 24 c8 02 00 	mov    %r9,0x2c8(%rsp)
    5686:	00 
    5687:	4f 8d 0c 16          	lea    (%r14,%r10,1),%r9
    568b:	4c 8b 94 24 80 00 00 	mov    0x80(%rsp),%r10
    5692:	00 
    5693:	4c 89 8c 24 68 02 00 	mov    %r9,0x268(%rsp)
    569a:	00 
    569b:	4c 01 d2             	add    %r10,%rdx
    569e:	4d 8d 0c 16          	lea    (%r14,%rdx,1),%r9
    56a2:	48 89 54 24 c0       	mov    %rdx,-0x40(%rsp)
    56a7:	48 01 fa             	add    %rdi,%rdx
    56aa:	4c 01 f2             	add    %r14,%rdx
    56ad:	4c 89 8c 24 88 02 00 	mov    %r9,0x288(%rsp)
    56b4:	00 
    56b5:	4c 8b 8c 24 b0 02 00 	mov    0x2b0(%rsp),%r9
    56bc:	00 
    56bd:	48 89 94 24 48 02 00 	mov    %rdx,0x248(%rsp)
    56c4:	00 
    56c5:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
    56ca:	4c 01 d2             	add    %r10,%rdx
    56cd:	4d 89 ca             	mov    %r9,%r10
    56d0:	49 01 d2             	add    %rdx,%r10
    56d3:	48 01 d7             	add    %rdx,%rdi
    56d6:	48 89 54 24 98       	mov    %rdx,-0x68(%rsp)
    56db:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
    56e0:	4c 01 cf             	add    %r9,%rdi
    56e3:	4d 89 d1             	mov    %r10,%r9
    56e6:	49 01 d3             	add    %rdx,%r11
    56e9:	4b 8d 14 1c          	lea    (%r12,%r11,1),%rdx
    56ed:	4f 8d 5c 1d ff       	lea    -0x1(%r13,%r11,1),%r11
    56f2:	4c 8b 6c 24 48       	mov    0x48(%rsp),%r13
    56f7:	4d 01 e3             	add    %r12,%r11
    56fa:	4f 8d 6c 2e 02       	lea    0x2(%r14,%r13,1),%r13
    56ff:	4d 29 e9             	sub    %r13,%r9
    5702:	4d 89 cd             	mov    %r9,%r13
    5705:	4d 89 d1             	mov    %r10,%r9
    5708:	49 83 c5 01          	add    $0x1,%r13
    570c:	49 83 fd 3e          	cmp    $0x3e,%r13
    5710:	4c 8b 6c 24 c0       	mov    -0x40(%rsp),%r13
    5715:	0f 97 84 24 08 02 00 	seta   0x208(%rsp)
    571c:	00 
    571d:	4f 8d 6c 2e 02       	lea    0x2(%r14,%r13,1),%r13
    5722:	4d 29 e9             	sub    %r13,%r9
    5725:	4d 89 cd             	mov    %r9,%r13
    5728:	4c 8b 8c 24 c8 02 00 	mov    0x2c8(%rsp),%r9
    572f:	00 
    5730:	49 83 c5 01          	add    $0x1,%r13
    5734:	49 83 fd 3e          	cmp    $0x3e,%r13
    5738:	41 0f 97 c5          	seta   %r13b
    573c:	49 83 e8 01          	sub    $0x1,%r8
    5740:	44 22 ac 24 08 02 00 	and    0x208(%rsp),%r13b
    5747:	00 
    5748:	49 83 f8 3e          	cmp    $0x3e,%r8
    574c:	41 0f 97 c0          	seta   %r8b
    5750:	45 21 e8             	and    %r13d,%r8d
    5753:	4c 39 cb             	cmp    %r9,%rbx
    5756:	4c 8b 8c 24 68 02 00 	mov    0x268(%rsp),%r9
    575d:	00 
    575e:	41 0f 93 c5          	setae  %r13b
    5762:	4c 39 c8             	cmp    %r9,%rax
    5765:	0f 93 84 24 08 02 00 	setae  0x208(%rsp)
    576c:	00 
    576d:	44 0f b6 8c 24 08 02 	movzbl 0x208(%rsp),%r9d
    5774:	00 00 
    5776:	45 09 cd             	or     %r9d,%r13d
    5779:	4c 8b 8c 24 c8 02 00 	mov    0x2c8(%rsp),%r9
    5780:	00 
    5781:	45 21 c5             	and    %r8d,%r13d
    5784:	4c 39 8c 24 88 02 00 	cmp    %r9,0x288(%rsp)
    578b:	00 
    578c:	4c 8b 8c 24 48 02 00 	mov    0x248(%rsp),%r9
    5793:	00 
    5794:	41 0f 93 c0          	setae  %r8b
    5798:	4c 39 c8             	cmp    %r9,%rax
    579b:	0f 93 84 24 08 02 00 	setae  0x208(%rsp)
    57a2:	00 
    57a3:	44 0f b6 8c 24 08 02 	movzbl 0x208(%rsp),%r9d
    57aa:	00 00 
    57ac:	45 09 c8             	or     %r9d,%r8d
    57af:	4c 8b 8c 24 c8 02 00 	mov    0x2c8(%rsp),%r9
    57b6:	00 
    57b7:	45 21 e8             	and    %r13d,%r8d
    57ba:	4d 39 ca             	cmp    %r9,%r10
    57bd:	41 0f 93 c1          	setae  %r9b
    57c1:	48 39 f8             	cmp    %rdi,%rax
    57c4:	41 0f 93 c5          	setae  %r13b
    57c8:	45 09 e9             	or     %r13d,%r9d
    57cb:	45 21 c1             	and    %r8d,%r9d
    57ce:	4c 8b 84 24 68 02 00 	mov    0x268(%rsp),%r8
    57d5:	00 
    57d6:	4c 39 c2             	cmp    %r8,%rdx
    57d9:	41 0f 93 c0          	setae  %r8b
    57dd:	4c 39 db             	cmp    %r11,%rbx
    57e0:	41 0f 93 c5          	setae  %r13b
    57e4:	45 09 e8             	or     %r13d,%r8d
    57e7:	4c 8b ac 24 48 02 00 	mov    0x248(%rsp),%r13
    57ee:	00 
    57ef:	45 21 c8             	and    %r9d,%r8d
    57f2:	4c 39 9c 24 88 02 00 	cmp    %r11,0x288(%rsp)
    57f9:	00 
    57fa:	41 0f 93 c1          	setae  %r9b
    57fe:	4c 39 ea             	cmp    %r13,%rdx
    5801:	41 0f 93 c5          	setae  %r13b
    5805:	45 09 e9             	or     %r13d,%r9d
    5808:	45 84 c8             	test   %r9b,%r8b
    580b:	0f 84 72 14 00 00    	je     6c83 <convert_avx2_job+0x17d3>
    5811:	4d 39 da             	cmp    %r11,%r10
    5814:	41 0f 93 c0          	setae  %r8b
    5818:	48 39 fa             	cmp    %rdi,%rdx
    581b:	40 0f 93 c7          	setae  %dil
    581f:	44 08 c7             	or     %r8b,%dil
    5822:	0f 84 5b 14 00 00    	je     6c83 <convert_avx2_job+0x17d3>
    5828:	8b bc 24 28 02 00 00 	mov    0x228(%rsp),%edi
    582f:	83 ff 3f             	cmp    $0x3f,%edi
    5832:	0f 86 fb 15 00 00    	jbe    6e33 <convert_avx2_job+0x1983>
    5838:	c4 e2 79 78 05 4f 9a 	vpbroadcastb 0x9a4f(%rip),%xmm0        # f290 <__PRETTY_FUNCTION__.4+0x1d>
    583f:	00 00 
    5841:	41 b8 10 00 00 00    	mov    $0x10,%r8d
    5847:	c1 ef 06             	shr    $0x6,%edi
    584a:	c4 62 7d 79 3d 2d 9a 	vpbroadcastw 0x9a2d(%rip),%ymm15        # f280 <__PRETTY_FUNCTION__.4+0xd>
    5851:	00 00 
    5853:	c4 c1 79 6e f0       	vmovd  %r8d,%xmm6
    5858:	41 89 fb             	mov    %edi,%r11d
    585b:	48 c1 e7 06          	shl    $0x6,%rdi
    585f:	c4 62 7d 30 e8       	vpmovzxbw %xmm0,%ymm13
    5864:	c4 e2 7d 78 f6       	vpbroadcastb %xmm6,%ymm6
    5869:	49 89 f9             	mov    %rdi,%r9
    586c:	31 ff                	xor    %edi,%edi
    586e:	c4 e2 79 78 05 29 9a 	vpbroadcastb 0x9a29(%rip),%xmm0        # f2a0 <__PRETTY_FUNCTION__.4+0x2d>
    5875:	00 00 
    5877:	c5 fd 7f b4 24 c8 02 	vmovdqa %ymm6,0x2c8(%rsp)
    587e:	00 00 
    5880:	c4 62 7d 30 e0       	vpmovzxbw %xmm0,%ymm12
    5885:	c4 c1 79 6e c0       	vmovd  %r8d,%xmm0
    588a:	41 b8 80 00 00 00    	mov    $0x80,%r8d
    5890:	c4 41 79 6e d0       	vmovd  %r8d,%xmm10
    5895:	41 b8 e6 ff ff ff    	mov    $0xffffffe6,%r8d
    589b:	c4 e2 79 78 c0       	vpbroadcastb %xmm0,%xmm0
    58a0:	c4 c1 79 6e f0       	vmovd  %r8d,%xmm6
    58a5:	41 b8 aa ff ff ff    	mov    $0xffffffaa,%r8d
    58ab:	c4 62 7d 30 d8       	vpmovzxbw %xmm0,%ymm11
    58b0:	c4 e2 7d 79 f6       	vpbroadcastw %xmm6,%ymm6
    58b5:	c4 42 7d 79 d2       	vpbroadcastw %xmm10,%ymm10
    58ba:	c5 fd 7f 74 24 28    	vmovdqa %ymm6,0x28(%rsp)
    58c0:	c4 c1 79 6e f0       	vmovd  %r8d,%xmm6
    58c5:	41 b8 80 ff ff ff    	mov    $0xffffff80,%r8d
    58cb:	c4 e2 7d 79 f6       	vpbroadcastw %xmm6,%ymm6
    58d0:	c5 fd 7f 74 24 08    	vmovdqa %ymm6,0x8(%rsp)
    58d6:	c4 c1 79 6e f0       	vmovd  %r8d,%xmm6
    58db:	41 b8 9a ff ff ff    	mov    $0xffffff9a,%r8d
    58e1:	c4 e2 7d 78 f6       	vpbroadcastb %xmm6,%ymm6
    58e6:	c5 fd 7f 74 24 e8    	vmovdqa %ymm6,-0x18(%rsp)
    58ec:	c4 c1 79 6e f0       	vmovd  %r8d,%xmm6
    58f1:	4c 8b 84 24 88 02 00 	mov    0x288(%rsp),%r8
    58f8:	00 
    58f9:	c4 e2 7d 79 f6       	vpbroadcastw %xmm6,%ymm6
    58fe:	c5 fd 7f 74 24 c8    	vmovdqa %ymm6,-0x38(%rsp)
    5904:	0f 1f 40 00          	nopl   0x0(%rax)
    5908:	c5 85 db 40 20       	vpand  0x20(%rax),%ymm15,%ymm0
    590d:	c5 85 db 18          	vpand  (%rax),%ymm15,%ymm3
    5911:	48 81 c2 00 01 00 00 	add    $0x100,%rdx
    5918:	48 05 00 01 00 00    	add    $0x100,%rax
    591e:	c5 85 db a0 40 ff ff 	vpand  -0xc0(%rax),%ymm15,%ymm4
    5925:	ff 
    5926:	c5 85 db 48 80       	vpand  -0x80(%rax),%ymm15,%ymm1
    592b:	c5 e5 67 d8          	vpackuswb %ymm0,%ymm3,%ymm3
    592f:	c5 85 db 80 60 ff ff 	vpand  -0xa0(%rax),%ymm15,%ymm0
    5936:	ff 
    5937:	c5 85 db 50 e0       	vpand  -0x20(%rax),%ymm15,%ymm2
    593c:	c4 e3 fd 00 db d8    	vpermq $0xd8,%ymm3,%ymm3
    5942:	c5 fe 6f b8 00 ff ff 	vmovdqu -0x100(%rax),%ymm7
    5949:	ff 
    594a:	c5 dd 67 e0          	vpackuswb %ymm0,%ymm4,%ymm4
    594e:	c5 85 db 40 a0       	vpand  -0x60(%rax),%ymm15,%ymm0
    5953:	c4 e3 fd 00 e4 d8    	vpermq $0xd8,%ymm4,%ymm4
    5959:	c5 f5 67 c8          	vpackuswb %ymm0,%ymm1,%ymm1
    595d:	c5 85 db 40 c0       	vpand  -0x40(%rax),%ymm15,%ymm0
    5962:	c5 85 db ec          	vpand  %ymm4,%ymm15,%ymm5
    5966:	c4 e3 fd 00 c9 d8    	vpermq $0xd8,%ymm1,%ymm1
    596c:	c5 dd 71 d4 08       	vpsrlw $0x8,%ymm4,%ymm4
    5971:	c5 fd 67 c2          	vpackuswb %ymm2,%ymm0,%ymm0
    5975:	c5 85 db d3          	vpand  %ymm3,%ymm15,%ymm2
    5979:	c5 85 db f1          	vpand  %ymm1,%ymm15,%ymm6
    597d:	c4 e3 fd 00 c0 d8    	vpermq $0xd8,%ymm0,%ymm0
    5983:	c5 e5 71 d3 08       	vpsrlw $0x8,%ymm3,%ymm3
    5988:	c5 ed 67 d5          	vpackuswb %ymm5,%ymm2,%ymm2
    598c:	c5 e5 67 dc          	vpackuswb %ymm4,%ymm3,%ymm3
    5990:	c5 85 db e0          	vpand  %ymm0,%ymm15,%ymm4
    5994:	c4 e3 fd 00 d2 d8    	vpermq $0xd8,%ymm2,%ymm2
    599a:	c5 cd 67 f4          	vpackuswb %ymm4,%ymm6,%ymm6
    599e:	c5 dd 71 d7 08       	vpsrlw $0x8,%ymm7,%ymm4
    59a3:	c5 fe 6f b8 20 ff ff 	vmovdqu -0xe0(%rax),%ymm7
    59aa:	ff 
    59ab:	c4 e3 fd 00 db d8    	vpermq $0xd8,%ymm3,%ymm3
    59b1:	c5 fd 71 d0 08       	vpsrlw $0x8,%ymm0,%ymm0
    59b6:	c5 f5 71 d1 08       	vpsrlw $0x8,%ymm1,%ymm1
    59bb:	c4 e3 fd 00 f6 d8    	vpermq $0xd8,%ymm6,%ymm6
    59c1:	c5 f5 67 c8          	vpackuswb %ymm0,%ymm1,%ymm1
    59c5:	c5 fd 71 d7 08       	vpsrlw $0x8,%ymm7,%ymm0
    59ca:	c5 fe 6f b8 40 ff ff 	vmovdqu -0xc0(%rax),%ymm7
    59d1:	ff 
    59d2:	c5 dd 67 e0          	vpackuswb %ymm0,%ymm4,%ymm4
    59d6:	c4 e3 fd 00 c9 d8    	vpermq $0xd8,%ymm1,%ymm1
    59dc:	c5 fd 71 d7 08       	vpsrlw $0x8,%ymm7,%ymm0
    59e1:	c5 fe 6f b8 60 ff ff 	vmovdqu -0xa0(%rax),%ymm7
    59e8:	ff 
    59e9:	c4 e3 fd 00 e4 d8    	vpermq $0xd8,%ymm4,%ymm4
    59ef:	c5 85 db e4          	vpand  %ymm4,%ymm15,%ymm4
    59f3:	c5 d5 71 d7 08       	vpsrlw $0x8,%ymm7,%ymm5
    59f8:	c5 fe 6f 78 80       	vmovdqu -0x80(%rax),%ymm7
    59fd:	c5 fd 67 c5          	vpackuswb %ymm5,%ymm0,%ymm0
    5a01:	c4 e3 fd 00 c0 d8    	vpermq $0xd8,%ymm0,%ymm0
    5a07:	c5 85 db c0          	vpand  %ymm0,%ymm15,%ymm0
    5a0b:	c5 dd 67 e0          	vpackuswb %ymm0,%ymm4,%ymm4
    5a0f:	c5 fd 71 d7 08       	vpsrlw $0x8,%ymm7,%ymm0
    5a14:	c5 fe 6f 78 a0       	vmovdqu -0x60(%rax),%ymm7
    5a19:	c4 e3 fd 00 e4 d8    	vpermq $0xd8,%ymm4,%ymm4
    5a1f:	c5 d5 71 d7 08       	vpsrlw $0x8,%ymm7,%ymm5
    5a24:	c5 fe 6f 78 c0       	vmovdqu -0x40(%rax),%ymm7
    5a29:	c5 fd 67 c5          	vpackuswb %ymm5,%ymm0,%ymm0
    5a2d:	c5 d5 71 d7 08       	vpsrlw $0x8,%ymm7,%ymm5
    5a32:	c5 fe 6f 78 e0       	vmovdqu -0x20(%rax),%ymm7
    5a37:	c4 e3 fd 00 c0 d8    	vpermq $0xd8,%ymm0,%ymm0
    5a3d:	c5 85 db c0          	vpand  %ymm0,%ymm15,%ymm0
    5a41:	c5 c5 71 d7 08       	vpsrlw $0x8,%ymm7,%ymm7
    5a46:	c5 d5 67 ef          	vpackuswb %ymm7,%ymm5,%ymm5
    5a4a:	c5 85 db fe          	vpand  %ymm6,%ymm15,%ymm7
    5a4e:	c4 e3 fd 00 ed d8    	vpermq $0xd8,%ymm5,%ymm5
    5a54:	c5 cd 71 d6 08       	vpsrlw $0x8,%ymm6,%ymm6
    5a59:	c5 85 db ed          	vpand  %ymm5,%ymm15,%ymm5
    5a5d:	c5 fd 67 c5          	vpackuswb %ymm5,%ymm0,%ymm0
    5a61:	c5 85 db ea          	vpand  %ymm2,%ymm15,%ymm5
    5a65:	c4 e3 fd 00 c0 d8    	vpermq $0xd8,%ymm0,%ymm0
    5a6b:	c5 ed 71 d2 08       	vpsrlw $0x8,%ymm2,%ymm2
    5a70:	c5 d5 67 ef          	vpackuswb %ymm7,%ymm5,%ymm5
    5a74:	c5 ed 67 d6          	vpackuswb %ymm6,%ymm2,%ymm2
    5a78:	c5 85 db f8          	vpand  %ymm0,%ymm15,%ymm7
    5a7c:	c5 85 db f4          	vpand  %ymm4,%ymm15,%ymm6
    5a80:	c5 fd 71 d0 08       	vpsrlw $0x8,%ymm0,%ymm0
    5a85:	c5 dd 71 d4 08       	vpsrlw $0x8,%ymm4,%ymm4
    5a8a:	c5 cd 67 f7          	vpackuswb %ymm7,%ymm6,%ymm6
    5a8e:	c5 dd 67 e0          	vpackuswb %ymm0,%ymm4,%ymm4
    5a92:	c5 85 db f9          	vpand  %ymm1,%ymm15,%ymm7
    5a96:	c5 85 db c3          	vpand  %ymm3,%ymm15,%ymm0
    5a9a:	c5 fd 67 c7          	vpackuswb %ymm7,%ymm0,%ymm0
    5a9e:	c4 e3 fd 00 f6 d8    	vpermq $0xd8,%ymm6,%ymm6
    5aa4:	c4 e3 fd 00 ed d8    	vpermq $0xd8,%ymm5,%ymm5
    5aaa:	c4 e3 fd 00 c0 d8    	vpermq $0xd8,%ymm0,%ymm0
    5ab0:	c4 62 7d 30 f6       	vpmovzxbw %xmm6,%ymm14
    5ab5:	c4 62 7d 30 c5       	vpmovzxbw %xmm5,%ymm8
    5aba:	c4 e2 7d 30 f8       	vpmovzxbw %xmm0,%ymm7
    5abf:	c5 f5 71 d1 08       	vpsrlw $0x8,%ymm1,%ymm1
    5ac4:	c4 e3 fd 00 e4 d8    	vpermq $0xd8,%ymm4,%ymm4
    5aca:	c5 7d 7f 84 24 48 02 	vmovdqa %ymm8,0x248(%rsp)
    5ad1:	00 00 
    5ad3:	c5 e5 71 d3 08       	vpsrlw $0x8,%ymm3,%ymm3
    5ad8:	c4 e3 7d 39 f6 01    	vextracti128 $0x1,%ymm6,%xmm6
    5ade:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    5ae4:	c5 fd 7f bc 24 88 02 	vmovdqa %ymm7,0x288(%rsp)
    5aeb:	00 00 
    5aed:	c5 e5 67 d9          	vpackuswb %ymm1,%ymm3,%ymm3
    5af1:	c5 95 d5 cf          	vpmullw %ymm7,%ymm13,%ymm1
    5af5:	c4 e3 7d 39 ed 01    	vextracti128 $0x1,%ymm5,%xmm5
    5afb:	c5 7d 7f b4 24 68 02 	vmovdqa %ymm14,0x268(%rsp)
    5b02:	00 00 
    5b04:	c4 c1 1d d5 fe       	vpmullw %ymm14,%ymm12,%ymm7
    5b09:	c4 62 7d 30 ce       	vpmovzxbw %xmm6,%ymm9
    5b0e:	c4 e2 7d 30 c0       	vpmovzxbw %xmm0,%ymm0
    5b13:	c4 e2 7d 30 ed       	vpmovzxbw %xmm5,%ymm5
    5b18:	c4 c1 1d d5 f1       	vpmullw %ymm9,%ymm12,%ymm6
    5b1d:	c4 e3 fd 00 db d8    	vpermq $0xd8,%ymm3,%ymm3
    5b23:	c5 fd 7f 84 24 28 02 	vmovdqa %ymm0,0x228(%rsp)
    5b2a:	00 00 
    5b2c:	c5 fd 7f ac 24 e8 01 	vmovdqa %ymm5,0x1e8(%rsp)
    5b33:	00 00 
    5b35:	c5 95 d5 c0          	vpmullw %ymm0,%ymm13,%ymm0
    5b39:	c5 a5 d5 ed          	vpmullw %ymm5,%ymm11,%ymm5
    5b3d:	c4 e3 fd 00 d2 d8    	vpermq $0xd8,%ymm2,%ymm2
    5b43:	c5 7d 7f 8c 24 08 02 	vmovdqa %ymm9,0x208(%rsp)
    5b4a:	00 00 
    5b4c:	c5 7d 6f 8c 24 c8 02 	vmovdqa 0x2c8(%rsp),%ymm9
    5b53:	00 00 
    5b55:	c5 f5 fd cf          	vpaddw %ymm7,%ymm1,%ymm1
    5b59:	c4 c1 25 d5 f8       	vpmullw %ymm8,%ymm11,%ymm7
    5b5e:	c4 62 7d 30 c4       	vpmovzxbw %xmm4,%ymm8
    5b63:	c5 7d 7f 84 24 a8 01 	vmovdqa %ymm8,0x1a8(%rsp)
    5b6a:	00 00 
    5b6c:	c4 e3 7d 39 e4 01    	vextracti128 $0x1,%ymm4,%xmm4
    5b72:	c5 fd fd c6          	vpaddw %ymm6,%ymm0,%ymm0
    5b76:	c4 c1 55 fd ea       	vpaddw %ymm10,%ymm5,%ymm5
    5b7b:	c4 e2 7d 30 f3       	vpmovzxbw %xmm3,%ymm6
    5b80:	c5 fd fd c5          	vpaddw %ymm5,%ymm0,%ymm0
    5b84:	c4 c1 1d d5 e8       	vpmullw %ymm8,%ymm12,%ymm5
    5b89:	c4 e3 7d 39 db 01    	vextracti128 $0x1,%ymm3,%xmm3
    5b8f:	c5 fd 7f b4 24 c8 01 	vmovdqa %ymm6,0x1c8(%rsp)
    5b96:	00 00 
    5b98:	c5 fd 71 d0 08       	vpsrlw $0x8,%ymm0,%ymm0
    5b9d:	c4 e2 7d 30 db       	vpmovzxbw %xmm3,%ymm3
    5ba2:	c4 e2 7d 30 e4       	vpmovzxbw %xmm4,%ymm4
    5ba7:	c4 c1 45 fd fa       	vpaddw %ymm10,%ymm7,%ymm7
    5bac:	c5 85 db c0          	vpand  %ymm0,%ymm15,%ymm0
    5bb0:	c5 fd 7f 9c 24 68 01 	vmovdqa %ymm3,0x168(%rsp)
    5bb7:	00 00 
    5bb9:	c5 f5 fd cf          	vpaddw %ymm7,%ymm1,%ymm1
    5bbd:	c5 95 d5 db          	vpmullw %ymm3,%ymm13,%ymm3
    5bc1:	c4 e2 7d 30 fa       	vpmovzxbw %xmm2,%ymm7
    5bc6:	c5 fd 7f a4 24 48 01 	vmovdqa %ymm4,0x148(%rsp)
    5bcd:	00 00 
    5bcf:	c5 f5 71 d1 08       	vpsrlw $0x8,%ymm1,%ymm1
    5bd4:	c4 e3 7d 39 d2 01    	vextracti128 $0x1,%ymm2,%xmm2
    5bda:	c5 fd 7f bc 24 88 01 	vmovdqa %ymm7,0x188(%rsp)
    5be1:	00 00 
    5be3:	c5 85 db c9          	vpand  %ymm1,%ymm15,%ymm1
    5be7:	c5 9d d5 e4          	vpmullw %ymm4,%ymm12,%ymm4
    5beb:	c4 e2 7d 30 d2       	vpmovzxbw %xmm2,%ymm2
    5bf0:	c5 fd 7f 94 24 28 01 	vmovdqa %ymm2,0x128(%rsp)
    5bf7:	00 00 
    5bf9:	c5 f5 67 c8          	vpackuswb %ymm0,%ymm1,%ymm1
    5bfd:	c5 95 d5 c6          	vpmullw %ymm6,%ymm13,%ymm0
    5c01:	c5 a5 d5 d2          	vpmullw %ymm2,%ymm11,%ymm2
    5c05:	c4 e3 fd 00 c9 d8    	vpermq $0xd8,%ymm1,%ymm1
    5c0b:	c4 c1 75 fc c9       	vpaddb %ymm9,%ymm1,%ymm1
    5c10:	c5 e5 fd dc          	vpaddw %ymm4,%ymm3,%ymm3
    5c14:	c5 fd fd c5          	vpaddw %ymm5,%ymm0,%ymm0
    5c18:	c5 a5 d5 ef          	vpmullw %ymm7,%ymm11,%ymm5
    5c1c:	c4 c1 6d fd d2       	vpaddw %ymm10,%ymm2,%ymm2
    5c21:	c5 e5 fd da          	vpaddw %ymm2,%ymm3,%ymm3
    5c25:	c5 e5 71 d3 08       	vpsrlw $0x8,%ymm3,%ymm3
    5c2a:	c5 85 db db          	vpand  %ymm3,%ymm15,%ymm3
    5c2e:	c4 c1 55 fd ea       	vpaddw %ymm10,%ymm5,%ymm5
    5c33:	c5 fd fd c5          	vpaddw %ymm5,%ymm0,%ymm0
    5c37:	c5 fd 71 d0 08       	vpsrlw $0x8,%ymm0,%ymm0
    5c3c:	c5 85 db c0          	vpand  %ymm0,%ymm15,%ymm0
    5c40:	c5 fd 67 c3          	vpackuswb %ymm3,%ymm0,%ymm0
    5c44:	c4 e3 fd 00 c0 d8    	vpermq $0xd8,%ymm0,%ymm0
    5c4a:	c4 c1 7d fc c1       	vpaddb %ymm9,%ymm0,%ymm0
    5c4f:	c5 f5 60 d0          	vpunpcklbw %ymm0,%ymm1,%ymm2
    5c53:	c5 f5 68 c0          	vpunpckhbw %ymm0,%ymm1,%ymm0
    5c57:	c4 e3 6d 46 c8 20    	vperm2i128 $0x20,%ymm0,%ymm2,%ymm1
    5c5d:	c4 e3 6d 46 d0 31    	vperm2i128 $0x31,%ymm0,%ymm2,%ymm2
    5c63:	c5 fe 7f 54 3b 20    	vmovdqu %ymm2,0x20(%rbx,%rdi,1)
    5c69:	c5 fe 7f 0c 3b       	vmovdqu %ymm1,(%rbx,%rdi,1)
    5c6e:	c5 85 db 8a 00 ff ff 	vpand  -0x100(%rdx),%ymm15,%ymm1
    5c75:	ff 
    5c76:	c5 85 db 82 20 ff ff 	vpand  -0xe0(%rdx),%ymm15,%ymm0
    5c7d:	ff 
    5c7e:	c5 85 db 92 40 ff ff 	vpand  -0xc0(%rdx),%ymm15,%ymm2
    5c85:	ff 
    5c86:	c5 85 db 5a 80       	vpand  -0x80(%rdx),%ymm15,%ymm3
    5c8b:	c5 f5 67 c8          	vpackuswb %ymm0,%ymm1,%ymm1
    5c8f:	c5 85 db 62 e0       	vpand  -0x20(%rdx),%ymm15,%ymm4
    5c94:	c5 7e 6f 72 e0       	vmovdqu -0x20(%rdx),%ymm14
    5c99:	c5 85 db 82 60 ff ff 	vpand  -0xa0(%rdx),%ymm15,%ymm0
    5ca0:	ff 
    5ca1:	c4 e3 fd 00 c9 d8    	vpermq $0xd8,%ymm1,%ymm1
    5ca7:	c5 85 db e9          	vpand  %ymm1,%ymm15,%ymm5
    5cab:	c5 f5 71 d1 08       	vpsrlw $0x8,%ymm1,%ymm1
    5cb0:	c5 ed 67 d0          	vpackuswb %ymm0,%ymm2,%ymm2
    5cb4:	c4 c1 45 71 d6 08    	vpsrlw $0x8,%ymm14,%ymm7
    5cba:	c5 85 db 42 a0       	vpand  -0x60(%rdx),%ymm15,%ymm0
    5cbf:	c4 e3 fd 00 d2 d8    	vpermq $0xd8,%ymm2,%ymm2
    5cc5:	c5 e5 67 d8          	vpackuswb %ymm0,%ymm3,%ymm3
    5cc9:	c5 85 db 42 c0       	vpand  -0x40(%rdx),%ymm15,%ymm0
    5cce:	c4 e3 fd 00 db d8    	vpermq $0xd8,%ymm3,%ymm3
    5cd4:	c5 fd 67 c4          	vpackuswb %ymm4,%ymm0,%ymm0
    5cd8:	c5 85 db e2          	vpand  %ymm2,%ymm15,%ymm4
    5cdc:	c5 85 db f3          	vpand  %ymm3,%ymm15,%ymm6
    5ce0:	c4 e3 fd 00 c0 d8    	vpermq $0xd8,%ymm0,%ymm0
    5ce6:	c5 ed 71 d2 08       	vpsrlw $0x8,%ymm2,%ymm2
    5ceb:	c5 d5 67 ec          	vpackuswb %ymm4,%ymm5,%ymm5
    5cef:	c5 fe 6f a2 20 ff ff 	vmovdqu -0xe0(%rdx),%ymm4
    5cf6:	ff 
    5cf7:	c5 f5 67 ca          	vpackuswb %ymm2,%ymm1,%ymm1
    5cfb:	c5 e5 71 d3 08       	vpsrlw $0x8,%ymm3,%ymm3
    5d00:	c5 85 db d0          	vpand  %ymm0,%ymm15,%ymm2
    5d04:	c5 fd 71 d0 08       	vpsrlw $0x8,%ymm0,%ymm0
    5d09:	c5 cd 67 f2          	vpackuswb %ymm2,%ymm6,%ymm6
    5d0d:	c4 e3 fd 00 ed d8    	vpermq $0xd8,%ymm5,%ymm5
    5d13:	c5 e5 67 d8          	vpackuswb %ymm0,%ymm3,%ymm3
    5d17:	c5 fe 6f 82 00 ff ff 	vmovdqu -0x100(%rdx),%ymm0
    5d1e:	ff 
    5d1f:	c4 e3 fd 00 f6 d8    	vpermq $0xd8,%ymm6,%ymm6
    5d25:	c4 e3 fd 00 c9 d8    	vpermq $0xd8,%ymm1,%ymm1
    5d2b:	c5 ed 71 d4 08       	vpsrlw $0x8,%ymm4,%ymm2
    5d30:	c5 fe 6f a2 40 ff ff 	vmovdqu -0xc0(%rdx),%ymm4
    5d37:	ff 
    5d38:	c4 e3 fd 00 db d8    	vpermq $0xd8,%ymm3,%ymm3
    5d3e:	c5 fd 71 d0 08       	vpsrlw $0x8,%ymm0,%ymm0
    5d43:	c5 fd 67 c2          	vpackuswb %ymm2,%ymm0,%ymm0
    5d47:	c5 ed 71 d4 08       	vpsrlw $0x8,%ymm4,%ymm2
    5d4c:	c5 fe 6f a2 60 ff ff 	vmovdqu -0xa0(%rdx),%ymm4
    5d53:	ff 
    5d54:	c4 e3 fd 00 c0 d8    	vpermq $0xd8,%ymm0,%ymm0
    5d5a:	c5 dd 71 d4 08       	vpsrlw $0x8,%ymm4,%ymm4
    5d5f:	c5 85 db c0          	vpand  %ymm0,%ymm15,%ymm0
    5d63:	c5 ed 67 d4          	vpackuswb %ymm4,%ymm2,%ymm2
    5d67:	c5 fe 6f 62 80       	vmovdqu -0x80(%rdx),%ymm4
    5d6c:	c4 e3 fd 00 d2 d8    	vpermq $0xd8,%ymm2,%ymm2
    5d72:	c5 85 db d2          	vpand  %ymm2,%ymm15,%ymm2
    5d76:	c5 fd 67 c2          	vpackuswb %ymm2,%ymm0,%ymm0
    5d7a:	c5 ed 71 d4 08       	vpsrlw $0x8,%ymm4,%ymm2
    5d7f:	c5 fe 6f 62 a0       	vmovdqu -0x60(%rdx),%ymm4
    5d84:	c4 e3 fd 00 c0 d8    	vpermq $0xd8,%ymm0,%ymm0
    5d8a:	c5 dd 71 d4 08       	vpsrlw $0x8,%ymm4,%ymm4
    5d8f:	c5 ed 67 d4          	vpackuswb %ymm4,%ymm2,%ymm2
    5d93:	c5 fe 6f 62 c0       	vmovdqu -0x40(%rdx),%ymm4
    5d98:	c4 e3 fd 00 d2 d8    	vpermq $0xd8,%ymm2,%ymm2
    5d9e:	c5 dd 71 d4 08       	vpsrlw $0x8,%ymm4,%ymm4
    5da3:	c5 85 db d2          	vpand  %ymm2,%ymm15,%ymm2
    5da7:	c5 dd 67 e7          	vpackuswb %ymm7,%ymm4,%ymm4
    5dab:	c5 85 db fe          	vpand  %ymm6,%ymm15,%ymm7
    5daf:	c4 e3 fd 00 e4 d8    	vpermq $0xd8,%ymm4,%ymm4
    5db5:	c5 cd 71 d6 08       	vpsrlw $0x8,%ymm6,%ymm6
    5dba:	c5 85 db e4          	vpand  %ymm4,%ymm15,%ymm4
    5dbe:	c5 ed 67 d4          	vpackuswb %ymm4,%ymm2,%ymm2
    5dc2:	c5 85 db e5          	vpand  %ymm5,%ymm15,%ymm4
    5dc6:	c5 d5 71 d5 08       	vpsrlw $0x8,%ymm5,%ymm5
    5dcb:	c4 e3 fd 00 d2 d8    	vpermq $0xd8,%ymm2,%ymm2
    5dd1:	c5 dd 67 e7          	vpackuswb %ymm7,%ymm4,%ymm4
    5dd5:	c5 d5 67 ee          	vpackuswb %ymm6,%ymm5,%ymm5
    5dd9:	c5 85 db f2          	vpand  %ymm2,%ymm15,%ymm6
    5ddd:	c4 e3 fd 00 e4 d8    	vpermq $0xd8,%ymm4,%ymm4
    5de3:	c4 63 fd 00 f5 d8    	vpermq $0xd8,%ymm5,%ymm14
    5de9:	c5 ed 71 d2 08       	vpsrlw $0x8,%ymm2,%ymm2
    5dee:	c5 85 db e8          	vpand  %ymm0,%ymm15,%ymm5
    5df2:	c5 fd 71 d0 08       	vpsrlw $0x8,%ymm0,%ymm0
    5df7:	c5 d5 67 ee          	vpackuswb %ymm6,%ymm5,%ymm5
    5dfb:	c5 85 db f3          	vpand  %ymm3,%ymm15,%ymm6
    5dff:	c5 fd 67 c2          	vpackuswb %ymm2,%ymm0,%ymm0
    5e03:	c5 85 db d1          	vpand  %ymm1,%ymm15,%ymm2
    5e07:	c4 e3 fd 00 ed d8    	vpermq $0xd8,%ymm5,%ymm5
    5e0d:	c5 ed 67 d6          	vpackuswb %ymm6,%ymm2,%ymm2
    5e11:	c4 62 7d 30 c5       	vpmovzxbw %xmm5,%ymm8
    5e16:	c4 e3 7d 39 ed 01    	vextracti128 $0x1,%ymm5,%xmm5
    5e1c:	c4 e3 fd 00 d2 d8    	vpermq $0xd8,%ymm2,%ymm2
    5e22:	c5 e5 71 d3 08       	vpsrlw $0x8,%ymm3,%ymm3
    5e27:	c4 e2 7d 30 ed       	vpmovzxbw %xmm5,%ymm5
    5e2c:	c5 7d 7f 84 24 e8 00 	vmovdqa %ymm8,0xe8(%rsp)
    5e33:	00 00 
    5e35:	c4 e2 7d 30 f2       	vpmovzxbw %xmm2,%ymm6
    5e3a:	c4 e3 7d 39 d2 01    	vextracti128 $0x1,%ymm2,%xmm2
    5e40:	c4 e2 7d 30 fc       	vpmovzxbw %xmm4,%ymm7
    5e45:	c5 fd 7f ac 24 88 00 	vmovdqa %ymm5,0x88(%rsp)
    5e4c:	00 00 
    5e4e:	c4 e2 7d 30 d2       	vpmovzxbw %xmm2,%ymm2
    5e53:	c5 f5 71 d1 08       	vpsrlw $0x8,%ymm1,%ymm1
    5e58:	c4 e3 7d 39 e4 01    	vextracti128 $0x1,%ymm4,%xmm4
    5e5e:	c5 fd 7f b4 24 08 01 	vmovdqa %ymm6,0x108(%rsp)
    5e65:	00 00 
    5e67:	c5 9d d5 ed          	vpmullw %ymm5,%ymm12,%ymm5
    5e6b:	c5 f5 67 cb          	vpackuswb %ymm3,%ymm1,%ymm1
    5e6f:	c4 e2 7d 30 e4       	vpmovzxbw %xmm4,%ymm4
    5e74:	c5 fd 7f 94 24 a8 00 	vmovdqa %ymm2,0xa8(%rsp)
    5e7b:	00 00 
    5e7d:	c5 95 d5 de          	vpmullw %ymm6,%ymm13,%ymm3
    5e81:	c5 95 d5 d2          	vpmullw %ymm2,%ymm13,%ymm2
    5e85:	c4 e3 fd 00 c0 d8    	vpermq $0xd8,%ymm0,%ymm0
    5e8b:	c5 fd 7f bc 24 c8 00 	vmovdqa %ymm7,0xc8(%rsp)
    5e92:	00 00 
    5e94:	c4 c1 1d d5 f0       	vpmullw %ymm8,%ymm12,%ymm6
    5e99:	c4 e3 fd 00 c9 d8    	vpermq $0xd8,%ymm1,%ymm1
    5e9f:	c4 62 7d 30 c0       	vpmovzxbw %xmm0,%ymm8
    5ea4:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    5eaa:	c4 e2 7d 30 c0       	vpmovzxbw %xmm0,%ymm0
    5eaf:	c5 ed fd d5          	vpaddw %ymm5,%ymm2,%ymm2
    5eb3:	c4 c1 5d d5 eb       	vpmullw %ymm11,%ymm4,%ymm5
    5eb8:	c5 e5 fd de          	vpaddw %ymm6,%ymm3,%ymm3
    5ebc:	c5 a5 d5 f7          	vpmullw %ymm7,%ymm11,%ymm6
    5ec0:	c4 e2 7d 30 f9       	vpmovzxbw %xmm1,%ymm7
    5ec5:	c4 e3 7d 39 c9 01    	vextracti128 $0x1,%ymm1,%xmm1
    5ecb:	c4 e2 7d 30 c9       	vpmovzxbw %xmm1,%ymm1
    5ed0:	c4 c1 55 fd ea       	vpaddw %ymm10,%ymm5,%ymm5
    5ed5:	c4 c1 4d fd f2       	vpaddw %ymm10,%ymm6,%ymm6
    5eda:	c5 ed fd d5          	vpaddw %ymm5,%ymm2,%ymm2
    5ede:	c4 c1 3d d5 ec       	vpmullw %ymm12,%ymm8,%ymm5
    5ee3:	c5 e5 fd de          	vpaddw %ymm6,%ymm3,%ymm3
    5ee7:	c5 ed 71 d2 08       	vpsrlw $0x8,%ymm2,%ymm2
    5eec:	c5 e5 71 d3 08       	vpsrlw $0x8,%ymm3,%ymm3
    5ef1:	c4 c1 7d d5 f4       	vpmullw %ymm12,%ymm0,%ymm6
    5ef6:	c5 85 db d2          	vpand  %ymm2,%ymm15,%ymm2
    5efa:	c5 85 db db          	vpand  %ymm3,%ymm15,%ymm3
    5efe:	c5 e5 67 da          	vpackuswb %ymm2,%ymm3,%ymm3
    5f02:	c4 c1 45 d5 d5       	vpmullw %ymm13,%ymm7,%ymm2
    5f07:	c4 e3 fd 00 db d8    	vpermq $0xd8,%ymm3,%ymm3
    5f0d:	c4 c1 65 fc d9       	vpaddb %ymm9,%ymm3,%ymm3
    5f12:	c4 42 7d 30 ce       	vpmovzxbw %xmm14,%ymm9
    5f17:	c5 ed fd d5          	vpaddw %ymm5,%ymm2,%ymm2
    5f1b:	c4 c1 35 d5 eb       	vpmullw %ymm11,%ymm9,%ymm5
    5f20:	c4 c1 55 fd ea       	vpaddw %ymm10,%ymm5,%ymm5
    5f25:	c5 ed fd d5          	vpaddw %ymm5,%ymm2,%ymm2
    5f29:	c4 c1 75 d5 ed       	vpmullw %ymm13,%ymm1,%ymm5
    5f2e:	c5 ed 71 d2 08       	vpsrlw $0x8,%ymm2,%ymm2
    5f33:	c5 85 db d2          	vpand  %ymm2,%ymm15,%ymm2
    5f37:	c5 d5 fd ee          	vpaddw %ymm6,%ymm5,%ymm5
    5f3b:	c4 63 7d 39 f6 01    	vextracti128 $0x1,%ymm14,%xmm6
    5f41:	c4 e2 7d 30 f6       	vpmovzxbw %xmm6,%ymm6
    5f46:	c4 41 4d d5 f3       	vpmullw %ymm11,%ymm6,%ymm14
    5f4b:	c5 dd fd e6          	vpaddw %ymm6,%ymm4,%ymm4
    5f4f:	c4 41 0d fd f2       	vpaddw %ymm10,%ymm14,%ymm14
    5f54:	c4 c1 55 fd ee       	vpaddw %ymm14,%ymm5,%ymm5
    5f59:	c5 d5 71 d5 08       	vpsrlw $0x8,%ymm5,%ymm5
    5f5e:	c5 85 db ed          	vpand  %ymm5,%ymm15,%ymm5
    5f62:	c5 ed 67 d5          	vpackuswb %ymm5,%ymm2,%ymm2
    5f66:	c4 e3 fd 00 d2 d8    	vpermq $0xd8,%ymm2,%ymm2
    5f6c:	c5 ed fc 94 24 c8 02 	vpaddb 0x2c8(%rsp),%ymm2,%ymm2
    5f73:	00 00 
    5f75:	c5 e5 60 ea          	vpunpcklbw %ymm2,%ymm3,%ymm5
    5f79:	c5 e5 68 d2          	vpunpckhbw %ymm2,%ymm3,%ymm2
    5f7d:	c4 e3 55 46 da 20    	vperm2i128 $0x20,%ymm2,%ymm5,%ymm3
    5f83:	c4 e3 55 46 ea 31    	vperm2i128 $0x31,%ymm2,%ymm5,%ymm5
    5f89:	c5 fd 6f 94 24 88 01 	vmovdqa 0x188(%rsp),%ymm2
    5f90:	00 00 
    5f92:	c5 ed fd 94 24 48 02 	vpaddw 0x248(%rsp),%ymm2,%ymm2
    5f99:	00 00 
    5f9b:	c4 c1 7e 7f 1c 38    	vmovdqu %ymm3,(%r8,%rdi,1)
    5fa1:	c5 b5 fd 9c 24 c8 00 	vpaddw 0xc8(%rsp),%ymm9,%ymm3
    5fa8:	00 00 
    5faa:	c4 c1 7e 7f 6c 38 20 	vmovdqu %ymm5,0x20(%r8,%rdi,1)
    5fb1:	c5 bd fd ac 24 e8 00 	vpaddw 0xe8(%rsp),%ymm8,%ymm5
    5fb8:	00 00 
    5fba:	c5 ed fd d3          	vpaddw %ymm3,%ymm2,%ymm2
    5fbe:	c5 fd 6f 9c 24 28 01 	vmovdqa 0x128(%rsp),%ymm3
    5fc5:	00 00 
    5fc7:	c5 e5 fd 9c 24 e8 01 	vpaddw 0x1e8(%rsp),%ymm3,%ymm3
    5fce:	00 00 
    5fd0:	c5 ed 71 d2 02       	vpsrlw $0x2,%ymm2,%ymm2
    5fd5:	c5 e5 fd dc          	vpaddw %ymm4,%ymm3,%ymm3
    5fd9:	c5 fd 6f a4 24 a8 01 	vmovdqa 0x1a8(%rsp),%ymm4
    5fe0:	00 00 
    5fe2:	c5 dd fd a4 24 68 02 	vpaddw 0x268(%rsp),%ymm4,%ymm4
    5fe9:	00 00 
    5feb:	c5 e5 71 d3 02       	vpsrlw $0x2,%ymm3,%ymm3
    5ff0:	c5 dd fd e5          	vpaddw %ymm5,%ymm4,%ymm4
    5ff4:	c5 fd 6f ac 24 48 01 	vmovdqa 0x148(%rsp),%ymm5
    5ffb:	00 00 
    5ffd:	c5 d5 fd ac 24 08 02 	vpaddw 0x208(%rsp),%ymm5,%ymm5
    6004:	00 00 
    6006:	c5 fd fd 84 24 88 00 	vpaddw 0x88(%rsp),%ymm0,%ymm0
    600d:	00 00 
    600f:	c5 7d 6f 4c 24 08    	vmovdqa 0x8(%rsp),%ymm9
    6015:	c5 dd 71 d4 02       	vpsrlw $0x2,%ymm4,%ymm4
    601a:	c5 c5 fd b4 24 08 01 	vpaddw 0x108(%rsp),%ymm7,%ymm6
    6021:	00 00 
    6023:	c5 7d 6f b4 24 c8 01 	vmovdqa 0x1c8(%rsp),%ymm14
    602a:	00 00 
    602c:	c5 d5 fd e8          	vpaddw %ymm0,%ymm5,%ymm5
    6030:	c4 c1 5d d5 f9       	vpmullw %ymm9,%ymm4,%ymm7
    6035:	c5 8d fd 84 24 88 02 	vpaddw 0x288(%rsp),%ymm14,%ymm0
    603c:	00 00 
    603e:	c5 7d 6f 74 24 28    	vmovdqa 0x28(%rsp),%ymm14
    6044:	c5 f5 fd 8c 24 a8 00 	vpaddw 0xa8(%rsp),%ymm1,%ymm1
    604b:	00 00 
    604d:	c5 d5 71 d5 02       	vpsrlw $0x2,%ymm5,%ymm5
    6052:	c5 fd fd c6          	vpaddw %ymm6,%ymm0,%ymm0
    6056:	c4 41 55 d5 c1       	vpmullw %ymm9,%ymm5,%ymm8
    605b:	c5 fd 6f b4 24 68 01 	vmovdqa 0x168(%rsp),%ymm6
    6062:	00 00 
    6064:	c5 cd fd b4 24 28 02 	vpaddw 0x228(%rsp),%ymm6,%ymm6
    606b:	00 00 
    606d:	c5 fd 71 d0 02       	vpsrlw $0x2,%ymm0,%ymm0
    6072:	c5 cd fd f1          	vpaddw %ymm1,%ymm6,%ymm6
    6076:	c4 c1 7d d5 ce       	vpmullw %ymm14,%ymm0,%ymm1
    607b:	c5 cd 71 d6 02       	vpsrlw $0x2,%ymm6,%ymm6
    6080:	c5 f5 fd cf          	vpaddw %ymm7,%ymm1,%ymm1
    6084:	c5 c5 71 f2 03       	vpsllw $0x3,%ymm2,%ymm7
    6089:	c5 c5 f9 fa          	vpsubw %ymm2,%ymm7,%ymm7
    608d:	c5 c5 71 f7 04       	vpsllw $0x4,%ymm7,%ymm7
    6092:	c4 c1 45 fd fa       	vpaddw %ymm10,%ymm7,%ymm7
    6097:	c5 f5 fd cf          	vpaddw %ymm7,%ymm1,%ymm1
    609b:	c4 c1 4d d5 fe       	vpmullw %ymm14,%ymm6,%ymm7
    60a0:	c5 7d 6f 74 24 e8    	vmovdqa -0x18(%rsp),%ymm14
    60a6:	c5 f5 71 e1 08       	vpsraw $0x8,%ymm1,%ymm1
    60ab:	c5 85 db c9          	vpand  %ymm1,%ymm15,%ymm1
    60af:	c4 c1 45 fd f8       	vpaddw %ymm8,%ymm7,%ymm7
    60b4:	c5 bd 71 f3 03       	vpsllw $0x3,%ymm3,%ymm8
    60b9:	c5 3d f9 c3          	vpsubw %ymm3,%ymm8,%ymm8
    60bd:	c4 c1 3d 71 f0 04    	vpsllw $0x4,%ymm8,%ymm8
    60c3:	c4 41 3d fd c2       	vpaddw %ymm10,%ymm8,%ymm8
    60c8:	c4 c1 45 fd f8       	vpaddw %ymm8,%ymm7,%ymm7
    60cd:	c5 c5 71 e7 08       	vpsraw $0x8,%ymm7,%ymm7
    60d2:	c5 85 db ff          	vpand  %ymm7,%ymm15,%ymm7
    60d6:	c5 f5 67 cf          	vpackuswb %ymm7,%ymm1,%ymm1
    60da:	c5 c5 71 f0 03       	vpsllw $0x3,%ymm0,%ymm7
    60df:	c5 c5 f9 c0          	vpsubw %ymm0,%ymm7,%ymm0
    60e3:	c5 fd 6f 7c 24 c8    	vmovdqa -0x38(%rsp),%ymm7
    60e9:	c4 e3 fd 00 c9 d8    	vpermq $0xd8,%ymm1,%ymm1
    60ef:	c5 fd 71 f0 04       	vpsllw $0x4,%ymm0,%ymm0
    60f4:	c4 c1 75 fc ce       	vpaddb %ymm14,%ymm1,%ymm1
    60f9:	c5 dd d5 e7          	vpmullw %ymm7,%ymm4,%ymm4
    60fd:	c5 d5 d5 ef          	vpmullw %ymm7,%ymm5,%ymm5
    6101:	c5 fd fd c4          	vpaddw %ymm4,%ymm0,%ymm0
    6105:	c5 dd 71 f2 02       	vpsllw $0x2,%ymm2,%ymm4
    610a:	c5 dd fd d2          	vpaddw %ymm2,%ymm4,%ymm2
    610e:	c5 dd 71 f3 02       	vpsllw $0x2,%ymm3,%ymm4
    6113:	c5 ed 71 f2 01       	vpsllw $0x1,%ymm2,%ymm2
    6118:	c5 dd fd db          	vpaddw %ymm3,%ymm4,%ymm3
    611c:	c5 ad f9 d2          	vpsubw %ymm2,%ymm10,%ymm2
    6120:	c5 e5 71 f3 01       	vpsllw $0x1,%ymm3,%ymm3
    6125:	c5 fd fd d2          	vpaddw %ymm2,%ymm0,%ymm2
    6129:	c5 fd 71 f6 03       	vpsllw $0x3,%ymm6,%ymm0
    612e:	c5 ad f9 db          	vpsubw %ymm3,%ymm10,%ymm3
    6132:	c5 fd f9 c6          	vpsubw %ymm6,%ymm0,%ymm0
    6136:	c5 ed 71 e2 08       	vpsraw $0x8,%ymm2,%ymm2
    613b:	c5 fd 71 f0 04       	vpsllw $0x4,%ymm0,%ymm0
    6140:	c5 85 db d2          	vpand  %ymm2,%ymm15,%ymm2
    6144:	c5 fd fd c5          	vpaddw %ymm5,%ymm0,%ymm0
    6148:	c5 fd fd c3          	vpaddw %ymm3,%ymm0,%ymm0
    614c:	c5 fd 71 e0 08       	vpsraw $0x8,%ymm0,%ymm0
    6151:	c5 85 db c0          	vpand  %ymm0,%ymm15,%ymm0
    6155:	c5 ed 67 c0          	vpackuswb %ymm0,%ymm2,%ymm0
    6159:	c4 e3 fd 00 c0 d8    	vpermq $0xd8,%ymm0,%ymm0
    615f:	c4 c1 7d fc c6       	vpaddb %ymm14,%ymm0,%ymm0
    6164:	c5 f5 60 d0          	vpunpcklbw %ymm0,%ymm1,%ymm2
    6168:	c5 f5 68 c8          	vpunpckhbw %ymm0,%ymm1,%ymm1
    616c:	c4 e3 6d 46 c1 20    	vperm2i128 $0x20,%ymm1,%ymm2,%ymm0
    6172:	c4 e3 6d 46 d1 31    	vperm2i128 $0x31,%ymm1,%ymm2,%ymm2
    6178:	c4 c1 7e 7f 04 3a    	vmovdqu %ymm0,(%r10,%rdi,1)
    617e:	c4 c1 7e 7f 54 3a 20 	vmovdqu %ymm2,0x20(%r10,%rdi,1)
    6185:	48 83 c7 40          	add    $0x40,%rdi
    6189:	49 39 f9             	cmp    %rdi,%r9
    618c:	0f 85 76 f7 ff ff    	jne    5908 <convert_avx2_job+0x458>
    6192:	44 89 da             	mov    %r11d,%edx
    6195:	44 89 d8             	mov    %r11d,%eax
    6198:	c1 e0 06             	shl    $0x6,%eax
    619b:	c1 e2 05             	shl    $0x5,%edx
    619e:	01 84 24 c0 02 00 00 	add    %eax,0x2c0(%rsp)
    61a5:	29 54 24 60          	sub    %edx,0x60(%rsp)
    61a9:	8b 44 24 60          	mov    0x60(%rsp),%eax
    61ad:	83 f8 0f             	cmp    $0xf,%eax
    61b0:	0f 86 e0 08 00 00    	jbe    6a96 <convert_avx2_job+0x15e6>
    61b6:	48 8b bc 24 80 00 00 	mov    0x80(%rsp),%rdi
    61bd:	00 
    61be:	48 01 d2             	add    %rdx,%rdx
    61c1:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    61c6:	48 8b 5c 24 50       	mov    0x50(%rsp),%rbx
    61cb:	4c 8b 44 24 48       	mov    0x48(%rsp),%r8
    61d0:	48 01 d7             	add    %rdx,%rdi
    61d3:	48 c1 e7 02          	shl    $0x2,%rdi
    61d7:	49 01 d0             	add    %rdx,%r8
    61da:	48 01 f8             	add    %rdi,%rax
    61dd:	48 01 fb             	add    %rdi,%rbx
    61e0:	4f 8d 0c 06          	lea    (%r14,%r8,1),%r9
    61e4:	4c 8b 44 24 c0       	mov    -0x40(%rsp),%r8
    61e9:	4c 01 e0             	add    %r12,%rax
    61ec:	48 89 df             	mov    %rbx,%rdi
    61ef:	48 8b 5c 24 98       	mov    -0x68(%rsp),%rbx
    61f4:	c5 fa 6f 00          	vmovdqu (%rax),%xmm0
    61f8:	c5 7a 6f 60 10       	vmovdqu 0x10(%rax),%xmm12
    61fd:	49 01 d0             	add    %rdx,%r8
    6200:	4c 01 e7             	add    %r12,%rdi
    6203:	c5 fa 6f 70 20       	vmovdqu 0x20(%rax),%xmm6
    6208:	c5 7a 6f 50 30       	vmovdqu 0x30(%rax),%xmm10
    620d:	48 01 d3             	add    %rdx,%rbx
    6210:	4d 01 f0             	add    %r14,%r8
    6213:	c5 99 db 25 65 90 00 	vpand  0x9065(%rip),%xmm12,%xmm4        # f280 <__PRETTY_FUNCTION__.4+0xd>
    621a:	00 
    621b:	c5 f9 db 1d 5d 90 00 	vpand  0x905d(%rip),%xmm0,%xmm3        # f280 <__PRETTY_FUNCTION__.4+0xd>
    6222:	00 
    6223:	48 89 da             	mov    %rbx,%rdx
    6226:	c5 fa 6f 48 40       	vmovdqu 0x40(%rax),%xmm1
    622b:	c5 7a 6f 48 50       	vmovdqu 0x50(%rax),%xmm9
    6230:	c4 c1 19 71 d4 08    	vpsrlw $0x8,%xmm12,%xmm12
    6236:	c5 f9 71 d0 08       	vpsrlw $0x8,%xmm0,%xmm0
    623b:	c5 a9 db 2d 3d 90 00 	vpand  0x903d(%rip),%xmm10,%xmm5        # f280 <__PRETTY_FUNCTION__.4+0xd>
    6242:	00 
    6243:	c5 e1 67 dc          	vpackuswb %xmm4,%xmm3,%xmm3
    6247:	c5 fa 6f 50 60       	vmovdqu 0x60(%rax),%xmm2
    624c:	c4 c1 79 67 c4       	vpackuswb %xmm12,%xmm0,%xmm0
    6251:	c5 c9 db 25 27 90 00 	vpand  0x9027(%rip),%xmm6,%xmm4        # f280 <__PRETTY_FUNCTION__.4+0xd>
    6258:	00 
    6259:	c5 71 db 05 1f 90 00 	vpand  0x901f(%rip),%xmm1,%xmm8        # f280 <__PRETTY_FUNCTION__.4+0xd>
    6260:	00 
    6261:	c5 fa 6f 78 70       	vmovdqu 0x70(%rax),%xmm7
    6266:	c4 c1 29 71 d2 08    	vpsrlw $0x8,%xmm10,%xmm10
    626c:	c5 c9 71 d6 08       	vpsrlw $0x8,%xmm6,%xmm6
    6271:	c5 69 db 1d 07 90 00 	vpand  0x9007(%rip),%xmm2,%xmm11        # f280 <__PRETTY_FUNCTION__.4+0xd>
    6278:	00 
    6279:	c5 d9 67 e5          	vpackuswb %xmm5,%xmm4,%xmm4
    627d:	c5 b1 db 2d fb 8f 00 	vpand  0x8ffb(%rip),%xmm9,%xmm5        # f280 <__PRETTY_FUNCTION__.4+0xd>
    6284:	00 
    6285:	c5 59 db 2d f3 8f 00 	vpand  0x8ff3(%rip),%xmm4,%xmm13        # f280 <__PRETTY_FUNCTION__.4+0xd>
    628c:	00 
    628d:	b8 2f 00 00 00       	mov    $0x2f,%eax
    6292:	c5 d9 71 d4 08       	vpsrlw $0x8,%xmm4,%xmm4
    6297:	c4 c1 31 71 d1 08    	vpsrlw $0x8,%xmm9,%xmm9
    629d:	c5 f9 db 05 db 8f 00 	vpand  0x8fdb(%rip),%xmm0,%xmm0        # f280 <__PRETTY_FUNCTION__.4+0xd>
    62a4:	00 
    62a5:	48 8b 9c 24 b0 02 00 	mov    0x2b0(%rsp),%rbx
    62ac:	00 
    62ad:	c5 39 67 c5          	vpackuswb %xmm5,%xmm8,%xmm8
    62b1:	c5 c1 db 2d c7 8f 00 	vpand  0x8fc7(%rip),%xmm7,%xmm5        # f280 <__PRETTY_FUNCTION__.4+0xd>
    62b8:	00 
    62b9:	c4 c1 49 67 f2       	vpackuswb %xmm10,%xmm6,%xmm6
    62be:	c5 c1 71 d7 08       	vpsrlw $0x8,%xmm7,%xmm7
    62c3:	c5 f1 71 d1 08       	vpsrlw $0x8,%xmm1,%xmm1
    62c8:	48 01 da             	add    %rbx,%rdx
    62cb:	c5 21 67 dd          	vpackuswb %xmm5,%xmm11,%xmm11
    62cf:	c5 e1 db 2d a9 8f 00 	vpand  0x8fa9(%rip),%xmm3,%xmm5        # f280 <__PRETTY_FUNCTION__.4+0xd>
    62d6:	00 
    62d7:	c5 c9 db 35 a1 8f 00 	vpand  0x8fa1(%rip),%xmm6,%xmm6        # f280 <__PRETTY_FUNCTION__.4+0xd>
    62de:	00 
    62df:	c5 e1 71 d3 08       	vpsrlw $0x8,%xmm3,%xmm3
    62e4:	c5 e9 71 d2 08       	vpsrlw $0x8,%xmm2,%xmm2
    62e9:	c4 c1 71 67 c9       	vpackuswb %xmm9,%xmm1,%xmm1
    62ee:	c4 c1 51 67 ed       	vpackuswb %xmm13,%xmm5,%xmm5
    62f3:	c5 e1 67 dc          	vpackuswb %xmm4,%xmm3,%xmm3
    62f7:	c5 21 db 2d 81 8f 00 	vpand  0x8f81(%rip),%xmm11,%xmm13        # f280 <__PRETTY_FUNCTION__.4+0xd>
    62fe:	00 
    62ff:	c5 b9 db 25 79 8f 00 	vpand  0x8f79(%rip),%xmm8,%xmm4        # f280 <__PRETTY_FUNCTION__.4+0xd>
    6306:	00 
    6307:	c5 f1 db 0d 71 8f 00 	vpand  0x8f71(%rip),%xmm1,%xmm1        # f280 <__PRETTY_FUNCTION__.4+0xd>
    630e:	00 
    630f:	c5 e9 67 d7          	vpackuswb %xmm7,%xmm2,%xmm2
    6313:	c4 c1 21 71 d3 08    	vpsrlw $0x8,%xmm11,%xmm11
    6319:	c4 c1 39 71 d0 08    	vpsrlw $0x8,%xmm8,%xmm8
    631f:	c5 f9 67 c6          	vpackuswb %xmm6,%xmm0,%xmm0
    6323:	c5 e9 db 15 55 8f 00 	vpand  0x8f55(%rip),%xmm2,%xmm2        # f280 <__PRETTY_FUNCTION__.4+0xd>
    632a:	00 
    632b:	c5 d1 db 35 4d 8f 00 	vpand  0x8f4d(%rip),%xmm5,%xmm6        # f280 <__PRETTY_FUNCTION__.4+0xd>
    6332:	00 
    6333:	c4 c1 59 67 e5       	vpackuswb %xmm13,%xmm4,%xmm4
    6338:	c5 d1 71 d5 08       	vpsrlw $0x8,%xmm5,%xmm5
    633d:	c4 41 39 67 c3       	vpackuswb %xmm11,%xmm8,%xmm8
    6342:	c5 f1 67 ca          	vpackuswb %xmm2,%xmm1,%xmm1
    6346:	c5 d9 db 15 32 8f 00 	vpand  0x8f32(%rip),%xmm4,%xmm2        # f280 <__PRETTY_FUNCTION__.4+0xd>
    634d:	00 
    634e:	c5 f9 db 3d 2a 8f 00 	vpand  0x8f2a(%rip),%xmm0,%xmm7        # f280 <__PRETTY_FUNCTION__.4+0xd>
    6355:	00 
    6356:	c5 d9 71 d4 08       	vpsrlw $0x8,%xmm4,%xmm4
    635b:	c5 f9 71 d0 08       	vpsrlw $0x8,%xmm0,%xmm0
    6360:	c5 c9 67 f2          	vpackuswb %xmm2,%xmm6,%xmm6
    6364:	c5 f1 db 15 14 8f 00 	vpand  0x8f14(%rip),%xmm1,%xmm2        # f280 <__PRETTY_FUNCTION__.4+0xd>
    636b:	00 
    636c:	c5 d1 67 ec          	vpackuswb %xmm4,%xmm5,%xmm5
    6370:	c5 f1 71 d1 08       	vpsrlw $0x8,%xmm1,%xmm1
    6375:	c5 e1 db 25 03 8f 00 	vpand  0x8f03(%rip),%xmm3,%xmm4        # f280 <__PRETTY_FUNCTION__.4+0xd>
    637c:	00 
    637d:	c4 62 79 30 ee       	vpmovzxbw %xmm6,%xmm13
    6382:	c5 c1 67 fa          	vpackuswb %xmm2,%xmm7,%xmm7
    6386:	c5 f9 67 c1          	vpackuswb %xmm1,%xmm0,%xmm0
    638a:	c5 f9 6e d0          	vmovd  %eax,%xmm2
    638e:	b8 9d ff ff ff       	mov    $0xffffff9d,%eax
    6393:	c5 79 6e e0          	vmovd  %eax,%xmm12
    6397:	c4 e2 79 78 d2       	vpbroadcastb %xmm2,%xmm2
    639c:	b8 10 00 00 00       	mov    $0x10,%eax
    63a1:	c5 79 7f ac 24 08 02 	vmovdqa %xmm13,0x208(%rsp)
    63a8:	00 00 
    63aa:	c4 42 79 78 e4       	vpbroadcastb %xmm12,%xmm12
    63af:	c5 e1 71 d3 08       	vpsrlw $0x8,%xmm3,%xmm3
    63b4:	c4 62 79 30 ca       	vpmovzxbw %xmm2,%xmm9
    63b9:	c4 42 79 30 f4       	vpmovzxbw %xmm12,%xmm14
    63be:	c4 e2 79 30 d7       	vpmovzxbw %xmm7,%xmm2
    63c3:	c5 79 6e e0          	vmovd  %eax,%xmm12
    63c7:	b8 80 00 00 00       	mov    $0x80,%eax
    63cc:	c5 c1 73 df 08       	vpsrldq $0x8,%xmm7,%xmm7
    63d1:	c5 c9 73 de 08       	vpsrldq $0x8,%xmm6,%xmm6
    63d6:	c4 42 79 78 e4       	vpbroadcastb %xmm12,%xmm12
    63db:	c5 f9 7f 94 24 28 02 	vmovdqa %xmm2,0x228(%rsp)
    63e2:	00 00 
    63e4:	c5 b9 db 0d 94 8e 00 	vpand  0x8e94(%rip),%xmm8,%xmm1        # f280 <__PRETTY_FUNCTION__.4+0xd>
    63eb:	00 
    63ec:	c5 89 d5 d2          	vpmullw %xmm2,%xmm14,%xmm2
    63f0:	c4 62 79 30 d7       	vpmovzxbw %xmm7,%xmm10
    63f5:	c5 79 7f 8c 24 48 02 	vmovdqa %xmm9,0x248(%rsp)
    63fc:	00 00 
    63fe:	c5 79 7f 94 24 c8 01 	vmovdqa %xmm10,0x1c8(%rsp)
    6405:	00 00 
    6407:	c4 c1 39 71 d0 08    	vpsrlw $0x8,%xmm8,%xmm8
    640d:	c5 d9 67 e1          	vpackuswb %xmm1,%xmm4,%xmm4
    6411:	c4 c1 61 67 d8       	vpackuswb %xmm8,%xmm3,%xmm3
    6416:	c5 11 d5 05 f2 8e 00 	vpmullw 0x8ef2(%rip),%xmm13,%xmm8        # f310 <__PRETTY_FUNCTION__.4+0x9d>
    641d:	00 
    641e:	c5 79 6f 6c 24 68    	vmovdqa 0x68(%rsp),%xmm13
    6424:	c4 e2 79 30 cc       	vpmovzxbw %xmm4,%xmm1
    6429:	c5 d9 73 dc 08       	vpsrldq $0x8,%xmm4,%xmm4
    642e:	c5 f9 7f 8c 24 68 02 	vmovdqa %xmm1,0x268(%rsp)
    6435:	00 00 
    6437:	c4 c1 71 d5 c9       	vpmullw %xmm9,%xmm1,%xmm1
    643c:	c4 62 79 30 dc       	vpmovzxbw %xmm4,%xmm11
    6441:	c5 79 7f 9c 24 e8 01 	vmovdqa %xmm11,0x1e8(%rsp)
    6448:	00 00 
    644a:	c4 c1 21 d5 e5       	vpmullw %xmm13,%xmm11,%xmm4
    644f:	c5 79 6f 5c 24 a8    	vmovdqa -0x58(%rsp),%xmm11
    6455:	c4 c1 29 d5 fb       	vpmullw %xmm11,%xmm10,%xmm7
    645a:	c5 f1 fd ca          	vpaddw %xmm2,%xmm1,%xmm1
    645e:	c5 f9 6e d0          	vmovd  %eax,%xmm2
    6462:	b8 e6 ff ff ff       	mov    $0xffffffe6,%eax
    6467:	c4 e2 79 79 d2       	vpbroadcastw %xmm2,%xmm2
    646c:	c5 39 fd c2          	vpaddw %xmm2,%xmm8,%xmm8
    6470:	c4 c1 71 fd c8       	vpaddw %xmm8,%xmm1,%xmm1
    6475:	c4 62 79 30 c6       	vpmovzxbw %xmm6,%xmm8
    647a:	c5 d9 fd e7          	vpaddw %xmm7,%xmm4,%xmm4
    647e:	c4 c1 49 73 dc 08    	vpsrldq $0x8,%xmm12,%xmm6
    6484:	c5 f1 71 d1 08       	vpsrlw $0x8,%xmm1,%xmm1
    6489:	c5 f1 db 0d ef 8d 00 	vpand  0x8def(%rip),%xmm1,%xmm1        # f280 <__PRETTY_FUNCTION__.4+0xd>
    6490:	00 
    6491:	c5 79 7f 84 24 a8 01 	vmovdqa %xmm8,0x1a8(%rsp)
    6498:	00 00 
    649a:	c4 62 79 30 d6       	vpmovzxbw %xmm6,%xmm10
    649f:	c5 79 7f e7          	vmovdqa %xmm12,%xmm7
    64a3:	c5 79 7f 94 24 88 02 	vmovdqa %xmm10,0x288(%rsp)
    64aa:	00 00 
    64ac:	c4 c1 29 d5 f0       	vpmullw %xmm8,%xmm10,%xmm6
    64b1:	c5 f9 7f bc 24 c8 02 	vmovdqa %xmm7,0x2c8(%rsp)
    64b8:	00 00 
    64ba:	c5 c9 fd f2          	vpaddw %xmm2,%xmm6,%xmm6
    64be:	c5 d9 fd e6          	vpaddw %xmm6,%xmm4,%xmm4
    64c2:	c4 e2 79 30 f3       	vpmovzxbw %xmm3,%xmm6
    64c7:	c5 d9 71 d4 08       	vpsrlw $0x8,%xmm4,%xmm4
    64cc:	c5 e1 73 db 08       	vpsrldq $0x8,%xmm3,%xmm3
    64d1:	c5 d9 db 25 a7 8d 00 	vpand  0x8da7(%rip),%xmm4,%xmm4        # f280 <__PRETTY_FUNCTION__.4+0xd>
    64d8:	00 
    64d9:	c5 f9 7f b4 24 88 01 	vmovdqa %xmm6,0x188(%rsp)
    64e0:	00 00 
    64e2:	c4 e2 79 30 db       	vpmovzxbw %xmm3,%xmm3
    64e7:	c5 f9 7f 9c 24 28 01 	vmovdqa %xmm3,0x128(%rsp)
    64ee:	00 00 
    64f0:	c5 f1 67 cc          	vpackuswb %xmm4,%xmm1,%xmm1
    64f4:	c4 c1 61 d5 dd       	vpmullw %xmm13,%xmm3,%xmm3
    64f9:	c4 c1 71 fc cc       	vpaddb %xmm12,%xmm1,%xmm1
    64fe:	c4 c1 49 d5 e1       	vpmullw %xmm9,%xmm6,%xmm4
    6503:	c4 62 79 30 e0       	vpmovzxbw %xmm0,%xmm12
    6508:	c5 f9 73 d8 08       	vpsrldq $0x8,%xmm0,%xmm0
    650d:	c4 62 79 30 cd       	vpmovzxbw %xmm5,%xmm9
    6512:	c5 79 7f a4 24 68 01 	vmovdqa %xmm12,0x168(%rsp)
    6519:	00 00 
    651b:	c5 d1 73 dd 08       	vpsrldq $0x8,%xmm5,%xmm5
    6520:	c4 e2 79 30 c0       	vpmovzxbw %xmm0,%xmm0
    6525:	c5 79 7f 8c 24 48 01 	vmovdqa %xmm9,0x148(%rsp)
    652c:	00 00 
    652e:	c5 f9 7f 84 24 08 01 	vmovdqa %xmm0,0x108(%rsp)
    6535:	00 00 
    6537:	c4 c1 79 d5 c3       	vpmullw %xmm11,%xmm0,%xmm0
    653c:	c4 e2 79 30 ed       	vpmovzxbw %xmm5,%xmm5
    6541:	c5 f9 7f ac 24 e8 00 	vmovdqa %xmm5,0xe8(%rsp)
    6548:	00 00 
    654a:	c4 c1 09 d5 f4       	vpmullw %xmm12,%xmm14,%xmm6
    654f:	c5 e1 fd c0          	vpaddw %xmm0,%xmm3,%xmm0
    6553:	c4 c1 51 d5 da       	vpmullw %xmm10,%xmm5,%xmm3
    6558:	c5 d9 fd e6          	vpaddw %xmm6,%xmm4,%xmm4
    655c:	c5 b1 d5 35 ac 8d 00 	vpmullw 0x8dac(%rip),%xmm9,%xmm6        # f310 <__PRETTY_FUNCTION__.4+0x9d>
    6563:	00 
    6564:	c5 c9 fd f2          	vpaddw %xmm2,%xmm6,%xmm6
    6568:	c5 d9 fd e6          	vpaddw %xmm6,%xmm4,%xmm4
    656c:	c5 d9 71 d4 08       	vpsrlw $0x8,%xmm4,%xmm4
    6571:	c5 d9 db 25 07 8d 00 	vpand  0x8d07(%rip),%xmm4,%xmm4        # f280 <__PRETTY_FUNCTION__.4+0xd>
    6578:	00 
    6579:	c5 e1 fd da          	vpaddw %xmm2,%xmm3,%xmm3
    657d:	c5 f9 fd c3          	vpaddw %xmm3,%xmm0,%xmm0
    6581:	c5 f9 71 d0 08       	vpsrlw $0x8,%xmm0,%xmm0
    6586:	c5 f9 db 05 f2 8c 00 	vpand  0x8cf2(%rip),%xmm0,%xmm0        # f280 <__PRETTY_FUNCTION__.4+0xd>
    658d:	00 
    658e:	c5 d9 67 e0          	vpackuswb %xmm0,%xmm4,%xmm4
    6592:	c5 d9 fc e7          	vpaddb %xmm7,%xmm4,%xmm4
    6596:	c5 f1 60 c4          	vpunpcklbw %xmm4,%xmm1,%xmm0
    659a:	c5 f1 68 cc          	vpunpckhbw %xmm4,%xmm1,%xmm1
    659e:	c4 c1 7a 7f 49 10    	vmovdqu %xmm1,0x10(%r9)
    65a4:	c4 c1 7a 7f 01       	vmovdqu %xmm0,(%r9)
    65a9:	c5 7a 6f 27          	vmovdqu (%rdi),%xmm12
    65ad:	c5 fa 6f 47 10       	vmovdqu 0x10(%rdi),%xmm0
    65b2:	c5 7a 6f 5f 20       	vmovdqu 0x20(%rdi),%xmm11
    65b7:	c5 f9 db 25 c1 8c 00 	vpand  0x8cc1(%rip),%xmm0,%xmm4        # f280 <__PRETTY_FUNCTION__.4+0xd>
    65be:	00 
    65bf:	c5 fa 6f 7f 30       	vmovdqu 0x30(%rdi),%xmm7
    65c4:	c5 7a 6f 57 40       	vmovdqu 0x40(%rdi),%xmm10
    65c9:	c5 f9 71 d0 08       	vpsrlw $0x8,%xmm0,%xmm0
    65ce:	c5 99 db 0d aa 8c 00 	vpand  0x8caa(%rip),%xmm12,%xmm1        # f280 <__PRETTY_FUNCTION__.4+0xd>
    65d5:	00 
    65d6:	c5 21 db 0d a2 8c 00 	vpand  0x8ca2(%rip),%xmm11,%xmm9        # f280 <__PRETTY_FUNCTION__.4+0xd>
    65dd:	00 
    65de:	c5 fa 6f 5f 50       	vmovdqu 0x50(%rdi),%xmm3
    65e3:	c5 7a 6f 47 60       	vmovdqu 0x60(%rdi),%xmm8
    65e8:	c4 c1 19 71 d4 08    	vpsrlw $0x8,%xmm12,%xmm12
    65ee:	c4 c1 21 71 d3 08    	vpsrlw $0x8,%xmm11,%xmm11
    65f4:	c5 f1 67 cc          	vpackuswb %xmm4,%xmm1,%xmm1
    65f8:	c5 c1 db 25 80 8c 00 	vpand  0x8c80(%rip),%xmm7,%xmm4        # f280 <__PRETTY_FUNCTION__.4+0xd>
    65ff:	00 
    6600:	c5 a9 db 2d 78 8c 00 	vpand  0x8c78(%rip),%xmm10,%xmm5        # f280 <__PRETTY_FUNCTION__.4+0xd>
    6607:	00 
    6608:	c5 fa 6f 77 70       	vmovdqu 0x70(%rdi),%xmm6
    660d:	c4 c1 29 71 d2 08    	vpsrlw $0x8,%xmm10,%xmm10
    6613:	c5 c1 71 d7 08       	vpsrlw $0x8,%xmm7,%xmm7
    6618:	c5 39 db 2d 60 8c 00 	vpand  0x8c60(%rip),%xmm8,%xmm13        # f280 <__PRETTY_FUNCTION__.4+0xd>
    661f:	00 
    6620:	c5 31 67 cc          	vpackuswb %xmm4,%xmm9,%xmm9
    6624:	c5 e1 db 25 54 8c 00 	vpand  0x8c54(%rip),%xmm3,%xmm4        # f280 <__PRETTY_FUNCTION__.4+0xd>
    662b:	00 
    662c:	c5 31 db 3d 4c 8c 00 	vpand  0x8c4c(%rip),%xmm9,%xmm15        # f280 <__PRETTY_FUNCTION__.4+0xd>
    6633:	00 
    6634:	c4 c1 39 71 d0 08    	vpsrlw $0x8,%xmm8,%xmm8
    663a:	c4 c1 31 71 d1 08    	vpsrlw $0x8,%xmm9,%xmm9
    6640:	c5 99 67 c0          	vpackuswb %xmm0,%xmm12,%xmm0
    6644:	c5 d1 67 ec          	vpackuswb %xmm4,%xmm5,%xmm5
    6648:	c5 c9 db 25 30 8c 00 	vpand  0x8c30(%rip),%xmm6,%xmm4        # f280 <__PRETTY_FUNCTION__.4+0xd>
    664f:	00 
    6650:	c5 a1 67 ff          	vpackuswb %xmm7,%xmm11,%xmm7
    6654:	c5 e1 71 d3 08       	vpsrlw $0x8,%xmm3,%xmm3
    6659:	c5 c9 71 d6 08       	vpsrlw $0x8,%xmm6,%xmm6
    665e:	c5 c1 db 3d 1a 8c 00 	vpand  0x8c1a(%rip),%xmm7,%xmm7        # f280 <__PRETTY_FUNCTION__.4+0xd>
    6665:	00 
    6666:	c5 11 67 ec          	vpackuswb %xmm4,%xmm13,%xmm13
    666a:	c5 a9 67 db          	vpackuswb %xmm3,%xmm10,%xmm3
    666e:	c5 f1 db 25 0a 8c 00 	vpand  0x8c0a(%rip),%xmm1,%xmm4        # f280 <__PRETTY_FUNCTION__.4+0xd>
    6675:	00 
    6676:	c5 f1 71 d1 08       	vpsrlw $0x8,%xmm1,%xmm1
    667b:	c5 e1 db 1d fd 8b 00 	vpand  0x8bfd(%rip),%xmm3,%xmm3        # f280 <__PRETTY_FUNCTION__.4+0xd>
    6682:	00 
    6683:	c5 b9 67 f6          	vpackuswb %xmm6,%xmm8,%xmm6
    6687:	c4 c1 59 67 e7       	vpackuswb %xmm15,%xmm4,%xmm4
    668c:	c5 c9 db 35 ec 8b 00 	vpand  0x8bec(%rip),%xmm6,%xmm6        # f280 <__PRETTY_FUNCTION__.4+0xd>
    6693:	00 
    6694:	c5 11 db 3d e4 8b 00 	vpand  0x8be4(%rip),%xmm13,%xmm15        # f280 <__PRETTY_FUNCTION__.4+0xd>
    669b:	00 
    669c:	c4 c1 71 67 c9       	vpackuswb %xmm9,%xmm1,%xmm1
    66a1:	c5 51 db 0d d7 8b 00 	vpand  0x8bd7(%rip),%xmm5,%xmm9        # f280 <__PRETTY_FUNCTION__.4+0xd>
    66a8:	00 
    66a9:	c5 59 db 05 cf 8b 00 	vpand  0x8bcf(%rip),%xmm4,%xmm8        # f280 <__PRETTY_FUNCTION__.4+0xd>
    66b0:	00 
    66b1:	c4 c1 11 71 d5 08    	vpsrlw $0x8,%xmm13,%xmm13
    66b7:	c5 d1 71 d5 08       	vpsrlw $0x8,%xmm5,%xmm5
    66bc:	c5 e1 67 de          	vpackuswb %xmm6,%xmm3,%xmm3
    66c0:	c4 41 31 67 cf       	vpackuswb %xmm15,%xmm9,%xmm9
    66c5:	c5 d9 71 d4 08       	vpsrlw $0x8,%xmm4,%xmm4
    66ca:	c4 c1 51 67 ed       	vpackuswb %xmm13,%xmm5,%xmm5
    66cf:	c5 79 6f ac 24 48 02 	vmovdqa 0x248(%rsp),%xmm13
    66d6:	00 00 
    66d8:	c5 b1 db 35 a0 8b 00 	vpand  0x8ba0(%rip),%xmm9,%xmm6        # f280 <__PRETTY_FUNCTION__.4+0xd>
    66df:	00 
    66e0:	c5 f9 db 05 98 8b 00 	vpand  0x8b98(%rip),%xmm0,%xmm0        # f280 <__PRETTY_FUNCTION__.4+0xd>
    66e7:	00 
    66e8:	c4 c1 31 71 d1 08    	vpsrlw $0x8,%xmm9,%xmm9
    66ee:	c5 39 67 c6          	vpackuswb %xmm6,%xmm8,%xmm8
    66f2:	c5 f9 67 c7          	vpackuswb %xmm7,%xmm0,%xmm0
    66f6:	c5 e1 db 35 82 8b 00 	vpand  0x8b82(%rip),%xmm3,%xmm6        # f280 <__PRETTY_FUNCTION__.4+0xd>
    66fd:	00 
    66fe:	c5 e1 71 d3 08       	vpsrlw $0x8,%xmm3,%xmm3
    6703:	c5 f9 db 3d 75 8b 00 	vpand  0x8b75(%rip),%xmm0,%xmm7        # f280 <__PRETTY_FUNCTION__.4+0xd>
    670a:	00 
    670b:	c4 42 79 30 d8       	vpmovzxbw %xmm8,%xmm11
    6710:	c5 f9 71 d0 08       	vpsrlw $0x8,%xmm0,%xmm0
    6715:	c4 c1 39 73 d8 08    	vpsrldq $0x8,%xmm8,%xmm8
    671b:	c4 c1 59 67 e1       	vpackuswb %xmm9,%xmm4,%xmm4
    6720:	c5 c1 67 fe          	vpackuswb %xmm6,%xmm7,%xmm7
    6724:	c5 f9 67 c3          	vpackuswb %xmm3,%xmm0,%xmm0
    6728:	c4 42 79 30 c0       	vpmovzxbw %xmm8,%xmm8
    672d:	c5 d1 db 1d 4b 8b 00 	vpand  0x8b4b(%rip),%xmm5,%xmm3        # f280 <__PRETTY_FUNCTION__.4+0xd>
    6734:	00 
    6735:	c5 d1 71 d5 08       	vpsrlw $0x8,%xmm5,%xmm5
    673a:	c4 62 79 30 d7       	vpmovzxbw %xmm7,%xmm10
    673f:	c5 f1 db 35 39 8b 00 	vpand  0x8b39(%rip),%xmm1,%xmm6        # f280 <__PRETTY_FUNCTION__.4+0xd>
    6746:	00 
    6747:	c5 f1 71 d1 08       	vpsrlw $0x8,%xmm1,%xmm1
    674c:	c5 f1 67 cd          	vpackuswb %xmm5,%xmm1,%xmm1
    6750:	c4 c1 29 d5 ee       	vpmullw %xmm14,%xmm10,%xmm5
    6755:	c5 c9 67 f3          	vpackuswb %xmm3,%xmm6,%xmm6
    6759:	c5 c1 73 df 08       	vpsrldq $0x8,%xmm7,%xmm7
    675e:	c4 62 79 30 e1       	vpmovzxbw %xmm1,%xmm12
    6763:	c4 e2 79 30 de       	vpmovzxbw %xmm6,%xmm3
    6768:	c5 c9 73 de 08       	vpsrldq $0x8,%xmm6,%xmm6
    676d:	c4 e2 79 30 ff       	vpmovzxbw %xmm7,%xmm7
    6772:	c5 f9 7f 9c 24 c8 00 	vmovdqa %xmm3,0xc8(%rsp)
    6779:	00 00 
    677b:	c4 c1 61 d5 dd       	vpmullw %xmm13,%xmm3,%xmm3
    6780:	c4 e2 79 30 f6       	vpmovzxbw %xmm6,%xmm6
    6785:	c5 f1 73 d9 08       	vpsrldq $0x8,%xmm1,%xmm1
    678a:	c4 e2 79 30 c9       	vpmovzxbw %xmm1,%xmm1
    678f:	c5 e1 fd dd          	vpaddw %xmm5,%xmm3,%xmm3
    6793:	c5 a1 d5 2d 75 8b 00 	vpmullw 0x8b75(%rip),%xmm11,%xmm5        # f310 <__PRETTY_FUNCTION__.4+0x9d>
    679a:	00 
    679b:	c5 d1 fd ea          	vpaddw %xmm2,%xmm5,%xmm5
    679f:	c5 e1 fd dd          	vpaddw %xmm5,%xmm3,%xmm3
    67a3:	c5 c9 d5 6c 24 68    	vpmullw 0x68(%rsp),%xmm6,%xmm5
    67a9:	c5 79 6f 7c 24 a8    	vmovdqa -0x58(%rsp),%xmm15
    67af:	c5 c9 fd f1          	vpaddw %xmm1,%xmm6,%xmm6
    67b3:	c5 e1 71 d3 08       	vpsrlw $0x8,%xmm3,%xmm3
    67b8:	c5 e1 db 1d c0 8a 00 	vpand  0x8ac0(%rip),%xmm3,%xmm3        # f280 <__PRETTY_FUNCTION__.4+0xd>
    67bf:	00 
    67c0:	c4 41 41 d5 cf       	vpmullw %xmm15,%xmm7,%xmm9
    67c5:	c4 c1 51 fd e9       	vpaddw %xmm9,%xmm5,%xmm5
    67ca:	c5 39 d5 8c 24 88 02 	vpmullw 0x288(%rsp),%xmm8,%xmm9
    67d1:	00 00 
    67d3:	c5 31 fd ca          	vpaddw %xmm2,%xmm9,%xmm9
    67d7:	c4 c1 51 fd e9       	vpaddw %xmm9,%xmm5,%xmm5
    67dc:	c5 d1 71 d5 08       	vpsrlw $0x8,%xmm5,%xmm5
    67e1:	c5 d1 db 2d 97 8a 00 	vpand  0x8a97(%rip),%xmm5,%xmm5        # f280 <__PRETTY_FUNCTION__.4+0xd>
    67e8:	00 
    67e9:	c5 e1 67 dd          	vpackuswb %xmm5,%xmm3,%xmm3
    67ed:	c4 c1 19 d5 ed       	vpmullw %xmm13,%xmm12,%xmm5
    67f2:	c4 62 79 30 e8       	vpmovzxbw %xmm0,%xmm13
    67f7:	c5 f9 73 d8 08       	vpsrldq $0x8,%xmm0,%xmm0
    67fc:	c4 41 11 d5 ce       	vpmullw %xmm14,%xmm13,%xmm9
    6801:	c4 62 79 30 f4       	vpmovzxbw %xmm4,%xmm14
    6806:	c4 e2 79 30 c0       	vpmovzxbw %xmm0,%xmm0
    680b:	c5 d9 73 dc 08       	vpsrldq $0x8,%xmm4,%xmm4
    6810:	c4 41 29 fd d5       	vpaddw %xmm13,%xmm10,%xmm10
    6815:	c5 79 6f ac 24 08 01 	vmovdqa 0x108(%rsp),%xmm13
    681c:	00 00 
    681e:	c4 41 79 d5 ff       	vpmullw %xmm15,%xmm0,%xmm15
    6823:	c4 e2 79 30 e4       	vpmovzxbw %xmm4,%xmm4
    6828:	c5 c1 fd f8          	vpaddw %xmm0,%xmm7,%xmm7
    682c:	c5 f9 6f 84 24 88 01 	vmovdqa 0x188(%rsp),%xmm0
    6833:	00 00 
    6835:	c5 e1 fc 9c 24 c8 02 	vpaddb 0x2c8(%rsp),%xmm3,%xmm3
    683c:	00 00 
    683e:	c5 39 fd c4          	vpaddw %xmm4,%xmm8,%xmm8
    6842:	c4 41 21 fd de       	vpaddw %xmm14,%xmm11,%xmm11
    6847:	c4 c1 51 fd e9       	vpaddw %xmm9,%xmm5,%xmm5
    684c:	c5 09 d5 0d bc 8a 00 	vpmullw 0x8abc(%rip),%xmm14,%xmm9        # f310 <__PRETTY_FUNCTION__.4+0x9d>
    6853:	00 
    6854:	c5 31 fd ca          	vpaddw %xmm2,%xmm9,%xmm9
    6858:	c5 79 6f b4 24 68 01 	vmovdqa 0x168(%rsp),%xmm14
    685f:	00 00 
    6861:	c4 c1 51 fd e9       	vpaddw %xmm9,%xmm5,%xmm5
    6866:	c5 71 d5 4c 24 68    	vpmullw 0x68(%rsp),%xmm1,%xmm9
    686c:	c4 41 31 fd cf       	vpaddw %xmm15,%xmm9,%xmm9
    6871:	c5 d1 71 d5 08       	vpsrlw $0x8,%xmm5,%xmm5
    6876:	c5 59 d5 bc 24 88 02 	vpmullw 0x288(%rsp),%xmm4,%xmm15
    687d:	00 00 
    687f:	c5 01 fd fa          	vpaddw %xmm2,%xmm15,%xmm15
    6883:	c4 41 31 fd cf       	vpaddw %xmm15,%xmm9,%xmm9
    6888:	c5 d1 db 2d f0 89 00 	vpand  0x89f0(%rip),%xmm5,%xmm5        # f280 <__PRETTY_FUNCTION__.4+0xd>
    688f:	00 
    6890:	c5 89 fd a4 24 28 02 	vpaddw 0x228(%rsp),%xmm14,%xmm4
    6897:	00 00 
    6899:	c4 c1 31 71 d1 08    	vpsrlw $0x8,%xmm9,%xmm9
    689f:	c5 31 db 0d d9 89 00 	vpand  0x89d9(%rip),%xmm9,%xmm9        # f280 <__PRETTY_FUNCTION__.4+0xd>
    68a6:	00 
    68a7:	c4 c1 59 fd e2       	vpaddw %xmm10,%xmm4,%xmm4
    68ac:	c4 c1 51 67 e9       	vpackuswb %xmm9,%xmm5,%xmm5
    68b1:	c5 d9 71 d4 02       	vpsrlw $0x2,%xmm4,%xmm4
    68b6:	c5 d1 fc ac 24 c8 02 	vpaddb 0x2c8(%rsp),%xmm5,%xmm5
    68bd:	00 00 
    68bf:	c5 61 60 cd          	vpunpcklbw %xmm5,%xmm3,%xmm9
    68c3:	c5 e1 68 dd          	vpunpckhbw %xmm5,%xmm3,%xmm3
    68c7:	c4 41 7a 7f 08       	vmovdqu %xmm9,(%r8)
    68cc:	c5 79 6f 8c 24 48 01 	vmovdqa 0x148(%rsp),%xmm9
    68d3:	00 00 
    68d5:	c4 c1 7a 7f 58 10    	vmovdqu %xmm3,0x10(%r8)
    68db:	c5 b1 fd 9c 24 08 02 	vpaddw 0x208(%rsp),%xmm9,%xmm3
    68e2:	00 00 
    68e4:	c5 79 6f 8c 24 e8 00 	vmovdqa 0xe8(%rsp),%xmm9
    68eb:	00 00 
    68ed:	c5 b1 fd ac 24 a8 01 	vpaddw 0x1a8(%rsp),%xmm9,%xmm5
    68f4:	00 00 
    68f6:	c4 c1 61 fd db       	vpaddw %xmm11,%xmm3,%xmm3
    68fb:	c4 c1 51 fd e8       	vpaddw %xmm8,%xmm5,%xmm5
    6900:	c5 e1 71 d3 02       	vpsrlw $0x2,%xmm3,%xmm3
    6905:	c5 11 fd 84 24 c8 01 	vpaddw 0x1c8(%rsp),%xmm13,%xmm8
    690c:	00 00 
    690e:	c5 d1 71 d5 02       	vpsrlw $0x2,%xmm5,%xmm5
    6913:	c5 39 fd c7          	vpaddw %xmm7,%xmm8,%xmm8
    6917:	c5 f9 fd bc 24 68 02 	vpaddw 0x268(%rsp),%xmm0,%xmm7
    691e:	00 00 
    6920:	c5 99 fd 84 24 c8 00 	vpaddw 0xc8(%rsp),%xmm12,%xmm0
    6927:	00 00 
    6929:	c4 c1 39 71 d0 02    	vpsrlw $0x2,%xmm8,%xmm8
    692f:	c5 c1 fd f8          	vpaddw %xmm0,%xmm7,%xmm7
    6933:	c5 f9 6f 84 24 28 01 	vmovdqa 0x128(%rsp),%xmm0
    693a:	00 00 
    693c:	c5 79 fd 8c 24 e8 01 	vpaddw 0x1e8(%rsp),%xmm0,%xmm9
    6943:	00 00 
    6945:	c5 f9 6e c0          	vmovd  %eax,%xmm0
    6949:	b8 aa ff ff ff       	mov    $0xffffffaa,%eax
    694e:	c5 c1 71 d7 02       	vpsrlw $0x2,%xmm7,%xmm7
    6953:	c4 e2 79 79 c0       	vpbroadcastw %xmm0,%xmm0
    6958:	c5 79 6e d0          	vmovd  %eax,%xmm10
    695c:	c5 c1 d5 c8          	vpmullw %xmm0,%xmm7,%xmm1
    6960:	c5 31 fd ce          	vpaddw %xmm6,%xmm9,%xmm9
    6964:	b8 80 ff ff ff       	mov    $0xffffff80,%eax
    6969:	c4 42 79 79 d2       	vpbroadcastw %xmm10,%xmm10
    696e:	c4 c1 31 71 d1 02    	vpsrlw $0x2,%xmm9,%xmm9
    6974:	c4 c1 59 d5 f2       	vpmullw %xmm10,%xmm4,%xmm6
    6979:	c5 b1 d5 c0          	vpmullw %xmm0,%xmm9,%xmm0
    697d:	c4 41 39 d5 d2       	vpmullw %xmm10,%xmm8,%xmm10
    6982:	c5 f1 fd ce          	vpaddw %xmm6,%xmm1,%xmm1
    6986:	c5 c9 71 f3 03       	vpsllw $0x3,%xmm3,%xmm6
    698b:	c5 c9 f9 f3          	vpsubw %xmm3,%xmm6,%xmm6
    698f:	c4 c1 79 fd c2       	vpaddw %xmm10,%xmm0,%xmm0
    6994:	c5 c9 71 f6 04       	vpsllw $0x4,%xmm6,%xmm6
    6999:	c5 c9 fd f2          	vpaddw %xmm2,%xmm6,%xmm6
    699d:	c5 f1 fd ce          	vpaddw %xmm6,%xmm1,%xmm1
    69a1:	c5 c9 71 f5 03       	vpsllw $0x3,%xmm5,%xmm6
    69a6:	c5 c9 f9 f5          	vpsubw %xmm5,%xmm6,%xmm6
    69aa:	c5 f1 71 e1 08       	vpsraw $0x8,%xmm1,%xmm1
    69af:	c5 f1 db 0d c9 88 00 	vpand  0x88c9(%rip),%xmm1,%xmm1        # f280 <__PRETTY_FUNCTION__.4+0xd>
    69b6:	00 
    69b7:	c5 c9 71 f6 04       	vpsllw $0x4,%xmm6,%xmm6
    69bc:	c5 c9 fd f2          	vpaddw %xmm2,%xmm6,%xmm6
    69c0:	c5 f9 fd c6          	vpaddw %xmm6,%xmm0,%xmm0
    69c4:	c5 f9 6e f0          	vmovd  %eax,%xmm6
    69c8:	b8 9a ff ff ff       	mov    $0xffffff9a,%eax
    69cd:	c5 f9 71 e0 08       	vpsraw $0x8,%xmm0,%xmm0
    69d2:	c5 f9 db 05 a6 88 00 	vpand  0x88a6(%rip),%xmm0,%xmm0        # f280 <__PRETTY_FUNCTION__.4+0xd>
    69d9:	00 
    69da:	c4 e2 79 78 f6       	vpbroadcastb %xmm6,%xmm6
    69df:	c5 f1 67 c8          	vpackuswb %xmm0,%xmm1,%xmm1
    69e3:	c5 f9 71 f7 03       	vpsllw $0x3,%xmm7,%xmm0
    69e8:	c5 f9 f9 c7          	vpsubw %xmm7,%xmm0,%xmm0
    69ec:	c5 f9 6e f8          	vmovd  %eax,%xmm7
    69f0:	c5 f1 fc ce          	vpaddb %xmm6,%xmm1,%xmm1
    69f4:	c4 e2 79 79 ff       	vpbroadcastw %xmm7,%xmm7
    69f9:	c5 f9 71 f0 04       	vpsllw $0x4,%xmm0,%xmm0
    69fe:	c5 d9 d5 e7          	vpmullw %xmm7,%xmm4,%xmm4
    6a02:	c5 39 d5 c7          	vpmullw %xmm7,%xmm8,%xmm8
    6a06:	c5 f9 fd c4          	vpaddw %xmm4,%xmm0,%xmm0
    6a0a:	c5 d9 71 f3 02       	vpsllw $0x2,%xmm3,%xmm4
    6a0f:	c5 d9 fd db          	vpaddw %xmm3,%xmm4,%xmm3
    6a13:	c5 d9 71 f5 02       	vpsllw $0x2,%xmm5,%xmm4
    6a18:	c5 e1 71 f3 01       	vpsllw $0x1,%xmm3,%xmm3
    6a1d:	c5 d9 fd e5          	vpaddw %xmm5,%xmm4,%xmm4
    6a21:	c5 e9 f9 db          	vpsubw %xmm3,%xmm2,%xmm3
    6a25:	c5 d9 71 f4 01       	vpsllw $0x1,%xmm4,%xmm4
    6a2a:	c5 f9 fd c3          	vpaddw %xmm3,%xmm0,%xmm0
    6a2e:	c4 c1 61 71 f1 03    	vpsllw $0x3,%xmm9,%xmm3
    6a34:	c5 e9 f9 d4          	vpsubw %xmm4,%xmm2,%xmm2
    6a38:	c4 c1 61 f9 d9       	vpsubw %xmm9,%xmm3,%xmm3
    6a3d:	c5 f9 71 e0 08       	vpsraw $0x8,%xmm0,%xmm0
    6a42:	c5 f9 db 05 36 88 00 	vpand  0x8836(%rip),%xmm0,%xmm0        # f280 <__PRETTY_FUNCTION__.4+0xd>
    6a49:	00 
    6a4a:	c5 e1 71 f3 04       	vpsllw $0x4,%xmm3,%xmm3
    6a4f:	c4 c1 61 fd d8       	vpaddw %xmm8,%xmm3,%xmm3
    6a54:	c5 e1 fd d2          	vpaddw %xmm2,%xmm3,%xmm2
    6a58:	c5 e9 71 e2 08       	vpsraw $0x8,%xmm2,%xmm2
    6a5d:	c5 e9 db 15 1b 88 00 	vpand  0x881b(%rip),%xmm2,%xmm2        # f280 <__PRETTY_FUNCTION__.4+0xd>
    6a64:	00 
    6a65:	c5 f9 67 c2          	vpackuswb %xmm2,%xmm0,%xmm0
    6a69:	c5 f9 fc c6          	vpaddb %xmm6,%xmm0,%xmm0
    6a6d:	c5 f1 60 d0          	vpunpcklbw %xmm0,%xmm1,%xmm2
    6a71:	c5 f1 68 c8          	vpunpckhbw %xmm0,%xmm1,%xmm1
    6a75:	c5 fa 7f 12          	vmovdqu %xmm2,(%rdx)
    6a79:	c5 fa 7f 4a 10       	vmovdqu %xmm1,0x10(%rdx)
    6a7e:	8b 44 24 60          	mov    0x60(%rsp),%eax
    6a82:	8b 9c 24 c0 02 00 00 	mov    0x2c0(%rsp),%ebx
    6a89:	83 e0 f0             	and    $0xfffffff0,%eax
    6a8c:	8d 04 43             	lea    (%rbx,%rax,2),%eax
    6a8f:	89 84 24 c0 02 00 00 	mov    %eax,0x2c0(%rsp)
    6a96:	4c 63 8c 24 c0 02 00 	movslq 0x2c0(%rsp),%r9
    6a9d:	00 
    6a9e:	48 8b 44 24 a0       	mov    -0x60(%rsp),%rax
    6aa3:	44 89 bc 24 c8 02 00 	mov    %r15d,0x2c8(%rsp)
    6aaa:	00 
    6aab:	48 8b 5c 24 b8       	mov    -0x48(%rsp),%rbx
    6ab0:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
    6ab5:	4e 8d 14 8d 00 00 00 	lea    0x0(,%r9,4),%r10
    6abc:	00 
    6abd:	4c 01 d0             	add    %r10,%rax
    6ac0:	4c 01 d3             	add    %r10,%rbx
    6ac3:	49 89 c2             	mov    %rax,%r10
    6ac6:	48 8b 84 24 b0 02 00 	mov    0x2b0(%rsp),%rax
    6acd:	00 
    6ace:	4c 8d 1c 38          	lea    (%rax,%rdi,1),%r11
    6ad2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ad8:	0f b6 7b 01          	movzbl 0x1(%rbx),%edi
    6adc:	44 0f b6 43 02       	movzbl 0x2(%rbx),%r8d
    6ae1:	0f b6 03             	movzbl (%rbx),%eax
    6ae4:	44 69 e7 9d 00 00 00 	imul   $0x9d,%edi,%r12d
    6aeb:	41 6b d0 2f          	imul   $0x2f,%r8d,%edx
    6aef:	44 01 e2             	add    %r12d,%edx
    6af2:	41 89 c4             	mov    %eax,%r12d
    6af5:	41 c1 e4 04          	shl    $0x4,%r12d
    6af9:	42 8d 94 22 80 00 00 	lea    0x80(%rdx,%r12,1),%edx
    6b00:	00 
    6b01:	c1 fa 08             	sar    $0x8,%edx
    6b04:	83 c2 10             	add    $0x10,%edx
    6b07:	42 88 14 09          	mov    %dl,(%rcx,%r9,1)
    6b0b:	44 0f b6 6b 05       	movzbl 0x5(%rbx),%r13d
    6b10:	44 0f b6 63 06       	movzbl 0x6(%rbx),%r12d
    6b15:	44 0f b6 73 04       	movzbl 0x4(%rbx),%r14d
    6b1a:	41 69 d5 9d 00 00 00 	imul   $0x9d,%r13d,%edx
    6b21:	44 01 ef             	add    %r13d,%edi
    6b24:	45 6b fc 2f          	imul   $0x2f,%r12d,%r15d
    6b28:	45 01 e0             	add    %r12d,%r8d
    6b2b:	44 01 f0             	add    %r14d,%eax
    6b2e:	44 01 fa             	add    %r15d,%edx
    6b31:	45 89 f7             	mov    %r14d,%r15d
    6b34:	41 c1 e7 04          	shl    $0x4,%r15d
    6b38:	42 8d 94 3a 80 00 00 	lea    0x80(%rdx,%r15,1),%edx
    6b3f:	00 
    6b40:	c1 fa 08             	sar    $0x8,%edx
    6b43:	83 c2 10             	add    $0x10,%edx
    6b46:	42 88 54 09 01       	mov    %dl,0x1(%rcx,%r9,1)
    6b4b:	45 0f b6 6a 01       	movzbl 0x1(%r10),%r13d
    6b50:	41 0f b6 52 02       	movzbl 0x2(%r10),%edx
    6b55:	45 0f b6 32          	movzbl (%r10),%r14d
    6b59:	45 69 e5 9d 00 00 00 	imul   $0x9d,%r13d,%r12d
    6b60:	44 01 ef             	add    %r13d,%edi
    6b63:	44 6b fa 2f          	imul   $0x2f,%edx,%r15d
    6b67:	44 01 c2             	add    %r8d,%edx
    6b6a:	44 01 f0             	add    %r14d,%eax
    6b6d:	45 01 fc             	add    %r15d,%r12d
    6b70:	45 89 f7             	mov    %r14d,%r15d
    6b73:	41 c1 e7 04          	shl    $0x4,%r15d
    6b77:	47 8d a4 3c 80 00 00 	lea    0x80(%r12,%r15,1),%r12d
    6b7e:	00 
    6b7f:	41 c1 fc 08          	sar    $0x8,%r12d
    6b83:	41 83 c4 10          	add    $0x10,%r12d
    6b87:	46 88 24 0e          	mov    %r12b,(%rsi,%r9,1)
    6b8b:	45 0f b6 62 06       	movzbl 0x6(%r10),%r12d
    6b90:	45 0f b6 6a 05       	movzbl 0x5(%r10),%r13d
    6b95:	45 0f b6 72 04       	movzbl 0x4(%r10),%r14d
    6b9a:	45 6b fc 2f          	imul   $0x2f,%r12d,%r15d
    6b9e:	45 69 c5 9d 00 00 00 	imul   $0x9d,%r13d,%r8d
    6ba5:	44 01 f0             	add    %r14d,%eax
    6ba8:	c1 f8 02             	sar    $0x2,%eax
    6bab:	45 01 f8             	add    %r15d,%r8d
    6bae:	45 89 f7             	mov    %r14d,%r15d
    6bb1:	41 c1 e7 04          	shl    $0x4,%r15d
    6bb5:	47 8d 84 38 80 00 00 	lea    0x80(%r8,%r15,1),%r8d
    6bbc:	00 
    6bbd:	41 c1 f8 08          	sar    $0x8,%r8d
    6bc1:	41 83 c0 10          	add    $0x10,%r8d
    6bc5:	44 01 ef             	add    %r13d,%edi
    6bc8:	44 01 e2             	add    %r12d,%edx
    6bcb:	48 83 c3 08          	add    $0x8,%rbx
    6bcf:	c1 ff 02             	sar    $0x2,%edi
    6bd2:	c1 fa 02             	sar    $0x2,%edx
    6bd5:	46 88 44 0e 01       	mov    %r8b,0x1(%rsi,%r9,1)
    6bda:	49 83 c2 08          	add    $0x8,%r10
    6bde:	44 6b e7 aa          	imul   $0xffffffaa,%edi,%r12d
    6be2:	44 6b c2 e6          	imul   $0xffffffe6,%edx,%r8d
    6be6:	6b ff 9a             	imul   $0xffffff9a,%edi,%edi
    6be9:	6b d2 70             	imul   $0x70,%edx,%edx
    6bec:	45 01 e0             	add    %r12d,%r8d
    6bef:	44 6b e0 70          	imul   $0x70,%eax,%r12d
    6bf3:	6b c0 f6             	imul   $0xfffffff6,%eax,%eax
    6bf6:	01 fa                	add    %edi,%edx
    6bf8:	47 8d 84 20 80 00 00 	lea    0x80(%r8,%r12,1),%r8d
    6bff:	00 
    6c00:	8d 84 02 80 00 00 00 	lea    0x80(%rdx,%rax,1),%eax
    6c07:	41 c1 f8 08          	sar    $0x8,%r8d
    6c0b:	c1 f8 08             	sar    $0x8,%eax
    6c0e:	41 83 e8 80          	sub    $0xffffff80,%r8d
    6c12:	83 e8 80             	sub    $0xffffff80,%eax
    6c15:	47 88 04 0b          	mov    %r8b,(%r11,%r9,1)
    6c19:	43 88 44 0b 01       	mov    %al,0x1(%r11,%r9,1)
    6c1e:	49 83 c1 02          	add    $0x2,%r9
    6c22:	44 39 8c 24 c8 02 00 	cmp    %r9d,0x2c8(%rsp)
    6c29:	00 
    6c2a:	0f 8f a8 fe ff ff    	jg     6ad8 <convert_avx2_job+0x1628>
    6c30:	48 8b 84 24 b8 02 00 	mov    0x2b8(%rsp),%rax
    6c37:	00 
    6c38:	8b 40 34             	mov    0x34(%rax),%eax
    6c3b:	83 84 24 c4 02 00 00 	addl   $0x1,0x2c4(%rsp)
    6c42:	01 
    6c43:	8b b4 24 c4 02 00 00 	mov    0x2c4(%rsp),%esi
    6c4a:	83 44 24 64 02       	addl   $0x2,0x64(%rsp)
    6c4f:	48 83 84 24 a8 02 00 	addq   $0x1,0x2a8(%rsp)
    6c56:	00 01 
    6c58:	39 c6                	cmp    %eax,%esi
    6c5a:	0f 8c d0 e8 ff ff    	jl     5530 <convert_avx2_job+0x80>
    6c60:	c5 f8 77             	vzeroupper
    6c63:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    6c67:	5b                   	pop    %rbx
    6c68:	41 5c                	pop    %r12
    6c6a:	41 5d                	pop    %r13
    6c6c:	41 5e                	pop    %r14
    6c6e:	41 5f                	pop    %r15
    6c70:	5d                   	pop    %rbp
    6c71:	c3                   	ret
    6c72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6c78:	48 63 c7             	movslq %edi,%rax
    6c7b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    6c82:	00 
    6c83:	4c 8b 84 24 80 00 00 	mov    0x80(%rsp),%r8
    6c8a:	00 
    6c8b:	48 8b 44 24 a0       	mov    -0x60(%rsp),%rax
    6c90:	44 89 bc 24 c8 02 00 	mov    %r15d,0x2c8(%rsp)
    6c97:	00 
    6c98:	4c 8b 54 24 b8       	mov    -0x48(%rsp),%r10
    6c9d:	48 8b 5c 24 78       	mov    0x78(%rsp),%rbx
    6ca2:	4e 8d 0c 85 00 00 00 	lea    0x0(,%r8,4),%r9
    6ca9:	00 
    6caa:	4c 01 c8             	add    %r9,%rax
    6cad:	4d 01 ca             	add    %r9,%r10
    6cb0:	49 89 c1             	mov    %rax,%r9
    6cb3:	48 8b 84 24 b0 02 00 	mov    0x2b0(%rsp),%rax
    6cba:	00 
    6cbb:	4c 8d 1c 18          	lea    (%rax,%rbx,1),%r11
    6cbf:	90                   	nop
    6cc0:	41 0f b6 7a 01       	movzbl 0x1(%r10),%edi
    6cc5:	41 0f b6 5a 02       	movzbl 0x2(%r10),%ebx
    6cca:	41 0f b6 02          	movzbl (%r10),%eax
    6cce:	44 69 e7 9d 00 00 00 	imul   $0x9d,%edi,%r12d
    6cd5:	6b d3 2f             	imul   $0x2f,%ebx,%edx
    6cd8:	44 01 e2             	add    %r12d,%edx
    6cdb:	41 89 c4             	mov    %eax,%r12d
    6cde:	41 c1 e4 04          	shl    $0x4,%r12d
    6ce2:	42 8d 94 22 80 00 00 	lea    0x80(%rdx,%r12,1),%edx
    6ce9:	00 
    6cea:	c1 fa 08             	sar    $0x8,%edx
    6ced:	83 c2 10             	add    $0x10,%edx
    6cf0:	42 88 14 01          	mov    %dl,(%rcx,%r8,1)
    6cf4:	45 0f b6 6a 05       	movzbl 0x5(%r10),%r13d
    6cf9:	45 0f b6 62 06       	movzbl 0x6(%r10),%r12d
    6cfe:	45 0f b6 72 04       	movzbl 0x4(%r10),%r14d
    6d03:	41 69 d5 9d 00 00 00 	imul   $0x9d,%r13d,%edx
    6d0a:	44 01 ef             	add    %r13d,%edi
    6d0d:	45 6b fc 2f          	imul   $0x2f,%r12d,%r15d
    6d11:	44 01 e3             	add    %r12d,%ebx
    6d14:	44 01 f0             	add    %r14d,%eax
    6d17:	44 01 fa             	add    %r15d,%edx
    6d1a:	45 89 f7             	mov    %r14d,%r15d
    6d1d:	41 c1 e7 04          	shl    $0x4,%r15d
    6d21:	42 8d 94 3a 80 00 00 	lea    0x80(%rdx,%r15,1),%edx
    6d28:	00 
    6d29:	c1 fa 08             	sar    $0x8,%edx
    6d2c:	83 c2 10             	add    $0x10,%edx
    6d2f:	42 88 54 01 01       	mov    %dl,0x1(%rcx,%r8,1)
    6d34:	45 0f b6 69 01       	movzbl 0x1(%r9),%r13d
    6d39:	41 0f b6 51 02       	movzbl 0x2(%r9),%edx
    6d3e:	45 0f b6 31          	movzbl (%r9),%r14d
    6d42:	45 69 e5 9d 00 00 00 	imul   $0x9d,%r13d,%r12d
    6d49:	44 01 ef             	add    %r13d,%edi
    6d4c:	44 6b fa 2f          	imul   $0x2f,%edx,%r15d
    6d50:	01 da                	add    %ebx,%edx
    6d52:	44 01 f0             	add    %r14d,%eax
    6d55:	45 01 fc             	add    %r15d,%r12d
    6d58:	45 89 f7             	mov    %r14d,%r15d
    6d5b:	41 c1 e7 04          	shl    $0x4,%r15d
    6d5f:	47 8d a4 3c 80 00 00 	lea    0x80(%r12,%r15,1),%r12d
    6d66:	00 
    6d67:	41 c1 fc 08          	sar    $0x8,%r12d
    6d6b:	41 83 c4 10          	add    $0x10,%r12d
    6d6f:	46 88 24 06          	mov    %r12b,(%rsi,%r8,1)
    6d73:	45 0f b6 61 06       	movzbl 0x6(%r9),%r12d
    6d78:	45 0f b6 69 05       	movzbl 0x5(%r9),%r13d
    6d7d:	45 0f b6 71 04       	movzbl 0x4(%r9),%r14d
    6d82:	45 6b fc 2f          	imul   $0x2f,%r12d,%r15d
    6d86:	41 69 dd 9d 00 00 00 	imul   $0x9d,%r13d,%ebx
    6d8d:	44 01 f0             	add    %r14d,%eax
    6d90:	c1 f8 02             	sar    $0x2,%eax
    6d93:	44 01 fb             	add    %r15d,%ebx
    6d96:	45 89 f7             	mov    %r14d,%r15d
    6d99:	41 c1 e7 04          	shl    $0x4,%r15d
    6d9d:	42 8d 9c 3b 80 00 00 	lea    0x80(%rbx,%r15,1),%ebx
    6da4:	00 
    6da5:	c1 fb 08             	sar    $0x8,%ebx
    6da8:	83 c3 10             	add    $0x10,%ebx
    6dab:	44 01 ef             	add    %r13d,%edi
    6dae:	44 01 e2             	add    %r12d,%edx
    6db1:	49 83 c2 08          	add    $0x8,%r10
    6db5:	c1 ff 02             	sar    $0x2,%edi
    6db8:	c1 fa 02             	sar    $0x2,%edx
    6dbb:	42 88 5c 06 01       	mov    %bl,0x1(%rsi,%r8,1)
    6dc0:	49 83 c1 08          	add    $0x8,%r9
    6dc4:	44 6b e7 aa          	imul   $0xffffffaa,%edi,%r12d
    6dc8:	6b da e6             	imul   $0xffffffe6,%edx,%ebx
    6dcb:	6b ff 9a             	imul   $0xffffff9a,%edi,%edi
    6dce:	6b d2 70             	imul   $0x70,%edx,%edx
    6dd1:	44 01 e3             	add    %r12d,%ebx
    6dd4:	44 6b e0 70          	imul   $0x70,%eax,%r12d
    6dd8:	6b c0 f6             	imul   $0xfffffff6,%eax,%eax
    6ddb:	01 fa                	add    %edi,%edx
    6ddd:	42 8d 9c 23 80 00 00 	lea    0x80(%rbx,%r12,1),%ebx
    6de4:	00 
    6de5:	8d 84 02 80 00 00 00 	lea    0x80(%rdx,%rax,1),%eax
    6dec:	c1 fb 08             	sar    $0x8,%ebx
    6def:	c1 f8 08             	sar    $0x8,%eax
    6df2:	83 eb 80             	sub    $0xffffff80,%ebx
    6df5:	83 e8 80             	sub    $0xffffff80,%eax
    6df8:	43 88 1c 03          	mov    %bl,(%r11,%r8,1)
    6dfc:	43 88 44 03 01       	mov    %al,0x1(%r11,%r8,1)
    6e01:	49 83 c0 02          	add    $0x2,%r8
    6e05:	44 39 84 24 c8 02 00 	cmp    %r8d,0x2c8(%rsp)
    6e0c:	00 
    6e0d:	0f 8f ad fe ff ff    	jg     6cc0 <convert_avx2_job+0x1810>
    6e13:	e9 18 fe ff ff       	jmp    6c30 <convert_avx2_job+0x1780>
    6e18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6e1f:	00 
    6e20:	c7 84 24 c0 02 00 00 	movl   $0x0,0x2c0(%rsp)
    6e27:	00 00 00 00 
    6e2b:	45 89 c7             	mov    %r8d,%r15d
    6e2e:	e9 62 e7 ff ff       	jmp    5595 <convert_avx2_job+0xe5>
    6e33:	31 d2                	xor    %edx,%edx
    6e35:	e9 7c f3 ff ff       	jmp    61b6 <convert_avx2_job+0xd06>

Disassembly of section .fini:
