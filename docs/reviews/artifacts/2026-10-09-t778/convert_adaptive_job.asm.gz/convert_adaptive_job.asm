
/tmp/blent-adaptive-20261009/t778-after:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

0000000000009f50 <convert_adaptive_job>:
    9f50:	f3 0f 1e fa          	endbr64
    9f54:	41 57                	push   %r15
    9f56:	48 89 f8             	mov    %rdi,%rax
    9f59:	41 56                	push   %r14
    9f5b:	41 55                	push   %r13
    9f5d:	41 54                	push   %r12
    9f5f:	55                   	push   %rbp
    9f60:	53                   	push   %rbx
    9f61:	48 81 ec 20 01 00 00 	sub    $0x120,%rsp
    9f68:	44 8b 7f 2c          	mov    0x2c(%rdi),%r15d
    9f6c:	8b 5f 30             	mov    0x30(%rdi),%ebx
    9f6f:	48 89 7c 24 e8       	mov    %rdi,-0x18(%rsp)
    9f74:	8b 4f 34             	mov    0x34(%rdi),%ecx
    9f77:	41 83 ff 03          	cmp    $0x3,%r15d
    9f7b:	0f 84 fe 07 00 00    	je     a77f <convert_adaptive_job+0x82f>
    9f81:	0f 8f 7e 04 00 00    	jg     a405 <convert_adaptive_job+0x4b5>
    9f87:	41 83 ff 01          	cmp    $0x1,%r15d
    9f8b:	0f 84 5b 12 00 00    	je     b1ec <convert_adaptive_job+0x129c>
    9f91:	41 83 ff 02          	cmp    $0x2,%r15d
    9f95:	0f 85 84 0a 00 00    	jne    aa1f <convert_adaptive_job+0xacf>
    9f9b:	89 de                	mov    %ebx,%esi
    9f9d:	89 d8                	mov    %ebx,%eax
    9f9f:	39 cb                	cmp    %ecx,%ebx
    9fa1:	0f 8d c6 07 00 00    	jge    a76d <convert_adaptive_job+0x81d>
    9fa7:	48 63 db             	movslq %ebx,%rbx
    9faa:	4c 8b 6c 24 e8       	mov    -0x18(%rsp),%r13
    9faf:	c1 e0 02             	shl    $0x2,%eax
    9fb2:	48 89 5c 24 b0       	mov    %rbx,-0x50(%rsp)
    9fb7:	49 8b 7d 38          	mov    0x38(%r13),%rdi
    9fbb:	48 85 ff             	test   %rdi,%rdi
    9fbe:	74 1a                	je     9fda <convert_adaptive_job+0x8a>
    9fc0:	89 f2                	mov    %esi,%edx
    9fc2:	c1 fa 03             	sar    $0x3,%edx
    9fc5:	48 63 d2             	movslq %edx,%rdx
    9fc8:	0f b6 3c 17          	movzbl (%rdi,%rdx,1),%edi
    9fcc:	89 f2                	mov    %esi,%edx
    9fce:	83 e2 07             	and    $0x7,%edx
    9fd1:	0f a3 d7             	bt     %edx,%edi
    9fd4:	0f 83 06 33 00 00    	jae    d2e0 <convert_adaptive_job+0x3390>
    9fda:	49 8b 55 40          	mov    0x40(%r13),%rdx
    9fde:	49 63 5d 24          	movslq 0x24(%r13),%rbx
    9fe2:	48 85 d2             	test   %rdx,%rdx
    9fe5:	0f 84 0e 33 00 00    	je     d2f9 <convert_adaptive_job+0x33a9>
    9feb:	48 8b 4c 24 b0       	mov    -0x50(%rsp),%rcx
    9ff0:	48 c1 e1 04          	shl    $0x4,%rcx
    9ff4:	48 01 ca             	add    %rcx,%rdx
    9ff7:	8b 4a 0c             	mov    0xc(%rdx),%ecx
    9ffa:	8b 7a 08             	mov    0x8(%rdx),%edi
    9ffd:	44 8b 12             	mov    (%rdx),%r10d
    a000:	44 8b 7a 04          	mov    0x4(%rdx),%r15d
    a004:	89 4c 24 c0          	mov    %ecx,-0x40(%rsp)
    a008:	29 f9                	sub    %edi,%ecx
    a00a:	83 f9 7f             	cmp    $0x7f,%ecx
    a00d:	0f 8e fd 32 00 00    	jle    d310 <convert_adaptive_job+0x33c0>
    a013:	45 89 f8             	mov    %r15d,%r8d
    a016:	45 29 d0             	sub    %r10d,%r8d
    a019:	44 89 c2             	mov    %r8d,%edx
    a01c:	c1 ea 1f             	shr    $0x1f,%edx
    a01f:	44 01 c2             	add    %r8d,%edx
    a022:	d1 fa                	sar    $1,%edx
    a024:	39 d1                	cmp    %edx,%ecx
    a026:	0f 9d c2             	setge  %dl
    a029:	0f b6 d2             	movzbl %dl,%edx
    a02c:	8d 0c 36             	lea    (%rsi,%rsi,1),%ecx
    a02f:	85 d2                	test   %edx,%edx
    a031:	c7 44 24 e8 00 00 00 	movl   $0x0,-0x18(%rsp)
    a038:	00 
    a039:	41 89 d0             	mov    %edx,%r8d
    a03c:	48 63 c9             	movslq %ecx,%rcx
    a03f:	89 74 24 08          	mov    %esi,0x8(%rsp)
    a043:	41 0f 44 ff          	cmove  %r15d,%edi
    a047:	48 89 4c 24 c8       	mov    %rcx,-0x38(%rsp)
    a04c:	48 63 c8             	movslq %eax,%rcx
    a04f:	48 89 4c 24 d8       	mov    %rcx,-0x28(%rsp)
    a054:	8d 48 01             	lea    0x1(%rax),%ecx
    a057:	48 63 c9             	movslq %ecx,%rcx
    a05a:	48 89 4c 24 f0       	mov    %rcx,-0x10(%rsp)
    a05f:	8d 48 02             	lea    0x2(%rax),%ecx
    a062:	48 63 c9             	movslq %ecx,%rcx
    a065:	48 89 4c 24 f8       	mov    %rcx,-0x8(%rsp)
    a06a:	8d 48 03             	lea    0x3(%rax),%ecx
    a06d:	48 63 c9             	movslq %ecx,%rcx
    a070:	48 89 0c 24          	mov    %rcx,(%rsp)
    a074:	4c 8b 5c 24 c8       	mov    -0x38(%rsp),%r11
    a079:	4c 8b 64 24 b0       	mov    -0x50(%rsp),%r12
    a07e:	49 63 75 20          	movslq 0x20(%r13),%rsi
    a082:	4d 8b 75 10          	mov    0x10(%r13),%r14
    a086:	4c 0f af db          	imul   %rbx,%r11
    a08a:	4d 03 5d 08          	add    0x8(%r13),%r11
    a08e:	4c 0f af e3          	imul   %rbx,%r12
    a092:	41 39 fa             	cmp    %edi,%r10d
    a095:	0f 8d 41 03 00 00    	jge    a3dc <convert_adaptive_job+0x48c>
    a09b:	48 8b 54 24 d8       	mov    -0x28(%rsp),%rdx
    a0a0:	48 8b 4c 24 f8       	mov    -0x8(%rsp),%rcx
    a0a5:	4d 01 e6             	add    %r12,%r14
    a0a8:	4c 01 db             	add    %r11,%rbx
    a0ab:	4c 8b 0c 24          	mov    (%rsp),%r9
    a0af:	48 8b 6c 24 f0       	mov    -0x10(%rsp),%rbp
    a0b4:	4c 89 74 24 b8       	mov    %r14,-0x48(%rsp)
    a0b9:	48 0f af d6          	imul   %rsi,%rdx
    a0bd:	44 89 7c 24 10       	mov    %r15d,0x10(%rsp)
    a0c2:	48 0f af ce          	imul   %rsi,%rcx
    a0c6:	44 89 44 24 18       	mov    %r8d,0x18(%rsp)
    a0cb:	48 0f af ee          	imul   %rsi,%rbp
    a0cf:	89 44 24 20          	mov    %eax,0x20(%rsp)
    a0d3:	49 0f af f1          	imul   %r9,%rsi
    a0d7:	47 8d 0c 12          	lea    (%r10,%r10,1),%r9d
    a0db:	48 29 d1             	sub    %rdx,%rcx
    a0de:	4d 63 c9             	movslq %r9d,%r9
    a0e1:	48 89 4c 24 98       	mov    %rcx,-0x68(%rsp)
    a0e6:	48 29 d5             	sub    %rdx,%rbp
    a0e9:	49 c1 e1 02          	shl    $0x2,%r9
    a0ed:	48 89 74 24 90       	mov    %rsi,-0x70(%rsp)
    a0f2:	48 8b 4c 24 90       	mov    -0x70(%rsp),%rcx
    a0f7:	49 63 f2             	movslq %r10d,%rsi
    a0fa:	4e 8d 14 0a          	lea    (%rdx,%r9,1),%r10
    a0fe:	48 89 6c 24 a8       	mov    %rbp,-0x58(%rsp)
    a103:	4e 8d 4c 0a 08       	lea    0x8(%rdx,%r9,1),%r9
    a108:	48 29 d1             	sub    %rdx,%rcx
    a10b:	48 89 4c 24 90       	mov    %rcx,-0x70(%rsp)
    a110:	4d 8b 45 00          	mov    0x0(%r13),%r8
    a114:	4b 8d 14 10          	lea    (%r8,%r10,1),%rdx
    a118:	0f b6 42 04          	movzbl 0x4(%rdx),%eax
    a11c:	0f b6 2a             	movzbl (%rdx),%ebp
    a11f:	0f b6 4a 01          	movzbl 0x1(%rdx),%ecx
    a123:	01 c5                	add    %eax,%ebp
    a125:	0f b6 42 05          	movzbl 0x5(%rdx),%eax
    a129:	01 c1                	add    %eax,%ecx
    a12b:	0f b6 42 02          	movzbl 0x2(%rdx),%eax
    a12f:	0f b6 52 06          	movzbl 0x6(%rdx),%edx
    a133:	01 d0                	add    %edx,%eax
    a135:	48 8b 54 24 a8       	mov    -0x58(%rsp),%rdx
    a13a:	4c 01 d2             	add    %r10,%rdx
    a13d:	4c 01 c2             	add    %r8,%rdx
    a140:	44 0f b6 02          	movzbl (%rdx),%r8d
    a144:	41 01 e8             	add    %ebp,%r8d
    a147:	0f b6 6a 01          	movzbl 0x1(%rdx),%ebp
    a14b:	01 cd                	add    %ecx,%ebp
    a14d:	0f b6 4a 02          	movzbl 0x2(%rdx),%ecx
    a151:	01 c1                	add    %eax,%ecx
    a153:	0f b6 42 04          	movzbl 0x4(%rdx),%eax
    a157:	41 01 c0             	add    %eax,%r8d
    a15a:	0f b6 42 05          	movzbl 0x5(%rdx),%eax
    a15e:	41 c1 f8 02          	sar    $0x2,%r8d
    a162:	01 e8                	add    %ebp,%eax
    a164:	41 89 c4             	mov    %eax,%r12d
    a167:	0f b6 42 06          	movzbl 0x6(%rdx),%eax
    a16b:	41 c1 fc 02          	sar    $0x2,%r12d
    a16f:	01 c1                	add    %eax,%ecx
    a171:	41 69 c4 9d 00 00 00 	imul   $0x9d,%r12d,%eax
    a178:	c1 f9 02             	sar    $0x2,%ecx
    a17b:	6b d1 2f             	imul   $0x2f,%ecx,%edx
    a17e:	01 d0                	add    %edx,%eax
    a180:	44 89 c2             	mov    %r8d,%edx
    a183:	c1 e2 04             	shl    $0x4,%edx
    a186:	8d 84 10 80 00 00 00 	lea    0x80(%rax,%rdx,1),%eax
    a18d:	c1 f8 08             	sar    $0x8,%eax
    a190:	83 c0 10             	add    $0x10,%eax
    a193:	41 88 04 33          	mov    %al,(%r11,%rsi,1)
    a197:	4d 8b 75 00          	mov    0x0(%r13),%r14
    a19b:	4b 8d 04 0e          	lea    (%r14,%r9,1),%rax
    a19f:	0f b6 50 04          	movzbl 0x4(%rax),%edx
    a1a3:	44 0f b6 38          	movzbl (%rax),%r15d
    a1a7:	0f b6 68 05          	movzbl 0x5(%rax),%ebp
    a1ab:	41 01 d7             	add    %edx,%r15d
    a1ae:	0f b6 50 01          	movzbl 0x1(%rax),%edx
    a1b2:	01 ea                	add    %ebp,%edx
    a1b4:	0f b6 68 02          	movzbl 0x2(%rax),%ebp
    a1b8:	0f b6 40 06          	movzbl 0x6(%rax),%eax
    a1bc:	01 c5                	add    %eax,%ebp
    a1be:	48 8b 44 24 a8       	mov    -0x58(%rsp),%rax
    a1c3:	4c 01 c8             	add    %r9,%rax
    a1c6:	4c 01 f0             	add    %r14,%rax
    a1c9:	44 0f b6 30          	movzbl (%rax),%r14d
    a1cd:	45 01 fe             	add    %r15d,%r14d
    a1d0:	44 0f b6 78 01       	movzbl 0x1(%rax),%r15d
    a1d5:	41 01 d7             	add    %edx,%r15d
    a1d8:	0f b6 50 02          	movzbl 0x2(%rax),%edx
    a1dc:	01 ea                	add    %ebp,%edx
    a1de:	0f b6 68 04          	movzbl 0x4(%rax),%ebp
    a1e2:	41 01 ee             	add    %ebp,%r14d
    a1e5:	0f b6 68 05          	movzbl 0x5(%rax),%ebp
    a1e9:	0f b6 40 06          	movzbl 0x6(%rax),%eax
    a1ed:	41 c1 fe 02          	sar    $0x2,%r14d
    a1f1:	44 01 fd             	add    %r15d,%ebp
    a1f4:	c1 fd 02             	sar    $0x2,%ebp
    a1f7:	01 c2                	add    %eax,%edx
    a1f9:	45 01 f0             	add    %r14d,%r8d
    a1fc:	c1 fa 02             	sar    $0x2,%edx
    a1ff:	69 c5 9d 00 00 00    	imul   $0x9d,%ebp,%eax
    a205:	44 6b fa 2f          	imul   $0x2f,%edx,%r15d
    a209:	01 d1                	add    %edx,%ecx
    a20b:	48 8b 54 24 98       	mov    -0x68(%rsp),%rdx
    a210:	4c 01 d2             	add    %r10,%rdx
    a213:	44 01 f8             	add    %r15d,%eax
    a216:	45 89 f7             	mov    %r14d,%r15d
    a219:	41 c1 e7 04          	shl    $0x4,%r15d
    a21d:	42 8d 84 38 80 00 00 	lea    0x80(%rax,%r15,1),%eax
    a224:	00 
    a225:	c1 f8 08             	sar    $0x8,%eax
    a228:	83 c0 10             	add    $0x10,%eax
    a22b:	41 88 44 33 01       	mov    %al,0x1(%r11,%rsi,1)
    a230:	41 8d 04 2c          	lea    (%r12,%rbp,1),%eax
    a234:	4d 8b 65 00          	mov    0x0(%r13),%r12
    a238:	4c 01 e2             	add    %r12,%rdx
    a23b:	44 0f b6 3a          	movzbl (%rdx),%r15d
    a23f:	0f b6 6a 04          	movzbl 0x4(%rdx),%ebp
    a243:	44 0f b6 72 01       	movzbl 0x1(%rdx),%r14d
    a248:	41 01 ef             	add    %ebp,%r15d
    a24b:	0f b6 6a 05          	movzbl 0x5(%rdx),%ebp
    a24f:	41 01 ee             	add    %ebp,%r14d
    a252:	0f b6 6a 02          	movzbl 0x2(%rdx),%ebp
    a256:	0f b6 52 06          	movzbl 0x6(%rdx),%edx
    a25a:	01 d5                	add    %edx,%ebp
    a25c:	48 8b 54 24 90       	mov    -0x70(%rsp),%rdx
    a261:	4c 01 d2             	add    %r10,%rdx
    a264:	4c 01 e2             	add    %r12,%rdx
    a267:	44 0f b6 22          	movzbl (%rdx),%r12d
    a26b:	45 01 fc             	add    %r15d,%r12d
    a26e:	44 0f b6 7a 01       	movzbl 0x1(%rdx),%r15d
    a273:	45 01 f7             	add    %r14d,%r15d
    a276:	44 0f b6 72 02       	movzbl 0x2(%rdx),%r14d
    a27b:	41 01 ee             	add    %ebp,%r14d
    a27e:	0f b6 6a 04          	movzbl 0x4(%rdx),%ebp
    a282:	41 01 ec             	add    %ebp,%r12d
    a285:	0f b6 6a 05          	movzbl 0x5(%rdx),%ebp
    a289:	0f b6 52 06          	movzbl 0x6(%rdx),%edx
    a28d:	41 c1 fc 02          	sar    $0x2,%r12d
    a291:	44 01 fd             	add    %r15d,%ebp
    a294:	44 01 f2             	add    %r14d,%edx
    a297:	c1 fd 02             	sar    $0x2,%ebp
    a29a:	c1 fa 02             	sar    $0x2,%edx
    a29d:	44 6b fa 2f          	imul   $0x2f,%edx,%r15d
    a2a1:	44 69 f5 9d 00 00 00 	imul   $0x9d,%ebp,%r14d
    a2a8:	45 01 fe             	add    %r15d,%r14d
    a2ab:	45 89 e7             	mov    %r12d,%r15d
    a2ae:	41 c1 e7 04          	shl    $0x4,%r15d
    a2b2:	47 8d b4 3e 80 00 00 	lea    0x80(%r14,%r15,1),%r14d
    a2b9:	00 
    a2ba:	41 c1 fe 08          	sar    $0x8,%r14d
    a2be:	41 83 c6 10          	add    $0x10,%r14d
    a2c2:	45 01 e0             	add    %r12d,%r8d
    a2c5:	01 d1                	add    %edx,%ecx
    a2c7:	48 8b 54 24 98       	mov    -0x68(%rsp),%rdx
    a2cc:	44 88 34 33          	mov    %r14b,(%rbx,%rsi,1)
    a2d0:	4d 8b 65 00          	mov    0x0(%r13),%r12
    a2d4:	01 e8                	add    %ebp,%eax
    a2d6:	4c 01 ca             	add    %r9,%rdx
    a2d9:	4c 01 e2             	add    %r12,%rdx
    a2dc:	0f b6 6a 04          	movzbl 0x4(%rdx),%ebp
    a2e0:	44 0f b6 3a          	movzbl (%rdx),%r15d
    a2e4:	44 0f b6 72 01       	movzbl 0x1(%rdx),%r14d
    a2e9:	41 01 ef             	add    %ebp,%r15d
    a2ec:	0f b6 6a 05          	movzbl 0x5(%rdx),%ebp
    a2f0:	41 01 ee             	add    %ebp,%r14d
    a2f3:	0f b6 6a 02          	movzbl 0x2(%rdx),%ebp
    a2f7:	0f b6 52 06          	movzbl 0x6(%rdx),%edx
    a2fb:	01 d5                	add    %edx,%ebp
    a2fd:	48 8b 54 24 90       	mov    -0x70(%rsp),%rdx
    a302:	4c 01 ca             	add    %r9,%rdx
    a305:	4c 01 e2             	add    %r12,%rdx
    a308:	44 0f b6 22          	movzbl (%rdx),%r12d
    a30c:	45 01 fc             	add    %r15d,%r12d
    a30f:	44 0f b6 7a 01       	movzbl 0x1(%rdx),%r15d
    a314:	45 01 f7             	add    %r14d,%r15d
    a317:	44 0f b6 72 02       	movzbl 0x2(%rdx),%r14d
    a31c:	41 01 ee             	add    %ebp,%r14d
    a31f:	0f b6 6a 04          	movzbl 0x4(%rdx),%ebp
    a323:	41 01 ec             	add    %ebp,%r12d
    a326:	0f b6 6a 05          	movzbl 0x5(%rdx),%ebp
    a32a:	0f b6 52 06          	movzbl 0x6(%rdx),%edx
    a32e:	41 c1 fc 02          	sar    $0x2,%r12d
    a332:	44 01 fd             	add    %r15d,%ebp
    a335:	44 01 f2             	add    %r14d,%edx
    a338:	45 01 e0             	add    %r12d,%r8d
    a33b:	c1 fd 02             	sar    $0x2,%ebp
    a33e:	c1 fa 02             	sar    $0x2,%edx
    a341:	44 6b fa 2f          	imul   $0x2f,%edx,%r15d
    a345:	01 e8                	add    %ebp,%eax
    a347:	01 ca                	add    %ecx,%edx
    a349:	41 c1 f8 02          	sar    $0x2,%r8d
    a34d:	44 69 f5 9d 00 00 00 	imul   $0x9d,%ebp,%r14d
    a354:	c1 fa 02             	sar    $0x2,%edx
    a357:	c1 f8 02             	sar    $0x2,%eax
    a35a:	6b ea e6             	imul   $0xffffffe6,%edx,%ebp
    a35d:	45 01 fe             	add    %r15d,%r14d
    a360:	45 89 e7             	mov    %r12d,%r15d
    a363:	41 c1 e7 04          	shl    $0x4,%r15d
    a367:	47 8d b4 3e 80 00 00 	lea    0x80(%r14,%r15,1),%r14d
    a36e:	00 
    a36f:	41 c1 fe 08          	sar    $0x8,%r14d
    a373:	41 83 c6 10          	add    $0x10,%r14d
    a377:	6b c8 aa             	imul   $0xffffffaa,%eax,%ecx
    a37a:	49 83 c2 10          	add    $0x10,%r10
    a37e:	49 83 c1 10          	add    $0x10,%r9
    a382:	6b d2 70             	imul   $0x70,%edx,%edx
    a385:	44 88 74 33 01       	mov    %r14b,0x1(%rbx,%rsi,1)
    a38a:	4c 8b 74 24 b8       	mov    -0x48(%rsp),%r14
    a38f:	6b c0 9a             	imul   $0xffffff9a,%eax,%eax
    a392:	01 e9                	add    %ebp,%ecx
    a394:	41 6b e8 70          	imul   $0x70,%r8d,%ebp
    a398:	45 6b c0 f6          	imul   $0xfffffff6,%r8d,%r8d
    a39c:	01 d0                	add    %edx,%eax
    a39e:	8d 8c 29 80 00 00 00 	lea    0x80(%rcx,%rbp,1),%ecx
    a3a5:	42 8d 84 00 80 00 00 	lea    0x80(%rax,%r8,1),%eax
    a3ac:	00 
    a3ad:	c1 f9 08             	sar    $0x8,%ecx
    a3b0:	c1 f8 08             	sar    $0x8,%eax
    a3b3:	83 e9 80             	sub    $0xffffff80,%ecx
    a3b6:	83 e8 80             	sub    $0xffffff80,%eax
    a3b9:	41 88 0c 36          	mov    %cl,(%r14,%rsi,1)
    a3bd:	41 88 44 36 01       	mov    %al,0x1(%r14,%rsi,1)
    a3c2:	48 83 c6 02          	add    $0x2,%rsi
    a3c6:	39 f7                	cmp    %esi,%edi
    a3c8:	0f 8f 42 fd ff ff    	jg     a110 <convert_adaptive_job+0x1c0>
    a3ce:	44 8b 7c 24 10       	mov    0x10(%rsp),%r15d
    a3d3:	44 8b 44 24 18       	mov    0x18(%rsp),%r8d
    a3d8:	8b 44 24 20          	mov    0x20(%rsp),%eax
    a3dc:	8b 54 24 e8          	mov    -0x18(%rsp),%edx
    a3e0:	83 c2 01             	add    $0x1,%edx
    a3e3:	44 39 c2             	cmp    %r8d,%edx
    a3e6:	0f 8f ec 2e 00 00    	jg     d2d8 <convert_adaptive_job+0x3388>
    a3ec:	c7 44 24 e8 01 00 00 	movl   $0x1,-0x18(%rsp)
    a3f3:	00 
    a3f4:	49 63 5d 24          	movslq 0x24(%r13),%rbx
    a3f8:	44 89 ff             	mov    %r15d,%edi
    a3fb:	44 8b 54 24 c0       	mov    -0x40(%rsp),%r10d
    a400:	e9 6f fc ff ff       	jmp    a074 <convert_adaptive_job+0x124>
    a405:	41 83 ff 04          	cmp    $0x4,%r15d
    a409:	0f 85 10 06 00 00    	jne    aa1f <convert_adaptive_job+0xacf>
    a40f:	41 89 d8             	mov    %ebx,%r8d
    a412:	39 cb                	cmp    %ecx,%ebx
    a414:	0f 8d 53 03 00 00    	jge    a76d <convert_adaptive_job+0x81d>
    a41a:	48 63 db             	movslq %ebx,%rbx
    a41d:	49 89 ff             	mov    %rdi,%r15
    a420:	48 89 da             	mov    %rbx,%rdx
    a423:	49 8b 77 38          	mov    0x38(%r15),%rsi
    a427:	48 85 f6             	test   %rsi,%rsi
    a42a:	74 1b                	je     a447 <convert_adaptive_job+0x4f7>
    a42c:	44 89 c0             	mov    %r8d,%eax
    a42f:	c1 f8 03             	sar    $0x3,%eax
    a432:	48 98                	cltq
    a434:	0f b6 34 06          	movzbl (%rsi,%rax,1),%esi
    a438:	44 89 c0             	mov    %r8d,%eax
    a43b:	83 e0 07             	and    $0x7,%eax
    a43e:	0f a3 c6             	bt     %eax,%esi
    a441:	0f 83 15 03 00 00    	jae    a75c <convert_adaptive_job+0x80c>
    a447:	49 8b 77 40          	mov    0x40(%r15),%rsi
    a44b:	41 8b 5f 24          	mov    0x24(%r15),%ebx
    a44f:	48 85 f6             	test   %rsi,%rsi
    a452:	0f 84 f9 29 00 00    	je     ce51 <convert_adaptive_job+0x2f01>
    a458:	48 89 d0             	mov    %rdx,%rax
    a45b:	48 c1 e0 04          	shl    $0x4,%rax
    a45f:	48 01 c6             	add    %rax,%rsi
    a462:	44 8b 66 0c          	mov    0xc(%rsi),%r12d
    a466:	8b 46 08             	mov    0x8(%rsi),%eax
    a469:	48 63 3e             	movslq (%rsi),%rdi
    a46c:	8b 4e 04             	mov    0x4(%rsi),%ecx
    a46f:	45 89 e2             	mov    %r12d,%r10d
    a472:	41 29 c2             	sub    %eax,%r10d
    a475:	41 83 fa 7f          	cmp    $0x7f,%r10d
    a479:	0f 8e d9 29 00 00    	jle    ce58 <convert_adaptive_job+0x2f08>
    a47f:	41 89 cb             	mov    %ecx,%r11d
    a482:	31 ed                	xor    %ebp,%ebp
    a484:	43 8d 34 00          	lea    (%r8,%r8,1),%esi
    a488:	41 29 fb             	sub    %edi,%r11d
    a48b:	89 74 24 98          	mov    %esi,-0x68(%rsp)
    a48f:	48 63 f6             	movslq %esi,%rsi
    a492:	45 89 d9             	mov    %r11d,%r9d
    a495:	41 c1 e9 1f          	shr    $0x1f,%r9d
    a499:	45 01 d9             	add    %r11d,%r9d
    a49c:	41 d1 f9             	sar    $1,%r9d
    a49f:	45 39 ca             	cmp    %r9d,%r10d
    a4a2:	0f 4c c1             	cmovl  %ecx,%eax
    a4a5:	40 0f 9d c5          	setge  %bpl
    a4a9:	44 89 44 24 c8       	mov    %r8d,-0x38(%rsp)
    a4ae:	45 31 db             	xor    %r11d,%r11d
    a4b1:	41 89 c2             	mov    %eax,%r10d
    a4b4:	48 89 d0             	mov    %rdx,%rax
    a4b7:	45 89 e6             	mov    %r12d,%r14d
    a4ba:	44 89 da             	mov    %r11d,%edx
    a4bd:	4d 89 fc             	mov    %r15,%r12
    a4c0:	41 89 cb             	mov    %ecx,%r11d
    a4c3:	48 89 c1             	mov    %rax,%rcx
    a4c6:	4c 63 c3             	movslq %ebx,%r8
    a4c9:	4d 63 4c 24 20       	movslq 0x20(%r12),%r9
    a4ce:	4c 89 c0             	mov    %r8,%rax
    a4d1:	4c 89 c3             	mov    %r8,%rbx
    a4d4:	48 0f af c6          	imul   %rsi,%rax
    a4d8:	49 03 44 24 08       	add    0x8(%r12),%rax
    a4dd:	48 89 44 24 a8       	mov    %rax,-0x58(%rsp)
    a4e2:	49 89 c7             	mov    %rax,%r15
    a4e5:	48 0f af d9          	imul   %rcx,%rbx
    a4e9:	49 8b 44 24 10       	mov    0x10(%r12),%rax
    a4ee:	41 39 fa             	cmp    %edi,%r10d
    a4f1:	0f 8e 2f 29 00 00    	jle    ce26 <convert_adaptive_job+0x2ed6>
    a4f7:	4d 01 c7             	add    %r8,%r15
    a4fa:	48 01 d8             	add    %rbx,%rax
    a4fd:	44 89 5c 24 d8       	mov    %r11d,-0x28(%rsp)
    a502:	4c 89 7c 24 b0       	mov    %r15,-0x50(%rsp)
    a507:	44 89 54 24 e8       	mov    %r10d,-0x18(%rsp)
    a50c:	44 89 74 24 f0       	mov    %r14d,-0x10(%rsp)
    a511:	48 89 74 24 f8       	mov    %rsi,-0x8(%rsp)
    a516:	89 2c 24             	mov    %ebp,(%rsp)
    a519:	89 54 24 08          	mov    %edx,0x8(%rsp)
    a51d:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    a522:	48 89 44 24 b8       	mov    %rax,-0x48(%rsp)
    a527:	89 7c 24 90          	mov    %edi,-0x70(%rsp)
    a52b:	31 ed                	xor    %ebp,%ebp
    a52d:	45 31 db             	xor    %r11d,%r11d
    a530:	31 db                	xor    %ebx,%ebx
    a532:	48 89 7c 24 c0       	mov    %rdi,-0x40(%rsp)
    a537:	45 31 c0             	xor    %r8d,%r8d
    a53a:	8b 44 24 90          	mov    -0x70(%rsp),%eax
    a53e:	44 89 c6             	mov    %r8d,%esi
    a541:	44 89 c2             	mov    %r8d,%edx
    a544:	49 8b 3c 24          	mov    (%r12),%rdi
    a548:	83 e6 01             	and    $0x1,%esi
    a54b:	d1 fa                	sar    $1,%edx
    a54d:	01 c6                	add    %eax,%esi
    a54f:	8b 44 24 98          	mov    -0x68(%rsp),%eax
    a553:	8d 0c b5 00 00 00 00 	lea    0x0(,%rsi,4),%ecx
    a55a:	48 63 f6             	movslq %esi,%rsi
    a55d:	01 c2                	add    %eax,%edx
    a55f:	48 63 c9             	movslq %ecx,%rcx
    a562:	c1 e2 02             	shl    $0x2,%edx
    a565:	48 c1 e1 02          	shl    $0x2,%rcx
    a569:	48 63 c2             	movslq %edx,%rax
    a56c:	49 0f af c1          	imul   %r9,%rax
    a570:	48 01 c8             	add    %rcx,%rax
    a573:	48 01 f8             	add    %rdi,%rax
    a576:	44 0f b6 50 04       	movzbl 0x4(%rax),%r10d
    a57b:	44 0f b6 38          	movzbl (%rax),%r15d
    a57f:	44 0f b6 70 01       	movzbl 0x1(%rax),%r14d
    a584:	44 0f b6 68 02       	movzbl 0x2(%rax),%r13d
    a589:	45 01 d7             	add    %r10d,%r15d
    a58c:	44 0f b6 50 05       	movzbl 0x5(%rax),%r10d
    a591:	45 01 d6             	add    %r10d,%r14d
    a594:	44 0f b6 50 06       	movzbl 0x6(%rax),%r10d
    a599:	45 01 d5             	add    %r10d,%r13d
    a59c:	44 0f b6 50 08       	movzbl 0x8(%rax),%r10d
    a5a1:	45 01 fa             	add    %r15d,%r10d
    a5a4:	44 0f b6 78 09       	movzbl 0x9(%rax),%r15d
    a5a9:	45 01 f7             	add    %r14d,%r15d
    a5ac:	44 0f b6 70 0a       	movzbl 0xa(%rax),%r14d
    a5b1:	45 01 ee             	add    %r13d,%r14d
    a5b4:	44 0f b6 68 0c       	movzbl 0xc(%rax),%r13d
    a5b9:	45 01 d5             	add    %r10d,%r13d
    a5bc:	44 0f b6 50 0d       	movzbl 0xd(%rax),%r10d
    a5c1:	45 01 fa             	add    %r15d,%r10d
    a5c4:	44 0f b6 78 0e       	movzbl 0xe(%rax),%r15d
    a5c9:	8d 42 01             	lea    0x1(%rdx),%eax
    a5cc:	48 98                	cltq
    a5ce:	49 0f af c1          	imul   %r9,%rax
    a5d2:	45 01 f7             	add    %r14d,%r15d
    a5d5:	48 8d 14 01          	lea    (%rcx,%rax,1),%rdx
    a5d9:	48 01 fa             	add    %rdi,%rdx
    a5dc:	44 0f b6 32          	movzbl (%rdx),%r14d
    a5e0:	45 01 ee             	add    %r13d,%r14d
    a5e3:	44 0f b6 6a 01       	movzbl 0x1(%rdx),%r13d
    a5e8:	45 01 d5             	add    %r10d,%r13d
    a5eb:	44 0f b6 52 02       	movzbl 0x2(%rdx),%r10d
    a5f0:	45 01 fa             	add    %r15d,%r10d
    a5f3:	44 0f b6 7a 04       	movzbl 0x4(%rdx),%r15d
    a5f8:	45 01 f7             	add    %r14d,%r15d
    a5fb:	44 0f b6 72 05       	movzbl 0x5(%rdx),%r14d
    a600:	45 01 ee             	add    %r13d,%r14d
    a603:	44 0f b6 6a 06       	movzbl 0x6(%rdx),%r13d
    a608:	45 01 d5             	add    %r10d,%r13d
    a60b:	44 0f b6 52 08       	movzbl 0x8(%rdx),%r10d
    a610:	45 01 fa             	add    %r15d,%r10d
    a613:	44 0f b6 7a 09       	movzbl 0x9(%rdx),%r15d
    a618:	45 01 f7             	add    %r14d,%r15d
    a61b:	44 0f b6 72 0a       	movzbl 0xa(%rdx),%r14d
    a620:	45 01 ee             	add    %r13d,%r14d
    a623:	44 0f b6 6a 0c       	movzbl 0xc(%rdx),%r13d
    a628:	45 01 d5             	add    %r10d,%r13d
    a62b:	44 0f b6 52 0d       	movzbl 0xd(%rdx),%r10d
    a630:	0f b6 52 0e          	movzbl 0xe(%rdx),%edx
    a634:	45 01 fa             	add    %r15d,%r10d
    a637:	41 01 d6             	add    %edx,%r14d
    a63a:	4c 01 c8             	add    %r9,%rax
    a63d:	48 8d 14 01          	lea    (%rcx,%rax,1),%rdx
    a641:	4c 01 c8             	add    %r9,%rax
    a644:	48 01 fa             	add    %rdi,%rdx
    a647:	48 01 c8             	add    %rcx,%rax
    a64a:	44 0f b6 3a          	movzbl (%rdx),%r15d
    a64e:	48 01 f8             	add    %rdi,%rax
    a651:	45 01 ef             	add    %r13d,%r15d
    a654:	44 0f b6 6a 01       	movzbl 0x1(%rdx),%r13d
    a659:	45 01 ea             	add    %r13d,%r10d
    a65c:	44 0f b6 6a 02       	movzbl 0x2(%rdx),%r13d
    a661:	45 01 ee             	add    %r13d,%r14d
    a664:	44 0f b6 6a 04       	movzbl 0x4(%rdx),%r13d
    a669:	45 01 fd             	add    %r15d,%r13d
    a66c:	44 0f b6 7a 05       	movzbl 0x5(%rdx),%r15d
    a671:	45 01 d7             	add    %r10d,%r15d
    a674:	44 0f b6 52 06       	movzbl 0x6(%rdx),%r10d
    a679:	0f b6 38             	movzbl (%rax),%edi
    a67c:	0f b6 48 02          	movzbl 0x2(%rax),%ecx
    a680:	45 01 f2             	add    %r14d,%r10d
    a683:	44 0f b6 72 08       	movzbl 0x8(%rdx),%r14d
    a688:	45 01 ee             	add    %r13d,%r14d
    a68b:	44 0f b6 6a 09       	movzbl 0x9(%rdx),%r13d
    a690:	45 01 fd             	add    %r15d,%r13d
    a693:	44 0f b6 7a 0a       	movzbl 0xa(%rdx),%r15d
    a698:	45 01 d7             	add    %r10d,%r15d
    a69b:	44 0f b6 52 0c       	movzbl 0xc(%rdx),%r10d
    a6a0:	45 01 d6             	add    %r10d,%r14d
    a6a3:	44 0f b6 52 0d       	movzbl 0xd(%rdx),%r10d
    a6a8:	0f b6 52 0e          	movzbl 0xe(%rdx),%edx
    a6ac:	44 01 f7             	add    %r14d,%edi
    a6af:	45 01 ea             	add    %r13d,%r10d
    a6b2:	44 0f b6 68 01       	movzbl 0x1(%rax),%r13d
    a6b7:	44 01 fa             	add    %r15d,%edx
    a6ba:	01 d1                	add    %edx,%ecx
    a6bc:	0f b6 50 06          	movzbl 0x6(%rax),%edx
    a6c0:	45 01 d5             	add    %r10d,%r13d
    a6c3:	44 0f b6 50 04       	movzbl 0x4(%rax),%r10d
    a6c8:	01 ca                	add    %ecx,%edx
    a6ca:	0f b6 48 08          	movzbl 0x8(%rax),%ecx
    a6ce:	41 01 fa             	add    %edi,%r10d
    a6d1:	0f b6 78 05          	movzbl 0x5(%rax),%edi
    a6d5:	44 01 d1             	add    %r10d,%ecx
    a6d8:	44 01 ef             	add    %r13d,%edi
    a6db:	44 0f b6 68 09       	movzbl 0x9(%rax),%r13d
    a6e0:	41 01 fd             	add    %edi,%r13d
    a6e3:	0f b6 78 0a          	movzbl 0xa(%rax),%edi
    a6e7:	01 d7                	add    %edx,%edi
    a6e9:	0f b6 50 0c          	movzbl 0xc(%rax),%edx
    a6ed:	01 ca                	add    %ecx,%edx
    a6ef:	0f b6 48 0d          	movzbl 0xd(%rax),%ecx
    a6f3:	0f b6 40 0e          	movzbl 0xe(%rax),%eax
    a6f7:	41 89 d2             	mov    %edx,%r10d
    a6fa:	01 f8                	add    %edi,%eax
    a6fc:	44 01 e9             	add    %r13d,%ecx
    a6ff:	41 c1 fa 04          	sar    $0x4,%r10d
    a703:	c1 f9 04             	sar    $0x4,%ecx
    a706:	c1 f8 04             	sar    $0x4,%eax
    a709:	44 6b e8 2f          	imul   $0x2f,%eax,%r13d
    a70d:	81 e2 f0 ff 7f 00    	and    $0x7ffff0,%edx
    a713:	69 f9 9d 00 00 00    	imul   $0x9d,%ecx,%edi
    a719:	44 01 ef             	add    %r13d,%edi
    a71c:	8d 94 17 80 00 00 00 	lea    0x80(%rdi,%rdx,1),%edx
    a723:	c1 fa 08             	sar    $0x8,%edx
    a726:	83 c2 10             	add    $0x10,%edx
    a729:	41 83 f8 01          	cmp    $0x1,%r8d
    a72d:	0f 8f 2c 26 00 00    	jg     cd5f <convert_adaptive_job+0x2e0f>
    a733:	48 8b 7c 24 a8       	mov    -0x58(%rsp),%rdi
    a738:	44 01 d3             	add    %r10d,%ebx
    a73b:	41 01 cb             	add    %ecx,%r11d
    a73e:	01 c5                	add    %eax,%ebp
    a740:	41 83 c0 01          	add    $0x1,%r8d
    a744:	88 14 37             	mov    %dl,(%rdi,%rsi,1)
    a747:	e9 ee fd ff ff       	jmp    a53a <convert_adaptive_job+0x5ea>
    a74c:	48 89 ca             	mov    %rcx,%rdx
    a74f:	44 8b 44 24 c8       	mov    -0x38(%rsp),%r8d
    a754:	41 8b 4c 24 34       	mov    0x34(%r12),%ecx
    a759:	4d 89 e7             	mov    %r12,%r15
    a75c:	41 83 c0 01          	add    $0x1,%r8d
    a760:	48 83 c2 01          	add    $0x1,%rdx
    a764:	41 39 c8             	cmp    %ecx,%r8d
    a767:	0f 8c b6 fc ff ff    	jl     a423 <convert_adaptive_job+0x4d3>
    a76d:	48 81 c4 20 01 00 00 	add    $0x120,%rsp
    a774:	5b                   	pop    %rbx
    a775:	5d                   	pop    %rbp
    a776:	41 5c                	pop    %r12
    a778:	41 5d                	pop    %r13
    a77a:	41 5e                	pop    %r14
    a77c:	41 5f                	pop    %r15
    a77e:	c3                   	ret
    a77f:	89 df                	mov    %ebx,%edi
    a781:	39 cb                	cmp    %ecx,%ebx
    a783:	7d e8                	jge    a76d <convert_adaptive_job+0x81d>
    a785:	48 63 db             	movslq %ebx,%rbx
    a788:	49 89 c7             	mov    %rax,%r15
    a78b:	48 89 da             	mov    %rbx,%rdx
    a78e:	49 8b 77 38          	mov    0x38(%r15),%rsi
    a792:	48 85 f6             	test   %rsi,%rsi
    a795:	74 19                	je     a7b0 <convert_adaptive_job+0x860>
    a797:	89 f8                	mov    %edi,%eax
    a799:	c1 f8 03             	sar    $0x3,%eax
    a79c:	48 98                	cltq
    a79e:	0f b6 34 06          	movzbl (%rsi,%rax,1),%esi
    a7a2:	89 f8                	mov    %edi,%eax
    a7a4:	83 e0 07             	and    $0x7,%eax
    a7a7:	0f a3 c6             	bt     %eax,%esi
    a7aa:	0f 83 f9 2a 00 00    	jae    d2a9 <convert_adaptive_job+0x3359>
    a7b0:	49 8b 77 40          	mov    0x40(%r15),%rsi
    a7b4:	41 8b 5f 24          	mov    0x24(%r15),%ebx
    a7b8:	48 85 f6             	test   %rsi,%rsi
    a7bb:	0f 84 fc 2a 00 00    	je     d2bd <convert_adaptive_job+0x336d>
    a7c1:	48 89 d0             	mov    %rdx,%rax
    a7c4:	48 c1 e0 04          	shl    $0x4,%rax
    a7c8:	48 01 c6             	add    %rax,%rsi
    a7cb:	44 8b 56 0c          	mov    0xc(%rsi),%r10d
    a7cf:	8b 46 08             	mov    0x8(%rsi),%eax
    a7d2:	4c 63 0e             	movslq (%rsi),%r9
    a7d5:	8b 4e 04             	mov    0x4(%rsi),%ecx
    a7d8:	45 89 d3             	mov    %r10d,%r11d
    a7db:	41 29 c3             	sub    %eax,%r11d
    a7de:	41 83 fb 7f          	cmp    $0x7f,%r11d
    a7e2:	0f 8e dd 2a 00 00    	jle    d2c5 <convert_adaptive_job+0x3375>
    a7e8:	89 cd                	mov    %ecx,%ebp
    a7ea:	8d 34 3f             	lea    (%rdi,%rdi,1),%esi
    a7ed:	44 29 cd             	sub    %r9d,%ebp
    a7f0:	89 74 24 98          	mov    %esi,-0x68(%rsp)
    a7f4:	48 63 f6             	movslq %esi,%rsi
    a7f7:	41 89 e8             	mov    %ebp,%r8d
    a7fa:	41 c1 e8 1f          	shr    $0x1f,%r8d
    a7fe:	41 01 e8             	add    %ebp,%r8d
    a801:	31 ed                	xor    %ebp,%ebp
    a803:	41 d1 f8             	sar    $1,%r8d
    a806:	45 39 c3             	cmp    %r8d,%r11d
    a809:	0f 4c c1             	cmovl  %ecx,%eax
    a80c:	40 0f 9d c5          	setge  %bpl
    a810:	45 31 db             	xor    %r11d,%r11d
    a813:	89 7c 24 c8          	mov    %edi,-0x38(%rsp)
    a817:	41 89 c0             	mov    %eax,%r8d
    a81a:	89 ef                	mov    %ebp,%edi
    a81c:	48 89 d0             	mov    %rdx,%rax
    a81f:	44 89 d5             	mov    %r10d,%ebp
    a822:	44 89 da             	mov    %r11d,%edx
    a825:	4d 89 fd             	mov    %r15,%r13
    a828:	41 89 cb             	mov    %ecx,%r11d
    a82b:	41 89 fa             	mov    %edi,%r10d
    a82e:	48 89 c1             	mov    %rax,%rcx
    a831:	48 63 fb             	movslq %ebx,%rdi
    a834:	4d 63 65 20          	movslq 0x20(%r13),%r12
    a838:	48 89 f8             	mov    %rdi,%rax
    a83b:	48 89 fb             	mov    %rdi,%rbx
    a83e:	48 0f af c6          	imul   %rsi,%rax
    a842:	49 03 45 08          	add    0x8(%r13),%rax
    a846:	48 89 44 24 a8       	mov    %rax,-0x58(%rsp)
    a84b:	49 89 c6             	mov    %rax,%r14
    a84e:	48 0f af d9          	imul   %rcx,%rbx
    a852:	49 8b 45 10          	mov    0x10(%r13),%rax
    a856:	45 39 c1             	cmp    %r8d,%r9d
    a859:	0f 8d 16 2a 00 00    	jge    d275 <convert_adaptive_job+0x3325>
    a85f:	4c 01 f7             	add    %r14,%rdi
    a862:	48 01 d8             	add    %rbx,%rax
    a865:	44 89 5c 24 d8       	mov    %r11d,-0x28(%rsp)
    a86a:	48 89 7c 24 b0       	mov    %rdi,-0x50(%rsp)
    a86f:	44 89 44 24 e8       	mov    %r8d,-0x18(%rsp)
    a874:	89 6c 24 f0          	mov    %ebp,-0x10(%rsp)
    a878:	48 89 74 24 f8       	mov    %rsi,-0x8(%rsp)
    a87d:	44 89 14 24          	mov    %r10d,(%rsp)
    a881:	89 54 24 08          	mov    %edx,0x8(%rsp)
    a885:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    a88a:	48 89 44 24 b8       	mov    %rax,-0x48(%rsp)
    a88f:	44 89 4c 24 90       	mov    %r9d,-0x70(%rsp)
    a894:	31 ed                	xor    %ebp,%ebp
    a896:	45 31 db             	xor    %r11d,%r11d
    a899:	31 db                	xor    %ebx,%ebx
    a89b:	4c 89 4c 24 c0       	mov    %r9,-0x40(%rsp)
    a8a0:	31 ff                	xor    %edi,%edi
    a8a2:	8b 44 24 90          	mov    -0x70(%rsp),%eax
    a8a6:	89 fe                	mov    %edi,%esi
    a8a8:	8b 4c 24 98          	mov    -0x68(%rsp),%ecx
    a8ac:	83 e6 01             	and    $0x1,%esi
    a8af:	4d 8b 4d 00          	mov    0x0(%r13),%r9
    a8b3:	01 c6                	add    %eax,%esi
    a8b5:	89 f8                	mov    %edi,%eax
    a8b7:	d1 f8                	sar    $1,%eax
    a8b9:	01 c8                	add    %ecx,%eax
    a8bb:	8d 0c 76             	lea    (%rsi,%rsi,2),%ecx
    a8be:	48 63 f6             	movslq %esi,%rsi
    a8c1:	8d 14 40             	lea    (%rax,%rax,2),%edx
    a8c4:	48 63 c9             	movslq %ecx,%rcx
    a8c7:	48 63 c2             	movslq %edx,%rax
    a8ca:	48 c1 e1 02          	shl    $0x2,%rcx
    a8ce:	49 0f af c4          	imul   %r12,%rax
    a8d2:	48 01 c8             	add    %rcx,%rax
    a8d5:	4c 01 c8             	add    %r9,%rax
    a8d8:	44 0f b6 50 04       	movzbl 0x4(%rax),%r10d
    a8dd:	44 0f b6 00          	movzbl (%rax),%r8d
    a8e1:	44 0f b6 70 01       	movzbl 0x1(%rax),%r14d
    a8e6:	44 0f b6 78 02       	movzbl 0x2(%rax),%r15d
    a8eb:	45 01 d0             	add    %r10d,%r8d
    a8ee:	44 0f b6 50 05       	movzbl 0x5(%rax),%r10d
    a8f3:	45 01 d6             	add    %r10d,%r14d
    a8f6:	44 0f b6 50 06       	movzbl 0x6(%rax),%r10d
    a8fb:	45 01 d7             	add    %r10d,%r15d
    a8fe:	44 0f b6 50 08       	movzbl 0x8(%rax),%r10d
    a903:	45 01 c2             	add    %r8d,%r10d
    a906:	44 0f b6 40 09       	movzbl 0x9(%rax),%r8d
    a90b:	45 01 f0             	add    %r14d,%r8d
    a90e:	44 0f b6 70 0a       	movzbl 0xa(%rax),%r14d
    a913:	8d 42 01             	lea    0x1(%rdx),%eax
    a916:	48 98                	cltq
    a918:	49 0f af c4          	imul   %r12,%rax
    a91c:	45 01 fe             	add    %r15d,%r14d
    a91f:	48 8d 14 01          	lea    (%rcx,%rax,1),%rdx
    a923:	4c 01 e0             	add    %r12,%rax
    a926:	4c 01 ca             	add    %r9,%rdx
    a929:	48 01 c8             	add    %rcx,%rax
    a92c:	44 0f b6 3a          	movzbl (%rdx),%r15d
    a930:	4c 01 c8             	add    %r9,%rax
    a933:	44 0f b6 48 01       	movzbl 0x1(%rax),%r9d
    a938:	0f b6 08             	movzbl (%rax),%ecx
    a93b:	45 01 fa             	add    %r15d,%r10d
    a93e:	44 0f b6 7a 01       	movzbl 0x1(%rdx),%r15d
    a943:	45 01 c7             	add    %r8d,%r15d
    a946:	44 0f b6 42 02       	movzbl 0x2(%rdx),%r8d
    a94b:	45 01 f0             	add    %r14d,%r8d
    a94e:	44 0f b6 72 04       	movzbl 0x4(%rdx),%r14d
    a953:	45 01 d6             	add    %r10d,%r14d
    a956:	44 0f b6 52 05       	movzbl 0x5(%rdx),%r10d
    a95b:	45 01 fa             	add    %r15d,%r10d
    a95e:	44 0f b6 7a 06       	movzbl 0x6(%rdx),%r15d
    a963:	45 01 c7             	add    %r8d,%r15d
    a966:	44 0f b6 42 08       	movzbl 0x8(%rdx),%r8d
    a96b:	45 01 c6             	add    %r8d,%r14d
    a96e:	44 0f b6 42 09       	movzbl 0x9(%rdx),%r8d
    a973:	0f b6 52 0a          	movzbl 0xa(%rdx),%edx
    a977:	44 01 f1             	add    %r14d,%ecx
    a97a:	45 01 d0             	add    %r10d,%r8d
    a97d:	44 01 fa             	add    %r15d,%edx
    a980:	45 01 c8             	add    %r9d,%r8d
    a983:	44 0f b6 48 02       	movzbl 0x2(%rax),%r9d
    a988:	44 01 ca             	add    %r9d,%edx
    a98b:	44 0f b6 48 04       	movzbl 0x4(%rax),%r9d
    a990:	41 01 c9             	add    %ecx,%r9d
    a993:	0f b6 48 05          	movzbl 0x5(%rax),%ecx
    a997:	44 01 c1             	add    %r8d,%ecx
    a99a:	44 0f b6 40 06       	movzbl 0x6(%rax),%r8d
    a99f:	41 01 d0             	add    %edx,%r8d
    a9a2:	0f b6 50 08          	movzbl 0x8(%rax),%edx
    a9a6:	44 01 ca             	add    %r9d,%edx
    a9a9:	44 0f b6 48 09       	movzbl 0x9(%rax),%r9d
    a9ae:	0f b6 40 0a          	movzbl 0xa(%rax),%eax
    a9b2:	48 69 d2 39 8e e3 38 	imul   $0x38e38e39,%rdx,%rdx
    a9b9:	44 01 c9             	add    %r9d,%ecx
    a9bc:	44 01 c0             	add    %r8d,%eax
    a9bf:	48 69 c9 39 8e e3 38 	imul   $0x38e38e39,%rcx,%rcx
    a9c6:	48 69 c0 39 8e e3 38 	imul   $0x38e38e39,%rax,%rax
    a9cd:	48 c1 ea 21          	shr    $0x21,%rdx
    a9d1:	48 c1 e9 21          	shr    $0x21,%rcx
    a9d5:	48 c1 e8 21          	shr    $0x21,%rax
    a9d9:	44 69 c1 9d 00 00 00 	imul   $0x9d,%ecx,%r8d
    a9e0:	44 6b c8 2f          	imul   $0x2f,%eax,%r9d
    a9e4:	45 01 c8             	add    %r9d,%r8d
    a9e7:	41 89 d1             	mov    %edx,%r9d
    a9ea:	41 c1 e1 04          	shl    $0x4,%r9d
    a9ee:	47 8d 84 08 80 00 00 	lea    0x80(%r8,%r9,1),%r8d
    a9f5:	00 
    a9f6:	41 c1 f8 08          	sar    $0x8,%r8d
    a9fa:	41 83 c0 10          	add    $0x10,%r8d
    a9fe:	83 ff 01             	cmp    $0x1,%edi
    aa01:	0f 8f b1 27 00 00    	jg     d1b8 <convert_adaptive_job+0x3268>
    aa07:	4c 8b 74 24 a8       	mov    -0x58(%rsp),%r14
    aa0c:	01 d3                	add    %edx,%ebx
    aa0e:	41 01 cb             	add    %ecx,%r11d
    aa11:	01 c5                	add    %eax,%ebp
    aa13:	83 c7 01             	add    $0x1,%edi
    aa16:	45 88 04 36          	mov    %r8b,(%r14,%rsi,1)
    aa1a:	e9 83 fe ff ff       	jmp    a8a2 <convert_adaptive_job+0x952>
    aa1f:	41 89 da             	mov    %ebx,%r10d
    aa22:	39 cb                	cmp    %ecx,%ebx
    aa24:	0f 8d 43 fd ff ff    	jge    a76d <convert_adaptive_job+0x81d>
    aa2a:	66 44 0f 6f 2d 4d 48 	movdqa 0x484d(%rip),%xmm13        # f280 <__PRETTY_FUNCTION__.4+0xd>
    aa31:	00 00 
    aa33:	44 89 f8             	mov    %r15d,%eax
    aa36:	4c 63 e3             	movslq %ebx,%r12
    aa39:	41 8d 5f ff          	lea    -0x1(%r15),%ebx
    aa3d:	41 0f af c7          	imul   %r15d,%eax
    aa41:	89 5c 24 98          	mov    %ebx,-0x68(%rsp)
    aa45:	f3 44 0f 7e 3d 32 48 	movq   0x4832(%rip),%xmm15        # f280 <__PRETTY_FUNCTION__.4+0xd>
    aa4c:	00 00 
    aa4e:	89 44 24 68          	mov    %eax,0x68(%rsp)
    aa52:	89 d8                	mov    %ebx,%eax
    aa54:	83 e3 f0             	and    $0xfffffff0,%ebx
    aa57:	c1 e8 04             	shr    $0x4,%eax
    aa5a:	89 5c 24 b8          	mov    %ebx,-0x48(%rsp)
    aa5e:	48 c1 e0 06          	shl    $0x6,%rax
    aa62:	48 89 44 24 c0       	mov    %rax,-0x40(%rsp)
    aa67:	48 8b 44 24 e8       	mov    -0x18(%rsp),%rax
    aa6c:	48 8b 50 38          	mov    0x38(%rax),%rdx
    aa70:	48 85 d2             	test   %rdx,%rdx
    aa73:	74 1b                	je     aa90 <convert_adaptive_job+0xb40>
    aa75:	44 89 d0             	mov    %r10d,%eax
    aa78:	c1 f8 03             	sar    $0x3,%eax
    aa7b:	48 98                	cltq
    aa7d:	0f b6 14 02          	movzbl (%rdx,%rax,1),%edx
    aa81:	44 89 d0             	mov    %r10d,%eax
    aa84:	83 e0 07             	and    $0x7,%eax
    aa87:	0f a3 c2             	bt     %eax,%edx
    aa8a:	0f 83 f2 26 00 00    	jae    d182 <convert_adaptive_job+0x3232>
    aa90:	48 8b 5c 24 e8       	mov    -0x18(%rsp),%rbx
    aa95:	48 8b 43 40          	mov    0x40(%rbx),%rax
    aa99:	8b 4b 24             	mov    0x24(%rbx),%ecx
    aa9c:	48 85 c0             	test   %rax,%rax
    aa9f:	0f 84 f3 26 00 00    	je     d198 <convert_adaptive_job+0x3248>
    aaa5:	4c 89 e2             	mov    %r12,%rdx
    aaa8:	48 c1 e2 04          	shl    $0x4,%rdx
    aaac:	48 01 d0             	add    %rdx,%rax
    aaaf:	44 8b 48 0c          	mov    0xc(%rax),%r9d
    aab3:	44 8b 58 08          	mov    0x8(%rax),%r11d
    aab7:	8b 18                	mov    (%rax),%ebx
    aab9:	8b 78 04             	mov    0x4(%rax),%edi
    aabc:	44 89 ca             	mov    %r9d,%edx
    aabf:	44 29 da             	sub    %r11d,%edx
    aac2:	83 fa 7f             	cmp    $0x7f,%edx
    aac5:	0f 8e d4 26 00 00    	jle    d19f <convert_adaptive_job+0x324f>
    aacb:	89 fe                	mov    %edi,%esi
    aacd:	43 8d 04 12          	lea    (%r10,%r10,1),%eax
    aad1:	45 31 ed             	xor    %r13d,%r13d
    aad4:	29 de                	sub    %ebx,%esi
    aad6:	89 44 24 58          	mov    %eax,0x58(%rsp)
    aada:	48 63 e8             	movslq %eax,%rbp
    aadd:	89 f0                	mov    %esi,%eax
    aadf:	c1 e8 1f             	shr    $0x1f,%eax
    aae2:	01 f0                	add    %esi,%eax
    aae4:	d1 f8                	sar    $1,%eax
    aae6:	39 c2                	cmp    %eax,%edx
    aae8:	44 0f 4c df          	cmovl  %edi,%r11d
    aaec:	41 0f 9d c5          	setge  %r13b
    aaf0:	44 89 54 24 74       	mov    %r10d,0x74(%rsp)
    aaf5:	45 31 f6             	xor    %r14d,%r14d
    aaf8:	66 45 0f ef f6       	pxor   %xmm14,%xmm14
    aafd:	48 8b 74 24 e8       	mov    -0x18(%rsp),%rsi
    ab02:	48 63 d1             	movslq %ecx,%rdx
    ab05:	8b 46 20             	mov    0x20(%rsi),%eax
    ab08:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    ab0c:	89 04 24             	mov    %eax,(%rsp)
    ab0f:	48 89 d0             	mov    %rdx,%rax
    ab12:	48 0f af c5          	imul   %rbp,%rax
    ab16:	48 03 46 08          	add    0x8(%rsi),%rax
    ab1a:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    ab1f:	49 89 c2             	mov    %rax,%r10
    ab22:	48 89 d0             	mov    %rdx,%rax
    ab25:	49 0f af c4          	imul   %r12,%rax
    ab29:	44 39 db             	cmp    %r11d,%ebx
    ab2c:	0f 8d 0d 26 00 00    	jge    d13f <convert_adaptive_job+0x31ef>
    ab32:	4c 63 c3             	movslq %ebx,%r8
    ab35:	49 8d 1c 12          	lea    (%r10,%rdx,1),%rbx
    ab39:	89 bc 24 08 01 00 00 	mov    %edi,0x108(%rsp)
    ab40:	66 45 0f ef d2       	pxor   %xmm10,%xmm10
    ab45:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
    ab4a:	48 8d 1c 01          	lea    (%rcx,%rax,1),%rbx
    ab4e:	44 89 5c 24 48       	mov    %r11d,0x48(%rsp)
    ab53:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
    ab5a:	00 
    ab5b:	44 89 ac 24 98 00 00 	mov    %r13d,0x98(%rsp)
    ab62:	00 
    ab63:	44 89 b4 24 a8 00 00 	mov    %r14d,0xa8(%rsp)
    ab6a:	00 
    ab6b:	4c 89 a4 24 b8 00 00 	mov    %r12,0xb8(%rsp)
    ab72:	00 
    ab73:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
    ab78:	44 89 4c 24 78       	mov    %r9d,0x78(%rsp)
    ab7d:	44 8b 4c 24 58       	mov    0x58(%rsp),%r9d
    ab82:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
    ab89:	00 
    ab8a:	44 89 c6             	mov    %r8d,%esi
    ab8d:	31 c9                	xor    %ecx,%ecx
    ab8f:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
    ab96:	00 
    ab97:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    ab9e:	00 
    ab9f:	4c 89 44 24 40       	mov    %r8,0x40(%rsp)
    aba4:	89 c8                	mov    %ecx,%eax
    aba6:	89 ca                	mov    %ecx,%edx
    aba8:	83 e0 01             	and    $0x1,%eax
    abab:	d1 fa                	sar    $1,%edx
    abad:	8d 3c 30             	lea    (%rax,%rsi,1),%edi
    abb0:	44 01 ca             	add    %r9d,%edx
    abb3:	45 85 ff             	test   %r15d,%r15d
    abb6:	0f 8e af 25 00 00    	jle    d16b <convert_adaptive_job+0x321b>
    abbc:	41 0f af d7          	imul   %r15d,%edx
    abc0:	45 89 fd             	mov    %r15d,%r13d
    abc3:	48 63 1c 24          	movslq (%rsp),%rbx
    abc7:	48 8b 44 24 e8       	mov    -0x18(%rsp),%rax
    abcc:	44 0f af ef          	imul   %edi,%r13d
    abd0:	89 4c 24 c8          	mov    %ecx,-0x38(%rsp)
    abd4:	45 31 db             	xor    %r11d,%r11d
    abd7:	45 31 e4             	xor    %r12d,%r12d
    abda:	4c 8b 30             	mov    (%rax),%r14
    abdd:	44 89 4c 24 d8       	mov    %r9d,-0x28(%rsp)
    abe2:	66 45 0f ef e4       	pxor   %xmm12,%xmm12
    abe7:	66 45 0f ef c9       	pxor   %xmm9,%xmm9
    abec:	4c 63 c2             	movslq %edx,%r8
    abef:	89 7c 24 f0          	mov    %edi,-0x10(%rsp)
    abf3:	4c 0f af c3          	imul   %rbx,%r8
    abf7:	4d 63 ed             	movslq %r13d,%r13
    abfa:	89 74 24 f8          	mov    %esi,-0x8(%rsp)
    abfe:	4a 8d 04 ad 00 00 00 	lea    0x0(,%r13,4),%rax
    ac05:	00 
    ac06:	48 89 5c 24 b0       	mov    %rbx,-0x50(%rsp)
    ac0b:	31 db                	xor    %ebx,%ebx
    ac0d:	49 01 c0             	add    %rax,%r8
    ac10:	4c 01 f0             	add    %r14,%rax
    ac13:	48 89 44 24 a8       	mov    %rax,-0x58(%rsp)
    ac18:	4d 01 f0             	add    %r14,%r8
    ac1b:	31 c0                	xor    %eax,%eax
    ac1d:	0f 1f 00             	nopl   (%rax)
    ac20:	48 8b 74 24 a8       	mov    -0x58(%rsp),%rsi
    ac25:	4c 89 c5             	mov    %r8,%rbp
    ac28:	48 29 f5             	sub    %rsi,%rbp
    ac2b:	83 7c 24 98 0f       	cmpl   $0xf,-0x68(%rsp)
    ac30:	0f 86 12 24 00 00    	jbe    d048 <convert_adaptive_job+0x30f8>
    ac36:	48 8b 74 24 c0       	mov    -0x40(%rsp),%rsi
    ac3b:	66 0f ef f6          	pxor   %xmm6,%xmm6
    ac3f:	4c 89 c2             	mov    %r8,%rdx
    ac42:	66 0f 6f ee          	movdqa %xmm6,%xmm5
    ac46:	66 0f 6f e6          	movdqa %xmm6,%xmm4
    ac4a:	49 8d 0c 30          	lea    (%r8,%rsi,1),%rcx
    ac4e:	f3 0f 6f 1a          	movdqu (%rdx),%xmm3
    ac52:	f3 0f 6f 42 10       	movdqu 0x10(%rdx),%xmm0
    ac57:	66 41 0f 6f fd       	movdqa %xmm13,%xmm7
    ac5c:	48 83 c2 40          	add    $0x40,%rdx
    ac60:	f3 0f 6f 4a f0       	movdqu -0x10(%rdx),%xmm1
    ac65:	f3 44 0f 6f 42 f0    	movdqu -0x10(%rdx),%xmm8
    ac6b:	66 41 0f db c5       	pand   %xmm13,%xmm0
    ac70:	66 41 0f db dd       	pand   %xmm13,%xmm3
    ac75:	66 0f 67 d8          	packuswb %xmm0,%xmm3
    ac79:	f3 0f 6f 42 e0       	movdqu -0x20(%rdx),%xmm0
    ac7e:	66 41 0f db cd       	pand   %xmm13,%xmm1
    ac83:	66 0f db fb          	pand   %xmm3,%xmm7
    ac87:	66 0f 71 d3 08       	psrlw  $0x8,%xmm3
    ac8c:	66 41 0f db c5       	pand   %xmm13,%xmm0
    ac91:	66 41 0f 71 d0 08    	psrlw  $0x8,%xmm8
    ac97:	66 0f 67 c1          	packuswb %xmm1,%xmm0
    ac9b:	66 41 0f 6f cd       	movdqa %xmm13,%xmm1
    aca0:	66 0f db c8          	pand   %xmm0,%xmm1
    aca4:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    aca9:	66 0f 67 f9          	packuswb %xmm1,%xmm7
    acad:	66 0f 67 d8          	packuswb %xmm0,%xmm3
    acb1:	f3 0f 6f 4a d0       	movdqu -0x30(%rdx),%xmm1
    acb6:	f3 0f 6f 42 c0       	movdqu -0x40(%rdx),%xmm0
    acbb:	66 0f 71 d1 08       	psrlw  $0x8,%xmm1
    acc0:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    acc5:	66 0f 67 c1          	packuswb %xmm1,%xmm0
    acc9:	f3 0f 6f 4a e0       	movdqu -0x20(%rdx),%xmm1
    acce:	66 41 0f db c5       	pand   %xmm13,%xmm0
    acd3:	66 0f 71 d1 08       	psrlw  $0x8,%xmm1
    acd8:	66 41 0f 67 c8       	packuswb %xmm8,%xmm1
    acdd:	66 44 0f 6f c7       	movdqa %xmm7,%xmm8
    ace2:	66 41 0f 68 fc       	punpckhbw %xmm12,%xmm7
    ace7:	66 41 0f db cd       	pand   %xmm13,%xmm1
    acec:	66 45 0f 60 c4       	punpcklbw %xmm12,%xmm8
    acf1:	66 0f 67 c1          	packuswb %xmm1,%xmm0
    acf5:	66 41 0f 6f c8       	movdqa %xmm8,%xmm1
    acfa:	66 45 0f 69 c1       	punpckhwd %xmm9,%xmm8
    acff:	66 41 0f 61 c9       	punpcklwd %xmm9,%xmm1
    ad04:	66 0f fe e1          	paddd  %xmm1,%xmm4
    ad08:	66 0f 6f cf          	movdqa %xmm7,%xmm1
    ad0c:	66 41 0f 69 f9       	punpckhwd %xmm9,%xmm7
    ad11:	66 41 0f 61 c9       	punpcklwd %xmm9,%xmm1
    ad16:	66 41 0f fe e0       	paddd  %xmm8,%xmm4
    ad1b:	66 0f fe e1          	paddd  %xmm1,%xmm4
    ad1f:	66 0f fe e7          	paddd  %xmm7,%xmm4
    ad23:	66 0f 6f f8          	movdqa %xmm0,%xmm7
    ad27:	66 41 0f 68 c4       	punpckhbw %xmm12,%xmm0
    ad2c:	66 41 0f 60 fc       	punpcklbw %xmm12,%xmm7
    ad31:	66 0f 6f cf          	movdqa %xmm7,%xmm1
    ad35:	66 41 0f 69 f9       	punpckhwd %xmm9,%xmm7
    ad3a:	66 41 0f 61 c9       	punpcklwd %xmm9,%xmm1
    ad3f:	66 0f fe e9          	paddd  %xmm1,%xmm5
    ad43:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    ad47:	66 41 0f 69 c1       	punpckhwd %xmm9,%xmm0
    ad4c:	66 41 0f 61 c9       	punpcklwd %xmm9,%xmm1
    ad51:	66 0f fe ef          	paddd  %xmm7,%xmm5
    ad55:	66 0f fe e9          	paddd  %xmm1,%xmm5
    ad59:	66 0f 6f cb          	movdqa %xmm3,%xmm1
    ad5d:	66 41 0f 68 dc       	punpckhbw %xmm12,%xmm3
    ad62:	66 41 0f 60 cc       	punpcklbw %xmm12,%xmm1
    ad67:	66 0f fe e8          	paddd  %xmm0,%xmm5
    ad6b:	66 0f 6f c1          	movdqa %xmm1,%xmm0
    ad6f:	66 41 0f 69 c9       	punpckhwd %xmm9,%xmm1
    ad74:	66 41 0f 61 c1       	punpcklwd %xmm9,%xmm0
    ad79:	66 0f fe f0          	paddd  %xmm0,%xmm6
    ad7d:	66 0f 6f c3          	movdqa %xmm3,%xmm0
    ad81:	66 41 0f 69 d9       	punpckhwd %xmm9,%xmm3
    ad86:	66 0f fe f1          	paddd  %xmm1,%xmm6
    ad8a:	66 41 0f 61 c1       	punpcklwd %xmm9,%xmm0
    ad8f:	66 0f fe f0          	paddd  %xmm0,%xmm6
    ad93:	66 0f fe f3          	paddd  %xmm3,%xmm6
    ad97:	48 39 d1             	cmp    %rdx,%rcx
    ad9a:	0f 85 ae fe ff ff    	jne    ac4e <convert_adaptive_job+0xcfe>
    ada0:	66 0f 6f c6          	movdqa %xmm6,%xmm0
    ada4:	44 0f 12 c6          	movhlps %xmm6,%xmm8
    ada8:	44 8b 54 24 b8       	mov    -0x48(%rsp),%r10d
    adad:	66 0f 73 d8 08       	psrldq $0x8,%xmm0
    adb2:	66 44 0f fe c6       	paddd  %xmm6,%xmm8
    adb7:	66 0f fe c6          	paddd  %xmm6,%xmm0
    adbb:	44 89 d7             	mov    %r10d,%edi
    adbe:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    adc2:	66 0f 73 d9 04       	psrldq $0x4,%xmm1
    adc7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    adcb:	66 0f 7e c2          	movd   %xmm0,%edx
    adcf:	66 0f 6f c5          	movdqa %xmm5,%xmm0
    add3:	66 0f 73 d8 08       	psrldq $0x8,%xmm0
    add8:	44 01 da             	add    %r11d,%edx
    addb:	66 0f fe c5          	paddd  %xmm5,%xmm0
    addf:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    ade3:	66 0f 73 d9 04       	psrldq $0x4,%xmm1
    ade8:	66 0f fe c1          	paddd  %xmm1,%xmm0
    adec:	66 0f 7e c1          	movd   %xmm0,%ecx
    adf0:	66 0f 6f c4          	movdqa %xmm4,%xmm0
    adf4:	66 0f 73 d8 08       	psrldq $0x8,%xmm0
    adf9:	01 d9                	add    %ebx,%ecx
    adfb:	66 0f fe c4          	paddd  %xmm4,%xmm0
    adff:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    ae03:	66 0f 73 d9 04       	psrldq $0x4,%xmm1
    ae08:	66 0f fe c1          	paddd  %xmm1,%xmm0
    ae0c:	66 0f 7e c6          	movd   %xmm0,%esi
    ae10:	0f 12 c4             	movhlps %xmm4,%xmm0
    ae13:	66 0f fe e0          	paddd  %xmm0,%xmm4
    ae17:	0f 12 c5             	movhlps %xmm5,%xmm0
    ae1a:	01 c6                	add    %eax,%esi
    ae1c:	66 0f fe e8          	paddd  %xmm0,%xmm5
    ae20:	66 0f d6 64 24 90    	movq   %xmm4,-0x70(%rsp)
    ae26:	44 8b 4c 24 98       	mov    -0x68(%rsp),%r9d
    ae2b:	41 29 f9             	sub    %edi,%r9d
    ae2e:	41 83 f9 07          	cmp    $0x7,%r9d
    ae32:	0f 86 e3 01 00 00    	jbe    b01b <convert_adaptive_job+0x10cb>
    ae38:	4c 01 ef             	add    %r13,%rdi
    ae3b:	66 41 0f 6f cf       	movdqa %xmm15,%xmm1
    ae40:	66 41 0f 6f df       	movdqa %xmm15,%xmm3
    ae45:	41 83 e1 f8          	and    $0xfffffff8,%r9d
    ae49:	48 8d 54 bd 00       	lea    0x0(%rbp,%rdi,4),%rdx
    ae4e:	66 41 0f 6f f7       	movdqa %xmm15,%xmm6
    ae53:	66 41 0f 6f e7       	movdqa %xmm15,%xmm4
    ae58:	45 01 ca             	add    %r9d,%r10d
    ae5b:	4c 01 f2             	add    %r14,%rdx
    ae5e:	f3 0f 7e 12          	movq   (%rdx),%xmm2
    ae62:	f3 44 0f 7e 5a 08    	movq   0x8(%rdx),%xmm11
    ae68:	f3 0f 7e 7a 10       	movq   0x10(%rdx),%xmm7
    ae6d:	f3 0f 7e 42 18       	movq   0x18(%rdx),%xmm0
    ae72:	66 41 0f db db       	pand   %xmm11,%xmm3
    ae77:	66 41 0f 71 d3 08    	psrlw  $0x8,%xmm11
    ae7d:	66 0f db ca          	pand   %xmm2,%xmm1
    ae81:	66 0f 67 cb          	packuswb %xmm3,%xmm1
    ae85:	66 41 0f 6f df       	movdqa %xmm15,%xmm3
    ae8a:	66 0f db f0          	pand   %xmm0,%xmm6
    ae8e:	66 0f db df          	pand   %xmm7,%xmm3
    ae92:	66 0f 71 d2 08       	psrlw  $0x8,%xmm2
    ae97:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    ae9c:	66 0f 67 de          	packuswb %xmm6,%xmm3
    aea0:	66 41 0f 6f f7       	movdqa %xmm15,%xmm6
    aea5:	66 41 0f 67 d3       	packuswb %xmm11,%xmm2
    aeaa:	66 0f 70 db 08       	pshufd $0x8,%xmm3,%xmm3
    aeaf:	66 0f db f1          	pand   %xmm1,%xmm6
    aeb3:	66 0f 70 d2 08       	pshufd $0x8,%xmm2,%xmm2
    aeb8:	66 0f db e3          	pand   %xmm3,%xmm4
    aebc:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    aec1:	66 41 0f db d7       	pand   %xmm15,%xmm2
    aec6:	66 0f 71 d7 08       	psrlw  $0x8,%xmm7
    aecb:	66 0f 71 d3 08       	psrlw  $0x8,%xmm3
    aed0:	66 0f 67 f4          	packuswb %xmm4,%xmm6
    aed4:	f3 0f 7e 64 24 90    	movq   -0x70(%rsp),%xmm4
    aeda:	66 0f 70 f6 08       	pshufd $0x8,%xmm6,%xmm6
    aedf:	66 0f 71 d1 08       	psrlw  $0x8,%xmm1
    aee4:	66 0f 67 f8          	packuswb %xmm0,%xmm7
    aee8:	66 0f 6f c2          	movdqa %xmm2,%xmm0
    aeec:	66 0f 6f d6          	movdqa %xmm6,%xmm2
    aef0:	66 0f 67 cb          	packuswb %xmm3,%xmm1
    aef4:	66 41 0f 60 d6       	punpcklbw %xmm14,%xmm2
    aef9:	66 0f 70 ff 08       	pshufd $0x8,%xmm7,%xmm7
    aefe:	66 41 0f 60 f6       	punpcklbw %xmm14,%xmm6
    af03:	66 0f 6f da          	movdqa %xmm2,%xmm3
    af07:	66 41 0f 61 d2       	punpcklwd %xmm10,%xmm2
    af0c:	66 41 0f db ff       	pand   %xmm15,%xmm7
    af11:	66 41 0f 61 da       	punpcklwd %xmm10,%xmm3
    af16:	66 0f 70 d2 4e       	pshufd $0x4e,%xmm2,%xmm2
    af1b:	66 0f 70 f6 4e       	pshufd $0x4e,%xmm6,%xmm6
    af20:	66 0f fe e3          	paddd  %xmm3,%xmm4
    af24:	66 0f 67 c7          	packuswb %xmm7,%xmm0
    af28:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    af2d:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    af32:	66 0f fe e2          	paddd  %xmm2,%xmm4
    af36:	66 0f 6f d6          	movdqa %xmm6,%xmm2
    af3a:	66 41 0f 61 f2       	punpcklwd %xmm10,%xmm6
    af3f:	66 41 0f 61 d2       	punpcklwd %xmm10,%xmm2
    af44:	66 0f 70 f6 4e       	pshufd $0x4e,%xmm6,%xmm6
    af49:	66 0f fe e2          	paddd  %xmm2,%xmm4
    af4d:	66 0f 6f d0          	movdqa %xmm0,%xmm2
    af51:	66 41 0f 60 c6       	punpcklbw %xmm14,%xmm0
    af56:	66 41 0f 60 d6       	punpcklbw %xmm14,%xmm2
    af5b:	66 0f 70 c0 4e       	pshufd $0x4e,%xmm0,%xmm0
    af60:	66 0f 6f da          	movdqa %xmm2,%xmm3
    af64:	66 41 0f 61 d2       	punpcklwd %xmm10,%xmm2
    af69:	66 41 0f 61 da       	punpcklwd %xmm10,%xmm3
    af6e:	66 0f 70 d2 4e       	pshufd $0x4e,%xmm2,%xmm2
    af73:	66 0f fe f4          	paddd  %xmm4,%xmm6
    af77:	66 0f fe eb          	paddd  %xmm3,%xmm5
    af7b:	66 0f 7e f7          	movd   %xmm6,%edi
    af7f:	66 0f fe ea          	paddd  %xmm2,%xmm5
    af83:	66 0f 6f d0          	movdqa %xmm0,%xmm2
    af87:	66 41 0f 61 c2       	punpcklwd %xmm10,%xmm0
    af8c:	66 41 0f 61 d2       	punpcklwd %xmm10,%xmm2
    af91:	66 0f 70 c0 4e       	pshufd $0x4e,%xmm0,%xmm0
    af96:	66 0f fe ea          	paddd  %xmm2,%xmm5
    af9a:	66 0f 6f d1          	movdqa %xmm1,%xmm2
    af9e:	66 41 0f 60 ce       	punpcklbw %xmm14,%xmm1
    afa3:	66 41 0f 60 d6       	punpcklbw %xmm14,%xmm2
    afa8:	66 0f 70 c9 4e       	pshufd $0x4e,%xmm1,%xmm1
    afad:	66 0f 6f da          	movdqa %xmm2,%xmm3
    afb1:	66 41 0f 61 d2       	punpcklwd %xmm10,%xmm2
    afb6:	66 41 0f 61 da       	punpcklwd %xmm10,%xmm3
    afbb:	66 0f 70 d2 4e       	pshufd $0x4e,%xmm2,%xmm2
    afc0:	66 0f fe c5          	paddd  %xmm5,%xmm0
    afc4:	66 44 0f fe c3       	paddd  %xmm3,%xmm8
    afc9:	66 0f 7e c6          	movd   %xmm0,%esi
    afcd:	66 0f 70 f8 e5       	pshufd $0xe5,%xmm0,%xmm7
    afd2:	66 44 0f fe c2       	paddd  %xmm2,%xmm8
    afd7:	66 0f 6f d1          	movdqa %xmm1,%xmm2
    afdb:	66 41 0f 61 ca       	punpcklwd %xmm10,%xmm1
    afe0:	66 41 0f 61 d2       	punpcklwd %xmm10,%xmm2
    afe5:	66 0f 70 c9 4e       	pshufd $0x4e,%xmm1,%xmm1
    afea:	66 44 0f fe c2       	paddd  %xmm2,%xmm8
    afef:	66 41 0f fe c8       	paddd  %xmm8,%xmm1
    aff4:	66 0f 7e c9          	movd   %xmm1,%ecx
    aff8:	66 0f 70 e9 e5       	pshufd $0xe5,%xmm1,%xmm5
    affd:	66 0f 7e ea          	movd   %xmm5,%edx
    b001:	66 0f 70 ee e5       	pshufd $0xe5,%xmm6,%xmm5
    b006:	01 ca                	add    %ecx,%edx
    b008:	66 0f 7e f9          	movd   %xmm7,%ecx
    b00c:	01 f1                	add    %esi,%ecx
    b00e:	66 0f 7e ee          	movd   %xmm5,%esi
    b012:	44 01 da             	add    %r11d,%edx
    b015:	01 fe                	add    %edi,%esi
    b017:	01 d9                	add    %ebx,%ecx
    b019:	01 c6                	add    %eax,%esi
    b01b:	42 8d 3c 95 00 00 00 	lea    0x0(,%r10,4),%edi
    b022:	00 
    b023:	4c 63 cf             	movslq %edi,%r9
    b026:	47 0f b6 5c 08 02    	movzbl 0x2(%r8,%r9,1),%r11d
    b02c:	43 0f b6 04 08       	movzbl (%r8,%r9,1),%eax
    b031:	43 0f b6 5c 08 01    	movzbl 0x1(%r8,%r9,1),%ebx
    b037:	41 01 d3             	add    %edx,%r11d
    b03a:	41 8d 52 01          	lea    0x1(%r10),%edx
    b03e:	01 f0                	add    %esi,%eax
    b040:	01 cb                	add    %ecx,%ebx
    b042:	41 39 d7             	cmp    %edx,%r15d
    b045:	0f 8e 15 01 00 00    	jle    b160 <convert_adaptive_job+0x1210>
    b04b:	8d 57 04             	lea    0x4(%rdi),%edx
    b04e:	48 63 d2             	movslq %edx,%rdx
    b051:	41 0f b6 0c 10       	movzbl (%r8,%rdx,1),%ecx
    b056:	01 c8                	add    %ecx,%eax
    b058:	41 0f b6 4c 10 01    	movzbl 0x1(%r8,%rdx,1),%ecx
    b05e:	41 0f b6 54 10 02    	movzbl 0x2(%r8,%rdx,1),%edx
    b064:	41 01 d3             	add    %edx,%r11d
    b067:	41 8d 52 02          	lea    0x2(%r10),%edx
    b06b:	01 cb                	add    %ecx,%ebx
    b06d:	41 39 d7             	cmp    %edx,%r15d
    b070:	0f 8e ea 00 00 00    	jle    b160 <convert_adaptive_job+0x1210>
    b076:	8d 57 08             	lea    0x8(%rdi),%edx
    b079:	48 63 d2             	movslq %edx,%rdx
    b07c:	41 0f b6 0c 10       	movzbl (%r8,%rdx,1),%ecx
    b081:	01 c8                	add    %ecx,%eax
    b083:	41 0f b6 4c 10 01    	movzbl 0x1(%r8,%rdx,1),%ecx
    b089:	41 0f b6 54 10 02    	movzbl 0x2(%r8,%rdx,1),%edx
    b08f:	41 01 d3             	add    %edx,%r11d
    b092:	41 8d 52 03          	lea    0x3(%r10),%edx
    b096:	01 cb                	add    %ecx,%ebx
    b098:	41 39 d7             	cmp    %edx,%r15d
    b09b:	0f 8e bf 00 00 00    	jle    b160 <convert_adaptive_job+0x1210>
    b0a1:	8d 57 0c             	lea    0xc(%rdi),%edx
    b0a4:	48 63 d2             	movslq %edx,%rdx
    b0a7:	41 0f b6 0c 10       	movzbl (%r8,%rdx,1),%ecx
    b0ac:	01 c8                	add    %ecx,%eax
    b0ae:	41 0f b6 4c 10 01    	movzbl 0x1(%r8,%rdx,1),%ecx
    b0b4:	41 0f b6 54 10 02    	movzbl 0x2(%r8,%rdx,1),%edx
    b0ba:	41 01 d3             	add    %edx,%r11d
    b0bd:	41 8d 52 04          	lea    0x4(%r10),%edx
    b0c1:	01 cb                	add    %ecx,%ebx
    b0c3:	41 39 d7             	cmp    %edx,%r15d
    b0c6:	0f 8e 94 00 00 00    	jle    b160 <convert_adaptive_job+0x1210>
    b0cc:	8d 57 10             	lea    0x10(%rdi),%edx
    b0cf:	48 63 d2             	movslq %edx,%rdx
    b0d2:	41 0f b6 0c 10       	movzbl (%r8,%rdx,1),%ecx
    b0d7:	01 c8                	add    %ecx,%eax
    b0d9:	41 0f b6 4c 10 01    	movzbl 0x1(%r8,%rdx,1),%ecx
    b0df:	41 0f b6 54 10 02    	movzbl 0x2(%r8,%rdx,1),%edx
    b0e5:	41 01 d3             	add    %edx,%r11d
    b0e8:	41 8d 52 05          	lea    0x5(%r10),%edx
    b0ec:	01 cb                	add    %ecx,%ebx
    b0ee:	41 39 d7             	cmp    %edx,%r15d
    b0f1:	7e 6d                	jle    b160 <convert_adaptive_job+0x1210>
    b0f3:	8d 57 14             	lea    0x14(%rdi),%edx
    b0f6:	48 63 d2             	movslq %edx,%rdx
    b0f9:	41 0f b6 0c 10       	movzbl (%r8,%rdx,1),%ecx
    b0fe:	01 c8                	add    %ecx,%eax
    b100:	41 0f b6 4c 10 01    	movzbl 0x1(%r8,%rdx,1),%ecx
    b106:	41 0f b6 54 10 02    	movzbl 0x2(%r8,%rdx,1),%edx
    b10c:	41 01 d3             	add    %edx,%r11d
    b10f:	41 8d 52 06          	lea    0x6(%r10),%edx
    b113:	01 cb                	add    %ecx,%ebx
    b115:	41 39 d7             	cmp    %edx,%r15d
    b118:	7e 46                	jle    b160 <convert_adaptive_job+0x1210>
    b11a:	8d 57 18             	lea    0x18(%rdi),%edx
    b11d:	41 83 c2 07          	add    $0x7,%r10d
    b121:	48 63 d2             	movslq %edx,%rdx
    b124:	41 0f b6 0c 10       	movzbl (%r8,%rdx,1),%ecx
    b129:	01 c8                	add    %ecx,%eax
    b12b:	41 0f b6 4c 10 01    	movzbl 0x1(%r8,%rdx,1),%ecx
    b131:	41 0f b6 54 10 02    	movzbl 0x2(%r8,%rdx,1),%edx
    b137:	01 cb                	add    %ecx,%ebx
    b139:	41 01 d3             	add    %edx,%r11d
    b13c:	45 39 d7             	cmp    %r10d,%r15d
    b13f:	7e 1f                	jle    b160 <convert_adaptive_job+0x1210>
    b141:	8d 57 1c             	lea    0x1c(%rdi),%edx
    b144:	48 63 d2             	movslq %edx,%rdx
    b147:	41 0f b6 0c 10       	movzbl (%r8,%rdx,1),%ecx
    b14c:	01 c8                	add    %ecx,%eax
    b14e:	41 0f b6 4c 10 01    	movzbl 0x1(%r8,%rdx,1),%ecx
    b154:	41 0f b6 54 10 02    	movzbl 0x2(%r8,%rdx,1),%edx
    b15a:	01 cb                	add    %ecx,%ebx
    b15c:	41 01 d3             	add    %edx,%r11d
    b15f:	90                   	nop
    b160:	48 8b 7c 24 b0       	mov    -0x50(%rsp),%rdi
    b165:	41 83 c4 01          	add    $0x1,%r12d
    b169:	49 01 f8             	add    %rdi,%r8
    b16c:	45 39 e7             	cmp    %r12d,%r15d
    b16f:	0f 85 ab fa ff ff    	jne    ac20 <convert_adaptive_job+0xcd0>
    b175:	44 8b 74 24 68       	mov    0x68(%rsp),%r14d
    b17a:	99                   	cltd
    b17b:	8b 4c 24 c8          	mov    -0x38(%rsp),%ecx
    b17f:	44 8b 4c 24 d8       	mov    -0x28(%rsp),%r9d
    b184:	8b 7c 24 f0          	mov    -0x10(%rsp),%edi
    b188:	41 f7 fe             	idiv   %r14d
    b18b:	8b 74 24 f8          	mov    -0x8(%rsp),%esi
    b18f:	41 89 c0             	mov    %eax,%r8d
    b192:	89 d8                	mov    %ebx,%eax
    b194:	44 01 44 24 18       	add    %r8d,0x18(%rsp)
    b199:	99                   	cltd
    b19a:	41 f7 fe             	idiv   %r14d
    b19d:	89 c3                	mov    %eax,%ebx
    b19f:	44 89 d8             	mov    %r11d,%eax
    b1a2:	01 5c 24 10          	add    %ebx,0x10(%rsp)
    b1a6:	99                   	cltd
    b1a7:	41 f7 fe             	idiv   %r14d
    b1aa:	69 d3 9d 00 00 00    	imul   $0x9d,%ebx,%edx
    b1b0:	01 44 24 08          	add    %eax,0x8(%rsp)
    b1b4:	44 6b d8 2f          	imul   $0x2f,%eax,%r11d
    b1b8:	44 01 da             	add    %r11d,%edx
    b1bb:	45 89 c3             	mov    %r8d,%r11d
    b1be:	41 c1 e3 04          	shl    $0x4,%r11d
    b1c2:	42 8d 94 1a 80 00 00 	lea    0x80(%rdx,%r11,1),%edx
    b1c9:	00 
    b1ca:	c1 fa 08             	sar    $0x8,%edx
    b1cd:	83 c2 10             	add    $0x10,%edx
    b1d0:	83 f9 01             	cmp    $0x1,%ecx
    b1d3:	0f 8f 91 1e 00 00    	jg     d06a <convert_adaptive_job+0x311a>
    b1d9:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
    b1de:	48 63 c7             	movslq %edi,%rax
    b1e1:	83 c1 01             	add    $0x1,%ecx
    b1e4:	88 14 03             	mov    %dl,(%rbx,%rax,1)
    b1e7:	e9 b8 f9 ff ff       	jmp    aba4 <convert_adaptive_job+0xc54>
    b1ec:	48 63 db             	movslq %ebx,%rbx
    b1ef:	48 89 5c 24 f0       	mov    %rbx,-0x10(%rsp)
    b1f4:	48 89 d8             	mov    %rbx,%rax
    b1f7:	8d 14 1b             	lea    (%rbx,%rbx,1),%edx
    b1fa:	39 cb                	cmp    %ecx,%ebx
    b1fc:	0f 8d 6b f5 ff ff    	jge    a76d <convert_adaptive_job+0x81d>
    b202:	f3 0f 7e 0d 76 40 00 	movq   0x4076(%rip),%xmm1        # f280 <__PRETTY_FUNCTION__.4+0xd>
    b209:	00 
    b20a:	66 0f 6f 15 6e 40 00 	movdqa 0x406e(%rip),%xmm2        # f280 <__PRETTY_FUNCTION__.4+0xd>
    b211:	00 
    b212:	66 0f ef f6          	pxor   %xmm6,%xmm6
    b216:	48 8b 5c 24 e8       	mov    -0x18(%rsp),%rbx
    b21b:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    b21f:	48 85 ff             	test   %rdi,%rdi
    b222:	74 1a                	je     b23e <convert_adaptive_job+0x12ee>
    b224:	89 c6                	mov    %eax,%esi
    b226:	c1 fe 03             	sar    $0x3,%esi
    b229:	48 63 f6             	movslq %esi,%rsi
    b22c:	0f b6 3c 37          	movzbl (%rdi,%rsi,1),%edi
    b230:	89 c6                	mov    %eax,%esi
    b232:	83 e6 07             	and    $0x7,%esi
    b235:	0f a3 f7             	bt     %esi,%edi
    b238:	0f 83 44 1c 00 00    	jae    ce82 <convert_adaptive_job+0x2f32>
    b23e:	48 8b 5c 24 e8       	mov    -0x18(%rsp),%rbx
    b243:	48 8b 73 40          	mov    0x40(%rbx),%rsi
    b247:	48 63 4b 24          	movslq 0x24(%rbx),%rcx
    b24b:	48 85 f6             	test   %rsi,%rsi
    b24e:	0f 84 b8 1d 00 00    	je     d00c <convert_adaptive_job+0x30bc>
    b254:	48 8b 7c 24 f0       	mov    -0x10(%rsp),%rdi
    b259:	48 c1 e7 04          	shl    $0x4,%rdi
    b25d:	48 01 fe             	add    %rdi,%rsi
    b260:	44 8b 76 04          	mov    0x4(%rsi),%r14d
    b264:	44 8b 5e 08          	mov    0x8(%rsi),%r11d
    b268:	8b 1e                	mov    (%rsi),%ebx
    b26a:	8b 76 0c             	mov    0xc(%rsi),%esi
    b26d:	44 89 74 24 a8       	mov    %r14d,-0x58(%rsp)
    b272:	89 74 24 f8          	mov    %esi,-0x8(%rsp)
    b276:	44 29 de             	sub    %r11d,%esi
    b279:	89 f7                	mov    %esi,%edi
    b27b:	83 fe 7f             	cmp    $0x7f,%esi
    b27e:	0f 8e 96 1d 00 00    	jle    d01a <convert_adaptive_job+0x30ca>
    b284:	48 63 f2             	movslq %edx,%rsi
    b287:	45 89 f0             	mov    %r14d,%r8d
    b28a:	48 89 34 24          	mov    %rsi,(%rsp)
    b28e:	8d 72 01             	lea    0x1(%rdx),%esi
    b291:	41 29 d8             	sub    %ebx,%r8d
    b294:	48 63 f6             	movslq %esi,%rsi
    b297:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    b29c:	44 89 c6             	mov    %r8d,%esi
    b29f:	c1 ee 1f             	shr    $0x1f,%esi
    b2a2:	44 01 c6             	add    %r8d,%esi
    b2a5:	d1 fe                	sar    $1,%esi
    b2a7:	39 f7                	cmp    %esi,%edi
    b2a9:	40 0f 9d c6          	setge  %sil
    b2ad:	45 0f 4c de          	cmovl  %r14d,%r11d
    b2b1:	40 0f b6 f6          	movzbl %sil,%esi
    b2b5:	89 74 24 b8          	mov    %esi,-0x48(%rsp)
    b2b9:	c7 44 24 74 00 00 00 	movl   $0x0,0x74(%rsp)
    b2c0:	00 
    b2c1:	89 84 24 10 01 00 00 	mov    %eax,0x110(%rsp)
    b2c8:	89 94 24 14 01 00 00 	mov    %edx,0x114(%rsp)
    b2cf:	48 8b 54 24 e8       	mov    -0x18(%rsp),%rdx
    b2d4:	48 8b 34 24          	mov    (%rsp),%rsi
    b2d8:	48 63 42 20          	movslq 0x20(%rdx),%rax
    b2dc:	48 89 f7             	mov    %rsi,%rdi
    b2df:	4c 8b 02             	mov    (%rdx),%r8
    b2e2:	48 0f af f1          	imul   %rcx,%rsi
    b2e6:	48 0f af f8          	imul   %rax,%rdi
    b2ea:	49 89 f2             	mov    %rsi,%r10
    b2ed:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    b2f2:	4c 01 c7             	add    %r8,%rdi
    b2f5:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
    b2fa:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    b2ff:	48 0f af c7          	imul   %rdi,%rax
    b303:	48 0f af f9          	imul   %rcx,%rdi
    b307:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    b30c:	4c 01 c0             	add    %r8,%rax
    b30f:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    b314:	48 89 d0             	mov    %rdx,%rax
    b317:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    b31b:	48 8b 68 10          	mov    0x10(%rax),%rbp
    b31f:	48 8b 44 24 f0       	mov    -0x10(%rsp),%rax
    b324:	48 89 7c 24 90       	mov    %rdi,-0x70(%rsp)
    b329:	4c 8d 24 32          	lea    (%rdx,%rsi,1),%r12
    b32d:	4c 8d 2c 3a          	lea    (%rdx,%rdi,1),%r13
    b331:	48 0f af c1          	imul   %rcx,%rax
    b335:	48 89 44 24 b0       	mov    %rax,-0x50(%rsp)
    b33a:	41 39 db             	cmp    %ebx,%r11d
    b33d:	0f 8e e2 19 00 00    	jle    cd25 <convert_adaptive_job+0x2dd5>
    b343:	41 8d 43 ff          	lea    -0x1(%r11),%eax
    b347:	29 d8                	sub    %ebx,%eax
    b349:	89 44 24 58          	mov    %eax,0x58(%rsp)
    b34d:	83 f8 0f             	cmp    $0xf,%eax
    b350:	0f 86 45 1b 00 00    	jbe    ce9b <convert_adaptive_job+0x2f4b>
    b356:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    b35b:	41 89 c1             	mov    %eax,%r9d
    b35e:	48 63 c3             	movslq %ebx,%rax
    b361:	48 8d 34 85 00 00 00 	lea    0x0(,%rax,4),%rsi
    b368:	00 
    b369:	41 d1 e9             	shr    $1,%r9d
    b36c:	49 01 c2             	add    %rax,%r10
    b36f:	48 89 74 24 78       	mov    %rsi,0x78(%rsp)
    b374:	49 01 f6             	add    %rsi,%r14
    b377:	41 8d 71 01          	lea    0x1(%r9),%esi
    b37b:	4c 8d 3c f5 00 00 00 	lea    0x0(,%rsi,8),%r15
    b382:	00 
    b383:	48 01 f6             	add    %rsi,%rsi
    b386:	4c 89 54 24 68       	mov    %r10,0x68(%rsp)
    b38b:	4b 8d 7c 37 ff       	lea    -0x1(%r15,%r14,1),%rdi
    b390:	4c 89 7c 24 c0       	mov    %r15,-0x40(%rsp)
    b395:	4d 01 c6             	add    %r8,%r14
    b398:	4d 8d 3c 38          	lea    (%r8,%rdi,1),%r15
    b39c:	4a 8d 3c 16          	lea    (%rsi,%r10,1),%rdi
    b3a0:	4c 89 74 24 98       	mov    %r14,-0x68(%rsp)
    b3a5:	4c 89 7c 24 d8       	mov    %r15,-0x28(%rsp)
    b3aa:	4e 8d 3c 12          	lea    (%rdx,%r10,1),%r15
    b3ae:	4c 8d 14 3a          	lea    (%rdx,%rdi,1),%r10
    b3b2:	4c 89 54 24 48       	mov    %r10,0x48(%rsp)
    b3b7:	4c 8b 54 24 90       	mov    -0x70(%rsp),%r10
    b3bc:	49 01 c2             	add    %rax,%r10
    b3bf:	49 8d 3c 32          	lea    (%r10,%rsi,1),%rdi
    b3c3:	4e 8d 34 12          	lea    (%rdx,%r10,1),%r14
    b3c7:	4c 89 54 24 40       	mov    %r10,0x40(%rsp)
    b3cc:	4c 89 74 24 c8       	mov    %r14,-0x38(%rsp)
    b3d1:	4c 8d 34 3a          	lea    (%rdx,%rdi,1),%r14
    b3d5:	48 8b 7c 24 b0       	mov    -0x50(%rsp),%rdi
    b3da:	48 01 c7             	add    %rax,%rdi
    b3dd:	48 01 fe             	add    %rdi,%rsi
    b3e0:	4c 8d 54 3d 00       	lea    0x0(%rbp,%rdi,1),%r10
    b3e5:	48 89 bc 24 08 01 00 	mov    %rdi,0x108(%rsp)
    b3ec:	00 
    b3ed:	48 8d 7c 35 00       	lea    0x0(%rbp,%rsi,1),%rdi
    b3f2:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
    b3f7:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
    b3fc:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
    b401:	48 01 fe             	add    %rdi,%rsi
    b404:	49 8d 3c 30          	lea    (%r8,%rsi,1),%rdi
    b408:	48 89 7c 24 90       	mov    %rdi,-0x70(%rsp)
    b40d:	48 8b 7c 24 c0       	mov    -0x40(%rsp),%rdi
    b412:	48 8d 74 3e ff       	lea    -0x1(%rsi,%rdi,1),%rsi
    b417:	49 8d 3c 30          	lea    (%r8,%rsi,1),%rdi
    b41b:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
    b420:	48 89 7c 24 c0       	mov    %rdi,-0x40(%rsp)
    b425:	48 8d 7c 32 02       	lea    0x2(%rdx,%rsi,1),%rdi
    b42a:	4c 89 d6             	mov    %r10,%rsi
    b42d:	48 29 fe             	sub    %rdi,%rsi
    b430:	48 83 c6 01          	add    $0x1,%rsi
    b434:	48 83 fe 1e          	cmp    $0x1e,%rsi
    b438:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
    b43d:	0f 97 44 24 78       	seta   0x78(%rsp)
    b442:	48 8d 7c 32 02       	lea    0x2(%rdx,%rsi,1),%rdi
    b447:	4c 89 d6             	mov    %r10,%rsi
    b44a:	48 29 fe             	sub    %rdi,%rsi
    b44d:	48 83 c6 01          	add    $0x1,%rsi
    b451:	48 83 fe 1e          	cmp    $0x1e,%rsi
    b455:	40 0f 97 c6          	seta   %sil
    b459:	48 83 e9 01          	sub    $0x1,%rcx
    b45d:	40 22 74 24 78       	and    0x78(%rsp),%sil
    b462:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
    b467:	48 83 f9 1e          	cmp    $0x1e,%rcx
    b46b:	89 f7                	mov    %esi,%edi
    b46d:	48 8b 74 24 d8       	mov    -0x28(%rsp),%rsi
    b472:	0f 97 c1             	seta   %cl
    b475:	21 cf                	and    %ecx,%edi
    b477:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
    b47c:	48 39 4c 24 98       	cmp    %rcx,-0x68(%rsp)
    b481:	0f 93 c1             	setae  %cl
    b484:	49 39 f7             	cmp    %rsi,%r15
    b487:	40 0f 93 c6          	setae  %sil
    b48b:	09 f1                	or     %esi,%ecx
    b48d:	48 8b 74 24 d8       	mov    -0x28(%rsp),%rsi
    b492:	21 cf                	and    %ecx,%edi
    b494:	4c 39 74 24 98       	cmp    %r14,-0x68(%rsp)
    b499:	4c 8b 74 24 28       	mov    0x28(%rsp),%r14
    b49e:	0f 93 c1             	setae  %cl
    b4a1:	48 39 74 24 c8       	cmp    %rsi,-0x38(%rsp)
    b4a6:	40 0f 93 c6          	setae  %sil
    b4aa:	09 f1                	or     %esi,%ecx
    b4ac:	48 8b 74 24 d8       	mov    -0x28(%rsp),%rsi
    b4b1:	21 cf                	and    %ecx,%edi
    b4b3:	4c 39 74 24 98       	cmp    %r14,-0x68(%rsp)
    b4b8:	0f 93 c1             	setae  %cl
    b4bb:	49 39 f2             	cmp    %rsi,%r10
    b4be:	40 0f 93 c6          	setae  %sil
    b4c2:	09 f1                	or     %esi,%ecx
    b4c4:	21 cf                	and    %ecx,%edi
    b4c6:	48 8b 4c 24 c0       	mov    -0x40(%rsp),%rcx
    b4cb:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
    b4d0:	49 39 cf             	cmp    %rcx,%r15
    b4d3:	0f 93 c1             	setae  %cl
    b4d6:	4c 39 74 24 90       	cmp    %r14,-0x70(%rsp)
    b4db:	4c 8b 74 24 78       	mov    0x78(%rsp),%r14
    b4e0:	40 0f 93 c6          	setae  %sil
    b4e4:	09 f1                	or     %esi,%ecx
    b4e6:	48 8b 74 24 c0       	mov    -0x40(%rsp),%rsi
    b4eb:	21 cf                	and    %ecx,%edi
    b4ed:	4c 39 74 24 90       	cmp    %r14,-0x70(%rsp)
    b4f2:	0f 93 c1             	setae  %cl
    b4f5:	48 39 74 24 c8       	cmp    %rsi,-0x38(%rsp)
    b4fa:	40 0f 93 c6          	setae  %sil
    b4fe:	09 f1                	or     %esi,%ecx
    b500:	40 84 cf             	test   %cl,%dil
    b503:	0f 84 95 19 00 00    	je     ce9e <convert_adaptive_job+0x2f4e>
    b509:	48 8b 7c 24 c0       	mov    -0x40(%rsp),%rdi
    b50e:	4c 8b 74 24 28       	mov    0x28(%rsp),%r14
    b513:	4c 39 74 24 90       	cmp    %r14,-0x70(%rsp)
    b518:	40 0f 93 c6          	setae  %sil
    b51c:	49 39 fa             	cmp    %rdi,%r10
    b51f:	0f 93 c1             	setae  %cl
    b522:	40 08 f1             	or     %sil,%cl
    b525:	0f 84 73 19 00 00    	je     ce9e <convert_adaptive_job+0x2f4e>
    b52b:	8b 7c 24 58          	mov    0x58(%rsp),%edi
    b52f:	83 ff 1f             	cmp    $0x1f,%edi
    b532:	0f 86 06 1b 00 00    	jbe    d03e <convert_adaptive_job+0x30ee>
    b538:	c1 ef 05             	shr    $0x5,%edi
    b53b:	48 8b 4c 24 98       	mov    -0x68(%rsp),%rcx
    b540:	4c 8b 74 24 c8       	mov    -0x38(%rsp),%r14
    b545:	89 7c 24 c0          	mov    %edi,-0x40(%rsp)
    b549:	48 c1 e7 05          	shl    $0x5,%rdi
    b54d:	48 8b 74 24 90       	mov    -0x70(%rsp),%rsi
    b552:	48 89 7c 24 90       	mov    %rdi,-0x70(%rsp)
    b557:	31 ff                	xor    %edi,%edi
    b559:	f3 0f 6f 29          	movdqu (%rcx),%xmm5
    b55d:	f3 0f 6f 41 10       	movdqu 0x10(%rcx),%xmm0
    b562:	66 44 0f 6f ca       	movdqa %xmm2,%xmm9
    b567:	66 44 0f 6f c2       	movdqa %xmm2,%xmm8
    b56c:	f3 0f 6f 61 20       	movdqu 0x20(%rcx),%xmm4
    b571:	f3 0f 6f 59 40       	movdqu 0x40(%rcx),%xmm3
    b576:	48 83 ee 80          	sub    $0xffffffffffffff80,%rsi
    b57a:	48 83 e9 80          	sub    $0xffffffffffffff80,%rcx
    b57e:	66 0f db c2          	pand   %xmm2,%xmm0
    b582:	66 0f db ea          	pand   %xmm2,%xmm5
    b586:	f3 0f 6f 79 f0       	movdqu -0x10(%rcx),%xmm7
    b58b:	f3 44 0f 6f 51 f0    	movdqu -0x10(%rcx),%xmm10
    b591:	66 0f 67 e8          	packuswb %xmm0,%xmm5
    b595:	f3 0f 6f 41 b0       	movdqu -0x50(%rcx),%xmm0
    b59a:	66 0f db e2          	pand   %xmm2,%xmm4
    b59e:	66 0f db da          	pand   %xmm2,%xmm3
    b5a2:	66 0f db fa          	pand   %xmm2,%xmm7
    b5a6:	66 44 0f db cd       	pand   %xmm5,%xmm9
    b5ab:	66 44 0f 6f 2d 7c 3d 	movdqa 0x3d7c(%rip),%xmm13        # f330 <__PRETTY_FUNCTION__.4+0xbd>
    b5b2:	00 00 
    b5b4:	66 44 0f 6f 1d 63 3d 	movdqa 0x3d63(%rip),%xmm11        # f320 <__PRETTY_FUNCTION__.4+0xad>
    b5bb:	00 00 
    b5bd:	66 0f 71 d5 08       	psrlw  $0x8,%xmm5
    b5c2:	66 41 0f 71 d2 08    	psrlw  $0x8,%xmm10
    b5c8:	66 0f db c2          	pand   %xmm2,%xmm0
    b5cc:	66 0f 67 e0          	packuswb %xmm0,%xmm4
    b5d0:	f3 0f 6f 41 d0       	movdqu -0x30(%rcx),%xmm0
    b5d5:	66 0f db c2          	pand   %xmm2,%xmm0
    b5d9:	66 0f 67 d8          	packuswb %xmm0,%xmm3
    b5dd:	f3 0f 6f 41 e0       	movdqu -0x20(%rcx),%xmm0
    b5e2:	66 44 0f db c3       	pand   %xmm3,%xmm8
    b5e7:	66 0f 71 d3 08       	psrlw  $0x8,%xmm3
    b5ec:	66 0f db c2          	pand   %xmm2,%xmm0
    b5f0:	66 0f 67 c7          	packuswb %xmm7,%xmm0
    b5f4:	66 0f 6f fa          	movdqa %xmm2,%xmm7
    b5f8:	66 0f db fc          	pand   %xmm4,%xmm7
    b5fc:	66 0f 71 d4 08       	psrlw  $0x8,%xmm4
    b601:	66 0f 67 ec          	packuswb %xmm4,%xmm5
    b605:	66 0f 6f e2          	movdqa %xmm2,%xmm4
    b609:	66 44 0f 67 cf       	packuswb %xmm7,%xmm9
    b60e:	66 0f db e0          	pand   %xmm0,%xmm4
    b612:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    b617:	66 0f 6f fb          	movdqa %xmm3,%xmm7
    b61b:	f3 0f 6f 59 b0       	movdqu -0x50(%rcx),%xmm3
    b620:	66 44 0f 67 c4       	packuswb %xmm4,%xmm8
    b625:	66 0f 67 f8          	packuswb %xmm0,%xmm7
    b629:	f3 0f 6f 61 80       	movdqu -0x80(%rcx),%xmm4
    b62e:	f3 0f 6f 41 90       	movdqu -0x70(%rcx),%xmm0
    b633:	66 0f 71 d3 08       	psrlw  $0x8,%xmm3
    b638:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    b63d:	66 0f 71 d4 08       	psrlw  $0x8,%xmm4
    b642:	66 0f 67 e0          	packuswb %xmm0,%xmm4
    b646:	f3 0f 6f 41 a0       	movdqu -0x60(%rcx),%xmm0
    b64b:	66 0f db e2          	pand   %xmm2,%xmm4
    b64f:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    b654:	66 0f 67 c3          	packuswb %xmm3,%xmm0
    b658:	f3 0f 6f 59 c0       	movdqu -0x40(%rcx),%xmm3
    b65d:	66 0f db c2          	pand   %xmm2,%xmm0
    b661:	66 0f 67 e0          	packuswb %xmm0,%xmm4
    b665:	f3 0f 6f 41 d0       	movdqu -0x30(%rcx),%xmm0
    b66a:	66 0f 71 d3 08       	psrlw  $0x8,%xmm3
    b66f:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    b674:	66 0f 67 d8          	packuswb %xmm0,%xmm3
    b678:	f3 0f 6f 41 e0       	movdqu -0x20(%rcx),%xmm0
    b67d:	66 0f db da          	pand   %xmm2,%xmm3
    b681:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    b686:	66 41 0f 67 c2       	packuswb %xmm10,%xmm0
    b68b:	66 44 0f 6f d2       	movdqa %xmm2,%xmm10
    b690:	66 0f db c2          	pand   %xmm2,%xmm0
    b694:	66 45 0f db d1       	pand   %xmm9,%xmm10
    b699:	66 0f 67 d8          	packuswb %xmm0,%xmm3
    b69d:	66 0f 6f c2          	movdqa %xmm2,%xmm0
    b6a1:	66 41 0f db c0       	pand   %xmm8,%xmm0
    b6a6:	66 41 0f 71 d0 08    	psrlw  $0x8,%xmm8
    b6ac:	66 44 0f 67 d0       	packuswb %xmm0,%xmm10
    b6b1:	66 41 0f 6f c1       	movdqa %xmm9,%xmm0
    b6b6:	66 44 0f 6f ca       	movdqa %xmm2,%xmm9
    b6bb:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    b6c0:	66 44 0f db cb       	pand   %xmm3,%xmm9
    b6c5:	66 41 0f 67 c0       	packuswb %xmm8,%xmm0
    b6ca:	66 0f 71 d3 08       	psrlw  $0x8,%xmm3
    b6cf:	66 44 0f 6f c2       	movdqa %xmm2,%xmm8
    b6d4:	66 44 0f db c4       	pand   %xmm4,%xmm8
    b6d9:	66 0f 71 d4 08       	psrlw  $0x8,%xmm4
    b6de:	66 45 0f 67 c1       	packuswb %xmm9,%xmm8
    b6e3:	66 0f 67 e3          	packuswb %xmm3,%xmm4
    b6e7:	66 44 0f 6f ca       	movdqa %xmm2,%xmm9
    b6ec:	66 0f 6f da          	movdqa %xmm2,%xmm3
    b6f0:	66 44 0f db cd       	pand   %xmm5,%xmm9
    b6f5:	66 0f db df          	pand   %xmm7,%xmm3
    b6f9:	66 0f 71 d5 08       	psrlw  $0x8,%xmm5
    b6fe:	66 44 0f 67 cb       	packuswb %xmm3,%xmm9
    b703:	66 0f 71 d7 08       	psrlw  $0x8,%xmm7
    b708:	66 0f 6f 1d 10 3c 00 	movdqa 0x3c10(%rip),%xmm3        # f320 <__PRETTY_FUNCTION__.4+0xad>
    b70f:	00 
    b710:	66 0f 67 ef          	packuswb %xmm7,%xmm5
    b714:	66 45 0f 6f e1       	movdqa %xmm9,%xmm12
    b719:	66 41 0f 6f f8       	movdqa %xmm8,%xmm7
    b71e:	66 0f 60 fe          	punpcklbw %xmm6,%xmm7
    b722:	66 44 0f 60 e6       	punpcklbw %xmm6,%xmm12
    b727:	66 44 0f 68 c6       	punpckhbw %xmm6,%xmm8
    b72c:	66 45 0f d5 ec       	pmullw %xmm12,%xmm13
    b731:	66 0f d5 df          	pmullw %xmm7,%xmm3
    b735:	44 0f 29 64 24 c8    	movaps %xmm12,-0x38(%rsp)
    b73b:	66 44 0f 68 ce       	punpckhbw %xmm6,%xmm9
    b740:	0f 29 7c 24 98       	movaps %xmm7,-0x68(%rsp)
    b745:	66 0f 6f 3d 73 3b 00 	movdqa 0x3b73(%rip),%xmm7        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    b74c:	00 
    b74d:	44 0f 29 44 24 d8    	movaps %xmm8,-0x28(%rsp)
    b753:	44 0f 29 4c 24 28    	movaps %xmm9,0x28(%rsp)
    b759:	66 41 0f fd dd       	paddw  %xmm13,%xmm3
    b75e:	66 45 0f 6f ea       	movdqa %xmm10,%xmm13
    b763:	66 44 0f 68 d6       	punpckhbw %xmm6,%xmm10
    b768:	66 44 0f 60 ee       	punpcklbw %xmm6,%xmm13
    b76d:	66 45 0f 6f e5       	movdqa %xmm13,%xmm12
    b772:	66 44 0f 6f 2d 95 3b 	movdqa 0x3b95(%rip),%xmm13        # f310 <__PRETTY_FUNCTION__.4+0x9d>
    b779:	00 00 
    b77b:	66 45 0f d5 ec       	pmullw %xmm12,%xmm13
    b780:	66 41 0f fd fd       	paddw  %xmm13,%xmm7
    b785:	66 44 0f 6f 2d 92 3b 	movdqa 0x3b92(%rip),%xmm13        # f320 <__PRETTY_FUNCTION__.4+0xad>
    b78c:	00 00 
    b78e:	66 0f fd df          	paddw  %xmm7,%xmm3
    b792:	66 45 0f d5 e8       	pmullw %xmm8,%xmm13
    b797:	66 0f 71 d3 08       	psrlw  $0x8,%xmm3
    b79c:	66 44 0f 6f 05 1b 3b 	movdqa 0x3b1b(%rip),%xmm8        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    b7a3:	00 00 
    b7a5:	66 0f db da          	pand   %xmm2,%xmm3
    b7a9:	66 41 0f 6f fd       	movdqa %xmm13,%xmm7
    b7ae:	66 44 0f 6f 2d 79 3b 	movdqa 0x3b79(%rip),%xmm13        # f330 <__PRETTY_FUNCTION__.4+0xbd>
    b7b5:	00 00 
    b7b7:	66 45 0f d5 e9       	pmullw %xmm9,%xmm13
    b7bc:	66 41 0f fd fd       	paddw  %xmm13,%xmm7
    b7c1:	66 44 0f 6f 2d 46 3b 	movdqa 0x3b46(%rip),%xmm13        # f310 <__PRETTY_FUNCTION__.4+0x9d>
    b7c8:	00 00 
    b7ca:	66 45 0f d5 ea       	pmullw %xmm10,%xmm13
    b7cf:	66 45 0f fd c5       	paddw  %xmm13,%xmm8
    b7d4:	66 44 0f 6f ec       	movdqa %xmm4,%xmm13
    b7d9:	66 0f 68 e6          	punpckhbw %xmm6,%xmm4
    b7dd:	66 44 0f 60 ee       	punpcklbw %xmm6,%xmm13
    b7e2:	66 41 0f fd f8       	paddw  %xmm8,%xmm7
    b7e7:	66 45 0f d5 dd       	pmullw %xmm13,%xmm11
    b7ec:	66 0f 71 d7 08       	psrlw  $0x8,%xmm7
    b7f1:	44 0f 29 6c 24 48    	movaps %xmm13,0x48(%rsp)
    b7f7:	66 0f db fa          	pand   %xmm2,%xmm7
    b7fb:	66 0f 67 df          	packuswb %xmm7,%xmm3
    b7ff:	66 0f fc 1d a9 3a 00 	paddb  0x3aa9(%rip),%xmm3        # f2b0 <__PRETTY_FUNCTION__.4+0x3d>
    b806:	00 
    b807:	66 41 0f 6f fb       	movdqa %xmm11,%xmm7
    b80c:	66 44 0f 6f dd       	movdqa %xmm5,%xmm11
    b811:	66 0f 68 ee          	punpckhbw %xmm6,%xmm5
    b815:	66 44 0f 60 de       	punpcklbw %xmm6,%xmm11
    b81a:	44 0f 29 5c 24 58    	movaps %xmm11,0x58(%rsp)
    b820:	66 44 0f 6f 35 07 3b 	movdqa 0x3b07(%rip),%xmm14        # f330 <__PRETTY_FUNCTION__.4+0xbd>
    b827:	00 00 
    b829:	66 44 0f 6f 05 8e 3a 	movdqa 0x3a8e(%rip),%xmm8        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    b830:	00 00 
    b832:	0f 29 64 24 78       	movaps %xmm4,0x78(%rsp)
    b837:	66 45 0f d5 f3       	pmullw %xmm11,%xmm14
    b83c:	0f 29 ac 24 88 00 00 	movaps %xmm5,0x88(%rsp)
    b843:	00 
    b844:	66 41 0f fd fe       	paddw  %xmm14,%xmm7
    b849:	66 44 0f 6f f0       	movdqa %xmm0,%xmm14
    b84e:	66 0f 68 c6          	punpckhbw %xmm6,%xmm0
    b852:	66 44 0f 60 f6       	punpcklbw %xmm6,%xmm14
    b857:	66 45 0f 6f de       	movdqa %xmm14,%xmm11
    b85c:	66 44 0f 6f 35 ab 3a 	movdqa 0x3aab(%rip),%xmm14        # f310 <__PRETTY_FUNCTION__.4+0x9d>
    b863:	00 00 
    b865:	66 45 0f d5 f3       	pmullw %xmm11,%xmm14
    b86a:	66 45 0f fd dc       	paddw  %xmm12,%xmm11
    b86f:	66 45 0f fd c6       	paddw  %xmm14,%xmm8
    b874:	66 44 0f 6f 35 a3 3a 	movdqa 0x3aa3(%rip),%xmm14        # f320 <__PRETTY_FUNCTION__.4+0xad>
    b87b:	00 00 
    b87d:	66 41 0f fd f8       	paddw  %xmm8,%xmm7
    b882:	66 44 0f d5 f4       	pmullw %xmm4,%xmm14
    b887:	66 0f 71 d7 08       	psrlw  $0x8,%xmm7
    b88c:	66 41 0f 6f e6       	movdqa %xmm14,%xmm4
    b891:	66 44 0f 6f 35 96 3a 	movdqa 0x3a96(%rip),%xmm14        # f330 <__PRETTY_FUNCTION__.4+0xbd>
    b898:	00 00 
    b89a:	66 44 0f d5 f5       	pmullw %xmm5,%xmm14
    b89f:	66 0f 6f 2d 19 3a 00 	movdqa 0x3a19(%rip),%xmm5        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    b8a6:	00 
    b8a7:	66 41 0f fd e6       	paddw  %xmm14,%xmm4
    b8ac:	66 44 0f 6f 35 5b 3a 	movdqa 0x3a5b(%rip),%xmm14        # f310 <__PRETTY_FUNCTION__.4+0x9d>
    b8b3:	00 00 
    b8b5:	66 44 0f d5 f0       	pmullw %xmm0,%xmm14
    b8ba:	66 41 0f fd c2       	paddw  %xmm10,%xmm0
    b8bf:	66 41 0f fd ee       	paddw  %xmm14,%xmm5
    b8c4:	66 44 0f 6f f7       	movdqa %xmm7,%xmm14
    b8c9:	66 0f fd e5          	paddw  %xmm5,%xmm4
    b8cd:	66 44 0f db f2       	pand   %xmm2,%xmm14
    b8d2:	66 0f 71 d4 08       	psrlw  $0x8,%xmm4
    b8d7:	66 41 0f 6f ee       	movdqa %xmm14,%xmm5
    b8dc:	66 44 0f 6f 35 cb 39 	movdqa 0x39cb(%rip),%xmm14        # f2b0 <__PRETTY_FUNCTION__.4+0x3d>
    b8e3:	00 00 
    b8e5:	66 0f db e2          	pand   %xmm2,%xmm4
    b8e9:	66 0f 67 ec          	packuswb %xmm4,%xmm5
    b8ed:	66 44 0f fc f5       	paddb  %xmm5,%xmm14
    b8f2:	66 41 0f 6f e6       	movdqa %xmm14,%xmm4
    b8f7:	66 44 0f 6f f3       	movdqa %xmm3,%xmm14
    b8fc:	66 44 0f 60 f4       	punpcklbw %xmm4,%xmm14
    b901:	66 0f 68 dc          	punpckhbw %xmm4,%xmm3
    b905:	45 0f 11 34 3f       	movups %xmm14,(%r15,%rdi,1)
    b90a:	66 44 0f 6f f2       	movdqa %xmm2,%xmm14
    b90f:	41 0f 11 5c 3f 10    	movups %xmm3,0x10(%r15,%rdi,1)
    b915:	f3 0f 6f 5e 80       	movdqu -0x80(%rsi),%xmm3
    b91a:	f3 44 0f 6f 7e e0    	movdqu -0x20(%rsi),%xmm15
    b920:	66 0f db da          	pand   %xmm2,%xmm3
    b924:	66 41 0f 71 d7 08    	psrlw  $0x8,%xmm15
    b92a:	66 0f 6f e3          	movdqa %xmm3,%xmm4
    b92e:	f3 0f 6f 5e 90       	movdqu -0x70(%rsi),%xmm3
    b933:	66 0f db da          	pand   %xmm2,%xmm3
    b937:	66 0f 67 e3          	packuswb %xmm3,%xmm4
    b93b:	f3 0f 6f 5e a0       	movdqu -0x60(%rsi),%xmm3
    b940:	66 0f db da          	pand   %xmm2,%xmm3
    b944:	66 44 0f 6f c3       	movdqa %xmm3,%xmm8
    b949:	f3 0f 6f 5e b0       	movdqu -0x50(%rsi),%xmm3
    b94e:	66 0f db da          	pand   %xmm2,%xmm3
    b952:	66 44 0f 67 c3       	packuswb %xmm3,%xmm8
    b957:	f3 0f 6f 5e c0       	movdqu -0x40(%rsi),%xmm3
    b95c:	66 45 0f db f0       	pand   %xmm8,%xmm14
    b961:	66 41 0f 71 d0 08    	psrlw  $0x8,%xmm8
    b967:	66 0f db da          	pand   %xmm2,%xmm3
    b96b:	66 0f 6f eb          	movdqa %xmm3,%xmm5
    b96f:	f3 0f 6f 5e d0       	movdqu -0x30(%rsi),%xmm3
    b974:	66 0f db da          	pand   %xmm2,%xmm3
    b978:	66 0f 67 eb          	packuswb %xmm3,%xmm5
    b97c:	f3 0f 6f 5e e0       	movdqu -0x20(%rsi),%xmm3
    b981:	66 0f db da          	pand   %xmm2,%xmm3
    b985:	66 0f 6f fb          	movdqa %xmm3,%xmm7
    b989:	f3 0f 6f 5e f0       	movdqu -0x10(%rsi),%xmm3
    b98e:	66 0f db da          	pand   %xmm2,%xmm3
    b992:	66 0f 67 fb          	packuswb %xmm3,%xmm7
    b996:	66 0f 6f da          	movdqa %xmm2,%xmm3
    b99a:	66 0f db dc          	pand   %xmm4,%xmm3
    b99e:	66 0f 71 d4 08       	psrlw  $0x8,%xmm4
    b9a3:	66 41 0f 67 de       	packuswb %xmm14,%xmm3
    b9a8:	66 44 0f 6f f2       	movdqa %xmm2,%xmm14
    b9ad:	66 41 0f 67 e0       	packuswb %xmm8,%xmm4
    b9b2:	66 44 0f db f5       	pand   %xmm5,%xmm14
    b9b7:	66 0f 71 d5 08       	psrlw  $0x8,%xmm5
    b9bc:	66 45 0f 6f ee       	movdqa %xmm14,%xmm13
    b9c1:	66 44 0f 6f f2       	movdqa %xmm2,%xmm14
    b9c6:	66 44 0f db f7       	pand   %xmm7,%xmm14
    b9cb:	66 0f 71 d7 08       	psrlw  $0x8,%xmm7
    b9d0:	66 45 0f 67 ee       	packuswb %xmm14,%xmm13
    b9d5:	f3 44 0f 6f 76 80    	movdqu -0x80(%rsi),%xmm14
    b9db:	66 0f 67 ef          	packuswb %xmm7,%xmm5
    b9df:	66 41 0f 71 d6 08    	psrlw  $0x8,%xmm14
    b9e5:	66 45 0f 6f c6       	movdqa %xmm14,%xmm8
    b9ea:	f3 44 0f 6f 76 90    	movdqu -0x70(%rsi),%xmm14
    b9f0:	66 45 0f 6f c8       	movdqa %xmm8,%xmm9
    b9f5:	66 41 0f 71 d6 08    	psrlw  $0x8,%xmm14
    b9fb:	66 45 0f 67 ce       	packuswb %xmm14,%xmm9
    ba00:	f3 44 0f 6f 76 a0    	movdqu -0x60(%rsi),%xmm14
    ba06:	66 41 0f 71 d6 08    	psrlw  $0x8,%xmm14
    ba0c:	66 45 0f 6f c6       	movdqa %xmm14,%xmm8
    ba11:	f3 44 0f 6f 76 b0    	movdqu -0x50(%rsi),%xmm14
    ba17:	66 41 0f 71 d6 08    	psrlw  $0x8,%xmm14
    ba1d:	66 45 0f 67 c6       	packuswb %xmm14,%xmm8
    ba22:	66 45 0f 6f f1       	movdqa %xmm9,%xmm14
    ba27:	66 44 0f db f2       	pand   %xmm2,%xmm14
    ba2c:	66 44 0f db c2       	pand   %xmm2,%xmm8
    ba31:	66 41 0f 6f fe       	movdqa %xmm14,%xmm7
    ba36:	f3 44 0f 6f 76 c0    	movdqu -0x40(%rsi),%xmm14
    ba3c:	66 41 0f 67 f8       	packuswb %xmm8,%xmm7
    ba41:	66 41 0f 71 d6 08    	psrlw  $0x8,%xmm14
    ba47:	66 45 0f 6f ce       	movdqa %xmm14,%xmm9
    ba4c:	f3 44 0f 6f 76 d0    	movdqu -0x30(%rsi),%xmm14
    ba52:	66 41 0f 71 d6 08    	psrlw  $0x8,%xmm14
    ba58:	66 45 0f 6f c6       	movdqa %xmm14,%xmm8
    ba5d:	66 45 0f 6f f1       	movdqa %xmm9,%xmm14
    ba62:	66 45 0f 6f cf       	movdqa %xmm15,%xmm9
    ba67:	f3 44 0f 6f 7e f0    	movdqu -0x10(%rsi),%xmm15
    ba6d:	66 45 0f 67 f0       	packuswb %xmm8,%xmm14
    ba72:	66 41 0f 71 d7 08    	psrlw  $0x8,%xmm15
    ba78:	66 44 0f db f2       	pand   %xmm2,%xmm14
    ba7d:	66 45 0f 67 cf       	packuswb %xmm15,%xmm9
    ba82:	66 45 0f 6f c6       	movdqa %xmm14,%xmm8
    ba87:	66 44 0f 6f f2       	movdqa %xmm2,%xmm14
    ba8c:	66 44 0f db f3       	pand   %xmm3,%xmm14
    ba91:	66 44 0f db ca       	pand   %xmm2,%xmm9
    ba96:	66 44 0f 6f fa       	movdqa %xmm2,%xmm15
    ba9b:	66 45 0f 67 c1       	packuswb %xmm9,%xmm8
    baa0:	66 0f 71 d3 08       	psrlw  $0x8,%xmm3
    baa5:	66 45 0f 6f ce       	movdqa %xmm14,%xmm9
    baaa:	66 44 0f 6f f2       	movdqa %xmm2,%xmm14
    baaf:	66 45 0f db f8       	pand   %xmm8,%xmm15
    bab4:	66 45 0f db f5       	pand   %xmm13,%xmm14
    bab9:	66 41 0f 71 d0 08    	psrlw  $0x8,%xmm8
    babf:	66 45 0f 67 ce       	packuswb %xmm14,%xmm9
    bac4:	66 41 0f 71 d5 08    	psrlw  $0x8,%xmm13
    baca:	66 44 0f 6f f2       	movdqa %xmm2,%xmm14
    bacf:	66 44 0f db f7       	pand   %xmm7,%xmm14
    bad4:	66 0f 71 d7 08       	psrlw  $0x8,%xmm7
    bad9:	66 41 0f 67 dd       	packuswb %xmm13,%xmm3
    bade:	66 45 0f 67 f7       	packuswb %xmm15,%xmm14
    bae3:	66 44 0f 6f fa       	movdqa %xmm2,%xmm15
    bae8:	66 41 0f 67 f8       	packuswb %xmm8,%xmm7
    baed:	66 44 0f db fc       	pand   %xmm4,%xmm15
    baf2:	66 0f 71 d4 08       	psrlw  $0x8,%xmm4
    baf7:	66 45 0f 6f c7       	movdqa %xmm15,%xmm8
    bafc:	66 44 0f 6f fa       	movdqa %xmm2,%xmm15
    bb01:	66 44 0f db fd       	pand   %xmm5,%xmm15
    bb06:	66 0f 71 d5 08       	psrlw  $0x8,%xmm5
    bb0b:	66 45 0f 67 c7       	packuswb %xmm15,%xmm8
    bb10:	66 0f 67 e5          	packuswb %xmm5,%xmm4
    bb14:	66 45 0f 6f fe       	movdqa %xmm14,%xmm15
    bb19:	66 0f 6f 2d ff 37 00 	movdqa 0x37ff(%rip),%xmm5        # f320 <__PRETTY_FUNCTION__.4+0xad>
    bb20:	00 
    bb21:	66 44 0f 60 fe       	punpcklbw %xmm6,%xmm15
    bb26:	66 45 0f 6f e8       	movdqa %xmm8,%xmm13
    bb2b:	66 44 0f 68 f6       	punpckhbw %xmm6,%xmm14
    bb30:	66 41 0f d5 ef       	pmullw %xmm15,%xmm5
    bb35:	66 44 0f 60 ee       	punpcklbw %xmm6,%xmm13
    bb3a:	66 44 0f 68 c6       	punpckhbw %xmm6,%xmm8
    bb3f:	44 0f 29 bc 24 98 00 	movaps %xmm15,0x98(%rsp)
    bb46:	00 00 
    bb48:	66 44 0f 6f 3d df 37 	movdqa 0x37df(%rip),%xmm15        # f330 <__PRETTY_FUNCTION__.4+0xbd>
    bb4f:	00 00 
    bb51:	44 0f 29 ac 24 a8 00 	movaps %xmm13,0xa8(%rsp)
    bb58:	00 00 
    bb5a:	66 45 0f d5 fd       	pmullw %xmm13,%xmm15
    bb5f:	66 41 0f fd ef       	paddw  %xmm15,%xmm5
    bb64:	66 45 0f 6f f9       	movdqa %xmm9,%xmm15
    bb69:	66 44 0f 68 ce       	punpckhbw %xmm6,%xmm9
    bb6e:	66 44 0f 60 fe       	punpcklbw %xmm6,%xmm15
    bb73:	66 45 0f 6f ef       	movdqa %xmm15,%xmm13
    bb78:	66 44 0f 6f 3d 8f 37 	movdqa 0x378f(%rip),%xmm15        # f310 <__PRETTY_FUNCTION__.4+0x9d>
    bb7f:	00 00 
    bb81:	44 0f 29 b4 24 b8 00 	movaps %xmm14,0xb8(%rsp)
    bb88:	00 00 
    bb8a:	44 0f 29 84 24 c8 00 	movaps %xmm8,0xc8(%rsp)
    bb91:	00 00 
    bb93:	66 45 0f d5 fd       	pmullw %xmm13,%xmm15
    bb98:	66 44 0f fd 3d 1f 37 	paddw  0x371f(%rip),%xmm15        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    bb9f:	00 00 
    bba1:	66 41 0f fd ef       	paddw  %xmm15,%xmm5
    bba6:	66 0f 71 d5 08       	psrlw  $0x8,%xmm5
    bbab:	66 44 0f 6f fd       	movdqa %xmm5,%xmm15
    bbb0:	66 0f 6f 2d 68 37 00 	movdqa 0x3768(%rip),%xmm5        # f320 <__PRETTY_FUNCTION__.4+0xad>
    bbb7:	00 
    bbb8:	66 44 0f db fa       	pand   %xmm2,%xmm15
    bbbd:	66 41 0f d5 ee       	pmullw %xmm14,%xmm5
    bbc2:	66 44 0f 6f 35 65 37 	movdqa 0x3765(%rip),%xmm14        # f330 <__PRETTY_FUNCTION__.4+0xbd>
    bbc9:	00 00 
    bbcb:	66 45 0f d5 f0       	pmullw %xmm8,%xmm14
    bbd0:	66 44 0f 6f 05 e7 36 	movdqa 0x36e7(%rip),%xmm8        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    bbd7:	00 00 
    bbd9:	66 41 0f fd ee       	paddw  %xmm14,%xmm5
    bbde:	66 44 0f 6f 35 29 37 	movdqa 0x3729(%rip),%xmm14        # f310 <__PRETTY_FUNCTION__.4+0x9d>
    bbe5:	00 00 
    bbe7:	66 45 0f d5 f1       	pmullw %xmm9,%xmm14
    bbec:	66 45 0f fd c6       	paddw  %xmm14,%xmm8
    bbf1:	66 44 0f 6f 35 26 37 	movdqa 0x3726(%rip),%xmm14        # f320 <__PRETTY_FUNCTION__.4+0xad>
    bbf8:	00 00 
    bbfa:	66 41 0f fd e8       	paddw  %xmm8,%xmm5
    bbff:	66 45 0f 6f c7       	movdqa %xmm15,%xmm8
    bc04:	66 44 0f 6f fc       	movdqa %xmm4,%xmm15
    bc09:	66 0f 71 d5 08       	psrlw  $0x8,%xmm5
    bc0e:	66 44 0f 60 fe       	punpcklbw %xmm6,%xmm15
    bc13:	66 0f 68 e6          	punpckhbw %xmm6,%xmm4
    bc17:	44 0f 29 bc 24 e8 00 	movaps %xmm15,0xe8(%rsp)
    bc1e:	00 00 
    bc20:	66 0f db ea          	pand   %xmm2,%xmm5
    bc24:	66 44 0f 67 c5       	packuswb %xmm5,%xmm8
    bc29:	66 0f 6f ef          	movdqa %xmm7,%xmm5
    bc2d:	66 0f 68 fe          	punpckhbw %xmm6,%xmm7
    bc31:	66 44 0f fc 05 76 36 	paddb  0x3676(%rip),%xmm8        # f2b0 <__PRETTY_FUNCTION__.4+0x3d>
    bc38:	00 00 
    bc3a:	66 0f 60 ee          	punpcklbw %xmm6,%xmm5
    bc3e:	0f 29 ac 24 d8 00 00 	movaps %xmm5,0xd8(%rsp)
    bc45:	00 
    bc46:	66 44 0f d5 f5       	pmullw %xmm5,%xmm14
    bc4b:	66 0f 6f 2d dd 36 00 	movdqa 0x36dd(%rip),%xmm5        # f330 <__PRETTY_FUNCTION__.4+0xbd>
    bc52:	00 
    bc53:	66 41 0f d5 ef       	pmullw %xmm15,%xmm5
    bc58:	66 44 0f 6f 3d af 36 	movdqa 0x36af(%rip),%xmm15        # f310 <__PRETTY_FUNCTION__.4+0x9d>
    bc5f:	00 00 
    bc61:	66 44 0f fd f5       	paddw  %xmm5,%xmm14
    bc66:	66 0f 6f eb          	movdqa %xmm3,%xmm5
    bc6a:	66 0f 68 de          	punpckhbw %xmm6,%xmm3
    bc6e:	66 0f 60 ee          	punpcklbw %xmm6,%xmm5
    bc72:	66 44 0f d5 fd       	pmullw %xmm5,%xmm15
    bc77:	66 41 0f fd ed       	paddw  %xmm13,%xmm5
    bc7c:	66 44 0f fd 3d 3b 36 	paddw  0x363b(%rip),%xmm15        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    bc83:	00 00 
    bc85:	66 41 0f fd eb       	paddw  %xmm11,%xmm5
    bc8a:	66 45 0f fd f7       	paddw  %xmm15,%xmm14
    bc8f:	66 44 0f 6f fc       	movdqa %xmm4,%xmm15
    bc94:	66 0f 6f 25 94 36 00 	movdqa 0x3694(%rip),%xmm4        # f330 <__PRETTY_FUNCTION__.4+0xbd>
    bc9b:	00 
    bc9c:	66 41 0f 71 d6 08    	psrlw  $0x8,%xmm14
    bca2:	44 0f 29 b4 24 f8 00 	movaps %xmm14,0xf8(%rsp)
    bca9:	00 00 
    bcab:	66 44 0f 6f f7       	movdqa %xmm7,%xmm14
    bcb0:	66 0f 6f 3d 68 36 00 	movdqa 0x3668(%rip),%xmm7        # f320 <__PRETTY_FUNCTION__.4+0xad>
    bcb7:	00 
    bcb8:	66 41 0f d5 e7       	pmullw %xmm15,%xmm4
    bcbd:	66 41 0f d5 fe       	pmullw %xmm14,%xmm7
    bcc2:	66 44 0f fd b4 24 b8 	paddw  0xb8(%rsp),%xmm14
    bcc9:	00 00 00 
    bccc:	66 0f fd e7          	paddw  %xmm7,%xmm4
    bcd0:	66 0f 6f 3d 38 36 00 	movdqa 0x3638(%rip),%xmm7        # f310 <__PRETTY_FUNCTION__.4+0x9d>
    bcd7:	00 
    bcd8:	66 0f d5 fb          	pmullw %xmm3,%xmm7
    bcdc:	66 41 0f fd d9       	paddw  %xmm9,%xmm3
    bce1:	66 0f fd 3d d7 35 00 	paddw  0x35d7(%rip),%xmm7        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    bce8:	00 
    bce9:	66 0f fd c3          	paddw  %xmm3,%xmm0
    bced:	66 0f 6f 5c 24 48    	movdqa 0x48(%rsp),%xmm3
    bcf3:	66 0f fd 5c 24 98    	paddw  -0x68(%rsp),%xmm3
    bcf9:	66 0f 71 d0 02       	psrlw  $0x2,%xmm0
    bcfe:	66 0f fd e7          	paddw  %xmm7,%xmm4
    bd02:	66 0f 6f bc 24 f8 00 	movdqa 0xf8(%rsp),%xmm7
    bd09:	00 00 
    bd0b:	66 0f 71 d4 08       	psrlw  $0x8,%xmm4
    bd10:	66 0f db e2          	pand   %xmm2,%xmm4
    bd14:	66 0f db fa          	pand   %xmm2,%xmm7
    bd18:	66 0f 67 fc          	packuswb %xmm4,%xmm7
    bd1c:	66 0f 6f 25 8c 35 00 	movdqa 0x358c(%rip),%xmm4        # f2b0 <__PRETTY_FUNCTION__.4+0x3d>
    bd23:	00 
    bd24:	66 0f fc e7          	paddb  %xmm7,%xmm4
    bd28:	66 41 0f 6f f8       	movdqa %xmm8,%xmm7
    bd2d:	66 0f 60 fc          	punpcklbw %xmm4,%xmm7
    bd31:	66 44 0f 68 c4       	punpckhbw %xmm4,%xmm8
    bd36:	66 0f 6f e5          	movdqa %xmm5,%xmm4
    bd3a:	41 0f 11 3c 3e       	movups %xmm7,(%r14,%rdi,1)
    bd3f:	66 0f 71 d4 02       	psrlw  $0x2,%xmm4
    bd44:	66 0f 6f bc 24 d8 00 	movdqa 0xd8(%rsp),%xmm7
    bd4b:	00 00 
    bd4d:	66 0f fd bc 24 98 00 	paddw  0x98(%rsp),%xmm7
    bd54:	00 00 
    bd56:	45 0f 11 44 3e 10    	movups %xmm8,0x10(%r14,%rdi,1)
    bd5c:	66 0f fd df          	paddw  %xmm7,%xmm3
    bd60:	66 0f 6f 7c 24 78    	movdqa 0x78(%rsp),%xmm7
    bd66:	66 0f fd 7c 24 d8    	paddw  -0x28(%rsp),%xmm7
    bd6c:	66 0f 71 d3 02       	psrlw  $0x2,%xmm3
    bd71:	66 0f 6f ef          	movdqa %xmm7,%xmm5
    bd75:	66 0f 6f 7c 24 58    	movdqa 0x58(%rsp),%xmm7
    bd7b:	66 0f fd 7c 24 c8    	paddw  -0x38(%rsp),%xmm7
    bd81:	66 44 0f 6f a4 24 e8 	movdqa 0xe8(%rsp),%xmm12
    bd88:	00 00 00 
    bd8b:	66 41 0f fd ee       	paddw  %xmm14,%xmm5
    bd90:	66 44 0f fd a4 24 a8 	paddw  0xa8(%rsp),%xmm12
    bd97:	00 00 00 
    bd9a:	66 44 0f 6f 15 3d 35 	movdqa 0x353d(%rip),%xmm10        # f2e0 <__PRETTY_FUNCTION__.4+0x6d>
    bda1:	00 00 
    bda3:	66 0f 71 d5 02       	psrlw  $0x2,%xmm5
    bda8:	66 44 0f 6f 05 1f 35 	movdqa 0x351f(%rip),%xmm8        # f2d0 <__PRETTY_FUNCTION__.4+0x5d>
    bdaf:	00 00 
    bdb1:	66 44 0f fd bc 24 c8 	paddw  0xc8(%rsp),%xmm15
    bdb8:	00 00 00 
    bdbb:	66 41 0f fd fc       	paddw  %xmm12,%xmm7
    bdc0:	66 44 0f 6f a4 24 88 	movdqa 0x88(%rsp),%xmm12
    bdc7:	00 00 00 
    bdca:	66 0f 71 d7 02       	psrlw  $0x2,%xmm7
    bdcf:	66 44 0f d5 d3       	pmullw %xmm3,%xmm10
    bdd4:	66 44 0f fd 64 24 28 	paddw  0x28(%rsp),%xmm12
    bddb:	66 44 0f 6f 1d ec 34 	movdqa 0x34ec(%rip),%xmm11        # f2d0 <__PRETTY_FUNCTION__.4+0x5d>
    bde2:	00 00 
    bde4:	66 44 0f d5 c7       	pmullw %xmm7,%xmm8
    bde9:	66 0f d5 1d 0f 35 00 	pmullw 0x350f(%rip),%xmm3        # f300 <__PRETTY_FUNCTION__.4+0x8d>
    bdf0:	00 
    bdf1:	66 45 0f 6f cc       	movdqa %xmm12,%xmm9
    bdf6:	66 45 0f fd cf       	paddw  %xmm15,%xmm9
    bdfb:	66 41 0f 71 d1 02    	psrlw  $0x2,%xmm9
    be01:	66 45 0f d5 d9       	pmullw %xmm9,%xmm11
    be06:	66 45 0f fd d0       	paddw  %xmm8,%xmm10
    be0b:	66 44 0f 6f c4       	movdqa %xmm4,%xmm8
    be10:	66 41 0f 71 f0 03    	psllw  $0x3,%xmm8
    be16:	66 44 0f f9 c4       	psubw  %xmm4,%xmm8
    be1b:	66 41 0f 71 f0 04    	psllw  $0x4,%xmm8
    be21:	66 44 0f fd 05 96 34 	paddw  0x3496(%rip),%xmm8        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    be28:	00 00 
    be2a:	66 45 0f fd d0       	paddw  %xmm8,%xmm10
    be2f:	66 44 0f 6f 05 a8 34 	movdqa 0x34a8(%rip),%xmm8        # f2e0 <__PRETTY_FUNCTION__.4+0x6d>
    be36:	00 00 
    be38:	66 41 0f 71 e2 08    	psraw  $0x8,%xmm10
    be3e:	66 44 0f d5 c5       	pmullw %xmm5,%xmm8
    be43:	66 44 0f db d2       	pand   %xmm2,%xmm10
    be48:	66 0f d5 2d b0 34 00 	pmullw 0x34b0(%rip),%xmm5        # f300 <__PRETTY_FUNCTION__.4+0x8d>
    be4f:	00 
    be50:	66 45 0f fd c3       	paddw  %xmm11,%xmm8
    be55:	66 44 0f 6f d8       	movdqa %xmm0,%xmm11
    be5a:	66 41 0f 71 f3 03    	psllw  $0x3,%xmm11
    be60:	66 44 0f f9 d8       	psubw  %xmm0,%xmm11
    be65:	66 41 0f 71 f3 04    	psllw  $0x4,%xmm11
    be6b:	66 44 0f fd 1d 4c 34 	paddw  0x344c(%rip),%xmm11        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    be72:	00 00 
    be74:	66 45 0f fd c3       	paddw  %xmm11,%xmm8
    be79:	66 41 0f 71 e0 08    	psraw  $0x8,%xmm8
    be7f:	66 44 0f db c2       	pand   %xmm2,%xmm8
    be84:	66 45 0f 67 d0       	packuswb %xmm8,%xmm10
    be89:	66 44 0f fc 15 5e 34 	paddb  0x345e(%rip),%xmm10        # f2f0 <__PRETTY_FUNCTION__.4+0x7d>
    be90:	00 00 
    be92:	66 45 0f 6f c2       	movdqa %xmm10,%xmm8
    be97:	66 44 0f 6f d7       	movdqa %xmm7,%xmm10
    be9c:	66 41 0f 71 f2 03    	psllw  $0x3,%xmm10
    bea2:	66 44 0f f9 d7       	psubw  %xmm7,%xmm10
    bea7:	66 41 0f 6f fa       	movdqa %xmm10,%xmm7
    beac:	66 0f 71 f7 04       	psllw  $0x4,%xmm7
    beb1:	66 0f fd df          	paddw  %xmm7,%xmm3
    beb5:	66 0f 6f fc          	movdqa %xmm4,%xmm7
    beb9:	66 0f 71 f7 02       	psllw  $0x2,%xmm7
    bebe:	66 0f fd e7          	paddw  %xmm7,%xmm4
    bec2:	66 0f 6f 3d f6 33 00 	movdqa 0x33f6(%rip),%xmm7        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    bec9:	00 
    beca:	66 0f 71 f4 01       	psllw  $0x1,%xmm4
    becf:	66 0f f9 fc          	psubw  %xmm4,%xmm7
    bed3:	66 0f fd df          	paddw  %xmm7,%xmm3
    bed7:	66 0f 6f e3          	movdqa %xmm3,%xmm4
    bedb:	66 0f 6f dd          	movdqa %xmm5,%xmm3
    bedf:	66 41 0f 6f e9       	movdqa %xmm9,%xmm5
    bee4:	66 0f 71 f5 03       	psllw  $0x3,%xmm5
    bee9:	66 0f 71 e4 08       	psraw  $0x8,%xmm4
    beee:	66 41 0f f9 e9       	psubw  %xmm9,%xmm5
    bef3:	66 0f db e2          	pand   %xmm2,%xmm4
    bef7:	66 0f 71 f5 04       	psllw  $0x4,%xmm5
    befc:	66 0f fd dd          	paddw  %xmm5,%xmm3
    bf00:	66 0f 6f e8          	movdqa %xmm0,%xmm5
    bf04:	66 0f 71 f5 02       	psllw  $0x2,%xmm5
    bf09:	66 0f fd c5          	paddw  %xmm5,%xmm0
    bf0d:	66 0f 6f 2d ab 33 00 	movdqa 0x33ab(%rip),%xmm5        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    bf14:	00 
    bf15:	66 0f 71 f0 01       	psllw  $0x1,%xmm0
    bf1a:	66 0f f9 e8          	psubw  %xmm0,%xmm5
    bf1e:	66 0f fd dd          	paddw  %xmm5,%xmm3
    bf22:	66 0f 6f c3          	movdqa %xmm3,%xmm0
    bf26:	66 0f 6f dc          	movdqa %xmm4,%xmm3
    bf2a:	66 0f 71 e0 08       	psraw  $0x8,%xmm0
    bf2f:	66 0f db c2          	pand   %xmm2,%xmm0
    bf33:	66 0f 67 d8          	packuswb %xmm0,%xmm3
    bf37:	66 0f fc 1d b1 33 00 	paddb  0x33b1(%rip),%xmm3        # f2f0 <__PRETTY_FUNCTION__.4+0x7d>
    bf3e:	00 
    bf3f:	66 0f 6f c3          	movdqa %xmm3,%xmm0
    bf43:	66 41 0f 6f d8       	movdqa %xmm8,%xmm3
    bf48:	66 0f 60 d8          	punpcklbw %xmm0,%xmm3
    bf4c:	66 44 0f 68 c0       	punpckhbw %xmm0,%xmm8
    bf51:	41 0f 11 1c 3a       	movups %xmm3,(%r10,%rdi,1)
    bf56:	45 0f 11 44 3a 10    	movups %xmm8,0x10(%r10,%rdi,1)
    bf5c:	48 83 c7 20          	add    $0x20,%rdi
    bf60:	48 39 7c 24 90       	cmp    %rdi,-0x70(%rsp)
    bf65:	0f 85 ee f5 ff ff    	jne    b559 <convert_adaptive_job+0x1609>
    bf6b:	8b 74 24 c0          	mov    -0x40(%rsp),%esi
    bf6f:	89 f1                	mov    %esi,%ecx
    bf71:	c1 e6 05             	shl    $0x5,%esi
    bf74:	c1 e1 04             	shl    $0x4,%ecx
    bf77:	01 f3                	add    %esi,%ebx
    bf79:	41 29 c9             	sub    %ecx,%r9d
    bf7c:	41 83 f9 07          	cmp    $0x7,%r9d
    bf80:	0f 86 2e 0c 00 00    	jbe    cbb4 <convert_adaptive_job+0x2c64>
    bf86:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
    bf8b:	48 01 c9             	add    %rcx,%rcx
    bf8e:	66 0f 6f d9          	movdqa %xmm1,%xmm3
    bf92:	66 0f 6f c1          	movdqa %xmm1,%xmm0
    bf96:	48 01 c8             	add    %rcx,%rax
    bf99:	66 44 0f 6f c1       	movdqa %xmm1,%xmm8
    bf9e:	66 44 0f 6f d1       	movdqa %xmm1,%xmm10
    bfa3:	41 83 e1 f8          	and    $0xfffffff8,%r9d
    bfa7:	48 01 cf             	add    %rcx,%rdi
    bfaa:	48 8d 34 85 00 00 00 	lea    0x0(,%rax,4),%rsi
    bfb1:	00 
    bfb2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    bfb7:	42 8d 1c 4b          	lea    (%rbx,%r9,2),%ebx
    bfbb:	4c 8d 34 3a          	lea    (%rdx,%rdi,1),%r14
    bfbf:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    bfc4:	66 44 0f 6f f9       	movdqa %xmm1,%xmm15
    bfc9:	48 01 f0             	add    %rsi,%rax
    bfcc:	48 01 f7             	add    %rsi,%rdi
    bfcf:	4c 01 c0             	add    %r8,%rax
    bfd2:	48 89 fe             	mov    %rdi,%rsi
    bfd5:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    bfda:	f3 44 0f 7e 68 08    	movq   0x8(%rax),%xmm13
    bfe0:	f3 0f 7e 78 10       	movq   0x10(%rax),%xmm7
    bfe5:	f3 44 0f 7e 60 18    	movq   0x18(%rax),%xmm12
    bfeb:	4c 01 c6             	add    %r8,%rsi
    bfee:	48 01 cf             	add    %rcx,%rdi
    bff1:	66 41 0f db dd       	pand   %xmm13,%xmm3
    bff6:	f3 0f 7e 68 20       	movq   0x20(%rax),%xmm5
    bffb:	f3 44 0f 7e 58 28    	movq   0x28(%rax),%xmm11
    c001:	4c 8d 14 3a          	lea    (%rdx,%rdi,1),%r10
    c005:	48 8b 38             	mov    (%rax),%rdi
    c008:	66 44 0f db d7       	pand   %xmm7,%xmm10
    c00d:	f3 44 0f 7e 48 30    	movq   0x30(%rax),%xmm9
    c013:	f3 44 0f 7e 70 38    	movq   0x38(%rax),%xmm14
    c019:	66 41 0f 71 d5 08    	psrlw  $0x8,%xmm13
    c01f:	48 8b 94 24 08 01 00 	mov    0x108(%rsp),%rdx
    c026:	00 
    c027:	66 48 0f 6e e7       	movq   %rdi,%xmm4
    c02c:	66 45 0f db f9       	pand   %xmm9,%xmm15
    c031:	66 44 0f db c4       	pand   %xmm4,%xmm8
    c036:	66 0f 6f e1          	movdqa %xmm1,%xmm4
    c03a:	48 01 ca             	add    %rcx,%rdx
    c03d:	66 44 0f 67 c3       	packuswb %xmm3,%xmm8
    c042:	66 0f 6f d9          	movdqa %xmm1,%xmm3
    c046:	66 41 0f db e3       	pand   %xmm11,%xmm4
    c04b:	48 01 ea             	add    %rbp,%rdx
    c04e:	66 41 0f db dc       	pand   %xmm12,%xmm3
    c053:	66 45 0f 70 c0 08    	pshufd $0x8,%xmm8,%xmm8
    c059:	66 44 0f 67 d3       	packuswb %xmm3,%xmm10
    c05e:	66 41 0f 71 d4 08    	psrlw  $0x8,%xmm12
    c064:	66 0f 6f d9          	movdqa %xmm1,%xmm3
    c068:	66 0f db dd          	pand   %xmm5,%xmm3
    c06c:	66 41 0f 71 d3 08    	psrlw  $0x8,%xmm11
    c072:	66 45 0f 70 d2 08    	pshufd $0x8,%xmm10,%xmm10
    c078:	66 0f 67 dc          	packuswb %xmm4,%xmm3
    c07c:	66 0f 6f e1          	movdqa %xmm1,%xmm4
    c080:	66 41 0f db c2       	pand   %xmm10,%xmm0
    c085:	66 41 0f db e6       	pand   %xmm14,%xmm4
    c08a:	66 41 0f 71 d2 08    	psrlw  $0x8,%xmm10
    c090:	66 0f 70 db 08       	pshufd $0x8,%xmm3,%xmm3
    c095:	66 44 0f 67 fc       	packuswb %xmm4,%xmm15
    c09a:	66 41 0f 71 d6 08    	psrlw  $0x8,%xmm14
    c0a0:	66 0f 6f e1          	movdqa %xmm1,%xmm4
    c0a4:	66 41 0f db e0       	pand   %xmm8,%xmm4
    c0a9:	66 41 0f 71 d0 08    	psrlw  $0x8,%xmm8
    c0af:	66 45 0f 70 ff 08    	pshufd $0x8,%xmm15,%xmm15
    c0b5:	66 0f 67 e0          	packuswb %xmm0,%xmm4
    c0b9:	66 45 0f 67 c2       	packuswb %xmm10,%xmm8
    c0be:	66 0f 6f c1          	movdqa %xmm1,%xmm0
    c0c2:	66 44 0f 6f d1       	movdqa %xmm1,%xmm10
    c0c7:	66 41 0f db c7       	pand   %xmm15,%xmm0
    c0cc:	66 0f 70 e4 08       	pshufd $0x8,%xmm4,%xmm4
    c0d1:	66 44 0f db d3       	pand   %xmm3,%xmm10
    c0d6:	66 41 0f 71 d7 08    	psrlw  $0x8,%xmm15
    c0dc:	66 45 0f 70 c0 08    	pshufd $0x8,%xmm8,%xmm8
    c0e2:	66 44 0f 67 d0       	packuswb %xmm0,%xmm10
    c0e7:	66 0f 71 d3 08       	psrlw  $0x8,%xmm3
    c0ec:	66 48 0f 6e c7       	movq   %rdi,%xmm0
    c0f1:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    c0f6:	66 41 0f 67 df       	packuswb %xmm15,%xmm3
    c0fb:	66 45 0f 70 d2 08    	pshufd $0x8,%xmm10,%xmm10
    c101:	66 44 0f 6f f8       	movdqa %xmm0,%xmm15
    c106:	66 0f 6f c7          	movdqa %xmm7,%xmm0
    c10a:	66 0f 70 db 08       	pshufd $0x8,%xmm3,%xmm3
    c10f:	66 45 0f 67 fd       	packuswb %xmm13,%xmm15
    c114:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    c119:	66 45 0f 70 ff 08    	pshufd $0x8,%xmm15,%xmm15
    c11f:	66 41 0f 67 c4       	packuswb %xmm12,%xmm0
    c124:	66 45 0f ef e4       	pxor   %xmm12,%xmm12
    c129:	66 41 0f 6f ff       	movdqa %xmm15,%xmm7
    c12e:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    c133:	66 45 0f 6f fc       	movdqa %xmm12,%xmm15
    c138:	66 0f db c1          	pand   %xmm1,%xmm0
    c13c:	66 0f db f9          	pand   %xmm1,%xmm7
    c140:	66 0f 67 f8          	packuswb %xmm0,%xmm7
    c144:	66 0f 6f c5          	movdqa %xmm5,%xmm0
    c148:	66 41 0f 6f e9       	movdqa %xmm9,%xmm5
    c14d:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    c152:	66 0f 71 d5 08       	psrlw  $0x8,%xmm5
    c157:	66 0f 70 ff 08       	pshufd $0x8,%xmm7,%xmm7
    c15c:	66 41 0f 67 c3       	packuswb %xmm11,%xmm0
    c161:	66 41 0f 67 ee       	packuswb %xmm14,%xmm5
    c166:	66 44 0f 6f d9       	movdqa %xmm1,%xmm11
    c16b:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    c170:	66 0f 70 ed 08       	pshufd $0x8,%xmm5,%xmm5
    c175:	66 44 0f db dc       	pand   %xmm4,%xmm11
    c17a:	66 0f db e9          	pand   %xmm1,%xmm5
    c17e:	66 0f 71 d4 08       	psrlw  $0x8,%xmm4
    c183:	66 0f db c1          	pand   %xmm1,%xmm0
    c187:	66 0f 67 c5          	packuswb %xmm5,%xmm0
    c18b:	66 0f 6f e9          	movdqa %xmm1,%xmm5
    c18f:	66 44 0f 6f cc       	movdqa %xmm4,%xmm9
    c194:	66 41 0f db ea       	pand   %xmm10,%xmm5
    c199:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    c19e:	66 0f 6f e1          	movdqa %xmm1,%xmm4
    c1a2:	66 44 0f 67 dd       	packuswb %xmm5,%xmm11
    c1a7:	66 0f 6f e9          	movdqa %xmm1,%xmm5
    c1ab:	66 0f db e7          	pand   %xmm7,%xmm4
    c1af:	66 0f db e8          	pand   %xmm0,%xmm5
    c1b3:	66 0f 71 d7 08       	psrlw  $0x8,%xmm7
    c1b8:	66 45 0f 70 db 08    	pshufd $0x8,%xmm11,%xmm11
    c1be:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    c1c3:	66 0f 67 e5          	packuswb %xmm5,%xmm4
    c1c7:	66 0f 6f e9          	movdqa %xmm1,%xmm5
    c1cb:	66 0f 67 f8          	packuswb %xmm0,%xmm7
    c1cf:	66 0f 6f c1          	movdqa %xmm1,%xmm0
    c1d3:	66 41 0f db e8       	pand   %xmm8,%xmm5
    c1d8:	66 0f db c3          	pand   %xmm3,%xmm0
    c1dc:	66 0f 70 e4 08       	pshufd $0x8,%xmm4,%xmm4
    c1e1:	66 45 0f 6f eb       	movdqa %xmm11,%xmm13
    c1e6:	66 0f 67 e8          	packuswb %xmm0,%xmm5
    c1ea:	66 41 0f 6f c0       	movdqa %xmm8,%xmm0
    c1ef:	66 45 0f 60 dc       	punpcklbw %xmm12,%xmm11
    c1f4:	f3 44 0f 7e 05 23 31 	movq   0x3123(%rip),%xmm8        # f320 <__PRETTY_FUNCTION__.4+0xad>
    c1fb:	00 00 
    c1fd:	66 0f 71 d3 08       	psrlw  $0x8,%xmm3
    c202:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    c207:	66 0f 70 ed 08       	pshufd $0x8,%xmm5,%xmm5
    c20c:	66 0f 67 c3          	packuswb %xmm3,%xmm0
    c210:	66 0f 6f dc          	movdqa %xmm4,%xmm3
    c214:	66 41 0f 60 e4       	punpcklbw %xmm12,%xmm4
    c219:	66 0f 70 e4 4e       	pshufd $0x4e,%xmm4,%xmm4
    c21e:	66 45 0f 70 db 4e    	pshufd $0x4e,%xmm11,%xmm11
    c224:	66 41 0f 60 dc       	punpcklbw %xmm12,%xmm3
    c229:	66 4d 0f 7e df       	movq   %xmm11,%r15
    c22e:	66 0f d6 64 24 d8    	movq   %xmm4,-0x28(%rsp)
    c234:	66 44 0f 6f dc       	movdqa %xmm4,%xmm11
    c239:	66 0f 6f e5          	movdqa %xmm5,%xmm4
    c23d:	66 41 0f 60 e4       	punpcklbw %xmm12,%xmm4
    c242:	66 45 0f 60 ec       	punpcklbw %xmm12,%xmm13
    c247:	66 41 0f 60 ec       	punpcklbw %xmm12,%xmm5
    c24c:	66 0f d6 5c 24 c8    	movq   %xmm3,-0x38(%rsp)
    c252:	66 44 0f d5 c3       	pmullw %xmm3,%xmm8
    c257:	66 0f d6 64 24 90    	movq   %xmm4,-0x70(%rsp)
    c25d:	66 0f 6f dc          	movdqa %xmm4,%xmm3
    c261:	f3 0f 7e 64 24 90    	movq   -0x70(%rsp),%xmm4
    c267:	66 0f 71 f3 01       	psllw  $0x1,%xmm3
    c26c:	66 0f 70 ed 4e       	pshufd $0x4e,%xmm5,%xmm5
    c271:	66 0f 70 ff 08       	pshufd $0x8,%xmm7,%xmm7
    c276:	66 44 0f d6 6c 24 c0 	movq   %xmm13,-0x40(%rsp)
    c27d:	66 0f fd dc          	paddw  %xmm4,%xmm3
    c281:	66 41 0f 71 d2 08    	psrlw  $0x8,%xmm10
    c287:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    c28c:	66 45 0f 67 ca       	packuswb %xmm10,%xmm9
    c291:	66 44 0f 6f d5       	movdqa %xmm5,%xmm10
    c296:	66 41 0f 71 f2 01    	psllw  $0x1,%xmm10
    c29c:	66 45 0f 70 c9 08    	pshufd $0x8,%xmm9,%xmm9
    c2a2:	66 0f 71 f3 04       	psllw  $0x4,%xmm3
    c2a7:	66 44 0f fd d5       	paddw  %xmm5,%xmm10
    c2ac:	66 45 0f 6f f1       	movdqa %xmm9,%xmm14
    c2b1:	66 0f f9 dc          	psubw  %xmm4,%xmm3
    c2b5:	66 45 0f 60 f4       	punpcklbw %xmm12,%xmm14
    c2ba:	66 41 0f 6f e4       	movdqa %xmm12,%xmm4
    c2bf:	66 45 0f 70 f6 4e    	pshufd $0x4e,%xmm14,%xmm14
    c2c5:	66 41 0f 71 f2 04    	psllw  $0x4,%xmm10
    c2cb:	66 44 0f d6 74 24 20 	movq   %xmm14,0x20(%rsp)
    c2d2:	66 41 0f fd d8       	paddw  %xmm8,%xmm3
    c2d7:	66 45 0f 6f c5       	movdqa %xmm13,%xmm8
    c2dc:	66 44 0f f9 d5       	psubw  %xmm5,%xmm10
    c2e1:	f3 44 0f 7e 2d d6 2f 	movq   0x2fd6(%rip),%xmm13        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    c2e8:	00 00 
    c2ea:	66 41 0f 71 f0 04    	psllw  $0x4,%xmm8
    c2f0:	66 45 0f fd c5       	paddw  %xmm13,%xmm8
    c2f5:	f3 44 0f 7e 2d c2 2f 	movq   0x2fc2(%rip),%xmm13        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    c2fc:	00 00 
    c2fe:	66 41 0f fd d8       	paddw  %xmm8,%xmm3
    c303:	f3 44 0f 7e 05 14 30 	movq   0x3014(%rip),%xmm8        # f320 <__PRETTY_FUNCTION__.4+0xad>
    c30a:	00 00 
    c30c:	66 45 0f d5 c3       	pmullw %xmm11,%xmm8
    c311:	66 45 0f 6f d9       	movdqa %xmm9,%xmm11
    c316:	66 44 0f 6f cf       	movdqa %xmm7,%xmm9
    c31b:	66 0f 71 d3 08       	psrlw  $0x8,%xmm3
    c320:	66 41 0f 60 ff       	punpcklbw %xmm15,%xmm7
    c325:	66 45 0f 60 cc       	punpcklbw %xmm12,%xmm9
    c32a:	66 0f db d9          	pand   %xmm1,%xmm3
    c32e:	66 0f 70 ff 4e       	pshufd $0x4e,%xmm7,%xmm7
    c333:	66 45 0f 60 dc       	punpcklbw %xmm12,%xmm11
    c338:	66 44 0f d6 4c 24 28 	movq   %xmm9,0x28(%rsp)
    c33f:	66 0f d6 7c 24 40    	movq   %xmm7,0x40(%rsp)
    c345:	66 44 0f d6 5c 24 08 	movq   %xmm11,0x8(%rsp)
    c34c:	66 45 0f fd c2       	paddw  %xmm10,%xmm8
    c351:	66 4d 0f 6e d7       	movq   %r15,%xmm10
    c356:	66 41 0f 71 f2 04    	psllw  $0x4,%xmm10
    c35c:	66 45 0f fd d5       	paddw  %xmm13,%xmm10
    c361:	f3 44 0f 7e 2d 46 2f 	movq   0x2f46(%rip),%xmm13        # f2b0 <__PRETTY_FUNCTION__.4+0x3d>
    c368:	00 00 
    c36a:	66 45 0f fd c2       	paddw  %xmm10,%xmm8
    c36f:	66 44 0f 6f d7       	movdqa %xmm7,%xmm10
    c374:	66 41 0f 71 d0 08    	psrlw  $0x8,%xmm8
    c37a:	66 44 0f db c1       	pand   %xmm1,%xmm8
    c37f:	66 41 0f 67 d8       	packuswb %xmm8,%xmm3
    c384:	f3 44 0f 7e 05 93 2f 	movq   0x2f93(%rip),%xmm8        # f320 <__PRETTY_FUNCTION__.4+0xad>
    c38b:	00 00 
    c38d:	66 0f 70 db 08       	pshufd $0x8,%xmm3,%xmm3
    c392:	66 41 0f fc dd       	paddb  %xmm13,%xmm3
    c397:	66 45 0f d5 c1       	pmullw %xmm9,%xmm8
    c39c:	66 44 0f 6f e8       	movdqa %xmm0,%xmm13
    c3a1:	66 45 0f 60 ef       	punpcklbw %xmm15,%xmm13
    c3a6:	66 41 0f 60 c7       	punpcklbw %xmm15,%xmm0
    c3ab:	66 41 0f 6f fd       	movdqa %xmm13,%xmm7
    c3b0:	66 0f 70 c0 4e       	pshufd $0x4e,%xmm0,%xmm0
    c3b5:	66 0f 71 f7 01       	psllw  $0x1,%xmm7
    c3ba:	66 44 0f 6f e0       	movdqa %xmm0,%xmm12
    c3bf:	66 0f d6 44 24 98    	movq   %xmm0,-0x68(%rsp)
    c3c5:	f3 0f 7e 05 f3 2e 00 	movq   0x2ef3(%rip),%xmm0        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    c3cc:	00 
    c3cd:	66 41 0f fd fd       	paddw  %xmm13,%xmm7
    c3d2:	66 0f 71 f7 04       	psllw  $0x4,%xmm7
    c3d7:	66 41 0f f9 fd       	psubw  %xmm13,%xmm7
    c3dc:	66 41 0f fd f8       	paddw  %xmm8,%xmm7
    c3e1:	66 45 0f 6f c3       	movdqa %xmm11,%xmm8
    c3e6:	66 44 0f 6f d9       	movdqa %xmm1,%xmm11
    c3eb:	66 41 0f 71 f0 04    	psllw  $0x4,%xmm8
    c3f1:	66 44 0f fd c0       	paddw  %xmm0,%xmm8
    c3f6:	f3 0f 7e 44 24 98    	movq   -0x68(%rsp),%xmm0
    c3fc:	66 41 0f fd f8       	paddw  %xmm8,%xmm7
    c401:	f3 44 0f 7e 05 16 2f 	movq   0x2f16(%rip),%xmm8        # f320 <__PRETTY_FUNCTION__.4+0xad>
    c408:	00 00 
    c40a:	66 45 0f d5 c2       	pmullw %xmm10,%xmm8
    c40f:	66 0f 71 d7 08       	psrlw  $0x8,%xmm7
    c414:	66 44 0f 6f cf       	movdqa %xmm7,%xmm9
    c419:	66 41 0f 6f fc       	movdqa %xmm12,%xmm7
    c41e:	66 0f 71 f7 01       	psllw  $0x1,%xmm7
    c423:	66 44 0f db c9       	pand   %xmm1,%xmm9
    c428:	66 0f fd f8          	paddw  %xmm0,%xmm7
    c42c:	66 0f 71 f7 04       	psllw  $0x4,%xmm7
    c431:	66 0f f9 f8          	psubw  %xmm0,%xmm7
    c435:	f3 0f 7e 05 83 2e 00 	movq   0x2e83(%rip),%xmm0        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    c43c:	00 
    c43d:	66 41 0f fd f8       	paddw  %xmm8,%xmm7
    c442:	66 45 0f 6f c6       	movdqa %xmm14,%xmm8
    c447:	66 41 0f 71 f0 04    	psllw  $0x4,%xmm8
    c44d:	66 44 0f fd c0       	paddw  %xmm0,%xmm8
    c452:	66 0f 6f c1          	movdqa %xmm1,%xmm0
    c456:	66 41 0f fd f8       	paddw  %xmm8,%xmm7
    c45b:	66 45 0f 6f c1       	movdqa %xmm9,%xmm8
    c460:	66 0f 71 d7 08       	psrlw  $0x8,%xmm7
    c465:	66 0f db f9          	pand   %xmm1,%xmm7
    c469:	66 44 0f 67 c7       	packuswb %xmm7,%xmm8
    c46e:	f3 0f 7e 3d 3a 2e 00 	movq   0x2e3a(%rip),%xmm7        # f2b0 <__PRETTY_FUNCTION__.4+0x3d>
    c475:	00 
    c476:	66 45 0f 70 c0 08    	pshufd $0x8,%xmm8,%xmm8
    c47c:	66 41 0f fc f8       	paddb  %xmm8,%xmm7
    c481:	66 44 0f 6f c3       	movdqa %xmm3,%xmm8
    c486:	66 0f 60 df          	punpcklbw %xmm7,%xmm3
    c48a:	66 44 0f 60 c7       	punpcklbw %xmm7,%xmm8
    c48f:	66 0f 70 db 4e       	pshufd $0x4e,%xmm3,%xmm3
    c494:	66 45 0f d6 06       	movq   %xmm8,(%r14)
    c499:	66 44 0f 6f c1       	movdqa %xmm1,%xmm8
    c49e:	66 41 0f d6 5e 08    	movq   %xmm3,0x8(%r14)
    c4a4:	4c 8b 06             	mov    (%rsi),%r8
    c4a7:	48 8b 7e 08          	mov    0x8(%rsi),%rdi
    c4ab:	48 8b 4e 18          	mov    0x18(%rsi),%rcx
    c4af:	f3 44 0f 7e 56 10    	movq   0x10(%rsi),%xmm10
    c4b5:	66 49 0f 6e d8       	movq   %r8,%xmm3
    c4ba:	66 48 0f 6e ff       	movq   %rdi,%xmm7
    c4bf:	48 8b 46 20          	mov    0x20(%rsi),%rax
    c4c3:	f3 44 0f 7e 7e 28    	movq   0x28(%rsi),%xmm15
    c4c9:	66 0f db f9          	pand   %xmm1,%xmm7
    c4cd:	66 0f db d9          	pand   %xmm1,%xmm3
    c4d1:	66 45 0f db da       	pand   %xmm10,%xmm11
    c4d6:	f3 44 0f 7e 4e 30    	movq   0x30(%rsi),%xmm9
    c4dc:	66 0f 67 df          	packuswb %xmm7,%xmm3
    c4e0:	66 48 0f 6e f9       	movq   %rcx,%xmm7
    c4e5:	f3 44 0f 7e 76 38    	movq   0x38(%rsi),%xmm14
    c4eb:	66 45 0f db c7       	pand   %xmm15,%xmm8
    c4f0:	66 0f db f9          	pand   %xmm1,%xmm7
    c4f4:	66 41 0f db c1       	pand   %xmm9,%xmm0
    c4f9:	66 0f 70 db 08       	pshufd $0x8,%xmm3,%xmm3
    c4fe:	66 44 0f 67 df       	packuswb %xmm7,%xmm11
    c503:	66 48 0f 6e f8       	movq   %rax,%xmm7
    c508:	66 44 0f 6f e0       	movdqa %xmm0,%xmm12
    c50d:	66 0f db f9          	pand   %xmm1,%xmm7
    c511:	66 45 0f 70 db 08    	pshufd $0x8,%xmm11,%xmm11
    c517:	66 0f 6f c1          	movdqa %xmm1,%xmm0
    c51b:	66 41 0f 67 f8       	packuswb %xmm8,%xmm7
    c520:	66 44 0f 6f c1       	movdqa %xmm1,%xmm8
    c525:	66 41 0f db c3       	pand   %xmm11,%xmm0
    c52a:	66 45 0f db c6       	pand   %xmm14,%xmm8
    c52f:	66 41 0f 71 d3 08    	psrlw  $0x8,%xmm11
    c535:	66 0f 70 ff 08       	pshufd $0x8,%xmm7,%xmm7
    c53a:	66 45 0f 67 e0       	packuswb %xmm8,%xmm12
    c53f:	66 44 0f 6f c1       	movdqa %xmm1,%xmm8
    c544:	66 44 0f db c3       	pand   %xmm3,%xmm8
    c549:	66 0f 71 d3 08       	psrlw  $0x8,%xmm3
    c54e:	66 45 0f 70 e4 08    	pshufd $0x8,%xmm12,%xmm12
    c554:	66 44 0f 67 c0       	packuswb %xmm0,%xmm8
    c559:	66 41 0f 67 db       	packuswb %xmm11,%xmm3
    c55e:	66 0f 6f c1          	movdqa %xmm1,%xmm0
    c562:	66 44 0f 6f d9       	movdqa %xmm1,%xmm11
    c567:	66 41 0f db c4       	pand   %xmm12,%xmm0
    c56c:	66 45 0f 70 c0 08    	pshufd $0x8,%xmm8,%xmm8
    c572:	66 44 0f db df       	pand   %xmm7,%xmm11
    c577:	66 0f 71 d7 08       	psrlw  $0x8,%xmm7
    c57c:	66 0f 70 db 08       	pshufd $0x8,%xmm3,%xmm3
    c581:	66 44 0f 67 d8       	packuswb %xmm0,%xmm11
    c586:	66 49 0f 6e c0       	movq   %r8,%xmm0
    c58b:	66 41 0f 71 d4 08    	psrlw  $0x8,%xmm12
    c591:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    c596:	66 45 0f 70 db 08    	pshufd $0x8,%xmm11,%xmm11
    c59c:	66 41 0f 67 fc       	packuswb %xmm12,%xmm7
    c5a1:	66 44 0f 6f e0       	movdqa %xmm0,%xmm12
    c5a6:	66 48 0f 6e c7       	movq   %rdi,%xmm0
    c5ab:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    c5b0:	66 41 0f 71 d2 08    	psrlw  $0x8,%xmm10
    c5b6:	66 0f 70 ff 08       	pshufd $0x8,%xmm7,%xmm7
    c5bb:	66 44 0f 67 e0       	packuswb %xmm0,%xmm12
    c5c0:	66 48 0f 6e c1       	movq   %rcx,%xmm0
    c5c5:	66 0f 71 d0 08       	psrlw  $0x8,%xmm0
    c5ca:	66 45 0f 70 e4 08    	pshufd $0x8,%xmm12,%xmm12
    c5d0:	66 44 0f 67 d0       	packuswb %xmm0,%xmm10
    c5d5:	66 44 0f db e1       	pand   %xmm1,%xmm12
    c5da:	66 45 0f 70 d2 08    	pshufd $0x8,%xmm10,%xmm10
    c5e0:	66 41 0f 71 d7 08    	psrlw  $0x8,%xmm15
    c5e6:	66 44 0f db d1       	pand   %xmm1,%xmm10
    c5eb:	66 41 0f 71 d6 08    	psrlw  $0x8,%xmm14
    c5f1:	66 45 0f 67 e2       	packuswb %xmm10,%xmm12
    c5f6:	66 4c 0f 6e d0       	movq   %rax,%xmm10
    c5fb:	66 41 0f 71 d2 08    	psrlw  $0x8,%xmm10
    c601:	66 45 0f 70 e4 08    	pshufd $0x8,%xmm12,%xmm12
    c607:	66 41 0f 6f c2       	movdqa %xmm10,%xmm0
    c60c:	66 45 0f 6f d1       	movdqa %xmm9,%xmm10
    c611:	66 41 0f 67 c7       	packuswb %xmm15,%xmm0
    c616:	66 41 0f 71 d2 08    	psrlw  $0x8,%xmm10
    c61c:	66 44 0f 6f fc       	movdqa %xmm4,%xmm15
    c621:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    c626:	66 45 0f 67 d6       	packuswb %xmm14,%xmm10
    c62b:	66 44 0f 6f f1       	movdqa %xmm1,%xmm14
    c630:	66 44 0f 6f c8       	movdqa %xmm0,%xmm9
    c635:	66 45 0f 70 d2 08    	pshufd $0x8,%xmm10,%xmm10
    c63b:	66 45 0f db f3       	pand   %xmm11,%xmm14
    c640:	f3 0f 7e 05 d8 2c 00 	movq   0x2cd8(%rip),%xmm0        # f320 <__PRETTY_FUNCTION__.4+0xad>
    c647:	00 
    c648:	66 44 0f db d1       	pand   %xmm1,%xmm10
    c64d:	66 41 0f 71 d3 08    	psrlw  $0x8,%xmm11
    c653:	66 44 0f db c9       	pand   %xmm1,%xmm9
    c658:	66 45 0f 67 ca       	packuswb %xmm10,%xmm9
    c65d:	66 44 0f 6f d1       	movdqa %xmm1,%xmm10
    c662:	66 45 0f db d0       	pand   %xmm8,%xmm10
    c667:	66 41 0f 71 d0 08    	psrlw  $0x8,%xmm8
    c66d:	66 45 0f 70 c9 08    	pshufd $0x8,%xmm9,%xmm9
    c673:	66 45 0f 67 d6       	packuswb %xmm14,%xmm10
    c678:	66 45 0f 67 c3       	packuswb %xmm11,%xmm8
    c67d:	66 44 0f 6f f1       	movdqa %xmm1,%xmm14
    c682:	66 44 0f 6f d9       	movdqa %xmm1,%xmm11
    c687:	66 45 0f db f4       	pand   %xmm12,%xmm14
    c68c:	66 45 0f 70 d2 08    	pshufd $0x8,%xmm10,%xmm10
    c692:	66 45 0f db d9       	pand   %xmm9,%xmm11
    c697:	66 41 0f 71 d4 08    	psrlw  $0x8,%xmm12
    c69d:	66 45 0f 70 c0 08    	pshufd $0x8,%xmm8,%xmm8
    c6a3:	66 41 0f 71 d1 08    	psrlw  $0x8,%xmm9
    c6a9:	66 45 0f 67 f3       	packuswb %xmm11,%xmm14
    c6ae:	66 44 0f 6f d9       	movdqa %xmm1,%xmm11
    c6b3:	66 45 0f 67 e1       	packuswb %xmm9,%xmm12
    c6b8:	66 44 0f 6f c9       	movdqa %xmm1,%xmm9
    c6bd:	66 44 0f db df       	pand   %xmm7,%xmm11
    c6c2:	66 45 0f 70 f6 08    	pshufd $0x8,%xmm14,%xmm14
    c6c8:	66 0f 71 d7 08       	psrlw  $0x8,%xmm7
    c6cd:	66 44 0f db cb       	pand   %xmm3,%xmm9
    c6d2:	66 0f 71 d3 08       	psrlw  $0x8,%xmm3
    c6d7:	66 45 0f 67 cb       	packuswb %xmm11,%xmm9
    c6dc:	66 45 0f 6f da       	movdqa %xmm10,%xmm11
    c6e1:	66 0f 67 df          	packuswb %xmm7,%xmm3
    c6e5:	66 41 0f 6f fe       	movdqa %xmm14,%xmm7
    c6ea:	66 45 0f 60 f7       	punpcklbw %xmm15,%xmm14
    c6ef:	66 45 0f 70 c9 08    	pshufd $0x8,%xmm9,%xmm9
    c6f5:	66 41 0f 60 ff       	punpcklbw %xmm15,%xmm7
    c6fa:	66 45 0f 70 f6 4e    	pshufd $0x4e,%xmm14,%xmm14
    c700:	66 48 0f 7e fe       	movq   %xmm7,%rsi
    c705:	66 4d 0f 7e f0       	movq   %xmm14,%r8
    c70a:	66 45 0f 6f f1       	movdqa %xmm9,%xmm14
    c70f:	66 45 0f 60 f7       	punpcklbw %xmm15,%xmm14
    c714:	66 41 0f 6f f9       	movdqa %xmm9,%xmm7
    c719:	66 4c 0f 6e ce       	movq   %rsi,%xmm9
    c71e:	66 41 0f d5 c1       	pmullw %xmm9,%xmm0
    c723:	66 45 0f 6f ce       	movdqa %xmm14,%xmm9
    c728:	66 45 0f 60 df       	punpcklbw %xmm15,%xmm11
    c72d:	66 41 0f 71 f1 01    	psllw  $0x1,%xmm9
    c733:	66 45 0f 60 d7       	punpcklbw %xmm15,%xmm10
    c738:	66 41 0f 60 ff       	punpcklbw %xmm15,%xmm7
    c73d:	66 45 0f fd ce       	paddw  %xmm14,%xmm9
    c742:	66 0f 70 ff 4e       	pshufd $0x4e,%xmm7,%xmm7
    c747:	66 0f 70 db 08       	pshufd $0x8,%xmm3,%xmm3
    c74c:	66 45 0f 70 d2 4e    	pshufd $0x4e,%xmm10,%xmm10
    c752:	66 45 0f 70 e4 08    	pshufd $0x8,%xmm12,%xmm12
    c758:	66 41 0f 71 f1 04    	psllw  $0x4,%xmm9
    c75e:	66 45 0f f9 ce       	psubw  %xmm14,%xmm9
    c763:	66 44 0f fd c8       	paddw  %xmm0,%xmm9
    c768:	66 41 0f 6f c3       	movdqa %xmm11,%xmm0
    c76d:	66 0f 71 f0 04       	psllw  $0x4,%xmm0
    c772:	66 44 0f 6f f8       	movdqa %xmm0,%xmm15
    c777:	f3 0f 7e 05 41 2b 00 	movq   0x2b41(%rip),%xmm0        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    c77e:	00 
    c77f:	66 44 0f fd f8       	paddw  %xmm0,%xmm15
    c784:	f3 0f 7e 05 94 2b 00 	movq   0x2b94(%rip),%xmm0        # f320 <__PRETTY_FUNCTION__.4+0xad>
    c78b:	00 
    c78c:	66 45 0f fd cf       	paddw  %xmm15,%xmm9
    c791:	66 41 0f 71 d1 08    	psrlw  $0x8,%xmm9
    c797:	66 4c 0f 7e c8       	movq   %xmm9,%rax
    c79c:	66 4d 0f 6e c8       	movq   %r8,%xmm9
    c7a1:	66 41 0f d5 c1       	pmullw %xmm9,%xmm0
    c7a6:	66 44 0f 6f cf       	movdqa %xmm7,%xmm9
    c7ab:	66 41 0f 71 f1 01    	psllw  $0x1,%xmm9
    c7b1:	66 44 0f fd cf       	paddw  %xmm7,%xmm9
    c7b6:	66 41 0f 71 f1 04    	psllw  $0x4,%xmm9
    c7bc:	66 44 0f f9 cf       	psubw  %xmm7,%xmm9
    c7c1:	66 44 0f fd c8       	paddw  %xmm0,%xmm9
    c7c6:	66 41 0f 6f c2       	movdqa %xmm10,%xmm0
    c7cb:	66 0f 71 f0 04       	psllw  $0x4,%xmm0
    c7d0:	66 44 0f 6f f8       	movdqa %xmm0,%xmm15
    c7d5:	f3 0f 7e 05 e3 2a 00 	movq   0x2ae3(%rip),%xmm0        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    c7dc:	00 
    c7dd:	66 44 0f fd f8       	paddw  %xmm0,%xmm15
    c7e2:	f3 0f 7e 05 c6 2a 00 	movq   0x2ac6(%rip),%xmm0        # f2b0 <__PRETTY_FUNCTION__.4+0x3d>
    c7e9:	00 
    c7ea:	66 45 0f fd f9       	paddw  %xmm9,%xmm15
    c7ef:	66 4c 0f 6e c8       	movq   %rax,%xmm9
    c7f4:	66 44 0f db c9       	pand   %xmm1,%xmm9
    c7f9:	66 41 0f 71 d7 08    	psrlw  $0x8,%xmm15
    c7ff:	66 44 0f db f9       	pand   %xmm1,%xmm15
    c804:	66 45 0f 67 cf       	packuswb %xmm15,%xmm9
    c809:	66 44 0f 6f fc       	movdqa %xmm4,%xmm15
    c80e:	66 45 0f 70 c9 08    	pshufd $0x8,%xmm9,%xmm9
    c814:	66 44 0f fc c8       	paddb  %xmm0,%xmm9
    c819:	66 41 0f 6f c0       	movdqa %xmm8,%xmm0
    c81e:	66 45 0f 60 c7       	punpcklbw %xmm15,%xmm8
    c823:	66 41 0f 60 c7       	punpcklbw %xmm15,%xmm0
    c828:	66 45 0f 70 c0 4e    	pshufd $0x4e,%xmm8,%xmm8
    c82e:	66 48 0f 7e c0       	movq   %xmm0,%rax
    c833:	66 41 0f 6f c4       	movdqa %xmm12,%xmm0
    c838:	66 4c 0f 7e c1       	movq   %xmm8,%rcx
    c83d:	66 41 0f 60 c7       	punpcklbw %xmm15,%xmm0
    c842:	66 44 0f 6f c4       	movdqa %xmm4,%xmm8
    c847:	f3 0f 7e 25 71 2a 00 	movq   0x2a71(%rip),%xmm4        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    c84e:	00 
    c84f:	66 48 0f 7e c7       	movq   %xmm0,%rdi
    c854:	66 41 0f 6f c4       	movdqa %xmm12,%xmm0
    c859:	66 44 0f 6f e3       	movdqa %xmm3,%xmm12
    c85e:	66 41 0f 60 d8       	punpcklbw %xmm8,%xmm3
    c863:	66 45 0f 60 e0       	punpcklbw %xmm8,%xmm12
    c868:	66 41 0f 60 c0       	punpcklbw %xmm8,%xmm0
    c86d:	66 0f 70 db 4e       	pshufd $0x4e,%xmm3,%xmm3
    c872:	66 4c 0f 6e c7       	movq   %rdi,%xmm8
    c877:	66 0f 70 c0 4e       	pshufd $0x4e,%xmm0,%xmm0
    c87c:	66 44 0f 6f fb       	movdqa %xmm3,%xmm15
    c881:	66 49 0f 7e c6       	movq   %xmm0,%r14
    c886:	66 45 0f fd f4       	paddw  %xmm12,%xmm14
    c88b:	f3 0f 7e 1d 8d 2a 00 	movq   0x2a8d(%rip),%xmm3        # f320 <__PRETTY_FUNCTION__.4+0xad>
    c892:	00 
    c893:	66 41 0f fd ff       	paddw  %xmm15,%xmm7
    c898:	66 41 0f d5 d8       	pmullw %xmm8,%xmm3
    c89d:	66 45 0f 6f c4       	movdqa %xmm12,%xmm8
    c8a2:	66 41 0f 71 f0 01    	psllw  $0x1,%xmm8
    c8a8:	66 45 0f fd c4       	paddw  %xmm12,%xmm8
    c8ad:	66 41 0f 71 f0 04    	psllw  $0x4,%xmm8
    c8b3:	66 45 0f f9 c4       	psubw  %xmm12,%xmm8
    c8b8:	66 44 0f fd c3       	paddw  %xmm3,%xmm8
    c8bd:	66 48 0f 6e d8       	movq   %rax,%xmm3
    c8c2:	66 0f 71 f3 04       	psllw  $0x4,%xmm3
    c8c7:	66 0f fd dc          	paddw  %xmm4,%xmm3
    c8cb:	f3 0f 7e 25 ed 29 00 	movq   0x29ed(%rip),%xmm4        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    c8d2:	00 
    c8d3:	66 44 0f fd c3       	paddw  %xmm3,%xmm8
    c8d8:	f3 0f 7e 1d 40 2a 00 	movq   0x2a40(%rip),%xmm3        # f320 <__PRETTY_FUNCTION__.4+0xad>
    c8df:	00 
    c8e0:	66 0f d5 d8          	pmullw %xmm0,%xmm3
    c8e4:	66 48 0f 6e c1       	movq   %rcx,%xmm0
    c8e9:	66 41 0f 71 d0 08    	psrlw  $0x8,%xmm8
    c8ef:	66 0f 71 f0 04       	psllw  $0x4,%xmm0
    c8f4:	66 44 0f d6 44 24 48 	movq   %xmm8,0x48(%rsp)
    c8fb:	66 44 0f 6f c3       	movdqa %xmm3,%xmm8
    c900:	66 41 0f 6f df       	movdqa %xmm15,%xmm3
    c905:	66 0f 71 f3 01       	psllw  $0x1,%xmm3
    c90a:	66 41 0f fd df       	paddw  %xmm15,%xmm3
    c90f:	66 0f 71 f3 04       	psllw  $0x4,%xmm3
    c914:	66 41 0f f9 df       	psubw  %xmm15,%xmm3
    c919:	66 41 0f fd d8       	paddw  %xmm8,%xmm3
    c91e:	66 44 0f 6f c0       	movdqa %xmm0,%xmm8
    c923:	66 44 0f fd c4       	paddw  %xmm4,%xmm8
    c928:	f3 0f 7e 64 24 08    	movq   0x8(%rsp),%xmm4
    c92e:	66 41 0f fd d8       	paddw  %xmm8,%xmm3
    c933:	f3 44 0f 7e 44 24 48 	movq   0x48(%rsp),%xmm8
    c93a:	66 44 0f db c1       	pand   %xmm1,%xmm8
    c93f:	66 0f 71 d3 08       	psrlw  $0x8,%xmm3
    c944:	66 0f db d9          	pand   %xmm1,%xmm3
    c948:	66 44 0f 67 c3       	packuswb %xmm3,%xmm8
    c94d:	f3 0f 7e 1d 5b 29 00 	movq   0x295b(%rip),%xmm3        # f2b0 <__PRETTY_FUNCTION__.4+0x3d>
    c954:	00 
    c955:	66 45 0f 70 c0 08    	pshufd $0x8,%xmm8,%xmm8
    c95b:	66 41 0f fc d8       	paddb  %xmm8,%xmm3
    c960:	66 45 0f 6f c1       	movdqa %xmm9,%xmm8
    c965:	66 44 0f 60 c3       	punpcklbw %xmm3,%xmm8
    c96a:	66 44 0f 60 cb       	punpcklbw %xmm3,%xmm9
    c96f:	f3 0f 7e 5c 24 c0    	movq   -0x40(%rsp),%xmm3
    c975:	66 45 0f d6 02       	movq   %xmm8,(%r10)
    c97a:	66 4d 0f 6e c7       	movq   %r15,%xmm8
    c97f:	66 45 0f 70 c9 4e    	pshufd $0x4e,%xmm9,%xmm9
    c985:	66 0f fd dc          	paddw  %xmm4,%xmm3
    c989:	66 48 0f 6e e0       	movq   %rax,%xmm4
    c98e:	66 45 0f d6 4a 08    	movq   %xmm9,0x8(%r10)
    c994:	f3 44 0f 7e 4c 24 c8 	movq   -0x38(%rsp),%xmm9
    c99b:	66 44 0f fd dc       	paddw  %xmm4,%xmm11
    c9a0:	f3 0f 7e 64 24 20    	movq   0x20(%rsp),%xmm4
    c9a6:	66 44 0f fd c4       	paddw  %xmm4,%xmm8
    c9ab:	66 48 0f 6e e1       	movq   %rcx,%xmm4
    c9b0:	66 44 0f fd d4       	paddw  %xmm4,%xmm10
    c9b5:	f3 0f 7e 64 24 28    	movq   0x28(%rsp),%xmm4
    c9bb:	66 41 0f fd db       	paddw  %xmm11,%xmm3
    c9c0:	66 4d 0f 6e d8       	movq   %r8,%xmm11
    c9c5:	66 44 0f fd cc       	paddw  %xmm4,%xmm9
    c9ca:	66 48 0f 6e e7       	movq   %rdi,%xmm4
    c9cf:	66 45 0f fd c2       	paddw  %xmm10,%xmm8
    c9d4:	66 0f 71 d3 02       	psrlw  $0x2,%xmm3
    c9d9:	66 4c 0f 6e d6       	movq   %rsi,%xmm10
    c9de:	66 44 0f fd d4       	paddw  %xmm4,%xmm10
    c9e3:	66 41 0f 71 d0 02    	psrlw  $0x2,%xmm8
    c9e9:	66 45 0f fd ca       	paddw  %xmm10,%xmm9
    c9ee:	f3 44 0f 7e 54 24 d8 	movq   -0x28(%rsp),%xmm10
    c9f5:	f3 0f 7e 64 24 40    	movq   0x40(%rsp),%xmm4
    c9fb:	f3 44 0f 7e 25 bc 28 	movq   0x28bc(%rip),%xmm12        # f2c0 <__PRETTY_FUNCTION__.4+0x4d>
    ca02:	00 00 
    ca04:	f3 0f 7e 44 24 98    	movq   -0x68(%rsp),%xmm0
    ca0a:	66 44 0f fd d4       	paddw  %xmm4,%xmm10
    ca0f:	66 49 0f 6e e6       	movq   %r14,%xmm4
    ca14:	66 44 0f fd dc       	paddw  %xmm4,%xmm11
    ca19:	f3 0f 7e 64 24 90    	movq   -0x70(%rsp),%xmm4
    ca1f:	66 0f fd e8          	paddw  %xmm0,%xmm5
    ca23:	f3 0f 7e 05 a5 28 00 	movq   0x28a5(%rip),%xmm0        # f2d0 <__PRETTY_FUNCTION__.4+0x5d>
    ca2a:	00 
    ca2b:	66 41 0f 71 d1 02    	psrlw  $0x2,%xmm9
    ca31:	66 41 0f fd e5       	paddw  %xmm13,%xmm4
    ca36:	66 0f fd fd          	paddw  %xmm5,%xmm7
    ca3a:	66 45 0f fd d3       	paddw  %xmm11,%xmm10
    ca3f:	f3 0f 7e 2d 99 28 00 	movq   0x2899(%rip),%xmm5        # f2e0 <__PRETTY_FUNCTION__.4+0x6d>
    ca46:	00 
    ca47:	f3 44 0f 7e 1d 80 28 	movq   0x2880(%rip),%xmm11        # f2d0 <__PRETTY_FUNCTION__.4+0x5d>
    ca4e:	00 00 
    ca50:	66 41 0f fd e6       	paddw  %xmm14,%xmm4
    ca55:	66 41 0f d5 e9       	pmullw %xmm9,%xmm5
    ca5a:	66 0f 71 d7 02       	psrlw  $0x2,%xmm7
    ca5f:	66 41 0f 71 d2 02    	psrlw  $0x2,%xmm10
    ca65:	66 44 0f d5 df       	pmullw %xmm7,%xmm11
    ca6a:	66 0f 71 d4 02       	psrlw  $0x2,%xmm4
    ca6f:	66 0f d5 c4          	pmullw %xmm4,%xmm0
    ca73:	66 0f fd e8          	paddw  %xmm0,%xmm5
    ca77:	66 0f 6f c3          	movdqa %xmm3,%xmm0
    ca7b:	66 0f 71 f0 03       	psllw  $0x3,%xmm0
    ca80:	66 0f f9 c3          	psubw  %xmm3,%xmm0
    ca84:	66 0f 71 f0 04       	psllw  $0x4,%xmm0
    ca89:	66 41 0f fd c4       	paddw  %xmm12,%xmm0
    ca8e:	66 0f fd e8          	paddw  %xmm0,%xmm5
    ca92:	f3 0f 7e 05 46 28 00 	movq   0x2846(%rip),%xmm0        # f2e0 <__PRETTY_FUNCTION__.4+0x6d>
    ca99:	00 
    ca9a:	66 41 0f d5 c2       	pmullw %xmm10,%xmm0
    ca9f:	66 0f 71 e5 08       	psraw  $0x8,%xmm5
    caa4:	66 0f db e9          	pand   %xmm1,%xmm5
    caa8:	66 41 0f fd c3       	paddw  %xmm11,%xmm0
    caad:	66 45 0f 6f d8       	movdqa %xmm8,%xmm11
    cab2:	66 41 0f 71 f3 03    	psllw  $0x3,%xmm11
    cab8:	66 45 0f f9 d8       	psubw  %xmm8,%xmm11
    cabd:	66 41 0f 71 f3 04    	psllw  $0x4,%xmm11
    cac3:	66 45 0f fd dc       	paddw  %xmm12,%xmm11
    cac8:	66 41 0f fd c3       	paddw  %xmm11,%xmm0
    cacd:	66 0f 71 e0 08       	psraw  $0x8,%xmm0
    cad2:	66 0f db c1          	pand   %xmm1,%xmm0
    cad6:	66 0f 67 e8          	packuswb %xmm0,%xmm5
    cada:	f3 0f 7e 05 0e 28 00 	movq   0x280e(%rip),%xmm0        # f2f0 <__PRETTY_FUNCTION__.4+0x7d>
    cae1:	00 
    cae2:	66 0f 70 ed 08       	pshufd $0x8,%xmm5,%xmm5
    cae7:	66 0f fc e8          	paddb  %xmm0,%xmm5
    caeb:	f3 0f 7e 05 0d 28 00 	movq   0x280d(%rip),%xmm0        # f300 <__PRETTY_FUNCTION__.4+0x8d>
    caf2:	00 
    caf3:	66 44 0f d5 c8       	pmullw %xmm0,%xmm9
    caf8:	66 0f 6f c4          	movdqa %xmm4,%xmm0
    cafc:	66 0f 71 f0 03       	psllw  $0x3,%xmm0
    cb01:	66 0f f9 c4          	psubw  %xmm4,%xmm0
    cb05:	66 0f 6f e7          	movdqa %xmm7,%xmm4
    cb09:	66 0f 71 f4 03       	psllw  $0x3,%xmm4
    cb0e:	66 0f f9 e7          	psubw  %xmm7,%xmm4
    cb12:	66 41 0f 6f fc       	movdqa %xmm12,%xmm7
    cb17:	66 0f 71 f0 04       	psllw  $0x4,%xmm0
    cb1c:	66 44 0f fd c8       	paddw  %xmm0,%xmm9
    cb21:	66 0f 6f c3          	movdqa %xmm3,%xmm0
    cb25:	66 0f 71 f0 02       	psllw  $0x2,%xmm0
    cb2a:	66 0f 71 f4 04       	psllw  $0x4,%xmm4
    cb2f:	66 0f fd c3          	paddw  %xmm3,%xmm0
    cb33:	66 41 0f 6f dc       	movdqa %xmm12,%xmm3
    cb38:	66 0f 71 f0 01       	psllw  $0x1,%xmm0
    cb3d:	66 0f f9 d8          	psubw  %xmm0,%xmm3
    cb41:	f3 0f 7e 05 b7 27 00 	movq   0x27b7(%rip),%xmm0        # f300 <__PRETTY_FUNCTION__.4+0x8d>
    cb48:	00 
    cb49:	66 41 0f d5 c2       	pmullw %xmm10,%xmm0
    cb4e:	66 41 0f fd d9       	paddw  %xmm9,%xmm3
    cb53:	66 0f 71 e3 08       	psraw  $0x8,%xmm3
    cb58:	66 0f fd c4          	paddw  %xmm4,%xmm0
    cb5c:	66 41 0f 6f e0       	movdqa %xmm8,%xmm4
    cb61:	66 0f db d9          	pand   %xmm1,%xmm3
    cb65:	66 0f 71 f4 02       	psllw  $0x2,%xmm4
    cb6a:	66 41 0f fd e0       	paddw  %xmm8,%xmm4
    cb6f:	66 0f 71 f4 01       	psllw  $0x1,%xmm4
    cb74:	66 0f f9 fc          	psubw  %xmm4,%xmm7
    cb78:	66 0f fd c7          	paddw  %xmm7,%xmm0
    cb7c:	66 0f 71 e0 08       	psraw  $0x8,%xmm0
    cb81:	66 0f db c1          	pand   %xmm1,%xmm0
    cb85:	66 0f 67 d8          	packuswb %xmm0,%xmm3
    cb89:	f3 0f 7e 05 5f 27 00 	movq   0x275f(%rip),%xmm0        # f2f0 <__PRETTY_FUNCTION__.4+0x7d>
    cb90:	00 
    cb91:	66 0f 70 db 08       	pshufd $0x8,%xmm3,%xmm3
    cb96:	66 0f fc c3          	paddb  %xmm3,%xmm0
    cb9a:	66 0f 6f dd          	movdqa %xmm5,%xmm3
    cb9e:	66 0f 60 e8          	punpcklbw %xmm0,%xmm5
    cba2:	66 0f 60 d8          	punpcklbw %xmm0,%xmm3
    cba6:	66 0f 70 ed 4e       	pshufd $0x4e,%xmm5,%xmm5
    cbab:	66 0f d6 1a          	movq   %xmm3,(%rdx)
    cbaf:	66 0f d6 6a 08       	movq   %xmm5,0x8(%rdx)
    cbb4:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
    cbb9:	48 63 db             	movslq %ebx,%rbx
    cbbc:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    cbc1:	48 8d 04 9d 00 00 00 	lea    0x0(,%rbx,4),%rax
    cbc8:	00 
    cbc9:	48 01 c6             	add    %rax,%rsi
    cbcc:	48 01 c7             	add    %rax,%rdi
    cbcf:	48 89 f0             	mov    %rsi,%rax
    cbd2:	48 8b 74 24 b0       	mov    -0x50(%rsp),%rsi
    cbd7:	4c 8d 4c 35 00       	lea    0x0(%rbp,%rsi,1),%r9
    cbdc:	44 0f b6 57 01       	movzbl 0x1(%rdi),%r10d
    cbe1:	44 0f b6 47 02       	movzbl 0x2(%rdi),%r8d
    cbe6:	44 0f b6 37          	movzbl (%rdi),%r14d
    cbea:	41 6b c8 2f          	imul   $0x2f,%r8d,%ecx
    cbee:	41 69 d2 9d 00 00 00 	imul   $0x9d,%r10d,%edx
    cbf5:	01 ca                	add    %ecx,%edx
    cbf7:	44 89 f1             	mov    %r14d,%ecx
    cbfa:	c1 e1 04             	shl    $0x4,%ecx
    cbfd:	8d 94 0a 80 00 00 00 	lea    0x80(%rdx,%rcx,1),%edx
    cc04:	c1 fa 08             	sar    $0x8,%edx
    cc07:	83 c2 10             	add    $0x10,%edx
    cc0a:	41 88 14 1c          	mov    %dl,(%r12,%rbx,1)
    cc0e:	0f b6 77 05          	movzbl 0x5(%rdi),%esi
    cc12:	0f b6 4f 06          	movzbl 0x6(%rdi),%ecx
    cc16:	0f b6 6f 04          	movzbl 0x4(%rdi),%ebp
    cc1a:	69 d6 9d 00 00 00    	imul   $0x9d,%esi,%edx
    cc20:	44 01 d6             	add    %r10d,%esi
    cc23:	44 6b f9 2f          	imul   $0x2f,%ecx,%r15d
    cc27:	44 01 c1             	add    %r8d,%ecx
    cc2a:	44 01 fa             	add    %r15d,%edx
    cc2d:	41 89 ef             	mov    %ebp,%r15d
    cc30:	44 01 f5             	add    %r14d,%ebp
    cc33:	41 c1 e7 04          	shl    $0x4,%r15d
    cc37:	42 8d 94 3a 80 00 00 	lea    0x80(%rdx,%r15,1),%edx
    cc3e:	00 
    cc3f:	c1 fa 08             	sar    $0x8,%edx
    cc42:	83 c2 10             	add    $0x10,%edx
    cc45:	41 88 54 1c 01       	mov    %dl,0x1(%r12,%rbx,1)
    cc4a:	44 0f b6 50 01       	movzbl 0x1(%rax),%r10d
    cc4f:	44 0f b6 40 02       	movzbl 0x2(%rax),%r8d
    cc54:	44 0f b6 30          	movzbl (%rax),%r14d
    cc58:	41 69 d2 9d 00 00 00 	imul   $0x9d,%r10d,%edx
    cc5f:	41 01 f2             	add    %esi,%r10d
    cc62:	45 6b f8 2f          	imul   $0x2f,%r8d,%r15d
    cc66:	41 01 c8             	add    %ecx,%r8d
    cc69:	44 01 fa             	add    %r15d,%edx
    cc6c:	45 89 f7             	mov    %r14d,%r15d
    cc6f:	41 01 ee             	add    %ebp,%r14d
    cc72:	41 c1 e7 04          	shl    $0x4,%r15d
    cc76:	42 8d 94 3a 80 00 00 	lea    0x80(%rdx,%r15,1),%edx
    cc7d:	00 
    cc7e:	c1 fa 08             	sar    $0x8,%edx
    cc81:	83 c2 10             	add    $0x10,%edx
    cc84:	41 88 54 1d 00       	mov    %dl,0x0(%r13,%rbx,1)
    cc89:	0f b6 50 05          	movzbl 0x5(%rax),%edx
    cc8d:	0f b6 48 06          	movzbl 0x6(%rax),%ecx
    cc91:	0f b6 68 04          	movzbl 0x4(%rax),%ebp
    cc95:	69 f2 9d 00 00 00    	imul   $0x9d,%edx,%esi
    cc9b:	44 01 d2             	add    %r10d,%edx
    cc9e:	44 6b f9 2f          	imul   $0x2f,%ecx,%r15d
    cca2:	44 01 fe             	add    %r15d,%esi
    cca5:	41 89 ef             	mov    %ebp,%r15d
    cca8:	41 c1 e7 04          	shl    $0x4,%r15d
    ccac:	42 8d b4 3e 80 00 00 	lea    0x80(%rsi,%r15,1),%esi
    ccb3:	00 
    ccb4:	c1 fe 08             	sar    $0x8,%esi
    ccb7:	83 c6 10             	add    $0x10,%esi
    ccba:	41 88 74 1d 01       	mov    %sil,0x1(%r13,%rbx,1)
    ccbf:	42 8d 74 35 00       	lea    0x0(%rbp,%r14,1),%esi
    ccc4:	c1 fe 02             	sar    $0x2,%esi
    ccc7:	c1 fa 02             	sar    $0x2,%edx
    ccca:	44 01 c1             	add    %r8d,%ecx
    cccd:	48 83 c7 08          	add    $0x8,%rdi
    ccd1:	c1 f9 02             	sar    $0x2,%ecx
    ccd4:	44 6b c2 aa          	imul   $0xffffffaa,%edx,%r8d
    ccd8:	48 83 c0 08          	add    $0x8,%rax
    ccdc:	44 6b d1 e6          	imul   $0xffffffe6,%ecx,%r10d
    cce0:	6b d2 9a             	imul   $0xffffff9a,%edx,%edx
    cce3:	6b c9 70             	imul   $0x70,%ecx,%ecx
    cce6:	45 01 d0             	add    %r10d,%r8d
    cce9:	44 6b d6 70          	imul   $0x70,%esi,%r10d
    cced:	6b f6 f6             	imul   $0xfffffff6,%esi,%esi
    ccf0:	01 ca                	add    %ecx,%edx
    ccf2:	47 8d 84 10 80 00 00 	lea    0x80(%r8,%r10,1),%r8d
    ccf9:	00 
    ccfa:	8d 94 32 80 00 00 00 	lea    0x80(%rdx,%rsi,1),%edx
    cd01:	41 c1 f8 08          	sar    $0x8,%r8d
    cd05:	c1 fa 08             	sar    $0x8,%edx
    cd08:	41 83 e8 80          	sub    $0xffffff80,%r8d
    cd0c:	83 ea 80             	sub    $0xffffff80,%edx
    cd0f:	45 88 04 19          	mov    %r8b,(%r9,%rbx,1)
    cd13:	41 88 54 19 01       	mov    %dl,0x1(%r9,%rbx,1)
    cd18:	48 83 c3 02          	add    $0x2,%rbx
    cd1c:	41 39 db             	cmp    %ebx,%r11d
    cd1f:	0f 8f b7 fe ff ff    	jg     cbdc <convert_adaptive_job+0x2c8c>
    cd25:	8b 44 24 74          	mov    0x74(%rsp),%eax
    cd29:	8b 5c 24 b8          	mov    -0x48(%rsp),%ebx
    cd2d:	83 c0 01             	add    $0x1,%eax
    cd30:	39 d8                	cmp    %ebx,%eax
    cd32:	0f 8f 34 01 00 00    	jg     ce6c <convert_adaptive_job+0x2f1c>
    cd38:	48 8b 44 24 e8       	mov    -0x18(%rsp),%rax
    cd3d:	c7 44 24 b8 01 00 00 	movl   $0x1,-0x48(%rsp)
    cd44:	00 
    cd45:	c7 44 24 74 01 00 00 	movl   $0x1,0x74(%rsp)
    cd4c:	00 
    cd4d:	44 8b 5c 24 a8       	mov    -0x58(%rsp),%r11d
    cd52:	48 63 48 24          	movslq 0x24(%rax),%rcx
    cd56:	8b 5c 24 f8          	mov    -0x8(%rsp),%ebx
    cd5a:	e9 70 e5 ff ff       	jmp    b2cf <convert_adaptive_job+0x137f>
    cd5f:	48 8b 7c 24 b0       	mov    -0x50(%rsp),%rdi
    cd64:	44 01 d3             	add    %r10d,%ebx
    cd67:	41 01 cb             	add    %ecx,%r11d
    cd6a:	01 c5                	add    %eax,%ebp
    cd6c:	88 14 37             	mov    %dl,(%rdi,%rsi,1)
    cd6f:	41 83 f8 03          	cmp    $0x3,%r8d
    cd73:	0f 85 cd 00 00 00    	jne    ce46 <convert_adaptive_job+0x2ef6>
    cd79:	41 c1 fb 02          	sar    $0x2,%r11d
    cd7d:	c1 fd 02             	sar    $0x2,%ebp
    cd80:	48 8b 7c 24 c0       	mov    -0x40(%rsp),%rdi
    cd85:	44 6b c5 e6          	imul   $0xffffffe6,%ebp,%r8d
    cd89:	c1 fb 02             	sar    $0x2,%ebx
    cd8c:	41 6b f3 aa          	imul   $0xffffffaa,%r11d,%esi
    cd90:	44 01 c6             	add    %r8d,%esi
    cd93:	44 6b c3 70          	imul   $0x70,%ebx,%r8d
    cd97:	42 8d b4 06 80 00 00 	lea    0x80(%rsi,%r8,1),%esi
    cd9e:	00 
    cd9f:	45 31 c0             	xor    %r8d,%r8d
    cda2:	c1 fe 08             	sar    $0x8,%esi
    cda5:	83 ee 80             	sub    $0xffffff80,%esi
    cda8:	78 10                	js     cdba <convert_adaptive_job+0x2e6a>
    cdaa:	81 fe ff 00 00 00    	cmp    $0xff,%esi
    cdb0:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    cdb6:	44 0f 4e c6          	cmovle %esi,%r8d
    cdba:	6b ed 70             	imul   $0x70,%ebp,%ebp
    cdbd:	48 8b 44 24 b8       	mov    -0x48(%rsp),%rax
    cdc2:	45 6b db 9a          	imul   $0xffffff9a,%r11d,%r11d
    cdc6:	6b db f6             	imul   $0xfffffff6,%ebx,%ebx
    cdc9:	44 88 04 38          	mov    %r8b,(%rax,%rdi,1)
    cdcd:	45 31 c0             	xor    %r8d,%r8d
    cdd0:	41 01 eb             	add    %ebp,%r11d
    cdd3:	41 8d b4 1b 80 00 00 	lea    0x80(%r11,%rbx,1),%esi
    cdda:	00 
    cddb:	c1 fe 08             	sar    $0x8,%esi
    cdde:	83 ee 80             	sub    $0xffffff80,%esi
    cde1:	78 10                	js     cdf3 <convert_adaptive_job+0x2ea3>
    cde3:	81 fe ff 00 00 00    	cmp    $0xff,%esi
    cde9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    cdef:	44 0f 4e c6          	cmovle %esi,%r8d
    cdf3:	48 8b 44 24 b8       	mov    -0x48(%rsp),%rax
    cdf8:	44 88 44 38 01       	mov    %r8b,0x1(%rax,%rdi,1)
    cdfd:	48 83 c7 02          	add    $0x2,%rdi
    ce01:	39 7c 24 e8          	cmp    %edi,-0x18(%rsp)
    ce05:	0f 8f 1c d7 ff ff    	jg     a527 <convert_adaptive_job+0x5d7>
    ce0b:	44 8b 5c 24 d8       	mov    -0x28(%rsp),%r11d
    ce10:	44 8b 74 24 f0       	mov    -0x10(%rsp),%r14d
    ce15:	48 8b 74 24 f8       	mov    -0x8(%rsp),%rsi
    ce1a:	8b 2c 24             	mov    (%rsp),%ebp
    ce1d:	8b 54 24 08          	mov    0x8(%rsp),%edx
    ce21:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    ce26:	8d 42 01             	lea    0x1(%rdx),%eax
    ce29:	39 e8                	cmp    %ebp,%eax
    ce2b:	0f 8f 1b d9 ff ff    	jg     a74c <convert_adaptive_job+0x7fc>
    ce31:	41 8b 5c 24 24       	mov    0x24(%r12),%ebx
    ce36:	45 89 da             	mov    %r11d,%r10d
    ce39:	49 63 fe             	movslq %r14d,%rdi
    ce3c:	ba 01 00 00 00       	mov    $0x1,%edx
    ce41:	e9 80 d6 ff ff       	jmp    a4c6 <convert_adaptive_job+0x576>
    ce46:	41 b8 03 00 00 00    	mov    $0x3,%r8d
    ce4c:	e9 e9 d6 ff ff       	jmp    a53a <convert_adaptive_job+0x5ea>
    ce51:	89 d9                	mov    %ebx,%ecx
    ce53:	45 31 e4             	xor    %r12d,%r12d
    ce56:	31 ff                	xor    %edi,%edi
    ce58:	43 8d 04 00          	lea    (%r8,%r8,1),%eax
    ce5c:	31 ed                	xor    %ebp,%ebp
    ce5e:	89 44 24 98          	mov    %eax,-0x68(%rsp)
    ce62:	48 63 f0             	movslq %eax,%rsi
    ce65:	89 c8                	mov    %ecx,%eax
    ce67:	e9 3d d6 ff ff       	jmp    a4a9 <convert_adaptive_job+0x559>
    ce6c:	48 8b 5c 24 e8       	mov    -0x18(%rsp),%rbx
    ce71:	8b 84 24 10 01 00 00 	mov    0x110(%rsp),%eax
    ce78:	8b 94 24 14 01 00 00 	mov    0x114(%rsp),%edx
    ce7f:	8b 4b 34             	mov    0x34(%rbx),%ecx
    ce82:	83 c0 01             	add    $0x1,%eax
    ce85:	48 83 44 24 f0 01    	addq   $0x1,-0x10(%rsp)
    ce8b:	83 c2 02             	add    $0x2,%edx
    ce8e:	39 c8                	cmp    %ecx,%eax
    ce90:	0f 8c 80 e3 ff ff    	jl     b216 <convert_adaptive_job+0x12c6>
    ce96:	e9 d2 d8 ff ff       	jmp    a76d <convert_adaptive_job+0x81d>
    ce9b:	48 63 c3             	movslq %ebx,%rax
    ce9e:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
    cea3:	48 8d 14 85 00 00 00 	lea    0x0(,%rax,4),%rdx
    ceaa:	00 
    ceab:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    ceb0:	48 01 d3             	add    %rdx,%rbx
    ceb3:	49 01 d0             	add    %rdx,%r8
    ceb6:	48 89 da             	mov    %rbx,%rdx
    ceb9:	48 8b 5c 24 b0       	mov    -0x50(%rsp),%rbx
    cebe:	4c 8d 4c 1d 00       	lea    0x0(%rbp,%rbx,1),%r9
    cec3:	41 0f b6 58 01       	movzbl 0x1(%r8),%ebx
    cec8:	45 0f b6 50 02       	movzbl 0x2(%r8),%r10d
    cecd:	45 0f b6 30          	movzbl (%r8),%r14d
    ced1:	41 6b f2 2f          	imul   $0x2f,%r10d,%esi
    ced5:	69 cb 9d 00 00 00    	imul   $0x9d,%ebx,%ecx
    cedb:	01 f1                	add    %esi,%ecx
    cedd:	44 89 f6             	mov    %r14d,%esi
    cee0:	c1 e6 04             	shl    $0x4,%esi
    cee3:	8d 8c 31 80 00 00 00 	lea    0x80(%rcx,%rsi,1),%ecx
    ceea:	c1 f9 08             	sar    $0x8,%ecx
    ceed:	83 c1 10             	add    $0x10,%ecx
    cef0:	41 88 0c 04          	mov    %cl,(%r12,%rax,1)
    cef4:	41 0f b6 78 05       	movzbl 0x5(%r8),%edi
    cef9:	41 0f b6 70 06       	movzbl 0x6(%r8),%esi
    cefe:	41 0f b6 68 04       	movzbl 0x4(%r8),%ebp
    cf03:	69 cf 9d 00 00 00    	imul   $0x9d,%edi,%ecx
    cf09:	01 df                	add    %ebx,%edi
    cf0b:	44 6b fe 2f          	imul   $0x2f,%esi,%r15d
    cf0f:	44 01 d6             	add    %r10d,%esi
    cf12:	44 01 f9             	add    %r15d,%ecx
    cf15:	41 89 ef             	mov    %ebp,%r15d
    cf18:	44 01 f5             	add    %r14d,%ebp
    cf1b:	41 c1 e7 04          	shl    $0x4,%r15d
    cf1f:	42 8d 8c 39 80 00 00 	lea    0x80(%rcx,%r15,1),%ecx
    cf26:	00 
    cf27:	c1 f9 08             	sar    $0x8,%ecx
    cf2a:	83 c1 10             	add    $0x10,%ecx
    cf2d:	41 88 4c 04 01       	mov    %cl,0x1(%r12,%rax,1)
    cf32:	0f b6 5a 01          	movzbl 0x1(%rdx),%ebx
    cf36:	44 0f b6 52 02       	movzbl 0x2(%rdx),%r10d
    cf3b:	44 0f b6 32          	movzbl (%rdx),%r14d
    cf3f:	69 cb 9d 00 00 00    	imul   $0x9d,%ebx,%ecx
    cf45:	01 fb                	add    %edi,%ebx
    cf47:	45 6b fa 2f          	imul   $0x2f,%r10d,%r15d
    cf4b:	41 01 f2             	add    %esi,%r10d
    cf4e:	44 01 f9             	add    %r15d,%ecx
    cf51:	45 89 f7             	mov    %r14d,%r15d
    cf54:	41 01 ee             	add    %ebp,%r14d
    cf57:	41 c1 e7 04          	shl    $0x4,%r15d
    cf5b:	42 8d 8c 39 80 00 00 	lea    0x80(%rcx,%r15,1),%ecx
    cf62:	00 
    cf63:	c1 f9 08             	sar    $0x8,%ecx
    cf66:	83 c1 10             	add    $0x10,%ecx
    cf69:	41 88 4c 05 00       	mov    %cl,0x0(%r13,%rax,1)
    cf6e:	0f b6 4a 05          	movzbl 0x5(%rdx),%ecx
    cf72:	0f b6 72 06          	movzbl 0x6(%rdx),%esi
    cf76:	0f b6 6a 04          	movzbl 0x4(%rdx),%ebp
    cf7a:	69 f9 9d 00 00 00    	imul   $0x9d,%ecx,%edi
    cf80:	01 d9                	add    %ebx,%ecx
    cf82:	44 6b fe 2f          	imul   $0x2f,%esi,%r15d
    cf86:	44 01 ff             	add    %r15d,%edi
    cf89:	41 89 ef             	mov    %ebp,%r15d
    cf8c:	41 c1 e7 04          	shl    $0x4,%r15d
    cf90:	42 8d bc 3f 80 00 00 	lea    0x80(%rdi,%r15,1),%edi
    cf97:	00 
    cf98:	c1 ff 08             	sar    $0x8,%edi
    cf9b:	83 c7 10             	add    $0x10,%edi
    cf9e:	41 88 7c 05 01       	mov    %dil,0x1(%r13,%rax,1)
    cfa3:	42 8d 7c 35 00       	lea    0x0(%rbp,%r14,1),%edi
    cfa8:	c1 ff 02             	sar    $0x2,%edi
    cfab:	c1 f9 02             	sar    $0x2,%ecx
    cfae:	44 01 d6             	add    %r10d,%esi
    cfb1:	49 83 c0 08          	add    $0x8,%r8
    cfb5:	c1 fe 02             	sar    $0x2,%esi
    cfb8:	44 6b d1 aa          	imul   $0xffffffaa,%ecx,%r10d
    cfbc:	48 83 c2 08          	add    $0x8,%rdx
    cfc0:	6b de e6             	imul   $0xffffffe6,%esi,%ebx
    cfc3:	6b c9 9a             	imul   $0xffffff9a,%ecx,%ecx
    cfc6:	6b f6 70             	imul   $0x70,%esi,%esi
    cfc9:	41 01 da             	add    %ebx,%r10d
    cfcc:	6b df 70             	imul   $0x70,%edi,%ebx
    cfcf:	6b ff f6             	imul   $0xfffffff6,%edi,%edi
    cfd2:	01 f1                	add    %esi,%ecx
    cfd4:	45 8d 94 1a 80 00 00 	lea    0x80(%r10,%rbx,1),%r10d
    cfdb:	00 
    cfdc:	8d 8c 39 80 00 00 00 	lea    0x80(%rcx,%rdi,1),%ecx
    cfe3:	41 c1 fa 08          	sar    $0x8,%r10d
    cfe7:	c1 f9 08             	sar    $0x8,%ecx
    cfea:	41 83 ea 80          	sub    $0xffffff80,%r10d
    cfee:	83 e9 80             	sub    $0xffffff80,%ecx
    cff1:	45 88 14 01          	mov    %r10b,(%r9,%rax,1)
    cff5:	41 88 4c 01 01       	mov    %cl,0x1(%r9,%rax,1)
    cffa:	48 83 c0 02          	add    $0x2,%rax
    cffe:	41 39 c3             	cmp    %eax,%r11d
    d001:	0f 8f bc fe ff ff    	jg     cec3 <convert_adaptive_job+0x2f73>
    d007:	e9 19 fd ff ff       	jmp    cd25 <convert_adaptive_job+0x2dd5>
    d00c:	89 4c 24 a8          	mov    %ecx,-0x58(%rsp)
    d010:	31 db                	xor    %ebx,%ebx
    d012:	c7 44 24 f8 00 00 00 	movl   $0x0,-0x8(%rsp)
    d019:	00 
    d01a:	48 63 f2             	movslq %edx,%rsi
    d01d:	c7 44 24 b8 00 00 00 	movl   $0x0,-0x48(%rsp)
    d024:	00 
    d025:	44 8b 5c 24 a8       	mov    -0x58(%rsp),%r11d
    d02a:	48 89 34 24          	mov    %rsi,(%rsp)
    d02e:	8d 72 01             	lea    0x1(%rdx),%esi
    d031:	48 63 f6             	movslq %esi,%rsi
    d034:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    d039:	e9 7b e2 ff ff       	jmp    b2b9 <convert_adaptive_job+0x1369>
    d03e:	31 c9                	xor    %ecx,%ecx
    d040:	e9 41 ef ff ff       	jmp    bf86 <convert_adaptive_job+0x2036>
    d045:	0f 1f 00             	nopl   (%rax)
    d048:	66 45 0f ef c0       	pxor   %xmm8,%xmm8
    d04d:	44 89 da             	mov    %r11d,%edx
    d050:	89 d9                	mov    %ebx,%ecx
    d052:	89 c6                	mov    %eax,%esi
    d054:	66 41 0f 6f e8       	movdqa %xmm8,%xmm5
    d059:	66 44 0f d6 44 24 90 	movq   %xmm8,-0x70(%rsp)
    d060:	31 ff                	xor    %edi,%edi
    d062:	45 31 d2             	xor    %r10d,%r10d
    d065:	e9 bc dd ff ff       	jmp    ae26 <convert_adaptive_job+0xed6>
    d06a:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    d06f:	48 63 ff             	movslq %edi,%rdi
    d072:	88 14 38             	mov    %dl,(%rax,%rdi,1)
    d075:	83 f9 03             	cmp    $0x3,%ecx
    d078:	0f 85 e3 00 00 00    	jne    d161 <convert_adaptive_job+0x3211>
    d07e:	8b 54 24 10          	mov    0x10(%rsp),%edx
    d082:	8b 74 24 08          	mov    0x8(%rsp),%esi
    d086:	8b 4c 24 18          	mov    0x18(%rsp),%ecx
    d08a:	4c 8b 44 24 40       	mov    0x40(%rsp),%r8
    d08f:	c1 fa 02             	sar    $0x2,%edx
    d092:	c1 fe 02             	sar    $0x2,%esi
    d095:	44 6b d6 e6          	imul   $0xffffffe6,%esi,%r10d
    d099:	c1 f9 02             	sar    $0x2,%ecx
    d09c:	6b c2 aa             	imul   $0xffffffaa,%edx,%eax
    d09f:	44 01 d0             	add    %r10d,%eax
    d0a2:	44 6b d1 70          	imul   $0x70,%ecx,%r10d
    d0a6:	42 8d 84 10 80 00 00 	lea    0x80(%rax,%r10,1),%eax
    d0ad:	00 
    d0ae:	45 31 d2             	xor    %r10d,%r10d
    d0b1:	c1 f8 08             	sar    $0x8,%eax
    d0b4:	83 e8 80             	sub    $0xffffff80,%eax
    d0b7:	78 0f                	js     d0c8 <convert_adaptive_job+0x3178>
    d0b9:	3d ff 00 00 00       	cmp    $0xff,%eax
    d0be:	41 ba ff ff ff ff    	mov    $0xffffffff,%r10d
    d0c4:	44 0f 4e d0          	cmovle %eax,%r10d
    d0c8:	6b f6 70             	imul   $0x70,%esi,%esi
    d0cb:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    d0d0:	6b d2 9a             	imul   $0xffffff9a,%edx,%edx
    d0d3:	6b c9 f6             	imul   $0xfffffff6,%ecx,%ecx
    d0d6:	46 88 14 00          	mov    %r10b,(%rax,%r8,1)
    d0da:	01 f2                	add    %esi,%edx
    d0dc:	8d 84 0a 80 00 00 00 	lea    0x80(%rdx,%rcx,1),%eax
    d0e3:	31 d2                	xor    %edx,%edx
    d0e5:	c1 f8 08             	sar    $0x8,%eax
    d0e8:	83 e8 80             	sub    $0xffffff80,%eax
    d0eb:	78 0d                	js     d0fa <convert_adaptive_job+0x31aa>
    d0ed:	3d ff 00 00 00       	cmp    $0xff,%eax
    d0f2:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    d0f7:	0f 4e d0             	cmovle %eax,%edx
    d0fa:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    d0ff:	42 88 54 00 01       	mov    %dl,0x1(%rax,%r8,1)
    d104:	49 83 c0 02          	add    $0x2,%r8
    d108:	44 39 44 24 48       	cmp    %r8d,0x48(%rsp)
    d10d:	0f 8f 6f da ff ff    	jg     ab82 <convert_adaptive_job+0xc32>
    d113:	8b bc 24 08 01 00 00 	mov    0x108(%rsp),%edi
    d11a:	44 8b 4c 24 78       	mov    0x78(%rsp),%r9d
    d11f:	48 8b ac 24 88 00 00 	mov    0x88(%rsp),%rbp
    d126:	00 
    d127:	44 8b ac 24 98 00 00 	mov    0x98(%rsp),%r13d
    d12e:	00 
    d12f:	44 8b b4 24 a8 00 00 	mov    0xa8(%rsp),%r14d
    d136:	00 
    d137:	4c 8b a4 24 b8 00 00 	mov    0xb8(%rsp),%r12
    d13e:	00 
    d13f:	41 8d 46 01          	lea    0x1(%r14),%eax
    d143:	44 39 e8             	cmp    %r13d,%eax
    d146:	7f 2d                	jg     d175 <convert_adaptive_job+0x3225>
    d148:	48 8b 44 24 e8       	mov    -0x18(%rsp),%rax
    d14d:	41 89 fb             	mov    %edi,%r11d
    d150:	44 89 cb             	mov    %r9d,%ebx
    d153:	41 be 01 00 00 00    	mov    $0x1,%r14d
    d159:	8b 48 24             	mov    0x24(%rax),%ecx
    d15c:	e9 9c d9 ff ff       	jmp    aafd <convert_adaptive_job+0xbad>
    d161:	b9 03 00 00 00       	mov    $0x3,%ecx
    d166:	e9 39 da ff ff       	jmp    aba4 <convert_adaptive_job+0xc54>
    d16b:	ba 10 00 00 00       	mov    $0x10,%edx
    d170:	e9 5b e0 ff ff       	jmp    b1d0 <convert_adaptive_job+0x1280>
    d175:	48 8b 44 24 e8       	mov    -0x18(%rsp),%rax
    d17a:	44 8b 54 24 74       	mov    0x74(%rsp),%r10d
    d17f:	8b 48 34             	mov    0x34(%rax),%ecx
    d182:	41 83 c2 01          	add    $0x1,%r10d
    d186:	49 83 c4 01          	add    $0x1,%r12
    d18a:	41 39 ca             	cmp    %ecx,%r10d
    d18d:	0f 8c d4 d8 ff ff    	jl     aa67 <convert_adaptive_job+0xb17>
    d193:	e9 d5 d5 ff ff       	jmp    a76d <convert_adaptive_job+0x81d>
    d198:	89 cf                	mov    %ecx,%edi
    d19a:	45 31 c9             	xor    %r9d,%r9d
    d19d:	31 db                	xor    %ebx,%ebx
    d19f:	43 8d 04 12          	lea    (%r10,%r10,1),%eax
    d1a3:	41 89 fb             	mov    %edi,%r11d
    d1a6:	45 31 ed             	xor    %r13d,%r13d
    d1a9:	89 44 24 58          	mov    %eax,0x58(%rsp)
    d1ad:	48 63 e8             	movslq %eax,%rbp
    d1b0:	e9 3b d9 ff ff       	jmp    aaf0 <convert_adaptive_job+0xba0>
    d1b5:	0f 1f 00             	nopl   (%rax)
    d1b8:	4c 8b 74 24 b0       	mov    -0x50(%rsp),%r14
    d1bd:	01 d3                	add    %edx,%ebx
    d1bf:	41 01 cb             	add    %ecx,%r11d
    d1c2:	01 c5                	add    %eax,%ebp
    d1c4:	45 88 04 36          	mov    %r8b,(%r14,%rsi,1)
    d1c8:	83 ff 03             	cmp    $0x3,%edi
    d1cb:	0f 85 c0 00 00 00    	jne    d291 <convert_adaptive_job+0x3341>
    d1d1:	41 c1 fb 02          	sar    $0x2,%r11d
    d1d5:	c1 fd 02             	sar    $0x2,%ebp
    d1d8:	4c 8b 4c 24 c0       	mov    -0x40(%rsp),%r9
    d1dd:	6b fd e6             	imul   $0xffffffe6,%ebp,%edi
    d1e0:	c1 fb 02             	sar    $0x2,%ebx
    d1e3:	41 6b f3 aa          	imul   $0xffffffaa,%r11d,%esi
    d1e7:	01 fe                	add    %edi,%esi
    d1e9:	6b fb 70             	imul   $0x70,%ebx,%edi
    d1ec:	8d b4 3e 80 00 00 00 	lea    0x80(%rsi,%rdi,1),%esi
    d1f3:	31 ff                	xor    %edi,%edi
    d1f5:	c1 fe 08             	sar    $0x8,%esi
    d1f8:	83 ee 80             	sub    $0xffffff80,%esi
    d1fb:	78 0e                	js     d20b <convert_adaptive_job+0x32bb>
    d1fd:	81 fe ff 00 00 00    	cmp    $0xff,%esi
    d203:	bf ff ff ff ff       	mov    $0xffffffff,%edi
    d208:	0f 4e fe             	cmovle %esi,%edi
    d20b:	6b ed 70             	imul   $0x70,%ebp,%ebp
    d20e:	48 8b 44 24 b8       	mov    -0x48(%rsp),%rax
    d213:	45 6b db 9a          	imul   $0xffffff9a,%r11d,%r11d
    d217:	6b db f6             	imul   $0xfffffff6,%ebx,%ebx
    d21a:	42 88 3c 08          	mov    %dil,(%rax,%r9,1)
    d21e:	31 ff                	xor    %edi,%edi
    d220:	41 01 eb             	add    %ebp,%r11d
    d223:	41 8d b4 1b 80 00 00 	lea    0x80(%r11,%rbx,1),%esi
    d22a:	00 
    d22b:	c1 fe 08             	sar    $0x8,%esi
    d22e:	83 ee 80             	sub    $0xffffff80,%esi
    d231:	78 0e                	js     d241 <convert_adaptive_job+0x32f1>
    d233:	81 fe ff 00 00 00    	cmp    $0xff,%esi
    d239:	bf ff ff ff ff       	mov    $0xffffffff,%edi
    d23e:	0f 4e fe             	cmovle %esi,%edi
    d241:	48 8b 44 24 b8       	mov    -0x48(%rsp),%rax
    d246:	42 88 7c 08 01       	mov    %dil,0x1(%rax,%r9,1)
    d24b:	49 83 c1 02          	add    $0x2,%r9
    d24f:	44 39 4c 24 e8       	cmp    %r9d,-0x18(%rsp)
    d254:	0f 8f 35 d6 ff ff    	jg     a88f <convert_adaptive_job+0x93f>
    d25a:	44 8b 5c 24 d8       	mov    -0x28(%rsp),%r11d
    d25f:	8b 6c 24 f0          	mov    -0x10(%rsp),%ebp
    d263:	48 8b 74 24 f8       	mov    -0x8(%rsp),%rsi
    d268:	44 8b 14 24          	mov    (%rsp),%r10d
    d26c:	8b 54 24 08          	mov    0x8(%rsp),%edx
    d270:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    d275:	8d 42 01             	lea    0x1(%rdx),%eax
    d278:	44 39 d0             	cmp    %r10d,%eax
    d27b:	7f 1e                	jg     d29b <convert_adaptive_job+0x334b>
    d27d:	41 8b 5d 24          	mov    0x24(%r13),%ebx
    d281:	45 89 d8             	mov    %r11d,%r8d
    d284:	4c 63 cd             	movslq %ebp,%r9
    d287:	ba 01 00 00 00       	mov    $0x1,%edx
    d28c:	e9 a0 d5 ff ff       	jmp    a831 <convert_adaptive_job+0x8e1>
    d291:	bf 03 00 00 00       	mov    $0x3,%edi
    d296:	e9 07 d6 ff ff       	jmp    a8a2 <convert_adaptive_job+0x952>
    d29b:	48 89 ca             	mov    %rcx,%rdx
    d29e:	8b 7c 24 c8          	mov    -0x38(%rsp),%edi
    d2a2:	41 8b 4d 34          	mov    0x34(%r13),%ecx
    d2a6:	4d 89 ef             	mov    %r13,%r15
    d2a9:	83 c7 01             	add    $0x1,%edi
    d2ac:	48 83 c2 01          	add    $0x1,%rdx
    d2b0:	39 cf                	cmp    %ecx,%edi
    d2b2:	0f 8c d6 d4 ff ff    	jl     a78e <convert_adaptive_job+0x83e>
    d2b8:	e9 b0 d4 ff ff       	jmp    a76d <convert_adaptive_job+0x81d>
    d2bd:	89 d9                	mov    %ebx,%ecx
    d2bf:	45 31 d2             	xor    %r10d,%r10d
    d2c2:	45 31 c9             	xor    %r9d,%r9d
    d2c5:	8d 04 3f             	lea    (%rdi,%rdi,1),%eax
    d2c8:	31 ed                	xor    %ebp,%ebp
    d2ca:	89 44 24 98          	mov    %eax,-0x68(%rsp)
    d2ce:	48 63 f0             	movslq %eax,%rsi
    d2d1:	89 c8                	mov    %ecx,%eax
    d2d3:	e9 38 d5 ff ff       	jmp    a810 <convert_adaptive_job+0x8c0>
    d2d8:	8b 74 24 08          	mov    0x8(%rsp),%esi
    d2dc:	41 8b 4d 34          	mov    0x34(%r13),%ecx
    d2e0:	83 c6 01             	add    $0x1,%esi
    d2e3:	48 83 44 24 b0 01    	addq   $0x1,-0x50(%rsp)
    d2e9:	83 c0 04             	add    $0x4,%eax
    d2ec:	39 ce                	cmp    %ecx,%esi
    d2ee:	0f 8c c3 cc ff ff    	jl     9fb7 <convert_adaptive_job+0x67>
    d2f4:	e9 74 d4 ff ff       	jmp    a76d <convert_adaptive_job+0x81d>
    d2f9:	c7 44 24 c0 00 00 00 	movl   $0x0,-0x40(%rsp)
    d300:	00 
    d301:	41 89 df             	mov    %ebx,%r15d
    d304:	31 ff                	xor    %edi,%edi
    d306:	45 31 d2             	xor    %r10d,%r10d
    d309:	31 d2                	xor    %edx,%edx
    d30b:	e9 1c cd ff ff       	jmp    a02c <convert_adaptive_job+0xdc>
    d310:	31 d2                	xor    %edx,%edx
    d312:	e9 15 cd ff ff       	jmp    a02c <convert_adaptive_job+0xdc>

Disassembly of section .fini:
