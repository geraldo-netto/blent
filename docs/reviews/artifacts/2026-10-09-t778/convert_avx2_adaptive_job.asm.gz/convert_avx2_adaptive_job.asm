
/tmp/blent-adaptive-20261009/t778-after:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

0000000000003ab0 <convert_avx2_adaptive_job>:
    3ab0:	f3 0f 1e fa          	endbr64
    3ab4:	55                   	push   %rbp
    3ab5:	48 89 e5             	mov    %rsp,%rbp
    3ab8:	41 57                	push   %r15
    3aba:	41 56                	push   %r14
    3abc:	41 55                	push   %r13
    3abe:	41 54                	push   %r12
    3ac0:	53                   	push   %rbx
    3ac1:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
    3ac5:	48 81 ec 28 03 00 00 	sub    $0x328,%rsp
    3acc:	48 89 bc 24 c0 00 00 	mov    %rdi,0xc0(%rsp)
    3ad3:	00 
    3ad4:	8b 47 30             	mov    0x30(%rdi),%eax
    3ad7:	8b 7f 34             	mov    0x34(%rdi),%edi
    3ada:	48 63 f0             	movslq %eax,%rsi
    3add:	48 89 74 24 e0       	mov    %rsi,-0x20(%rsp)
    3ae2:	39 f8                	cmp    %edi,%eax
    3ae4:	0f 8d db 17 00 00    	jge    52c5 <convert_avx2_adaptive_job+0x1815>
    3aea:	c5 f9 6f 35 9e b7 00 	vmovdqa 0xb79e(%rip),%xmm6        # f290 <__PRETTY_FUNCTION__.4+0x1d>
    3af1:	00 
    3af2:	8d 0c 00             	lea    (%rax,%rax,1),%ecx
    3af5:	41 89 c0             	mov    %eax,%r8d
    3af8:	c5 f9 73 de 08       	vpsrldq $0x8,%xmm6,%xmm0
    3afd:	c4 e2 79 30 f0       	vpmovzxbw %xmm0,%xmm6
    3b02:	c5 f9 7f b4 24 a8 00 	vmovdqa %xmm6,0xa8(%rsp)
    3b09:	00 00 
    3b0b:	c5 f9 6f 35 8d b7 00 	vmovdqa 0xb78d(%rip),%xmm6        # f2a0 <__PRETTY_FUNCTION__.4+0x2d>
    3b12:	00 
    3b13:	c5 f9 73 de 08       	vpsrldq $0x8,%xmm6,%xmm0
    3b18:	c4 e2 79 30 f0       	vpmovzxbw %xmm0,%xmm6
    3b1d:	c5 f9 7f 74 24 e8    	vmovdqa %xmm6,-0x18(%rsp)
    3b23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3b28:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
    3b2f:	00 
    3b30:	48 8b 50 38          	mov    0x38(%rax),%rdx
    3b34:	48 85 d2             	test   %rdx,%rdx
    3b37:	74 1b                	je     3b54 <convert_avx2_adaptive_job+0xa4>
    3b39:	44 89 c0             	mov    %r8d,%eax
    3b3c:	c1 f8 03             	sar    $0x3,%eax
    3b3f:	48 98                	cltq
    3b41:	0f b6 14 02          	movzbl (%rdx,%rax,1),%edx
    3b45:	44 89 c0             	mov    %r8d,%eax
    3b48:	83 e0 07             	and    $0x7,%eax
    3b4b:	0f a3 c2             	bt     %eax,%edx
    3b4e:	0f 83 58 17 00 00    	jae    52ac <convert_avx2_adaptive_job+0x17fc>
    3b54:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
    3b5b:	00 
    3b5c:	48 8b 46 40          	mov    0x40(%rsi),%rax
    3b60:	48 63 56 24          	movslq 0x24(%rsi),%rdx
    3b64:	48 85 c0             	test   %rax,%rax
    3b67:	0f 84 03 19 00 00    	je     5470 <convert_avx2_adaptive_job+0x19c0>
    3b6d:	48 8b 74 24 e0       	mov    -0x20(%rsp),%rsi
    3b72:	48 c1 e6 04          	shl    $0x4,%rsi
    3b76:	48 01 f0             	add    %rsi,%rax
    3b79:	8b 78 04             	mov    0x4(%rax),%edi
    3b7c:	44 8b 78 08          	mov    0x8(%rax),%r15d
    3b80:	44 8b 30             	mov    (%rax),%r14d
    3b83:	8b 40 0c             	mov    0xc(%rax),%eax
    3b86:	89 7c 24 d8          	mov    %edi,-0x28(%rsp)
    3b8a:	89 fb                	mov    %edi,%ebx
    3b8c:	89 c6                	mov    %eax,%esi
    3b8e:	89 44 24 ac          	mov    %eax,-0x54(%rsp)
    3b92:	44 29 fe             	sub    %r15d,%esi
    3b95:	83 fe 7f             	cmp    $0x7f,%esi
    3b98:	0f 8e 04 19 00 00    	jle    54a2 <convert_avx2_adaptive_job+0x19f2>
    3b9e:	48 63 c1             	movslq %ecx,%rax
    3ba1:	44 29 f7             	sub    %r14d,%edi
    3ba4:	48 89 44 24 b0       	mov    %rax,-0x50(%rsp)
    3ba9:	8d 41 01             	lea    0x1(%rcx),%eax
    3bac:	48 98                	cltq
    3bae:	48 89 44 24 b8       	mov    %rax,-0x48(%rsp)
    3bb3:	89 f8                	mov    %edi,%eax
    3bb5:	c1 e8 1f             	shr    $0x1f,%eax
    3bb8:	01 f8                	add    %edi,%eax
    3bba:	d1 f8                	sar    $1,%eax
    3bbc:	39 c6                	cmp    %eax,%esi
    3bbe:	0f 9d c0             	setge  %al
    3bc1:	44 0f 4c fb          	cmovl  %ebx,%r15d
    3bc5:	0f b6 c0             	movzbl %al,%eax
    3bc8:	89 44 24 dc          	mov    %eax,-0x24(%rsp)
    3bcc:	b8 ff 00 00 00       	mov    $0xff,%eax
    3bd1:	44 89 44 24 a8       	mov    %r8d,-0x58(%rsp)
    3bd6:	c5 f9 6e f0          	vmovd  %eax,%xmm6
    3bda:	44 89 b4 24 20 03 00 	mov    %r14d,0x320(%rsp)
    3be1:	00 
    3be2:	c7 84 24 a0 00 00 00 	movl   $0x0,0xa0(%rsp)
    3be9:	00 00 00 00 
    3bed:	c4 e2 79 79 f6       	vpbroadcastw %xmm6,%xmm6
    3bf2:	44 89 bc 24 24 03 00 	mov    %r15d,0x324(%rsp)
    3bf9:	00 
    3bfa:	89 4c 24 a4          	mov    %ecx,-0x5c(%rsp)
    3bfe:	c5 f9 7f b4 24 08 03 	vmovdqa %xmm6,0x308(%rsp)
    3c05:	00 00 
    3c07:	48 8b 9c 24 c0 00 00 	mov    0xc0(%rsp),%rbx
    3c0e:	00 
    3c0f:	48 8b 74 24 b0       	mov    -0x50(%rsp),%rsi
    3c14:	44 8b 84 24 24 03 00 	mov    0x324(%rsp),%r8d
    3c1b:	00 
    3c1c:	48 63 43 20          	movslq 0x20(%rbx),%rax
    3c20:	48 89 f7             	mov    %rsi,%rdi
    3c23:	4c 8b 33             	mov    (%rbx),%r14
    3c26:	48 0f af f2          	imul   %rdx,%rsi
    3c2a:	4c 8b 63 08          	mov    0x8(%rbx),%r12
    3c2e:	48 0f af f8          	imul   %rax,%rdi
    3c32:	48 89 bc 24 98 00 00 	mov    %rdi,0x98(%rsp)
    3c39:	00 
    3c3a:	4c 01 f7             	add    %r14,%rdi
    3c3d:	48 89 7c 24 d0       	mov    %rdi,-0x30(%rsp)
    3c42:	48 8b 7c 24 b8       	mov    -0x48(%rsp),%rdi
    3c47:	48 0f af c7          	imul   %rdi,%rax
    3c4b:	48 0f af fa          	imul   %rdx,%rdi
    3c4f:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    3c56:	00 
    3c57:	4c 01 f0             	add    %r14,%rax
    3c5a:	48 89 44 24 c8       	mov    %rax,-0x38(%rsp)
    3c5f:	48 89 d8             	mov    %rbx,%rax
    3c62:	48 89 f9             	mov    %rdi,%rcx
    3c65:	48 89 f3             	mov    %rsi,%rbx
    3c68:	48 8b 40 10          	mov    0x10(%rax),%rax
    3c6c:	49 8d 34 34          	lea    (%r12,%rsi,1),%rsi
    3c70:	49 8d 3c 3c          	lea    (%r12,%rdi,1),%rdi
    3c74:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    3c7b:	00 
    3c7c:	48 8b 44 24 e0       	mov    -0x20(%rsp),%rax
    3c81:	48 0f af c2          	imul   %rdx,%rax
    3c85:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    3c8c:	00 
    3c8d:	44 39 84 24 20 03 00 	cmp    %r8d,0x320(%rsp)
    3c94:	00 
    3c95:	0f 8d ad 15 00 00    	jge    5248 <convert_avx2_adaptive_job+0x1798>
    3c9b:	48 63 84 24 20 03 00 	movslq 0x320(%rsp),%rax
    3ca2:	00 
    3ca3:	45 8d 50 ff          	lea    -0x1(%r8),%r10d
    3ca7:	41 29 c2             	sub    %eax,%r10d
    3caa:	44 89 94 24 88 02 00 	mov    %r10d,0x288(%rsp)
    3cb1:	00 
    3cb2:	41 83 fa 1f          	cmp    $0x1f,%r10d
    3cb6:	0f 86 1c 16 00 00    	jbe    52d8 <convert_avx2_adaptive_job+0x1828>
    3cbc:	45 89 d0             	mov    %r10d,%r8d
    3cbf:	4c 63 bc 24 20 03 00 	movslq 0x320(%rsp),%r15
    3cc6:	00 
    3cc7:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
    3cce:	00 
    3ccf:	41 d1 e8             	shr    $1,%r8d
    3cd2:	44 89 84 24 a4 00 00 	mov    %r8d,0xa4(%rsp)
    3cd9:	00 
    3cda:	45 8d 40 01          	lea    0x1(%r8),%r8d
    3cde:	4e 8d 14 3b          	lea    (%rbx,%r15,1),%r10
    3ce2:	4c 01 f9             	add    %r15,%rcx
    3ce5:	4e 8d 2c c5 00 00 00 	lea    0x0(,%r8,8),%r13
    3cec:	00 
    3ced:	4d 01 c0             	add    %r8,%r8
    3cf0:	4e 8d 1c bd 00 00 00 	lea    0x0(,%r15,4),%r11
    3cf7:	00 
    3cf8:	4c 89 94 24 88 00 00 	mov    %r10,0x88(%rsp)
    3cff:	00 
    3d00:	4c 01 d8             	add    %r11,%rax
    3d03:	4b 8d 1c 14          	lea    (%r12,%r10,1),%rbx
    3d07:	4d 01 c2             	add    %r8,%r10
    3d0a:	48 89 0c 24          	mov    %rcx,(%rsp)
    3d0e:	4e 8d 4c 28 ff       	lea    -0x1(%rax,%r13,1),%r9
    3d13:	4d 01 e2             	add    %r12,%r10
    3d16:	4c 89 7c 24 f8       	mov    %r15,-0x8(%rsp)
    3d1b:	4c 01 f0             	add    %r14,%rax
    3d1e:	4c 89 94 24 c8 02 00 	mov    %r10,0x2c8(%rsp)
    3d25:	00 
    3d26:	4d 01 f1             	add    %r14,%r9
    3d29:	4d 8d 14 0c          	lea    (%r12,%rcx,1),%r10
    3d2d:	4c 01 c1             	add    %r8,%rcx
    3d30:	4c 89 8c 24 e8 02 00 	mov    %r9,0x2e8(%rsp)
    3d37:	00 
    3d38:	4d 8d 0c 0c          	lea    (%r12,%rcx,1),%r9
    3d3c:	4c 89 8c 24 a8 02 00 	mov    %r9,0x2a8(%rsp)
    3d43:	00 
    3d44:	4c 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%r9
    3d4b:	00 
    3d4c:	4d 01 cf             	add    %r9,%r15
    3d4f:	4c 8b 8c 24 18 03 00 	mov    0x318(%rsp),%r9
    3d56:	00 
    3d57:	4c 89 f9             	mov    %r15,%rcx
    3d5a:	4c 89 7c 24 c0       	mov    %r15,-0x40(%rsp)
    3d5f:	49 01 c8             	add    %rcx,%r8
    3d62:	4d 01 cf             	add    %r9,%r15
    3d65:	4d 01 c8             	add    %r9,%r8
    3d68:	4c 8b 8c 24 90 00 00 	mov    0x90(%rsp),%r9
    3d6f:	00 
    3d70:	4d 01 cb             	add    %r9,%r11
    3d73:	4d 89 f9             	mov    %r15,%r9
    3d76:	4b 8d 0c 1e          	lea    (%r14,%r11,1),%rcx
    3d7a:	4f 8d 5c 1d ff       	lea    -0x1(%r13,%r11,1),%r11
    3d7f:	4c 8b ac 24 88 00 00 	mov    0x88(%rsp),%r13
    3d86:	00 
    3d87:	4d 01 f3             	add    %r14,%r11
    3d8a:	4f 8d 6c 2c 02       	lea    0x2(%r12,%r13,1),%r13
    3d8f:	4d 29 e9             	sub    %r13,%r9
    3d92:	4d 8d 69 01          	lea    0x1(%r9),%r13
    3d96:	4d 89 f9             	mov    %r15,%r9
    3d99:	49 83 fd 3e          	cmp    $0x3e,%r13
    3d9d:	4c 8b 2c 24          	mov    (%rsp),%r13
    3da1:	0f 97 84 24 68 02 00 	seta   0x268(%rsp)
    3da8:	00 
    3da9:	4f 8d 6c 2c 02       	lea    0x2(%r12,%r13,1),%r13
    3dae:	4d 29 e9             	sub    %r13,%r9
    3db1:	4d 89 cd             	mov    %r9,%r13
    3db4:	4c 8b 8c 24 e8 02 00 	mov    0x2e8(%rsp),%r9
    3dbb:	00 
    3dbc:	49 83 c5 01          	add    $0x1,%r13
    3dc0:	49 83 fd 3e          	cmp    $0x3e,%r13
    3dc4:	41 0f 97 c5          	seta   %r13b
    3dc8:	48 83 ea 01          	sub    $0x1,%rdx
    3dcc:	44 22 ac 24 68 02 00 	and    0x268(%rsp),%r13b
    3dd3:	00 
    3dd4:	48 83 fa 3e          	cmp    $0x3e,%rdx
    3dd8:	0f 97 c2             	seta   %dl
    3ddb:	44 21 ea             	and    %r13d,%edx
    3dde:	4c 39 cb             	cmp    %r9,%rbx
    3de1:	4c 8b 8c 24 c8 02 00 	mov    0x2c8(%rsp),%r9
    3de8:	00 
    3de9:	41 0f 93 c5          	setae  %r13b
    3ded:	4c 39 c8             	cmp    %r9,%rax
    3df0:	0f 93 84 24 68 02 00 	setae  0x268(%rsp)
    3df7:	00 
    3df8:	44 0f b6 8c 24 68 02 	movzbl 0x268(%rsp),%r9d
    3dff:	00 00 
    3e01:	45 09 cd             	or     %r9d,%r13d
    3e04:	4c 8b 8c 24 e8 02 00 	mov    0x2e8(%rsp),%r9
    3e0b:	00 
    3e0c:	41 21 d5             	and    %edx,%r13d
    3e0f:	4d 39 ca             	cmp    %r9,%r10
    3e12:	4c 8b 8c 24 a8 02 00 	mov    0x2a8(%rsp),%r9
    3e19:	00 
    3e1a:	0f 93 c2             	setae  %dl
    3e1d:	4c 39 c8             	cmp    %r9,%rax
    3e20:	0f 93 84 24 68 02 00 	setae  0x268(%rsp)
    3e27:	00 
    3e28:	44 0f b6 8c 24 68 02 	movzbl 0x268(%rsp),%r9d
    3e2f:	00 00 
    3e31:	44 09 ca             	or     %r9d,%edx
    3e34:	4c 8b 8c 24 e8 02 00 	mov    0x2e8(%rsp),%r9
    3e3b:	00 
    3e3c:	44 21 ea             	and    %r13d,%edx
    3e3f:	4d 39 cf             	cmp    %r9,%r15
    3e42:	41 0f 93 c1          	setae  %r9b
    3e46:	4c 39 c0             	cmp    %r8,%rax
    3e49:	41 0f 93 c5          	setae  %r13b
    3e4d:	45 09 e9             	or     %r13d,%r9d
    3e50:	4c 8b ac 24 c8 02 00 	mov    0x2c8(%rsp),%r13
    3e57:	00 
    3e58:	41 21 d1             	and    %edx,%r9d
    3e5b:	4c 39 e9             	cmp    %r13,%rcx
    3e5e:	0f 93 c2             	setae  %dl
    3e61:	4c 39 db             	cmp    %r11,%rbx
    3e64:	41 0f 93 c5          	setae  %r13b
    3e68:	44 09 ea             	or     %r13d,%edx
    3e6b:	4c 8b ac 24 a8 02 00 	mov    0x2a8(%rsp),%r13
    3e72:	00 
    3e73:	44 21 ca             	and    %r9d,%edx
    3e76:	4d 39 da             	cmp    %r11,%r10
    3e79:	41 0f 93 c1          	setae  %r9b
    3e7d:	4c 39 e9             	cmp    %r13,%rcx
    3e80:	41 0f 93 c5          	setae  %r13b
    3e84:	45 09 e9             	or     %r13d,%r9d
    3e87:	44 84 ca             	test   %r9b,%dl
    3e8a:	0f 84 4d 14 00 00    	je     52dd <convert_avx2_adaptive_job+0x182d>
    3e90:	4d 39 df             	cmp    %r11,%r15
    3e93:	0f 93 c2             	setae  %dl
    3e96:	4c 39 c1             	cmp    %r8,%rcx
    3e99:	41 0f 93 c0          	setae  %r8b
    3e9d:	41 08 d0             	or     %dl,%r8b
    3ea0:	0f 84 37 14 00 00    	je     52dd <convert_avx2_adaptive_job+0x182d>
    3ea6:	8b 94 24 88 02 00 00 	mov    0x288(%rsp),%edx
    3ead:	83 fa 3f             	cmp    $0x3f,%edx
    3eb0:	0f 86 f1 15 00 00    	jbe    54a7 <convert_avx2_adaptive_job+0x19f7>
    3eb6:	c4 e2 79 78 05 d1 b3 	vpbroadcastb 0xb3d1(%rip),%xmm0        # f290 <__PRETTY_FUNCTION__.4+0x1d>
    3ebd:	00 00 
    3ebf:	41 b8 ff 00 00 00    	mov    $0xff,%r8d
    3ec5:	c1 ea 06             	shr    $0x6,%edx
    3ec8:	c4 41 79 6e f8       	vmovd  %r8d,%xmm15
    3ecd:	41 b8 10 00 00 00    	mov    $0x10,%r8d
    3ed3:	41 89 d3             	mov    %edx,%r11d
    3ed6:	48 c1 e2 06          	shl    $0x6,%rdx
    3eda:	c4 62 7d 30 e8       	vpmovzxbw %xmm0,%ymm13
    3edf:	c4 c1 79 6e f0       	vmovd  %r8d,%xmm6
    3ee4:	49 89 d1             	mov    %rdx,%r9
    3ee7:	c4 e2 79 78 05 b0 b3 	vpbroadcastb 0xb3b0(%rip),%xmm0        # f2a0 <__PRETTY_FUNCTION__.4+0x2d>
    3eee:	00 00 
    3ef0:	c4 e2 7d 78 f6       	vpbroadcastb %xmm6,%ymm6
    3ef5:	31 d2                	xor    %edx,%edx
    3ef7:	c4 42 7d 79 ff       	vpbroadcastw %xmm15,%ymm15
    3efc:	c5 fd 7f b4 24 e8 02 	vmovdqa %ymm6,0x2e8(%rsp)
    3f03:	00 00 
    3f05:	c4 62 7d 30 e0       	vpmovzxbw %xmm0,%ymm12
    3f0a:	c4 c1 79 6e c0       	vmovd  %r8d,%xmm0
    3f0f:	41 b8 80 00 00 00    	mov    $0x80,%r8d
    3f15:	c4 41 79 6e d0       	vmovd  %r8d,%xmm10
    3f1a:	41 b8 e6 ff ff ff    	mov    $0xffffffe6,%r8d
    3f20:	c4 e2 79 78 c0       	vpbroadcastb %xmm0,%xmm0
    3f25:	c4 c1 79 6e f0       	vmovd  %r8d,%xmm6
    3f2a:	41 b8 aa ff ff ff    	mov    $0xffffffaa,%r8d
    3f30:	c4 62 7d 30 d8       	vpmovzxbw %xmm0,%ymm11
    3f35:	c4 e2 7d 79 f6       	vpbroadcastw %xmm6,%ymm6
    3f3a:	c4 42 7d 79 d2       	vpbroadcastw %xmm10,%ymm10
    3f3f:	c5 fd 7f 74 24 68    	vmovdqa %ymm6,0x68(%rsp)
    3f45:	c4 c1 79 6e f0       	vmovd  %r8d,%xmm6
    3f4a:	41 b8 80 ff ff ff    	mov    $0xffffff80,%r8d
    3f50:	c4 e2 7d 79 f6       	vpbroadcastw %xmm6,%ymm6
    3f55:	c5 fd 7f 74 24 48    	vmovdqa %ymm6,0x48(%rsp)
    3f5b:	c4 c1 79 6e f0       	vmovd  %r8d,%xmm6
    3f60:	41 b8 9a ff ff ff    	mov    $0xffffff9a,%r8d
    3f66:	c4 e2 7d 78 f6       	vpbroadcastb %xmm6,%ymm6
    3f6b:	c5 fd 7f 74 24 28    	vmovdqa %ymm6,0x28(%rsp)
    3f71:	c4 c1 79 6e f0       	vmovd  %r8d,%xmm6
    3f76:	c4 e2 7d 79 f6       	vpbroadcastw %xmm6,%ymm6
    3f7b:	c5 fd 7f 74 24 08    	vmovdqa %ymm6,0x8(%rsp)
    3f81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3f88:	c5 85 db 40 20       	vpand  0x20(%rax),%ymm15,%ymm0
    3f8d:	c5 85 db 18          	vpand  (%rax),%ymm15,%ymm3
    3f91:	48 81 c1 00 01 00 00 	add    $0x100,%rcx
    3f98:	48 05 00 01 00 00    	add    $0x100,%rax
    3f9e:	c5 85 db a0 40 ff ff 	vpand  -0xc0(%rax),%ymm15,%ymm4
    3fa5:	ff 
    3fa6:	c5 85 db 48 80       	vpand  -0x80(%rax),%ymm15,%ymm1
    3fab:	c5 e5 67 d8          	vpackuswb %ymm0,%ymm3,%ymm3
    3faf:	c5 85 db 80 60 ff ff 	vpand  -0xa0(%rax),%ymm15,%ymm0
    3fb6:	ff 
    3fb7:	c5 85 db 50 e0       	vpand  -0x20(%rax),%ymm15,%ymm2
    3fbc:	c4 e3 fd 00 db d8    	vpermq $0xd8,%ymm3,%ymm3
    3fc2:	c5 fe 6f b8 00 ff ff 	vmovdqu -0x100(%rax),%ymm7
    3fc9:	ff 
    3fca:	c5 dd 67 e0          	vpackuswb %ymm0,%ymm4,%ymm4
    3fce:	c5 85 db 40 a0       	vpand  -0x60(%rax),%ymm15,%ymm0
    3fd3:	c4 e3 fd 00 e4 d8    	vpermq $0xd8,%ymm4,%ymm4
    3fd9:	c5 f5 67 c8          	vpackuswb %ymm0,%ymm1,%ymm1
    3fdd:	c5 85 db 40 c0       	vpand  -0x40(%rax),%ymm15,%ymm0
    3fe2:	c5 85 db ec          	vpand  %ymm4,%ymm15,%ymm5
    3fe6:	c4 e3 fd 00 c9 d8    	vpermq $0xd8,%ymm1,%ymm1
    3fec:	c5 dd 71 d4 08       	vpsrlw $0x8,%ymm4,%ymm4
    3ff1:	c5 fd 67 c2          	vpackuswb %ymm2,%ymm0,%ymm0
    3ff5:	c5 85 db d3          	vpand  %ymm3,%ymm15,%ymm2
    3ff9:	c5 85 db f1          	vpand  %ymm1,%ymm15,%ymm6
    3ffd:	c4 e3 fd 00 c0 d8    	vpermq $0xd8,%ymm0,%ymm0
    4003:	c5 e5 71 d3 08       	vpsrlw $0x8,%ymm3,%ymm3
    4008:	c5 ed 67 d5          	vpackuswb %ymm5,%ymm2,%ymm2
    400c:	c5 e5 67 dc          	vpackuswb %ymm4,%ymm3,%ymm3
    4010:	c5 85 db e0          	vpand  %ymm0,%ymm15,%ymm4
    4014:	c4 e3 fd 00 d2 d8    	vpermq $0xd8,%ymm2,%ymm2
    401a:	c5 cd 67 f4          	vpackuswb %ymm4,%ymm6,%ymm6
    401e:	c5 dd 71 d7 08       	vpsrlw $0x8,%ymm7,%ymm4
    4023:	c5 fe 6f b8 20 ff ff 	vmovdqu -0xe0(%rax),%ymm7
    402a:	ff 
    402b:	c4 e3 fd 00 db d8    	vpermq $0xd8,%ymm3,%ymm3
    4031:	c5 fd 71 d0 08       	vpsrlw $0x8,%ymm0,%ymm0
    4036:	c5 f5 71 d1 08       	vpsrlw $0x8,%ymm1,%ymm1
    403b:	c4 e3 fd 00 f6 d8    	vpermq $0xd8,%ymm6,%ymm6
    4041:	c5 f5 67 c8          	vpackuswb %ymm0,%ymm1,%ymm1
    4045:	c5 fd 71 d7 08       	vpsrlw $0x8,%ymm7,%ymm0
    404a:	c5 fe 6f b8 40 ff ff 	vmovdqu -0xc0(%rax),%ymm7
    4051:	ff 
    4052:	c5 dd 67 e0          	vpackuswb %ymm0,%ymm4,%ymm4
    4056:	c4 e3 fd 00 c9 d8    	vpermq $0xd8,%ymm1,%ymm1
    405c:	c5 fd 71 d7 08       	vpsrlw $0x8,%ymm7,%ymm0
    4061:	c5 fe 6f b8 60 ff ff 	vmovdqu -0xa0(%rax),%ymm7
    4068:	ff 
    4069:	c4 e3 fd 00 e4 d8    	vpermq $0xd8,%ymm4,%ymm4
    406f:	c5 85 db e4          	vpand  %ymm4,%ymm15,%ymm4
    4073:	c5 d5 71 d7 08       	vpsrlw $0x8,%ymm7,%ymm5
    4078:	c5 fe 6f 78 80       	vmovdqu -0x80(%rax),%ymm7
    407d:	c5 fd 67 c5          	vpackuswb %ymm5,%ymm0,%ymm0
    4081:	c4 e3 fd 00 c0 d8    	vpermq $0xd8,%ymm0,%ymm0
    4087:	c5 85 db c0          	vpand  %ymm0,%ymm15,%ymm0
    408b:	c5 dd 67 e0          	vpackuswb %ymm0,%ymm4,%ymm4
    408f:	c5 fd 71 d7 08       	vpsrlw $0x8,%ymm7,%ymm0
    4094:	c5 fe 6f 78 a0       	vmovdqu -0x60(%rax),%ymm7
    4099:	c4 e3 fd 00 e4 d8    	vpermq $0xd8,%ymm4,%ymm4
    409f:	c5 d5 71 d7 08       	vpsrlw $0x8,%ymm7,%ymm5
    40a4:	c5 fe 6f 78 c0       	vmovdqu -0x40(%rax),%ymm7
    40a9:	c5 fd 67 c5          	vpackuswb %ymm5,%ymm0,%ymm0
    40ad:	c5 d5 71 d7 08       	vpsrlw $0x8,%ymm7,%ymm5
    40b2:	c5 fe 6f 78 e0       	vmovdqu -0x20(%rax),%ymm7
    40b7:	c4 e3 fd 00 c0 d8    	vpermq $0xd8,%ymm0,%ymm0
    40bd:	c5 85 db c0          	vpand  %ymm0,%ymm15,%ymm0
    40c1:	c5 c5 71 d7 08       	vpsrlw $0x8,%ymm7,%ymm7
    40c6:	c5 d5 67 ef          	vpackuswb %ymm7,%ymm5,%ymm5
    40ca:	c5 85 db fe          	vpand  %ymm6,%ymm15,%ymm7
    40ce:	c4 e3 fd 00 ed d8    	vpermq $0xd8,%ymm5,%ymm5
    40d4:	c5 cd 71 d6 08       	vpsrlw $0x8,%ymm6,%ymm6
    40d9:	c5 85 db ed          	vpand  %ymm5,%ymm15,%ymm5
    40dd:	c5 fd 67 c5          	vpackuswb %ymm5,%ymm0,%ymm0
    40e1:	c5 85 db ea          	vpand  %ymm2,%ymm15,%ymm5
    40e5:	c4 e3 fd 00 c0 d8    	vpermq $0xd8,%ymm0,%ymm0
    40eb:	c5 ed 71 d2 08       	vpsrlw $0x8,%ymm2,%ymm2
    40f0:	c5 d5 67 ef          	vpackuswb %ymm7,%ymm5,%ymm5
    40f4:	c5 ed 67 d6          	vpackuswb %ymm6,%ymm2,%ymm2
    40f8:	c5 85 db f8          	vpand  %ymm0,%ymm15,%ymm7
    40fc:	c5 85 db f4          	vpand  %ymm4,%ymm15,%ymm6
    4100:	c5 fd 71 d0 08       	vpsrlw $0x8,%ymm0,%ymm0
    4105:	c5 dd 71 d4 08       	vpsrlw $0x8,%ymm4,%ymm4
    410a:	c5 cd 67 f7          	vpackuswb %ymm7,%ymm6,%ymm6
    410e:	c5 dd 67 e0          	vpackuswb %ymm0,%ymm4,%ymm4
    4112:	c5 85 db f9          	vpand  %ymm1,%ymm15,%ymm7
    4116:	c5 85 db c3          	vpand  %ymm3,%ymm15,%ymm0
    411a:	c5 fd 67 c7          	vpackuswb %ymm7,%ymm0,%ymm0
    411e:	c4 e3 fd 00 f6 d8    	vpermq $0xd8,%ymm6,%ymm6
    4124:	c4 e3 fd 00 ed d8    	vpermq $0xd8,%ymm5,%ymm5
    412a:	c4 e3 fd 00 c0 d8    	vpermq $0xd8,%ymm0,%ymm0
    4130:	c4 62 7d 30 c6       	vpmovzxbw %xmm6,%ymm8
    4135:	c4 62 7d 30 f5       	vpmovzxbw %xmm5,%ymm14
    413a:	c4 e2 7d 30 f8       	vpmovzxbw %xmm0,%ymm7
    413f:	c5 f5 71 d1 08       	vpsrlw $0x8,%ymm1,%ymm1
    4144:	c4 e3 fd 00 e4 d8    	vpermq $0xd8,%ymm4,%ymm4
    414a:	c5 7d 7f 84 24 a8 02 	vmovdqa %ymm8,0x2a8(%rsp)
    4151:	00 00 
    4153:	c5 e5 71 d3 08       	vpsrlw $0x8,%ymm3,%ymm3
    4158:	c4 e3 7d 39 f6 01    	vextracti128 $0x1,%ymm6,%xmm6
    415e:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    4164:	c5 fd 7f bc 24 c8 02 	vmovdqa %ymm7,0x2c8(%rsp)
    416b:	00 00 
    416d:	c5 e5 67 d9          	vpackuswb %ymm1,%ymm3,%ymm3
    4171:	c5 95 d5 cf          	vpmullw %ymm7,%ymm13,%ymm1
    4175:	c4 e3 7d 39 ed 01    	vextracti128 $0x1,%ymm5,%xmm5
    417b:	c5 7d 7f b4 24 88 02 	vmovdqa %ymm14,0x288(%rsp)
    4182:	00 00 
    4184:	c4 c1 1d d5 f8       	vpmullw %ymm8,%ymm12,%ymm7
    4189:	c4 62 7d 30 ce       	vpmovzxbw %xmm6,%ymm9
    418e:	c4 e2 7d 30 c0       	vpmovzxbw %xmm0,%ymm0
    4193:	c4 e2 7d 30 ed       	vpmovzxbw %xmm5,%ymm5
    4198:	c4 c1 1d d5 f1       	vpmullw %ymm9,%ymm12,%ymm6
    419d:	c4 e3 fd 00 db d8    	vpermq $0xd8,%ymm3,%ymm3
    41a3:	c5 fd 7f 84 24 68 02 	vmovdqa %ymm0,0x268(%rsp)
    41aa:	00 00 
    41ac:	c5 fd 7f ac 24 28 02 	vmovdqa %ymm5,0x228(%rsp)
    41b3:	00 00 
    41b5:	c5 95 d5 c0          	vpmullw %ymm0,%ymm13,%ymm0
    41b9:	c5 a5 d5 ed          	vpmullw %ymm5,%ymm11,%ymm5
    41bd:	c4 e3 fd 00 d2 d8    	vpermq $0xd8,%ymm2,%ymm2
    41c3:	c5 7d 7f 8c 24 48 02 	vmovdqa %ymm9,0x248(%rsp)
    41ca:	00 00 
    41cc:	c5 7d 6f 8c 24 e8 02 	vmovdqa 0x2e8(%rsp),%ymm9
    41d3:	00 00 
    41d5:	c5 f5 fd cf          	vpaddw %ymm7,%ymm1,%ymm1
    41d9:	c4 c1 25 d5 fe       	vpmullw %ymm14,%ymm11,%ymm7
    41de:	c5 fd fd c6          	vpaddw %ymm6,%ymm0,%ymm0
    41e2:	c4 c1 55 fd ea       	vpaddw %ymm10,%ymm5,%ymm5
    41e7:	c4 e2 7d 30 f3       	vpmovzxbw %xmm3,%ymm6
    41ec:	c5 fd fd c5          	vpaddw %ymm5,%ymm0,%ymm0
    41f0:	c4 e2 7d 30 ec       	vpmovzxbw %xmm4,%ymm5
    41f5:	c4 e3 7d 39 db 01    	vextracti128 $0x1,%ymm3,%xmm3
    41fb:	c5 fd 7f b4 24 08 02 	vmovdqa %ymm6,0x208(%rsp)
    4202:	00 00 
    4204:	c5 fd 71 d0 08       	vpsrlw $0x8,%ymm0,%ymm0
    4209:	c4 e3 7d 39 e4 01    	vextracti128 $0x1,%ymm4,%xmm4
    420f:	c4 e2 7d 30 db       	vpmovzxbw %xmm3,%ymm3
    4214:	c5 fd 7f ac 24 e8 01 	vmovdqa %ymm5,0x1e8(%rsp)
    421b:	00 00 
    421d:	c4 c1 45 fd fa       	vpaddw %ymm10,%ymm7,%ymm7
    4222:	c5 85 db c0          	vpand  %ymm0,%ymm15,%ymm0
    4226:	c4 e2 7d 30 e4       	vpmovzxbw %xmm4,%ymm4
    422b:	c5 fd 7f 9c 24 a8 01 	vmovdqa %ymm3,0x1a8(%rsp)
    4232:	00 00 
    4234:	c5 9d d5 ed          	vpmullw %ymm5,%ymm12,%ymm5
    4238:	c5 95 d5 db          	vpmullw %ymm3,%ymm13,%ymm3
    423c:	c5 f5 fd cf          	vpaddw %ymm7,%ymm1,%ymm1
    4240:	c5 fd 7f a4 24 88 01 	vmovdqa %ymm4,0x188(%rsp)
    4247:	00 00 
    4249:	c5 f5 71 d1 08       	vpsrlw $0x8,%ymm1,%ymm1
    424e:	c5 9d d5 e4          	vpmullw %ymm4,%ymm12,%ymm4
    4252:	c4 e2 7d 30 fa       	vpmovzxbw %xmm2,%ymm7
    4257:	c5 85 db c9          	vpand  %ymm1,%ymm15,%ymm1
    425b:	c4 e3 7d 39 d2 01    	vextracti128 $0x1,%ymm2,%xmm2
    4261:	c5 fd 7f bc 24 c8 01 	vmovdqa %ymm7,0x1c8(%rsp)
    4268:	00 00 
    426a:	c5 f5 67 c8          	vpackuswb %ymm0,%ymm1,%ymm1
    426e:	c5 95 d5 c6          	vpmullw %ymm6,%ymm13,%ymm0
    4272:	c4 e2 7d 30 d2       	vpmovzxbw %xmm2,%ymm2
    4277:	c5 fd 7f 94 24 68 01 	vmovdqa %ymm2,0x168(%rsp)
    427e:	00 00 
    4280:	c5 a5 d5 d2          	vpmullw %ymm2,%ymm11,%ymm2
    4284:	c4 e3 fd 00 c9 d8    	vpermq $0xd8,%ymm1,%ymm1
    428a:	c4 c1 75 fc c9       	vpaddb %ymm9,%ymm1,%ymm1
    428f:	c5 e5 fd dc          	vpaddw %ymm4,%ymm3,%ymm3
    4293:	c5 fd fd c5          	vpaddw %ymm5,%ymm0,%ymm0
    4297:	c5 a5 d5 ef          	vpmullw %ymm7,%ymm11,%ymm5
    429b:	c4 c1 6d fd d2       	vpaddw %ymm10,%ymm2,%ymm2
    42a0:	c5 e5 fd da          	vpaddw %ymm2,%ymm3,%ymm3
    42a4:	c5 e5 71 d3 08       	vpsrlw $0x8,%ymm3,%ymm3
    42a9:	c5 85 db db          	vpand  %ymm3,%ymm15,%ymm3
    42ad:	c4 c1 55 fd ea       	vpaddw %ymm10,%ymm5,%ymm5
    42b2:	c5 fd fd c5          	vpaddw %ymm5,%ymm0,%ymm0
    42b6:	c5 fd 71 d0 08       	vpsrlw $0x8,%ymm0,%ymm0
    42bb:	c5 85 db c0          	vpand  %ymm0,%ymm15,%ymm0
    42bf:	c5 fd 67 c3          	vpackuswb %ymm3,%ymm0,%ymm0
    42c3:	c4 e3 fd 00 c0 d8    	vpermq $0xd8,%ymm0,%ymm0
    42c9:	c4 c1 7d fc c1       	vpaddb %ymm9,%ymm0,%ymm0
    42ce:	c5 f5 60 d0          	vpunpcklbw %ymm0,%ymm1,%ymm2
    42d2:	c5 f5 68 c0          	vpunpckhbw %ymm0,%ymm1,%ymm0
    42d6:	c4 e3 6d 46 c8 20    	vperm2i128 $0x20,%ymm0,%ymm2,%ymm1
    42dc:	c4 e3 6d 46 d0 31    	vperm2i128 $0x31,%ymm0,%ymm2,%ymm2
    42e2:	c5 fe 7f 54 13 20    	vmovdqu %ymm2,0x20(%rbx,%rdx,1)
    42e8:	c5 fe 7f 0c 13       	vmovdqu %ymm1,(%rbx,%rdx,1)
    42ed:	c5 85 db 89 00 ff ff 	vpand  -0x100(%rcx),%ymm15,%ymm1
    42f4:	ff 
    42f5:	c5 85 db 81 20 ff ff 	vpand  -0xe0(%rcx),%ymm15,%ymm0
    42fc:	ff 
    42fd:	c5 85 db 91 40 ff ff 	vpand  -0xc0(%rcx),%ymm15,%ymm2
    4304:	ff 
    4305:	c5 85 db 59 80       	vpand  -0x80(%rcx),%ymm15,%ymm3
    430a:	c5 f5 67 c8          	vpackuswb %ymm0,%ymm1,%ymm1
    430e:	c5 85 db 61 e0       	vpand  -0x20(%rcx),%ymm15,%ymm4
    4313:	c5 7e 6f 41 e0       	vmovdqu -0x20(%rcx),%ymm8
    4318:	c5 85 db 81 60 ff ff 	vpand  -0xa0(%rcx),%ymm15,%ymm0
    431f:	ff 
    4320:	c4 e3 fd 00 c9 d8    	vpermq $0xd8,%ymm1,%ymm1
    4326:	c5 85 db e9          	vpand  %ymm1,%ymm15,%ymm5
    432a:	c5 f5 71 d1 08       	vpsrlw $0x8,%ymm1,%ymm1
    432f:	c5 ed 67 d0          	vpackuswb %ymm0,%ymm2,%ymm2
    4333:	c4 c1 45 71 d0 08    	vpsrlw $0x8,%ymm8,%ymm7
    4339:	c5 85 db 41 a0       	vpand  -0x60(%rcx),%ymm15,%ymm0
    433e:	c4 e3 fd 00 d2 d8    	vpermq $0xd8,%ymm2,%ymm2
    4344:	c5 e5 67 d8          	vpackuswb %ymm0,%ymm3,%ymm3
    4348:	c5 85 db 41 c0       	vpand  -0x40(%rcx),%ymm15,%ymm0
    434d:	c4 e3 fd 00 db d8    	vpermq $0xd8,%ymm3,%ymm3
    4353:	c5 fd 67 c4          	vpackuswb %ymm4,%ymm0,%ymm0
    4357:	c5 85 db e2          	vpand  %ymm2,%ymm15,%ymm4
    435b:	c5 85 db f3          	vpand  %ymm3,%ymm15,%ymm6
    435f:	c4 e3 fd 00 c0 d8    	vpermq $0xd8,%ymm0,%ymm0
    4365:	c5 ed 71 d2 08       	vpsrlw $0x8,%ymm2,%ymm2
    436a:	c5 d5 67 ec          	vpackuswb %ymm4,%ymm5,%ymm5
    436e:	c5 fe 6f a1 60 ff ff 	vmovdqu -0xa0(%rcx),%ymm4
    4375:	ff 
    4376:	c5 f5 67 ca          	vpackuswb %ymm2,%ymm1,%ymm1
    437a:	c5 85 db d0          	vpand  %ymm0,%ymm15,%ymm2
    437e:	c4 e3 fd 00 ed d8    	vpermq $0xd8,%ymm5,%ymm5
    4384:	c5 cd 67 f2          	vpackuswb %ymm2,%ymm6,%ymm6
    4388:	c5 fd 71 d0 08       	vpsrlw $0x8,%ymm0,%ymm0
    438d:	c4 e3 fd 00 c9 d8    	vpermq $0xd8,%ymm1,%ymm1
    4393:	c5 fe 6f 91 00 ff ff 	vmovdqu -0x100(%rcx),%ymm2
    439a:	ff 
    439b:	c5 e5 71 d3 08       	vpsrlw $0x8,%ymm3,%ymm3
    43a0:	c5 dd 71 d4 08       	vpsrlw $0x8,%ymm4,%ymm4
    43a5:	c4 e3 fd 00 f6 d8    	vpermq $0xd8,%ymm6,%ymm6
    43ab:	c5 e5 67 d8          	vpackuswb %ymm0,%ymm3,%ymm3
    43af:	c5 fd 71 d2 08       	vpsrlw $0x8,%ymm2,%ymm0
    43b4:	c5 fe 6f 91 20 ff ff 	vmovdqu -0xe0(%rcx),%ymm2
    43bb:	ff 
    43bc:	c4 e3 fd 00 db d8    	vpermq $0xd8,%ymm3,%ymm3
    43c2:	c5 ed 71 d2 08       	vpsrlw $0x8,%ymm2,%ymm2
    43c7:	c5 fd 67 c2          	vpackuswb %ymm2,%ymm0,%ymm0
    43cb:	c5 fe 6f 91 40 ff ff 	vmovdqu -0xc0(%rcx),%ymm2
    43d2:	ff 
    43d3:	c4 e3 fd 00 c0 d8    	vpermq $0xd8,%ymm0,%ymm0
    43d9:	c5 ed 71 d2 08       	vpsrlw $0x8,%ymm2,%ymm2
    43de:	c5 85 db c0          	vpand  %ymm0,%ymm15,%ymm0
    43e2:	c5 ed 67 d4          	vpackuswb %ymm4,%ymm2,%ymm2
    43e6:	c5 fe 6f 61 a0       	vmovdqu -0x60(%rcx),%ymm4
    43eb:	c4 e3 fd 00 d2 d8    	vpermq $0xd8,%ymm2,%ymm2
    43f1:	c5 85 db d2          	vpand  %ymm2,%ymm15,%ymm2
    43f5:	c5 dd 71 d4 08       	vpsrlw $0x8,%ymm4,%ymm4
    43fa:	c5 fd 67 c2          	vpackuswb %ymm2,%ymm0,%ymm0
    43fe:	c5 fe 6f 51 80       	vmovdqu -0x80(%rcx),%ymm2
    4403:	c4 e3 fd 00 c0 d8    	vpermq $0xd8,%ymm0,%ymm0
    4409:	c5 ed 71 d2 08       	vpsrlw $0x8,%ymm2,%ymm2
    440e:	c5 ed 67 d4          	vpackuswb %ymm4,%ymm2,%ymm2
    4412:	c5 fe 6f 61 c0       	vmovdqu -0x40(%rcx),%ymm4
    4417:	c4 e3 fd 00 d2 d8    	vpermq $0xd8,%ymm2,%ymm2
    441d:	c5 dd 71 d4 08       	vpsrlw $0x8,%ymm4,%ymm4
    4422:	c5 85 db d2          	vpand  %ymm2,%ymm15,%ymm2
    4426:	c5 dd 67 e7          	vpackuswb %ymm7,%ymm4,%ymm4
    442a:	c5 85 db fe          	vpand  %ymm6,%ymm15,%ymm7
    442e:	c4 e3 fd 00 e4 d8    	vpermq $0xd8,%ymm4,%ymm4
    4434:	c5 cd 71 d6 08       	vpsrlw $0x8,%ymm6,%ymm6
    4439:	c5 85 db e4          	vpand  %ymm4,%ymm15,%ymm4
    443d:	c5 ed 67 d4          	vpackuswb %ymm4,%ymm2,%ymm2
    4441:	c5 85 db e5          	vpand  %ymm5,%ymm15,%ymm4
    4445:	c5 d5 71 d5 08       	vpsrlw $0x8,%ymm5,%ymm5
    444a:	c4 e3 fd 00 d2 d8    	vpermq $0xd8,%ymm2,%ymm2
    4450:	c5 dd 67 e7          	vpackuswb %ymm7,%ymm4,%ymm4
    4454:	c5 d5 67 ee          	vpackuswb %ymm6,%ymm5,%ymm5
    4458:	c5 85 db f2          	vpand  %ymm2,%ymm15,%ymm6
    445c:	c4 e3 fd 00 e4 d8    	vpermq $0xd8,%ymm4,%ymm4
    4462:	c4 63 fd 00 f5 d8    	vpermq $0xd8,%ymm5,%ymm14
    4468:	c5 ed 71 d2 08       	vpsrlw $0x8,%ymm2,%ymm2
    446d:	c5 85 db e8          	vpand  %ymm0,%ymm15,%ymm5
    4471:	c5 fd 71 d0 08       	vpsrlw $0x8,%ymm0,%ymm0
    4476:	c5 d5 67 ee          	vpackuswb %ymm6,%ymm5,%ymm5
    447a:	c5 85 db f3          	vpand  %ymm3,%ymm15,%ymm6
    447e:	c5 fd 67 c2          	vpackuswb %ymm2,%ymm0,%ymm0
    4482:	c5 85 db d1          	vpand  %ymm1,%ymm15,%ymm2
    4486:	c4 e3 fd 00 ed d8    	vpermq $0xd8,%ymm5,%ymm5
    448c:	c5 ed 67 d6          	vpackuswb %ymm6,%ymm2,%ymm2
    4490:	c5 e5 71 d3 08       	vpsrlw $0x8,%ymm3,%ymm3
    4495:	c4 e2 7d 30 f5       	vpmovzxbw %xmm5,%ymm6
    449a:	c4 e3 fd 00 d2 d8    	vpermq $0xd8,%ymm2,%ymm2
    44a0:	c5 f5 71 d1 08       	vpsrlw $0x8,%ymm1,%ymm1
    44a5:	c4 e3 7d 39 ed 01    	vextracti128 $0x1,%ymm5,%xmm5
    44ab:	c5 fd 7f b4 24 28 01 	vmovdqa %ymm6,0x128(%rsp)
    44b2:	00 00 
    44b4:	c5 f5 67 cb          	vpackuswb %ymm3,%ymm1,%ymm1
    44b8:	c4 e2 7d 30 da       	vpmovzxbw %xmm2,%ymm3
    44bd:	c4 e3 7d 39 d2 01    	vextracti128 $0x1,%ymm2,%xmm2
    44c3:	c4 e2 7d 30 fd       	vpmovzxbw %xmm5,%ymm7
    44c8:	c4 e2 7d 30 d2       	vpmovzxbw %xmm2,%ymm2
    44cd:	c5 fd 7f 9c 24 48 01 	vmovdqa %ymm3,0x148(%rsp)
    44d4:	00 00 
    44d6:	c4 62 7d 30 c4       	vpmovzxbw %xmm4,%ymm8
    44db:	c5 9d d5 ef          	vpmullw %ymm7,%ymm12,%ymm5
    44df:	c5 9d d5 f6          	vpmullw %ymm6,%ymm12,%ymm6
    44e3:	c4 e3 7d 39 e4 01    	vextracti128 $0x1,%ymm4,%xmm4
    44e9:	c5 fd 7f 94 24 e8 00 	vmovdqa %ymm2,0xe8(%rsp)
    44f0:	00 00 
    44f2:	c5 95 d5 db          	vpmullw %ymm3,%ymm13,%ymm3
    44f6:	c5 95 d5 d2          	vpmullw %ymm2,%ymm13,%ymm2
    44fa:	c4 e2 7d 30 e4       	vpmovzxbw %xmm4,%ymm4
    44ff:	c5 7d 7f 84 24 08 01 	vmovdqa %ymm8,0x108(%rsp)
    4506:	00 00 
    4508:	c4 e3 fd 00 c0 d8    	vpermq $0xd8,%ymm0,%ymm0
    450e:	c4 e3 fd 00 c9 d8    	vpermq $0xd8,%ymm1,%ymm1
    4514:	c5 fd 7f bc 24 c8 00 	vmovdqa %ymm7,0xc8(%rsp)
    451b:	00 00 
    451d:	c4 e2 7d 30 f9       	vpmovzxbw %xmm1,%ymm7
    4522:	c4 e3 7d 39 c9 01    	vextracti128 $0x1,%ymm1,%xmm1
    4528:	c4 e2 7d 30 c9       	vpmovzxbw %xmm1,%ymm1
    452d:	c5 e5 fd de          	vpaddw %ymm6,%ymm3,%ymm3
    4531:	c5 ed fd d5          	vpaddw %ymm5,%ymm2,%ymm2
    4535:	c4 c1 25 d5 f0       	vpmullw %ymm8,%ymm11,%ymm6
    453a:	c4 c1 5d d5 eb       	vpmullw %ymm11,%ymm4,%ymm5
    453f:	c4 62 7d 30 c0       	vpmovzxbw %xmm0,%ymm8
    4544:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    454a:	c4 e2 7d 30 c0       	vpmovzxbw %xmm0,%ymm0
    454f:	c4 c1 4d fd f2       	vpaddw %ymm10,%ymm6,%ymm6
    4554:	c4 c1 55 fd ea       	vpaddw %ymm10,%ymm5,%ymm5
    4559:	c5 e5 fd de          	vpaddw %ymm6,%ymm3,%ymm3
    455d:	c4 c1 7d d5 f4       	vpmullw %ymm12,%ymm0,%ymm6
    4562:	c5 ed fd d5          	vpaddw %ymm5,%ymm2,%ymm2
    4566:	c5 e5 71 d3 08       	vpsrlw $0x8,%ymm3,%ymm3
    456b:	c5 ed 71 d2 08       	vpsrlw $0x8,%ymm2,%ymm2
    4570:	c4 c1 3d d5 ec       	vpmullw %ymm12,%ymm8,%ymm5
    4575:	c5 85 db db          	vpand  %ymm3,%ymm15,%ymm3
    4579:	c5 85 db d2          	vpand  %ymm2,%ymm15,%ymm2
    457d:	c5 e5 67 da          	vpackuswb %ymm2,%ymm3,%ymm3
    4581:	c4 c1 45 d5 d5       	vpmullw %ymm13,%ymm7,%ymm2
    4586:	c4 e3 fd 00 db d8    	vpermq $0xd8,%ymm3,%ymm3
    458c:	c4 c1 65 fc d9       	vpaddb %ymm9,%ymm3,%ymm3
    4591:	c4 42 7d 30 ce       	vpmovzxbw %xmm14,%ymm9
    4596:	c5 ed fd d5          	vpaddw %ymm5,%ymm2,%ymm2
    459a:	c4 c1 35 d5 eb       	vpmullw %ymm11,%ymm9,%ymm5
    459f:	c4 c1 55 fd ea       	vpaddw %ymm10,%ymm5,%ymm5
    45a4:	c5 ed fd d5          	vpaddw %ymm5,%ymm2,%ymm2
    45a8:	c4 c1 75 d5 ed       	vpmullw %ymm13,%ymm1,%ymm5
    45ad:	c5 ed 71 d2 08       	vpsrlw $0x8,%ymm2,%ymm2
    45b2:	c5 85 db d2          	vpand  %ymm2,%ymm15,%ymm2
    45b6:	c5 d5 fd ee          	vpaddw %ymm6,%ymm5,%ymm5
    45ba:	c4 63 7d 39 f6 01    	vextracti128 $0x1,%ymm14,%xmm6
    45c0:	c4 e2 7d 30 f6       	vpmovzxbw %xmm6,%ymm6
    45c5:	c4 41 4d d5 f3       	vpmullw %ymm11,%ymm6,%ymm14
    45ca:	c5 dd fd e6          	vpaddw %ymm6,%ymm4,%ymm4
    45ce:	c4 41 0d fd f2       	vpaddw %ymm10,%ymm14,%ymm14
    45d3:	c4 c1 55 fd ee       	vpaddw %ymm14,%ymm5,%ymm5
    45d8:	c5 7d 6f b4 24 68 01 	vmovdqa 0x168(%rsp),%ymm14
    45df:	00 00 
    45e1:	c5 d5 71 d5 08       	vpsrlw $0x8,%ymm5,%ymm5
    45e6:	c5 85 db ed          	vpand  %ymm5,%ymm15,%ymm5
    45ea:	c5 ed 67 d5          	vpackuswb %ymm5,%ymm2,%ymm2
    45ee:	c4 e3 fd 00 d2 d8    	vpermq $0xd8,%ymm2,%ymm2
    45f4:	c5 ed fc 94 24 e8 02 	vpaddb 0x2e8(%rsp),%ymm2,%ymm2
    45fb:	00 00 
    45fd:	c5 e5 60 ea          	vpunpcklbw %ymm2,%ymm3,%ymm5
    4601:	c5 e5 68 d2          	vpunpckhbw %ymm2,%ymm3,%ymm2
    4605:	c4 e3 55 46 da 20    	vperm2i128 $0x20,%ymm2,%ymm5,%ymm3
    460b:	c4 e3 55 46 ea 31    	vperm2i128 $0x31,%ymm2,%ymm5,%ymm5
    4611:	c4 c1 7e 7f 1c 12    	vmovdqu %ymm3,(%r10,%rdx,1)
    4617:	c5 fd 6f 9c 24 c8 01 	vmovdqa 0x1c8(%rsp),%ymm3
    461e:	00 00 
    4620:	c5 e5 fd 94 24 88 02 	vpaddw 0x288(%rsp),%ymm3,%ymm2
    4627:	00 00 
    4629:	c5 b5 fd 9c 24 08 01 	vpaddw 0x108(%rsp),%ymm9,%ymm3
    4630:	00 00 
    4632:	c4 c1 7e 7f 6c 12 20 	vmovdqu %ymm5,0x20(%r10,%rdx,1)
    4639:	c5 fd 6f ac 24 e8 01 	vmovdqa 0x1e8(%rsp),%ymm5
    4640:	00 00 
    4642:	c5 ed fd d3          	vpaddw %ymm3,%ymm2,%ymm2
    4646:	c5 8d fd 9c 24 28 02 	vpaddw 0x228(%rsp),%ymm14,%ymm3
    464d:	00 00 
    464f:	c5 ed 71 d2 02       	vpsrlw $0x2,%ymm2,%ymm2
    4654:	c5 e5 fd dc          	vpaddw %ymm4,%ymm3,%ymm3
    4658:	c5 d5 fd a4 24 a8 02 	vpaddw 0x2a8(%rsp),%ymm5,%ymm4
    465f:	00 00 
    4661:	c5 bd fd ac 24 28 01 	vpaddw 0x128(%rsp),%ymm8,%ymm5
    4668:	00 00 
    466a:	c5 e5 71 d3 02       	vpsrlw $0x2,%ymm3,%ymm3
    466f:	c5 dd fd e5          	vpaddw %ymm5,%ymm4,%ymm4
    4673:	c5 fd 6f ac 24 88 01 	vmovdqa 0x188(%rsp),%ymm5
    467a:	00 00 
    467c:	c5 d5 fd ac 24 48 02 	vpaddw 0x248(%rsp),%ymm5,%ymm5
    4683:	00 00 
    4685:	c5 fd fd 84 24 c8 00 	vpaddw 0xc8(%rsp),%ymm0,%ymm0
    468c:	00 00 
    468e:	c5 7d 6f 4c 24 68    	vmovdqa 0x68(%rsp),%ymm9
    4694:	c5 dd 71 d4 02       	vpsrlw $0x2,%ymm4,%ymm4
    4699:	c5 c5 fd b4 24 48 01 	vpaddw 0x148(%rsp),%ymm7,%ymm6
    46a0:	00 00 
    46a2:	c5 7d 6f 74 24 28    	vmovdqa 0x28(%rsp),%ymm14
    46a8:	c5 7d 6f 84 24 08 02 	vmovdqa 0x208(%rsp),%ymm8
    46af:	00 00 
    46b1:	c5 d5 fd e8          	vpaddw %ymm0,%ymm5,%ymm5
    46b5:	c5 bd fd 84 24 c8 02 	vpaddw 0x2c8(%rsp),%ymm8,%ymm0
    46bc:	00 00 
    46be:	c5 f5 fd 8c 24 e8 00 	vpaddw 0xe8(%rsp),%ymm1,%ymm1
    46c5:	00 00 
    46c7:	c5 7d 6f 44 24 48    	vmovdqa 0x48(%rsp),%ymm8
    46cd:	c5 d5 71 d5 02       	vpsrlw $0x2,%ymm5,%ymm5
    46d2:	c5 fd fd c6          	vpaddw %ymm6,%ymm0,%ymm0
    46d6:	c5 fd 6f b4 24 a8 01 	vmovdqa 0x1a8(%rsp),%ymm6
    46dd:	00 00 
    46df:	c5 cd fd b4 24 68 02 	vpaddw 0x268(%rsp),%ymm6,%ymm6
    46e6:	00 00 
    46e8:	c5 fd 71 d0 02       	vpsrlw $0x2,%ymm0,%ymm0
    46ed:	c4 c1 5d d5 f8       	vpmullw %ymm8,%ymm4,%ymm7
    46f2:	c5 cd fd f1          	vpaddw %ymm1,%ymm6,%ymm6
    46f6:	c4 c1 7d d5 c9       	vpmullw %ymm9,%ymm0,%ymm1
    46fb:	c5 cd 71 d6 02       	vpsrlw $0x2,%ymm6,%ymm6
    4700:	c4 41 55 d5 c0       	vpmullw %ymm8,%ymm5,%ymm8
    4705:	c5 f5 fd cf          	vpaddw %ymm7,%ymm1,%ymm1
    4709:	c5 c5 71 f2 03       	vpsllw $0x3,%ymm2,%ymm7
    470e:	c5 c5 f9 fa          	vpsubw %ymm2,%ymm7,%ymm7
    4712:	c5 c5 71 f7 04       	vpsllw $0x4,%ymm7,%ymm7
    4717:	c4 c1 45 fd fa       	vpaddw %ymm10,%ymm7,%ymm7
    471c:	c5 f5 fd cf          	vpaddw %ymm7,%ymm1,%ymm1
    4720:	c4 c1 4d d5 f9       	vpmullw %ymm9,%ymm6,%ymm7
    4725:	c5 f5 71 e1 08       	vpsraw $0x8,%ymm1,%ymm1
    472a:	c5 85 db c9          	vpand  %ymm1,%ymm15,%ymm1
    472e:	c4 c1 45 fd f8       	vpaddw %ymm8,%ymm7,%ymm7
    4733:	c5 bd 71 f3 03       	vpsllw $0x3,%ymm3,%ymm8
    4738:	c5 3d f9 c3          	vpsubw %ymm3,%ymm8,%ymm8
    473c:	c4 c1 3d 71 f0 04    	vpsllw $0x4,%ymm8,%ymm8
    4742:	c4 41 3d fd c2       	vpaddw %ymm10,%ymm8,%ymm8
    4747:	c4 c1 45 fd f8       	vpaddw %ymm8,%ymm7,%ymm7
    474c:	c5 c5 71 e7 08       	vpsraw $0x8,%ymm7,%ymm7
    4751:	c5 85 db ff          	vpand  %ymm7,%ymm15,%ymm7
    4755:	c5 f5 67 cf          	vpackuswb %ymm7,%ymm1,%ymm1
    4759:	c5 c5 71 f0 03       	vpsllw $0x3,%ymm0,%ymm7
    475e:	c5 c5 f9 c0          	vpsubw %ymm0,%ymm7,%ymm0
    4762:	c5 fd 6f 7c 24 08    	vmovdqa 0x8(%rsp),%ymm7
    4768:	c4 e3 fd 00 c9 d8    	vpermq $0xd8,%ymm1,%ymm1
    476e:	c5 fd 71 f0 04       	vpsllw $0x4,%ymm0,%ymm0
    4773:	c4 c1 75 fc ce       	vpaddb %ymm14,%ymm1,%ymm1
    4778:	c5 dd d5 e7          	vpmullw %ymm7,%ymm4,%ymm4
    477c:	c5 d5 d5 ef          	vpmullw %ymm7,%ymm5,%ymm5
    4780:	c5 fd fd c4          	vpaddw %ymm4,%ymm0,%ymm0
    4784:	c5 dd 71 f2 02       	vpsllw $0x2,%ymm2,%ymm4
    4789:	c5 dd fd d2          	vpaddw %ymm2,%ymm4,%ymm2
    478d:	c5 dd 71 f3 02       	vpsllw $0x2,%ymm3,%ymm4
    4792:	c5 ed 71 f2 01       	vpsllw $0x1,%ymm2,%ymm2
    4797:	c5 dd fd db          	vpaddw %ymm3,%ymm4,%ymm3
    479b:	c5 ad f9 d2          	vpsubw %ymm2,%ymm10,%ymm2
    479f:	c5 e5 71 f3 01       	vpsllw $0x1,%ymm3,%ymm3
    47a4:	c5 fd fd d2          	vpaddw %ymm2,%ymm0,%ymm2
    47a8:	c5 fd 71 f6 03       	vpsllw $0x3,%ymm6,%ymm0
    47ad:	c5 ad f9 db          	vpsubw %ymm3,%ymm10,%ymm3
    47b1:	c5 fd f9 c6          	vpsubw %ymm6,%ymm0,%ymm0
    47b5:	c5 ed 71 e2 08       	vpsraw $0x8,%ymm2,%ymm2
    47ba:	c5 fd 71 f0 04       	vpsllw $0x4,%ymm0,%ymm0
    47bf:	c5 85 db d2          	vpand  %ymm2,%ymm15,%ymm2
    47c3:	c5 fd fd c5          	vpaddw %ymm5,%ymm0,%ymm0
    47c7:	c5 fd fd c3          	vpaddw %ymm3,%ymm0,%ymm0
    47cb:	c5 fd 71 e0 08       	vpsraw $0x8,%ymm0,%ymm0
    47d0:	c5 85 db c0          	vpand  %ymm0,%ymm15,%ymm0
    47d4:	c5 ed 67 c0          	vpackuswb %ymm0,%ymm2,%ymm0
    47d8:	c4 e3 fd 00 c0 d8    	vpermq $0xd8,%ymm0,%ymm0
    47de:	c4 c1 7d fc c6       	vpaddb %ymm14,%ymm0,%ymm0
    47e3:	c5 f5 60 d0          	vpunpcklbw %ymm0,%ymm1,%ymm2
    47e7:	c5 f5 68 c8          	vpunpckhbw %ymm0,%ymm1,%ymm1
    47eb:	c4 e3 6d 46 c1 20    	vperm2i128 $0x20,%ymm1,%ymm2,%ymm0
    47f1:	c4 e3 6d 46 d1 31    	vperm2i128 $0x31,%ymm1,%ymm2,%ymm2
    47f7:	c4 c1 7e 7f 04 17    	vmovdqu %ymm0,(%r15,%rdx,1)
    47fd:	c4 c1 7e 7f 54 17 20 	vmovdqu %ymm2,0x20(%r15,%rdx,1)
    4804:	48 83 c2 40          	add    $0x40,%rdx
    4808:	49 39 d1             	cmp    %rdx,%r9
    480b:	0f 85 77 f7 ff ff    	jne    3f88 <convert_avx2_adaptive_job+0x4d8>
    4811:	44 89 d8             	mov    %r11d,%eax
    4814:	44 89 da             	mov    %r11d,%edx
    4817:	c1 e0 05             	shl    $0x5,%eax
    481a:	29 84 24 a4 00 00 00 	sub    %eax,0xa4(%rsp)
    4821:	c1 e2 06             	shl    $0x6,%edx
    4824:	8b 9c 24 a4 00 00 00 	mov    0xa4(%rsp),%ebx
    482b:	01 94 24 20 03 00 00 	add    %edx,0x320(%rsp)
    4832:	83 fb 0f             	cmp    $0xf,%ebx
    4835:	0f 86 77 08 00 00    	jbe    50b2 <convert_avx2_adaptive_job+0x1602>
    483b:	48 8b 54 24 f8       	mov    -0x8(%rsp),%rdx
    4840:	48 01 c0             	add    %rax,%rax
    4843:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
    484a:	00 
    484b:	48 8b 9c 24 90 00 00 	mov    0x90(%rsp),%rbx
    4852:	00 
    4853:	4c 8b 84 24 88 00 00 	mov    0x88(%rsp),%r8
    485a:	00 
    485b:	c5 79 6f b4 24 08 03 	vmovdqa 0x308(%rsp),%xmm14
    4862:	00 00 
    4864:	48 01 c2             	add    %rax,%rdx
    4867:	48 c1 e2 02          	shl    $0x2,%rdx
    486b:	49 01 c0             	add    %rax,%r8
    486e:	48 01 d1             	add    %rdx,%rcx
    4871:	48 01 d3             	add    %rdx,%rbx
    4874:	4f 8d 0c 04          	lea    (%r12,%r8,1),%r9
    4878:	4c 8b 04 24          	mov    (%rsp),%r8
    487c:	4c 01 f1             	add    %r14,%rcx
    487f:	48 89 da             	mov    %rbx,%rdx
    4882:	48 8b 5c 24 c0       	mov    -0x40(%rsp),%rbx
    4887:	c5 fa 6f 01          	vmovdqu (%rcx),%xmm0
    488b:	c5 7a 6f 61 10       	vmovdqu 0x10(%rcx),%xmm12
    4890:	49 01 c0             	add    %rax,%r8
    4893:	4c 01 f2             	add    %r14,%rdx
    4896:	c5 fa 6f 71 20       	vmovdqu 0x20(%rcx),%xmm6
    489b:	c5 7a 6f 51 30       	vmovdqu 0x30(%rcx),%xmm10
    48a0:	48 01 c3             	add    %rax,%rbx
    48a3:	4d 01 e0             	add    %r12,%r8
    48a6:	c5 fa 6f 49 40       	vmovdqu 0x40(%rcx),%xmm1
    48ab:	c4 c1 19 db e6       	vpand  %xmm14,%xmm12,%xmm4
    48b0:	c4 c1 79 db d6       	vpand  %xmm14,%xmm0,%xmm2
    48b5:	48 89 d8             	mov    %rbx,%rax
    48b8:	c5 7a 6f 49 50       	vmovdqu 0x50(%rcx),%xmm9
    48bd:	c5 fa 6f 59 60       	vmovdqu 0x60(%rcx),%xmm3
    48c2:	c4 c1 29 db ee       	vpand  %xmm14,%xmm10,%xmm5
    48c7:	c5 e9 67 d4          	vpackuswb %xmm4,%xmm2,%xmm2
    48cb:	c5 fa 6f 79 70       	vmovdqu 0x70(%rcx),%xmm7
    48d0:	c4 c1 49 db e6       	vpand  %xmm14,%xmm6,%xmm4
    48d5:	c4 41 71 db c6       	vpand  %xmm14,%xmm1,%xmm8
    48da:	48 8b 9c 24 18 03 00 	mov    0x318(%rsp),%rbx
    48e1:	00 
    48e2:	c5 d9 67 e5          	vpackuswb %xmm5,%xmm4,%xmm4
    48e6:	c4 c1 31 db ee       	vpand  %xmm14,%xmm9,%xmm5
    48eb:	c4 41 61 db de       	vpand  %xmm14,%xmm3,%xmm11
    48f0:	b9 10 00 00 00       	mov    $0x10,%ecx
    48f5:	c5 39 67 c5          	vpackuswb %xmm5,%xmm8,%xmm8
    48f9:	c4 c1 41 db ee       	vpand  %xmm14,%xmm7,%xmm5
    48fe:	c4 41 59 db ee       	vpand  %xmm14,%xmm4,%xmm13
    4903:	48 01 d8             	add    %rbx,%rax
    4906:	c5 21 67 dd          	vpackuswb %xmm5,%xmm11,%xmm11
    490a:	c5 d9 71 d4 08       	vpsrlw $0x8,%xmm4,%xmm4
    490f:	c4 c1 69 db ee       	vpand  %xmm14,%xmm2,%xmm5
    4914:	bb 2f 00 00 00       	mov    $0x2f,%ebx
    4919:	c4 c1 19 71 d4 08    	vpsrlw $0x8,%xmm12,%xmm12
    491f:	c4 c1 29 71 d2 08    	vpsrlw $0x8,%xmm10,%xmm10
    4925:	c4 c1 51 67 ed       	vpackuswb %xmm13,%xmm5,%xmm5
    492a:	c4 c1 31 71 d1 08    	vpsrlw $0x8,%xmm9,%xmm9
    4930:	c5 c1 71 d7 08       	vpsrlw $0x8,%xmm7,%xmm7
    4935:	c4 41 21 db ee       	vpand  %xmm14,%xmm11,%xmm13
    493a:	c5 e9 71 d2 08       	vpsrlw $0x8,%xmm2,%xmm2
    493f:	c5 f9 71 d0 08       	vpsrlw $0x8,%xmm0,%xmm0
    4944:	c5 c9 71 d6 08       	vpsrlw $0x8,%xmm6,%xmm6
    4949:	c5 f1 71 d1 08       	vpsrlw $0x8,%xmm1,%xmm1
    494e:	c5 e9 67 d4          	vpackuswb %xmm4,%xmm2,%xmm2
    4952:	c5 e1 71 d3 08       	vpsrlw $0x8,%xmm3,%xmm3
    4957:	c4 c1 39 db e6       	vpand  %xmm14,%xmm8,%xmm4
    495c:	c4 c1 79 67 c4       	vpackuswb %xmm12,%xmm0,%xmm0
    4961:	c4 c1 49 67 f2       	vpackuswb %xmm10,%xmm6,%xmm6
    4966:	c4 c1 71 67 c9       	vpackuswb %xmm9,%xmm1,%xmm1
    496b:	c5 e1 67 df          	vpackuswb %xmm7,%xmm3,%xmm3
    496f:	c4 c1 59 67 e5       	vpackuswb %xmm13,%xmm4,%xmm4
    4974:	c4 c1 49 db f6       	vpand  %xmm14,%xmm6,%xmm6
    4979:	c4 c1 61 db de       	vpand  %xmm14,%xmm3,%xmm3
    497e:	c5 79 6f 6c 24 e8    	vmovdqa -0x18(%rsp),%xmm13
    4984:	c4 c1 79 db c6       	vpand  %xmm14,%xmm0,%xmm0
    4989:	c4 c1 71 db ce       	vpand  %xmm14,%xmm1,%xmm1
    498e:	c4 41 79 6f e6       	vmovdqa %xmm14,%xmm12
    4993:	c5 f9 67 c6          	vpackuswb %xmm6,%xmm0,%xmm0
    4997:	c5 f1 67 cb          	vpackuswb %xmm3,%xmm1,%xmm1
    499b:	c4 c1 51 db f6       	vpand  %xmm14,%xmm5,%xmm6
    49a0:	c4 c1 59 db de       	vpand  %xmm14,%xmm4,%xmm3
    49a5:	c4 c1 21 71 d3 08    	vpsrlw $0x8,%xmm11,%xmm11
    49ab:	c4 c1 79 db fe       	vpand  %xmm14,%xmm0,%xmm7
    49b0:	c4 c1 39 71 d0 08    	vpsrlw $0x8,%xmm8,%xmm8
    49b6:	c5 d9 71 d4 08       	vpsrlw $0x8,%xmm4,%xmm4
    49bb:	c5 c9 67 f3          	vpackuswb %xmm3,%xmm6,%xmm6
    49bf:	c4 c1 71 db de       	vpand  %xmm14,%xmm1,%xmm3
    49c4:	c5 d1 71 d5 08       	vpsrlw $0x8,%xmm5,%xmm5
    49c9:	c4 41 39 67 c3       	vpackuswb %xmm11,%xmm8,%xmm8
    49ce:	c5 c1 67 fb          	vpackuswb %xmm3,%xmm7,%xmm7
    49d2:	c5 f9 6e db          	vmovd  %ebx,%xmm3
    49d6:	bb 9d ff ff ff       	mov    $0xffffff9d,%ebx
    49db:	c5 f1 71 d1 08       	vpsrlw $0x8,%xmm1,%xmm1
    49e0:	c5 79 6e d3          	vmovd  %ebx,%xmm10
    49e4:	c5 d1 67 ec          	vpackuswb %xmm4,%xmm5,%xmm5
    49e8:	c5 f9 71 d0 08       	vpsrlw $0x8,%xmm0,%xmm0
    49ed:	c4 c1 69 db e6       	vpand  %xmm14,%xmm2,%xmm4
    49f2:	c4 42 79 78 d2       	vpbroadcastb %xmm10,%xmm10
    49f7:	c5 f9 67 c1          	vpackuswb %xmm1,%xmm0,%xmm0
    49fb:	c4 c1 39 db ce       	vpand  %xmm14,%xmm8,%xmm1
    4a00:	c4 e2 79 78 db       	vpbroadcastb %xmm3,%xmm3
    4a05:	c4 42 79 30 f2       	vpmovzxbw %xmm10,%xmm14
    4a0a:	c5 d9 67 e1          	vpackuswb %xmm1,%xmm4,%xmm4
    4a0e:	c4 62 79 30 d6       	vpmovzxbw %xmm6,%xmm10
    4a13:	c4 c1 39 71 d0 08    	vpsrlw $0x8,%xmm8,%xmm8
    4a19:	c5 e9 71 d2 08       	vpsrlw $0x8,%xmm2,%xmm2
    4a1e:	c4 62 79 30 fb       	vpmovzxbw %xmm3,%xmm15
    4a23:	c5 79 7f 94 24 48 02 	vmovdqa %xmm10,0x248(%rsp)
    4a2a:	00 00 
    4a2c:	c4 c1 69 67 d0       	vpackuswb %xmm8,%xmm2,%xmm2
    4a31:	c4 e2 79 30 cc       	vpmovzxbw %xmm4,%xmm1
    4a36:	c4 e2 79 30 df       	vpmovzxbw %xmm7,%xmm3
    4a3b:	c5 29 d5 05 cd a8 00 	vpmullw 0xa8cd(%rip),%xmm10,%xmm8        # f310 <__PRETTY_FUNCTION__.4+0x9d>
    4a42:	00 
    4a43:	c5 d9 73 dc 08       	vpsrldq $0x8,%xmm4,%xmm4
    4a48:	c5 c1 73 df 08       	vpsrldq $0x8,%xmm7,%xmm7
    4a4d:	c5 79 6e d9          	vmovd  %ecx,%xmm11
    4a51:	c5 79 6f 94 24 a8 00 	vmovdqa 0xa8(%rsp),%xmm10
    4a58:	00 00 
    4a5a:	c4 e2 79 30 e4       	vpmovzxbw %xmm4,%xmm4
    4a5f:	c4 e2 79 30 ff       	vpmovzxbw %xmm7,%xmm7
    4a64:	c4 42 79 78 db       	vpbroadcastb %xmm11,%xmm11
    4a69:	c5 f9 7f 8c 24 88 02 	vmovdqa %xmm1,0x288(%rsp)
    4a70:	00 00 
    4a72:	c5 c9 73 de 08       	vpsrldq $0x8,%xmm6,%xmm6
    4a77:	c4 c1 71 d5 cf       	vpmullw %xmm15,%xmm1,%xmm1
    4a7c:	c5 f9 7f a4 24 28 02 	vmovdqa %xmm4,0x228(%rsp)
    4a83:	00 00 
    4a85:	b9 80 00 00 00       	mov    $0x80,%ecx
    4a8a:	c4 c1 59 d5 e2       	vpmullw %xmm10,%xmm4,%xmm4
    4a8f:	c4 62 79 30 ce       	vpmovzxbw %xmm6,%xmm9
    4a94:	c5 f9 7f bc 24 08 02 	vmovdqa %xmm7,0x208(%rsp)
    4a9b:	00 00 
    4a9d:	c4 c1 41 d5 fd       	vpmullw %xmm13,%xmm7,%xmm7
    4aa2:	c4 c1 49 73 db 08    	vpsrldq $0x8,%xmm11,%xmm6
    4aa8:	c5 f9 7f 9c 24 68 02 	vmovdqa %xmm3,0x268(%rsp)
    4aaf:	00 00 
    4ab1:	c5 79 7f 8c 24 e8 01 	vmovdqa %xmm9,0x1e8(%rsp)
    4ab8:	00 00 
    4aba:	c5 89 d5 db          	vpmullw %xmm3,%xmm14,%xmm3
    4abe:	c5 79 7f bc 24 e8 02 	vmovdqa %xmm15,0x2e8(%rsp)
    4ac5:	00 00 
    4ac7:	c5 d9 fd e7          	vpaddw %xmm7,%xmm4,%xmm4
    4acb:	c5 79 7f df          	vmovdqa %xmm11,%xmm7
    4acf:	c4 62 79 30 de       	vpmovzxbw %xmm6,%xmm11
    4ad4:	c4 c1 21 d5 f1       	vpmullw %xmm9,%xmm11,%xmm6
    4ad9:	c5 f1 fd cb          	vpaddw %xmm3,%xmm1,%xmm1
    4add:	c5 f9 6e d9          	vmovd  %ecx,%xmm3
    4ae1:	c4 e2 79 79 db       	vpbroadcastw %xmm3,%xmm3
    4ae6:	c5 39 fd c3          	vpaddw %xmm3,%xmm8,%xmm8
    4aea:	c4 c1 71 fd c8       	vpaddw %xmm8,%xmm1,%xmm1
    4aef:	c4 62 79 30 c2       	vpmovzxbw %xmm2,%xmm8
    4af4:	c5 e9 73 da 08       	vpsrldq $0x8,%xmm2,%xmm2
    4af9:	c5 f1 71 d1 08       	vpsrlw $0x8,%xmm1,%xmm1
    4afe:	c5 79 7f 84 24 c8 01 	vmovdqa %xmm8,0x1c8(%rsp)
    4b05:	00 00 
    4b07:	c5 c9 fd f3          	vpaddw %xmm3,%xmm6,%xmm6
    4b0b:	c4 e2 79 30 d2       	vpmovzxbw %xmm2,%xmm2
    4b10:	c4 c1 71 db cc       	vpand  %xmm12,%xmm1,%xmm1
    4b15:	c5 f9 7f 94 24 68 01 	vmovdqa %xmm2,0x168(%rsp)
    4b1c:	00 00 
    4b1e:	c5 d9 fd e6          	vpaddw %xmm6,%xmm4,%xmm4
    4b22:	c4 e2 79 30 f0       	vpmovzxbw %xmm0,%xmm6
    4b27:	c5 f9 73 d8 08       	vpsrldq $0x8,%xmm0,%xmm0
    4b2c:	c4 c1 69 d5 d2       	vpmullw %xmm10,%xmm2,%xmm2
    4b31:	c5 f9 7f b4 24 a8 01 	vmovdqa %xmm6,0x1a8(%rsp)
    4b38:	00 00 
    4b3a:	c5 d9 71 d4 08       	vpsrlw $0x8,%xmm4,%xmm4
    4b3f:	c5 89 d5 f6          	vpmullw %xmm6,%xmm14,%xmm6
    4b43:	c4 e2 79 30 c0       	vpmovzxbw %xmm0,%xmm0
    4b48:	c5 f9 7f 84 24 48 01 	vmovdqa %xmm0,0x148(%rsp)
    4b4f:	00 00 
    4b51:	c4 c1 79 d5 c5       	vpmullw %xmm13,%xmm0,%xmm0
    4b56:	c4 c1 59 db e4       	vpand  %xmm12,%xmm4,%xmm4
    4b5b:	c5 f1 67 cc          	vpackuswb %xmm4,%xmm1,%xmm1
    4b5f:	c4 c1 39 d5 e7       	vpmullw %xmm15,%xmm8,%xmm4
    4b64:	c4 62 79 30 c5       	vpmovzxbw %xmm5,%xmm8
    4b69:	c5 d1 73 dd 08       	vpsrldq $0x8,%xmm5,%xmm5
    4b6e:	c5 f1 fc cf          	vpaddb %xmm7,%xmm1,%xmm1
    4b72:	c4 41 79 6f fc       	vmovdqa %xmm12,%xmm15
    4b77:	c5 79 7f 84 24 88 01 	vmovdqa %xmm8,0x188(%rsp)
    4b7e:	00 00 
    4b80:	c4 e2 79 30 ed       	vpmovzxbw %xmm5,%xmm5
    4b85:	c5 e9 fd c0          	vpaddw %xmm0,%xmm2,%xmm0
    4b89:	c4 c1 51 d5 d3       	vpmullw %xmm11,%xmm5,%xmm2
    4b8e:	c5 d9 fd e6          	vpaddw %xmm6,%xmm4,%xmm4
    4b92:	c5 b9 d5 35 76 a7 00 	vpmullw 0xa776(%rip),%xmm8,%xmm6        # f310 <__PRETTY_FUNCTION__.4+0x9d>
    4b99:	00 
    4b9a:	c5 c9 fd f3          	vpaddw %xmm3,%xmm6,%xmm6
    4b9e:	c5 f9 7f ac 24 28 01 	vmovdqa %xmm5,0x128(%rsp)
    4ba5:	00 00 
    4ba7:	c5 79 7f 9c 24 a8 02 	vmovdqa %xmm11,0x2a8(%rsp)
    4bae:	00 00 
    4bb0:	c5 d9 fd e6          	vpaddw %xmm6,%xmm4,%xmm4
    4bb4:	c5 f9 7f bc 24 c8 02 	vmovdqa %xmm7,0x2c8(%rsp)
    4bbb:	00 00 
    4bbd:	c5 d9 71 d4 08       	vpsrlw $0x8,%xmm4,%xmm4
    4bc2:	c4 c1 59 db e4       	vpand  %xmm12,%xmm4,%xmm4
    4bc7:	c5 e9 fd d3          	vpaddw %xmm3,%xmm2,%xmm2
    4bcb:	c5 f9 fd c2          	vpaddw %xmm2,%xmm0,%xmm0
    4bcf:	c5 f9 71 d0 08       	vpsrlw $0x8,%xmm0,%xmm0
    4bd4:	c4 c1 79 db c4       	vpand  %xmm12,%xmm0,%xmm0
    4bd9:	c5 d9 67 e0          	vpackuswb %xmm0,%xmm4,%xmm4
    4bdd:	c5 d9 fc e7          	vpaddb %xmm7,%xmm4,%xmm4
    4be1:	c5 f1 60 c4          	vpunpcklbw %xmm4,%xmm1,%xmm0
    4be5:	c5 f1 68 cc          	vpunpckhbw %xmm4,%xmm1,%xmm1
    4be9:	c4 c1 7a 7f 49 10    	vmovdqu %xmm1,0x10(%r9)
    4bef:	c4 c1 7a 7f 01       	vmovdqu %xmm0,(%r9)
    4bf4:	c5 7a 6f 22          	vmovdqu (%rdx),%xmm12
    4bf8:	c5 fa 6f 42 10       	vmovdqu 0x10(%rdx),%xmm0
    4bfd:	c5 7a 6f 5a 20       	vmovdqu 0x20(%rdx),%xmm11
    4c02:	c5 fa 6f 7a 30       	vmovdqu 0x30(%rdx),%xmm7
    4c07:	c5 7a 6f 52 40       	vmovdqu 0x40(%rdx),%xmm10
    4c0c:	c5 fa 6f 52 50       	vmovdqu 0x50(%rdx),%xmm2
    4c11:	c4 c1 79 db e7       	vpand  %xmm15,%xmm0,%xmm4
    4c16:	c4 c1 19 db cf       	vpand  %xmm15,%xmm12,%xmm1
    4c1b:	c5 7a 6f 42 60       	vmovdqu 0x60(%rdx),%xmm8
    4c20:	c5 fa 6f 72 70       	vmovdqu 0x70(%rdx),%xmm6
    4c25:	c5 f1 67 cc          	vpackuswb %xmm4,%xmm1,%xmm1
    4c29:	c4 41 21 db cf       	vpand  %xmm15,%xmm11,%xmm9
    4c2e:	c4 c1 41 db e7       	vpand  %xmm15,%xmm7,%xmm4
    4c33:	c4 c1 69 db ef       	vpand  %xmm15,%xmm2,%xmm5
    4c38:	ba e6 ff ff ff       	mov    $0xffffffe6,%edx
    4c3d:	c5 31 67 cc          	vpackuswb %xmm4,%xmm9,%xmm9
    4c41:	c4 c1 29 db e7       	vpand  %xmm15,%xmm10,%xmm4
    4c46:	c4 41 39 db ef       	vpand  %xmm15,%xmm8,%xmm13
    4c4b:	c4 c1 19 71 d4 08    	vpsrlw $0x8,%xmm12,%xmm12
    4c51:	c4 c1 21 71 d3 08    	vpsrlw $0x8,%xmm11,%xmm11
    4c57:	c5 d9 67 e5          	vpackuswb %xmm5,%xmm4,%xmm4
    4c5b:	c4 c1 29 71 d2 08    	vpsrlw $0x8,%xmm10,%xmm10
    4c61:	c4 c1 39 71 d0 08    	vpsrlw $0x8,%xmm8,%xmm8
    4c67:	c4 c1 49 db ef       	vpand  %xmm15,%xmm6,%xmm5
    4c6c:	c5 f9 71 d0 08       	vpsrlw $0x8,%xmm0,%xmm0
    4c71:	c5 c1 71 d7 08       	vpsrlw $0x8,%xmm7,%xmm7
    4c76:	c5 11 67 ed          	vpackuswb %xmm5,%xmm13,%xmm13
    4c7a:	c4 c1 71 db ef       	vpand  %xmm15,%xmm1,%xmm5
    4c7f:	c4 41 31 db ff       	vpand  %xmm15,%xmm9,%xmm15
    4c84:	c5 99 67 c0          	vpackuswb %xmm0,%xmm12,%xmm0
    4c88:	c4 c1 51 67 ef       	vpackuswb %xmm15,%xmm5,%xmm5
    4c8d:	c4 c1 31 71 d1 08    	vpsrlw $0x8,%xmm9,%xmm9
    4c93:	c5 a1 67 ff          	vpackuswb %xmm7,%xmm11,%xmm7
    4c97:	c5 79 6f bc 24 08 03 	vmovdqa 0x308(%rsp),%xmm15
    4c9e:	00 00 
    4ca0:	c5 f1 71 d1 08       	vpsrlw $0x8,%xmm1,%xmm1
    4ca5:	c5 e9 71 d2 08       	vpsrlw $0x8,%xmm2,%xmm2
    4caa:	c4 c1 71 67 c9       	vpackuswb %xmm9,%xmm1,%xmm1
    4caf:	c4 41 59 db cf       	vpand  %xmm15,%xmm4,%xmm9
    4cb4:	c4 41 11 db ff       	vpand  %xmm15,%xmm13,%xmm15
    4cb9:	c5 d9 71 d4 08       	vpsrlw $0x8,%xmm4,%xmm4
    4cbe:	c4 c1 11 71 d5 08    	vpsrlw $0x8,%xmm13,%xmm13
    4cc4:	c5 a9 67 d2          	vpackuswb %xmm2,%xmm10,%xmm2
    4cc8:	c4 c1 59 67 e5       	vpackuswb %xmm13,%xmm4,%xmm4
    4ccd:	c5 c9 71 d6 08       	vpsrlw $0x8,%xmm6,%xmm6
    4cd2:	c4 41 31 67 cf       	vpackuswb %xmm15,%xmm9,%xmm9
    4cd7:	c5 79 6f ac 24 08 03 	vmovdqa 0x308(%rsp),%xmm13
    4cde:	00 00 
    4ce0:	c5 b9 67 f6          	vpackuswb %xmm6,%xmm8,%xmm6
    4ce4:	c5 79 6f 7c 24 e8    	vmovdqa -0x18(%rsp),%xmm15
    4cea:	c4 c1 41 db fd       	vpand  %xmm13,%xmm7,%xmm7
    4cef:	c4 c1 69 db d5       	vpand  %xmm13,%xmm2,%xmm2
    4cf4:	c4 c1 79 db c5       	vpand  %xmm13,%xmm0,%xmm0
    4cf9:	c4 c1 49 db f5       	vpand  %xmm13,%xmm6,%xmm6
    4cfe:	c5 f9 67 c7          	vpackuswb %xmm7,%xmm0,%xmm0
    4d02:	c4 41 51 db c5       	vpand  %xmm13,%xmm5,%xmm8
    4d07:	c5 e9 67 f6          	vpackuswb %xmm6,%xmm2,%xmm6
    4d0b:	c5 d1 71 d5 08       	vpsrlw $0x8,%xmm5,%xmm5
    4d10:	c4 c1 31 db d5       	vpand  %xmm13,%xmm9,%xmm2
    4d15:	c4 c1 49 db fd       	vpand  %xmm13,%xmm6,%xmm7
    4d1a:	c5 c9 71 d6 08       	vpsrlw $0x8,%xmm6,%xmm6
    4d1f:	c5 39 67 c2          	vpackuswb %xmm2,%xmm8,%xmm8
    4d23:	c4 c1 79 db d5       	vpand  %xmm13,%xmm0,%xmm2
    4d28:	c5 f9 71 d0 08       	vpsrlw $0x8,%xmm0,%xmm0
    4d2d:	c4 42 79 30 d8       	vpmovzxbw %xmm8,%xmm11
    4d32:	c5 e9 67 d7          	vpackuswb %xmm7,%xmm2,%xmm2
    4d36:	c5 f9 67 c6          	vpackuswb %xmm6,%xmm0,%xmm0
    4d3a:	c4 c1 71 db fd       	vpand  %xmm13,%xmm1,%xmm7
    4d3f:	c4 c1 59 db f5       	vpand  %xmm13,%xmm4,%xmm6
    4d44:	c4 c1 31 71 d1 08    	vpsrlw $0x8,%xmm9,%xmm9
    4d4a:	c4 62 79 30 d2       	vpmovzxbw %xmm2,%xmm10
    4d4f:	c5 e9 73 da 08       	vpsrldq $0x8,%xmm2,%xmm2
    4d54:	c5 c1 67 fe          	vpackuswb %xmm6,%xmm7,%xmm7
    4d58:	c4 c1 51 67 e9       	vpackuswb %xmm9,%xmm5,%xmm5
    4d5d:	c4 c1 29 d5 f6       	vpmullw %xmm14,%xmm10,%xmm6
    4d62:	c4 e2 79 30 d2       	vpmovzxbw %xmm2,%xmm2
    4d67:	c4 62 79 30 e7       	vpmovzxbw %xmm7,%xmm12
    4d6c:	c4 41 69 d5 cf       	vpmullw %xmm15,%xmm2,%xmm9
    4d71:	c5 d9 71 d4 08       	vpsrlw $0x8,%xmm4,%xmm4
    4d76:	c5 79 7f a4 24 08 01 	vmovdqa %xmm12,0x108(%rsp)
    4d7d:	00 00 
    4d7f:	c5 f1 71 d1 08       	vpsrlw $0x8,%xmm1,%xmm1
    4d84:	c5 c1 73 df 08       	vpsrldq $0x8,%xmm7,%xmm7
    4d89:	c5 f1 67 cc          	vpackuswb %xmm4,%xmm1,%xmm1
    4d8d:	c4 c1 39 73 d8 08    	vpsrldq $0x8,%xmm8,%xmm8
    4d93:	c4 e2 79 30 ff       	vpmovzxbw %xmm7,%xmm7
    4d98:	c5 99 d5 a4 24 e8 02 	vpmullw 0x2e8(%rsp),%xmm12,%xmm4
    4d9f:	00 00 
    4da1:	c4 42 79 30 c0       	vpmovzxbw %xmm8,%xmm8
    4da6:	c4 62 79 30 e1       	vpmovzxbw %xmm1,%xmm12
    4dab:	c5 d9 fd e6          	vpaddw %xmm6,%xmm4,%xmm4
    4daf:	c5 a1 d5 35 59 a5 00 	vpmullw 0xa559(%rip),%xmm11,%xmm6        # f310 <__PRETTY_FUNCTION__.4+0x9d>
    4db6:	00 
    4db7:	c5 c9 fd f3          	vpaddw %xmm3,%xmm6,%xmm6
    4dbb:	c5 f1 73 d9 08       	vpsrldq $0x8,%xmm1,%xmm1
    4dc0:	c5 d9 fd e6          	vpaddw %xmm6,%xmm4,%xmm4
    4dc4:	c4 e2 79 30 c9       	vpmovzxbw %xmm1,%xmm1
    4dc9:	c5 c1 d5 b4 24 a8 00 	vpmullw 0xa8(%rsp),%xmm7,%xmm6
    4dd0:	00 00 
    4dd2:	c4 c1 49 fd f1       	vpaddw %xmm9,%xmm6,%xmm6
    4dd7:	c5 39 d5 8c 24 a8 02 	vpmullw 0x2a8(%rsp),%xmm8,%xmm9
    4dde:	00 00 
    4de0:	c5 31 fd cb          	vpaddw %xmm3,%xmm9,%xmm9
    4de4:	c5 d9 71 d4 08       	vpsrlw $0x8,%xmm4,%xmm4
    4de9:	c5 c1 fd f9          	vpaddw %xmm1,%xmm7,%xmm7
    4ded:	c4 c1 49 fd f1       	vpaddw %xmm9,%xmm6,%xmm6
    4df2:	c4 c1 59 db e5       	vpand  %xmm13,%xmm4,%xmm4
    4df7:	c5 c9 71 d6 08       	vpsrlw $0x8,%xmm6,%xmm6
    4dfc:	c4 c1 49 db f5       	vpand  %xmm13,%xmm6,%xmm6
    4e01:	c4 62 79 30 e8       	vpmovzxbw %xmm0,%xmm13
    4e06:	c5 f9 73 d8 08       	vpsrldq $0x8,%xmm0,%xmm0
    4e0b:	c4 41 11 d5 ce       	vpmullw %xmm14,%xmm13,%xmm9
    4e10:	c5 d9 67 e6          	vpackuswb %xmm6,%xmm4,%xmm4
    4e14:	c5 99 d5 b4 24 e8 02 	vpmullw 0x2e8(%rsp),%xmm12,%xmm6
    4e1b:	00 00 
    4e1d:	c4 e2 79 30 c0       	vpmovzxbw %xmm0,%xmm0
    4e22:	c4 62 79 30 f5       	vpmovzxbw %xmm5,%xmm14
    4e27:	c4 41 29 fd d5       	vpaddw %xmm13,%xmm10,%xmm10
    4e2c:	c4 41 79 d5 ff       	vpmullw %xmm15,%xmm0,%xmm15
    4e31:	c5 d1 73 dd 08       	vpsrldq $0x8,%xmm5,%xmm5
    4e36:	c4 41 21 fd de       	vpaddw %xmm14,%xmm11,%xmm11
    4e3b:	c4 e2 79 30 ed       	vpmovzxbw %xmm5,%xmm5
    4e40:	c5 e9 fd d0          	vpaddw %xmm0,%xmm2,%xmm2
    4e44:	c5 d9 fc a4 24 c8 02 	vpaddb 0x2c8(%rsp),%xmm4,%xmm4
    4e4b:	00 00 
    4e4d:	c5 39 fd c5          	vpaddw %xmm5,%xmm8,%xmm8
    4e51:	c4 c1 49 fd f1       	vpaddw %xmm9,%xmm6,%xmm6
    4e56:	c5 09 d5 0d b2 a4 00 	vpmullw 0xa4b2(%rip),%xmm14,%xmm9        # f310 <__PRETTY_FUNCTION__.4+0x9d>
    4e5d:	00 
    4e5e:	c5 31 fd cb          	vpaddw %xmm3,%xmm9,%xmm9
    4e62:	c5 79 6f b4 24 28 01 	vmovdqa 0x128(%rsp),%xmm14
    4e69:	00 00 
    4e6b:	c4 c1 49 fd f1       	vpaddw %xmm9,%xmm6,%xmm6
    4e70:	c5 71 d5 8c 24 a8 00 	vpmullw 0xa8(%rsp),%xmm1,%xmm9
    4e77:	00 00 
    4e79:	c4 41 31 fd cf       	vpaddw %xmm15,%xmm9,%xmm9
    4e7e:	c5 c9 71 d6 08       	vpsrlw $0x8,%xmm6,%xmm6
    4e83:	c5 51 d5 bc 24 a8 02 	vpmullw 0x2a8(%rsp),%xmm5,%xmm15
    4e8a:	00 00 
    4e8c:	c5 01 fd fb          	vpaddw %xmm3,%xmm15,%xmm15
    4e90:	c4 41 31 fd cf       	vpaddw %xmm15,%xmm9,%xmm9
    4e95:	c5 79 6f bc 24 08 03 	vmovdqa 0x308(%rsp),%xmm15
    4e9c:	00 00 
    4e9e:	c4 c1 31 71 d1 08    	vpsrlw $0x8,%xmm9,%xmm9
    4ea4:	c4 41 31 db cf       	vpand  %xmm15,%xmm9,%xmm9
    4ea9:	c4 c1 49 db f7       	vpand  %xmm15,%xmm6,%xmm6
    4eae:	c4 c1 49 67 f1       	vpackuswb %xmm9,%xmm6,%xmm6
    4eb3:	c5 c9 fc b4 24 c8 02 	vpaddb 0x2c8(%rsp),%xmm6,%xmm6
    4eba:	00 00 
    4ebc:	c5 59 60 ce          	vpunpcklbw %xmm6,%xmm4,%xmm9
    4ec0:	c5 d9 68 e6          	vpunpckhbw %xmm6,%xmm4,%xmm4
    4ec4:	c4 41 7a 7f 08       	vmovdqu %xmm9,(%r8)
    4ec9:	c4 c1 7a 7f 60 10    	vmovdqu %xmm4,0x10(%r8)
    4ecf:	c5 f9 6f a4 24 88 01 	vmovdqa 0x188(%rsp),%xmm4
    4ed6:	00 00 
    4ed8:	c5 d9 fd a4 24 48 02 	vpaddw 0x248(%rsp),%xmm4,%xmm4
    4edf:	00 00 
    4ee1:	c5 89 fd b4 24 e8 01 	vpaddw 0x1e8(%rsp),%xmm14,%xmm6
    4ee8:	00 00 
    4eea:	8b 9c 24 20 03 00 00 	mov    0x320(%rsp),%ebx
    4ef1:	c5 79 6f ac 24 48 01 	vmovdqa 0x148(%rsp),%xmm13
    4ef8:	00 00 
    4efa:	c4 c1 59 fd e3       	vpaddw %xmm11,%xmm4,%xmm4
    4eff:	c5 91 fd 84 24 08 02 	vpaddw 0x208(%rsp),%xmm13,%xmm0
    4f06:	00 00 
    4f08:	c4 c1 49 fd f0       	vpaddw %xmm8,%xmm6,%xmm6
    4f0d:	c5 d9 71 d4 02       	vpsrlw $0x2,%xmm4,%xmm4
    4f12:	c5 79 6f 9c 24 c8 01 	vmovdqa 0x1c8(%rsp),%xmm11
    4f19:	00 00 
    4f1b:	c5 21 fd 84 24 88 02 	vpaddw 0x288(%rsp),%xmm11,%xmm8
    4f22:	00 00 
    4f24:	c5 e9 fd d0          	vpaddw %xmm0,%xmm2,%xmm2
    4f28:	c5 c9 71 d6 02       	vpsrlw $0x2,%xmm6,%xmm6
    4f2d:	c5 99 fd 84 24 08 01 	vpaddw 0x108(%rsp),%xmm12,%xmm0
    4f34:	00 00 
    4f36:	c5 79 6f b4 24 a8 01 	vmovdqa 0x1a8(%rsp),%xmm14
    4f3d:	00 00 
    4f3f:	c5 89 fd ac 24 68 02 	vpaddw 0x268(%rsp),%xmm14,%xmm5
    4f46:	00 00 
    4f48:	c5 e9 71 d2 02       	vpsrlw $0x2,%xmm2,%xmm2
    4f4d:	c5 39 fd c0          	vpaddw %xmm0,%xmm8,%xmm8
    4f51:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    4f55:	ba aa ff ff ff       	mov    $0xffffffaa,%edx
    4f5a:	c4 c1 51 fd ea       	vpaddw %xmm10,%xmm5,%xmm5
    4f5f:	c4 c1 39 71 d0 02    	vpsrlw $0x2,%xmm8,%xmm8
    4f65:	c4 e2 79 79 c0       	vpbroadcastw %xmm0,%xmm0
    4f6a:	c5 79 6f 94 24 68 01 	vmovdqa 0x168(%rsp),%xmm10
    4f71:	00 00 
    4f73:	c5 29 fd 8c 24 28 02 	vpaddw 0x228(%rsp),%xmm10,%xmm9
    4f7a:	00 00 
    4f7c:	c5 d1 71 d5 02       	vpsrlw $0x2,%xmm5,%xmm5
    4f81:	c5 79 6e d2          	vmovd  %edx,%xmm10
    4f85:	ba 80 ff ff ff       	mov    $0xffffff80,%edx
    4f8a:	c4 42 79 79 d2       	vpbroadcastw %xmm10,%xmm10
    4f8f:	c5 b9 d5 c8          	vpmullw %xmm0,%xmm8,%xmm1
    4f93:	c5 31 fd cf          	vpaddw %xmm7,%xmm9,%xmm9
    4f97:	c4 c1 51 d5 fa       	vpmullw %xmm10,%xmm5,%xmm7
    4f9c:	c4 c1 31 71 d1 02    	vpsrlw $0x2,%xmm9,%xmm9
    4fa2:	c4 41 69 d5 d2       	vpmullw %xmm10,%xmm2,%xmm10
    4fa7:	c5 b1 d5 c0          	vpmullw %xmm0,%xmm9,%xmm0
    4fab:	c5 f1 fd cf          	vpaddw %xmm7,%xmm1,%xmm1
    4faf:	c5 c1 71 f4 03       	vpsllw $0x3,%xmm4,%xmm7
    4fb4:	c5 c1 f9 fc          	vpsubw %xmm4,%xmm7,%xmm7
    4fb8:	c5 c1 71 f7 04       	vpsllw $0x4,%xmm7,%xmm7
    4fbd:	c4 c1 79 fd c2       	vpaddw %xmm10,%xmm0,%xmm0
    4fc2:	c5 c1 fd fb          	vpaddw %xmm3,%xmm7,%xmm7
    4fc6:	c5 f1 fd cf          	vpaddw %xmm7,%xmm1,%xmm1
    4fca:	c5 c1 71 f6 03       	vpsllw $0x3,%xmm6,%xmm7
    4fcf:	c5 c1 f9 fe          	vpsubw %xmm6,%xmm7,%xmm7
    4fd3:	c5 f1 71 e1 08       	vpsraw $0x8,%xmm1,%xmm1
    4fd8:	c5 c1 71 f7 04       	vpsllw $0x4,%xmm7,%xmm7
    4fdd:	c4 c1 71 db cf       	vpand  %xmm15,%xmm1,%xmm1
    4fe2:	c5 c1 fd fb          	vpaddw %xmm3,%xmm7,%xmm7
    4fe6:	c5 f9 fd c7          	vpaddw %xmm7,%xmm0,%xmm0
    4fea:	c5 f9 6e fa          	vmovd  %edx,%xmm7
    4fee:	ba 9a ff ff ff       	mov    $0xffffff9a,%edx
    4ff3:	c5 f9 71 e0 08       	vpsraw $0x8,%xmm0,%xmm0
    4ff8:	c4 e2 79 78 ff       	vpbroadcastb %xmm7,%xmm7
    4ffd:	c4 c1 79 db c7       	vpand  %xmm15,%xmm0,%xmm0
    5002:	c5 f1 67 c8          	vpackuswb %xmm0,%xmm1,%xmm1
    5006:	c4 c1 79 71 f0 03    	vpsllw $0x3,%xmm8,%xmm0
    500c:	c4 c1 79 f9 c0       	vpsubw %xmm8,%xmm0,%xmm0
    5011:	c5 79 6e c2          	vmovd  %edx,%xmm8
    5015:	c5 f1 fc cf          	vpaddb %xmm7,%xmm1,%xmm1
    5019:	c4 42 79 79 c0       	vpbroadcastw %xmm8,%xmm8
    501e:	c5 f9 71 f0 04       	vpsllw $0x4,%xmm0,%xmm0
    5023:	c4 c1 51 d5 e8       	vpmullw %xmm8,%xmm5,%xmm5
    5028:	c4 c1 69 d5 d0       	vpmullw %xmm8,%xmm2,%xmm2
    502d:	c5 f9 fd c5          	vpaddw %xmm5,%xmm0,%xmm0
    5031:	c5 d1 71 f4 02       	vpsllw $0x2,%xmm4,%xmm5
    5036:	c5 d1 fd e4          	vpaddw %xmm4,%xmm5,%xmm4
    503a:	c5 d9 71 f4 01       	vpsllw $0x1,%xmm4,%xmm4
    503f:	c5 e1 f9 e4          	vpsubw %xmm4,%xmm3,%xmm4
    5043:	c5 f9 fd c4          	vpaddw %xmm4,%xmm0,%xmm0
    5047:	c4 c1 59 71 f1 03    	vpsllw $0x3,%xmm9,%xmm4
    504d:	c4 c1 59 f9 e1       	vpsubw %xmm9,%xmm4,%xmm4
    5052:	c5 f9 71 e0 08       	vpsraw $0x8,%xmm0,%xmm0
    5057:	c5 d9 71 f4 04       	vpsllw $0x4,%xmm4,%xmm4
    505c:	c4 c1 79 db c7       	vpand  %xmm15,%xmm0,%xmm0
    5061:	c5 d9 fd d2          	vpaddw %xmm2,%xmm4,%xmm2
    5065:	c5 d9 71 f6 02       	vpsllw $0x2,%xmm6,%xmm4
    506a:	c5 d9 fd e6          	vpaddw %xmm6,%xmm4,%xmm4
    506e:	c5 d9 71 f4 01       	vpsllw $0x1,%xmm4,%xmm4
    5073:	c5 e1 f9 dc          	vpsubw %xmm4,%xmm3,%xmm3
    5077:	c5 e9 fd d3          	vpaddw %xmm3,%xmm2,%xmm2
    507b:	c5 e9 71 e2 08       	vpsraw $0x8,%xmm2,%xmm2
    5080:	c4 c1 69 db d7       	vpand  %xmm15,%xmm2,%xmm2
    5085:	c5 f9 67 c2          	vpackuswb %xmm2,%xmm0,%xmm0
    5089:	c5 f9 fc c7          	vpaddb %xmm7,%xmm0,%xmm0
    508d:	c5 f1 60 d0          	vpunpcklbw %xmm0,%xmm1,%xmm2
    5091:	c5 f1 68 c8          	vpunpckhbw %xmm0,%xmm1,%xmm1
    5095:	c5 fa 7f 10          	vmovdqu %xmm2,(%rax)
    5099:	c5 fa 7f 48 10       	vmovdqu %xmm1,0x10(%rax)
    509e:	8b 84 24 a4 00 00 00 	mov    0xa4(%rsp),%eax
    50a5:	83 e0 f0             	and    $0xfffffff0,%eax
    50a8:	8d 04 43             	lea    (%rbx,%rax,2),%eax
    50ab:	89 84 24 20 03 00 00 	mov    %eax,0x320(%rsp)
    50b2:	4c 63 94 24 20 03 00 	movslq 0x320(%rsp),%r10
    50b9:	00 
    50ba:	48 8b 44 24 c8       	mov    -0x38(%rsp),%rax
    50bf:	48 8b 5c 24 d0       	mov    -0x30(%rsp),%rbx
    50c4:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
    50cb:	00 
    50cc:	4e 8d 1c 95 00 00 00 	lea    0x0(,%r10,4),%r11
    50d3:	00 
    50d4:	4c 01 d8             	add    %r11,%rax
    50d7:	4c 01 db             	add    %r11,%rbx
    50da:	49 89 c3             	mov    %rax,%r11
    50dd:	48 8b 84 24 18 03 00 	mov    0x318(%rsp),%rax
    50e4:	00 
    50e5:	4c 8d 04 08          	lea    (%rax,%rcx,1),%r8
    50e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    50f0:	0f b6 4b 01          	movzbl 0x1(%rbx),%ecx
    50f4:	44 0f b6 4b 02       	movzbl 0x2(%rbx),%r9d
    50f9:	0f b6 03             	movzbl (%rbx),%eax
    50fc:	44 69 e1 9d 00 00 00 	imul   $0x9d,%ecx,%r12d
    5103:	41 6b d1 2f          	imul   $0x2f,%r9d,%edx
    5107:	44 01 e2             	add    %r12d,%edx
    510a:	41 89 c4             	mov    %eax,%r12d
    510d:	41 c1 e4 04          	shl    $0x4,%r12d
    5111:	42 8d 94 22 80 00 00 	lea    0x80(%rdx,%r12,1),%edx
    5118:	00 
    5119:	c1 fa 08             	sar    $0x8,%edx
    511c:	83 c2 10             	add    $0x10,%edx
    511f:	42 88 14 16          	mov    %dl,(%rsi,%r10,1)
    5123:	44 0f b6 6b 05       	movzbl 0x5(%rbx),%r13d
    5128:	44 0f b6 63 06       	movzbl 0x6(%rbx),%r12d
    512d:	44 0f b6 73 04       	movzbl 0x4(%rbx),%r14d
    5132:	41 69 d5 9d 00 00 00 	imul   $0x9d,%r13d,%edx
    5139:	44 01 e9             	add    %r13d,%ecx
    513c:	45 6b fc 2f          	imul   $0x2f,%r12d,%r15d
    5140:	45 01 e1             	add    %r12d,%r9d
    5143:	44 01 f0             	add    %r14d,%eax
    5146:	44 01 fa             	add    %r15d,%edx
    5149:	45 89 f7             	mov    %r14d,%r15d
    514c:	41 c1 e7 04          	shl    $0x4,%r15d
    5150:	42 8d 94 3a 80 00 00 	lea    0x80(%rdx,%r15,1),%edx
    5157:	00 
    5158:	c1 fa 08             	sar    $0x8,%edx
    515b:	83 c2 10             	add    $0x10,%edx
    515e:	42 88 54 16 01       	mov    %dl,0x1(%rsi,%r10,1)
    5163:	45 0f b6 6b 01       	movzbl 0x1(%r11),%r13d
    5168:	41 0f b6 53 02       	movzbl 0x2(%r11),%edx
    516d:	45 0f b6 33          	movzbl (%r11),%r14d
    5171:	45 69 e5 9d 00 00 00 	imul   $0x9d,%r13d,%r12d
    5178:	44 01 e9             	add    %r13d,%ecx
    517b:	44 6b fa 2f          	imul   $0x2f,%edx,%r15d
    517f:	44 01 ca             	add    %r9d,%edx
    5182:	44 01 f0             	add    %r14d,%eax
    5185:	45 01 fc             	add    %r15d,%r12d
    5188:	45 89 f7             	mov    %r14d,%r15d
    518b:	41 c1 e7 04          	shl    $0x4,%r15d
    518f:	47 8d a4 3c 80 00 00 	lea    0x80(%r12,%r15,1),%r12d
    5196:	00 
    5197:	41 c1 fc 08          	sar    $0x8,%r12d
    519b:	41 83 c4 10          	add    $0x10,%r12d
    519f:	46 88 24 17          	mov    %r12b,(%rdi,%r10,1)
    51a3:	45 0f b6 63 06       	movzbl 0x6(%r11),%r12d
    51a8:	45 0f b6 6b 05       	movzbl 0x5(%r11),%r13d
    51ad:	45 0f b6 73 04       	movzbl 0x4(%r11),%r14d
    51b2:	45 6b fc 2f          	imul   $0x2f,%r12d,%r15d
    51b6:	45 69 cd 9d 00 00 00 	imul   $0x9d,%r13d,%r9d
    51bd:	44 01 f0             	add    %r14d,%eax
    51c0:	c1 f8 02             	sar    $0x2,%eax
    51c3:	45 01 f9             	add    %r15d,%r9d
    51c6:	45 89 f7             	mov    %r14d,%r15d
    51c9:	41 c1 e7 04          	shl    $0x4,%r15d
    51cd:	47 8d 8c 39 80 00 00 	lea    0x80(%r9,%r15,1),%r9d
    51d4:	00 
    51d5:	41 c1 f9 08          	sar    $0x8,%r9d
    51d9:	41 83 c1 10          	add    $0x10,%r9d
    51dd:	44 01 e9             	add    %r13d,%ecx
    51e0:	44 01 e2             	add    %r12d,%edx
    51e3:	48 83 c3 08          	add    $0x8,%rbx
    51e7:	c1 f9 02             	sar    $0x2,%ecx
    51ea:	c1 fa 02             	sar    $0x2,%edx
    51ed:	46 88 4c 17 01       	mov    %r9b,0x1(%rdi,%r10,1)
    51f2:	49 83 c3 08          	add    $0x8,%r11
    51f6:	44 6b e1 aa          	imul   $0xffffffaa,%ecx,%r12d
    51fa:	44 6b ca e6          	imul   $0xffffffe6,%edx,%r9d
    51fe:	6b c9 9a             	imul   $0xffffff9a,%ecx,%ecx
    5201:	6b d2 70             	imul   $0x70,%edx,%edx
    5204:	45 01 e1             	add    %r12d,%r9d
    5207:	44 6b e0 70          	imul   $0x70,%eax,%r12d
    520b:	6b c0 f6             	imul   $0xfffffff6,%eax,%eax
    520e:	01 ca                	add    %ecx,%edx
    5210:	47 8d 8c 21 80 00 00 	lea    0x80(%r9,%r12,1),%r9d
    5217:	00 
    5218:	8d 84 02 80 00 00 00 	lea    0x80(%rdx,%rax,1),%eax
    521f:	41 c1 f9 08          	sar    $0x8,%r9d
    5223:	c1 f8 08             	sar    $0x8,%eax
    5226:	41 83 e9 80          	sub    $0xffffff80,%r9d
    522a:	83 e8 80             	sub    $0xffffff80,%eax
    522d:	47 88 0c 10          	mov    %r9b,(%r8,%r10,1)
    5231:	43 88 44 10 01       	mov    %al,0x1(%r8,%r10,1)
    5236:	49 83 c2 02          	add    $0x2,%r10
    523a:	44 39 94 24 24 03 00 	cmp    %r10d,0x324(%rsp)
    5241:	00 
    5242:	0f 8f a8 fe ff ff    	jg     50f0 <convert_avx2_adaptive_job+0x1640>
    5248:	8b 84 24 a0 00 00 00 	mov    0xa0(%rsp),%eax
    524f:	8b 74 24 dc          	mov    -0x24(%rsp),%esi
    5253:	83 c0 01             	add    $0x1,%eax
    5256:	39 f0                	cmp    %esi,%eax
    5258:	7f 3e                	jg     5298 <convert_avx2_adaptive_job+0x17e8>
    525a:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
    5261:	00 
    5262:	c7 44 24 dc 01 00 00 	movl   $0x1,-0x24(%rsp)
    5269:	00 
    526a:	c7 84 24 a0 00 00 00 	movl   $0x1,0xa0(%rsp)
    5271:	01 00 00 00 
    5275:	48 63 50 24          	movslq 0x24(%rax),%rdx
    5279:	8b 44 24 d8          	mov    -0x28(%rsp),%eax
    527d:	89 84 24 24 03 00 00 	mov    %eax,0x324(%rsp)
    5284:	8b 44 24 ac          	mov    -0x54(%rsp),%eax
    5288:	89 84 24 20 03 00 00 	mov    %eax,0x320(%rsp)
    528f:	e9 73 e9 ff ff       	jmp    3c07 <convert_avx2_adaptive_job+0x157>
    5294:	0f 1f 40 00          	nopl   0x0(%rax)
    5298:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
    529f:	00 
    52a0:	44 8b 44 24 a8       	mov    -0x58(%rsp),%r8d
    52a5:	8b 4c 24 a4          	mov    -0x5c(%rsp),%ecx
    52a9:	8b 78 34             	mov    0x34(%rax),%edi
    52ac:	41 83 c0 01          	add    $0x1,%r8d
    52b0:	48 83 44 24 e0 01    	addq   $0x1,-0x20(%rsp)
    52b6:	83 c1 02             	add    $0x2,%ecx
    52b9:	41 39 f8             	cmp    %edi,%r8d
    52bc:	0f 8c 66 e8 ff ff    	jl     3b28 <convert_avx2_adaptive_job+0x78>
    52c2:	c5 f8 77             	vzeroupper
    52c5:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    52c9:	5b                   	pop    %rbx
    52ca:	41 5c                	pop    %r12
    52cc:	41 5d                	pop    %r13
    52ce:	41 5e                	pop    %r14
    52d0:	41 5f                	pop    %r15
    52d2:	5d                   	pop    %rbp
    52d3:	c3                   	ret
    52d4:	0f 1f 40 00          	nopl   0x0(%rax)
    52d8:	48 89 44 24 f8       	mov    %rax,-0x8(%rsp)
    52dd:	4c 8b 4c 24 f8       	mov    -0x8(%rsp),%r9
    52e2:	48 8b 44 24 c8       	mov    -0x38(%rsp),%rax
    52e7:	4c 8b 5c 24 d0       	mov    -0x30(%rsp),%r11
    52ec:	48 8b 9c 24 b8 00 00 	mov    0xb8(%rsp),%rbx
    52f3:	00 
    52f4:	4e 8d 14 8d 00 00 00 	lea    0x0(,%r9,4),%r10
    52fb:	00 
    52fc:	4c 01 d0             	add    %r10,%rax
    52ff:	4d 01 d3             	add    %r10,%r11
    5302:	49 89 c2             	mov    %rax,%r10
    5305:	48 8b 84 24 18 03 00 	mov    0x318(%rsp),%rax
    530c:	00 
    530d:	4c 8d 04 18          	lea    (%rax,%rbx,1),%r8
    5311:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5318:	41 0f b6 4b 01       	movzbl 0x1(%r11),%ecx
    531d:	41 0f b6 5b 02       	movzbl 0x2(%r11),%ebx
    5322:	41 0f b6 03          	movzbl (%r11),%eax
    5326:	44 69 e1 9d 00 00 00 	imul   $0x9d,%ecx,%r12d
    532d:	6b d3 2f             	imul   $0x2f,%ebx,%edx
    5330:	44 01 e2             	add    %r12d,%edx
    5333:	41 89 c4             	mov    %eax,%r12d
    5336:	41 c1 e4 04          	shl    $0x4,%r12d
    533a:	42 8d 94 22 80 00 00 	lea    0x80(%rdx,%r12,1),%edx
    5341:	00 
    5342:	c1 fa 08             	sar    $0x8,%edx
    5345:	83 c2 10             	add    $0x10,%edx
    5348:	42 88 14 0e          	mov    %dl,(%rsi,%r9,1)
    534c:	45 0f b6 6b 05       	movzbl 0x5(%r11),%r13d
    5351:	45 0f b6 63 06       	movzbl 0x6(%r11),%r12d
    5356:	45 0f b6 73 04       	movzbl 0x4(%r11),%r14d
    535b:	41 69 d5 9d 00 00 00 	imul   $0x9d,%r13d,%edx
    5362:	44 01 e9             	add    %r13d,%ecx
    5365:	45 6b fc 2f          	imul   $0x2f,%r12d,%r15d
    5369:	44 01 e3             	add    %r12d,%ebx
    536c:	44 01 f0             	add    %r14d,%eax
    536f:	44 01 fa             	add    %r15d,%edx
    5372:	45 89 f7             	mov    %r14d,%r15d
    5375:	41 c1 e7 04          	shl    $0x4,%r15d
    5379:	42 8d 94 3a 80 00 00 	lea    0x80(%rdx,%r15,1),%edx
    5380:	00 
    5381:	c1 fa 08             	sar    $0x8,%edx
    5384:	83 c2 10             	add    $0x10,%edx
    5387:	42 88 54 0e 01       	mov    %dl,0x1(%rsi,%r9,1)
    538c:	45 0f b6 6a 01       	movzbl 0x1(%r10),%r13d
    5391:	41 0f b6 52 02       	movzbl 0x2(%r10),%edx
    5396:	45 0f b6 32          	movzbl (%r10),%r14d
    539a:	45 69 e5 9d 00 00 00 	imul   $0x9d,%r13d,%r12d
    53a1:	44 01 e9             	add    %r13d,%ecx
    53a4:	44 6b fa 2f          	imul   $0x2f,%edx,%r15d
    53a8:	01 da                	add    %ebx,%edx
    53aa:	44 01 f0             	add    %r14d,%eax
    53ad:	45 01 fc             	add    %r15d,%r12d
    53b0:	45 89 f7             	mov    %r14d,%r15d
    53b3:	41 c1 e7 04          	shl    $0x4,%r15d
    53b7:	47 8d a4 3c 80 00 00 	lea    0x80(%r12,%r15,1),%r12d
    53be:	00 
    53bf:	41 c1 fc 08          	sar    $0x8,%r12d
    53c3:	41 83 c4 10          	add    $0x10,%r12d
    53c7:	46 88 24 0f          	mov    %r12b,(%rdi,%r9,1)
    53cb:	45 0f b6 62 06       	movzbl 0x6(%r10),%r12d
    53d0:	45 0f b6 6a 05       	movzbl 0x5(%r10),%r13d
    53d5:	45 0f b6 72 04       	movzbl 0x4(%r10),%r14d
    53da:	45 6b fc 2f          	imul   $0x2f,%r12d,%r15d
    53de:	41 69 dd 9d 00 00 00 	imul   $0x9d,%r13d,%ebx
    53e5:	44 01 f0             	add    %r14d,%eax
    53e8:	c1 f8 02             	sar    $0x2,%eax
    53eb:	44 01 fb             	add    %r15d,%ebx
    53ee:	45 89 f7             	mov    %r14d,%r15d
    53f1:	41 c1 e7 04          	shl    $0x4,%r15d
    53f5:	42 8d 9c 3b 80 00 00 	lea    0x80(%rbx,%r15,1),%ebx
    53fc:	00 
    53fd:	c1 fb 08             	sar    $0x8,%ebx
    5400:	83 c3 10             	add    $0x10,%ebx
    5403:	44 01 e9             	add    %r13d,%ecx
    5406:	44 01 e2             	add    %r12d,%edx
    5409:	49 83 c3 08          	add    $0x8,%r11
    540d:	c1 f9 02             	sar    $0x2,%ecx
    5410:	c1 fa 02             	sar    $0x2,%edx
    5413:	42 88 5c 0f 01       	mov    %bl,0x1(%rdi,%r9,1)
    5418:	49 83 c2 08          	add    $0x8,%r10
    541c:	44 6b e1 aa          	imul   $0xffffffaa,%ecx,%r12d
    5420:	6b da e6             	imul   $0xffffffe6,%edx,%ebx
    5423:	6b c9 9a             	imul   $0xffffff9a,%ecx,%ecx
    5426:	6b d2 70             	imul   $0x70,%edx,%edx
    5429:	44 01 e3             	add    %r12d,%ebx
    542c:	44 6b e0 70          	imul   $0x70,%eax,%r12d
    5430:	6b c0 f6             	imul   $0xfffffff6,%eax,%eax
    5433:	01 ca                	add    %ecx,%edx
    5435:	42 8d 9c 23 80 00 00 	lea    0x80(%rbx,%r12,1),%ebx
    543c:	00 
    543d:	8d 84 02 80 00 00 00 	lea    0x80(%rdx,%rax,1),%eax
    5444:	c1 fb 08             	sar    $0x8,%ebx
    5447:	c1 f8 08             	sar    $0x8,%eax
    544a:	83 eb 80             	sub    $0xffffff80,%ebx
    544d:	83 e8 80             	sub    $0xffffff80,%eax
    5450:	43 88 1c 08          	mov    %bl,(%r8,%r9,1)
    5454:	43 88 44 08 01       	mov    %al,0x1(%r8,%r9,1)
    5459:	49 83 c1 02          	add    $0x2,%r9
    545d:	44 39 8c 24 24 03 00 	cmp    %r9d,0x324(%rsp)
    5464:	00 
    5465:	0f 8f ad fe ff ff    	jg     5318 <convert_avx2_adaptive_job+0x1868>
    546b:	e9 d8 fd ff ff       	jmp    5248 <convert_avx2_adaptive_job+0x1798>
    5470:	c7 44 24 ac 00 00 00 	movl   $0x0,-0x54(%rsp)
    5477:	00 
    5478:	41 89 d7             	mov    %edx,%r15d
    547b:	45 31 f6             	xor    %r14d,%r14d
    547e:	48 63 c1             	movslq %ecx,%rax
    5481:	44 89 7c 24 d8       	mov    %r15d,-0x28(%rsp)
    5486:	48 89 44 24 b0       	mov    %rax,-0x50(%rsp)
    548b:	8d 41 01             	lea    0x1(%rcx),%eax
    548e:	48 98                	cltq
    5490:	c7 44 24 dc 00 00 00 	movl   $0x0,-0x24(%rsp)
    5497:	00 
    5498:	48 89 44 24 b8       	mov    %rax,-0x48(%rsp)
    549d:	e9 2a e7 ff ff       	jmp    3bcc <convert_avx2_adaptive_job+0x11c>
    54a2:	41 89 ff             	mov    %edi,%r15d
    54a5:	eb d7                	jmp    547e <convert_avx2_adaptive_job+0x19ce>
    54a7:	31 c0                	xor    %eax,%eax
    54a9:	e9 8d f3 ff ff       	jmp    483b <convert_avx2_adaptive_job+0xd8b>

Disassembly of section .fini:
