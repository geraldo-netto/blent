from pathlib import Path
import os
import sys
sys.path.insert(0,str(Path.cwd()/'scripts/benchmarks'))
import profile_process as owned
root=Path.cwd();base=Path('/tmp/blent-t1123-evidence');source=root/'host/src/capture/idle/tests.rs';original=source.read_bytes()
old=b'observe_native(Duration::from_secs(5), || original.is_complete()).await;'
new=b'''tokio::time::timeout(Duration::from_secs(5), async {
        while !original.is_complete() { tokio::time::sleep(Duration::from_millis(1)).await; }
    }).await.unwrap();'''
assert original.count(old)==1
(base/'correct-tests.rs').write_bytes(original)
try:
 source.write_bytes(original.replace(old,new))
 status=owned.logged(['cargo','test','--offline','--locked','-p','blent','--bin','blent','t1123'],dict(os.environ),base/'fault.log',root)
 assert status!=0,'T1123 media-clock fault escaped original native-fence regression'
 print('T1123 clock fault rejected',flush=True)
finally:
 source.write_bytes(original)
 assert source.read_bytes()==original
