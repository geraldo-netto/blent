from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET

base = Path('/tmp/blent-t1060-evidence')
out = Path('docs/reviews/artifacts/2026-10-18-t1060')
out.mkdir(exist_ok=True)
report = Path('android/app/build/reports/jacoco/profileCoverage/profileCoverage.xml')
summary = {name: 0 for name in ('tests', 'failures', 'errors', 'skipped')}
for path in Path('android/app/build/test-results/testDebugUnitTest').glob('TEST-*.xml'):
    suite = ET.parse(path).getroot()
    for key in summary:
        summary[key] += int(suite.get(key, 0))
assert summary['tests'] > 2100 and all(summary[key] == 0 for key in ('failures', 'errors', 'skipped'))
(base/'suite-summary.json').write_text(json.dumps(summary, indent=2)+'\n')
rows = json.loads((base/'per-function.json').read_text())
assert rows['passes'] and all(row['passes'] for row in rows['functions'])
expected = json.loads((base/'sources.json').read_text())
assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest for path, digest in expected.items())
scoped = {Path(path).name for path in json.loads((base/'kotlin-scope.json').read_text())}
classes = {}
for package in ET.parse(report).getroot().findall('package'):
    for owner in package.findall('class'):
        if owner.get('sourcefilename') not in scoped:
            continue
        path = Path('android/app/build/tmp/kotlin-classes/debug')/(owner.attrib['name']+'.class')
        assert path.exists(), path
        classes[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
inputs = {}
for path in [Path('android/app/src/main/AndroidManifest.xml'), Path('android/build.gradle.kts'),
             Path('scripts/coverage/android.init.gradle'), Path('scripts/coverage/kotlin_report.py')]:
    inputs[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
for version in ['8.1.0-robolectric-4611349-i7', '14-robolectric-10818077-i7']:
    path = Path.home()/'.m2/repository/org/robolectric/android-all-instrumented'/version/f'android-all-instrumented-{version}.jar'
    with path.open('rb') as source:
        inputs[str(path)] = hashlib.file_digest(source, 'sha256').hexdigest()
manifest = Path('android/app/build/intermediates/merged_manifests/debug/AndroidManifest.xml')
application = ET.parse(manifest).getroot().find('application')
assert application.get('{http://schemas.android.com/apk/res/android}name') == 'com.blent.BlentApplication'
attestation = dict(sources=expected, classes=classes, inputs=inputs,
                   gradle='8.5', kotlin='1.9.20', jacoco='0.8.15', robolectric='4.17', sdks=[27,34],
                   java=subprocess.run(['java','-version'], capture_output=True, text=True, check=True).stderr)
(base/'android-attestation.json').write_text(json.dumps(attestation, indent=2)+'\n')
for name in ['check_kotlin.py','archive.py','sources.json','changed-lines.json','kotlin-scope.json','inventory.json',
             'per-function.json','suite-summary.json','android-attestation.json','root-complexity.json',
             'paused-native-red.log','native-ownership-red.log','promotion-stale-red.log',
             'weak-root-control.kt','app-owner-red2.log','app-owner-green.log','app-owner-green2.log',
             'invalid-callback-clock-control.kt','unguarded-foreground-control.kt',
             'expanded-final.log','gap-check.log','final-owned-coverage.log','final-function-coverage.log',
             'architecture.log','sdk27-WakeLock.javap','sdk27-WifiLock.javap','sdk34-WakeLock.javap','sdk34-WifiLock.javap']:
    (out/(name+'.gz')).write_bytes(gzip.compress((base/name).read_bytes(), mtime=0))
for name in ['red.log','green.log']:
    (out/('timer-'+name+'.gz')).write_bytes(gzip.compress((Path('/tmp/blent-t1066-evidence')/name).read_bytes(), mtime=0))
for path in [report, Path('android/app/build/jacoco/testDebugUnitTest.exec')]:
    (out/(path.name+'.gz')).write_bytes(gzip.compress(path.read_bytes(), mtime=0))
for directory in ['preliminary','before-app-owner']:
    archive = out/directory
    archive.mkdir(exist_ok=True)
    for path in (base/directory).iterdir():
        (archive/(path.name+'.gz')).write_bytes(gzip.compress(path.read_bytes(), mtime=0))
print(summary)
print(len(rows['functions']), 'maintained methods; minimum', min(row['percent'] for row in rows['functions']))
print(len(classes), 'native compiled class hashes')
