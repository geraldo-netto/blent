package com.blent

import android.util.Log
import com.blent.activity.DisplayActivityInbox
import com.blent.activity.DisplayActivityUpdate
import android.os.SystemClock
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import okhttp3.*
import okio.utf8Size
import org.json.JSONObject
import java.util.concurrent.TimeUnit

internal fun defaultControlClient(): OkHttpClient = OkHttpClient.Builder()
    .readTimeout(0, TimeUnit.SECONDS)
    .connectTimeout(5, TimeUnit.SECONDS)
    .pingInterval(5, TimeUnit.SECONDS)
    .build()

/** Motion state changed by a connection reset or host greeting, under the shared input lock. */
internal interface ControlInputState {
    fun reset()
    fun forgetTouches()
    fun setTouchEnabled(enabled: Boolean)
    fun setPenEnabled(enabled: Boolean)
    fun setDirectInput(status: JSONObject?) {}
}

internal data class RejectedStreamSettings(val reason: String, val bitrate: Int, val fps: Int, val requestGeneration: Long)

/** Owns authentication, host metadata and socket lifetime; never interprets MotionEvents. */
internal class ControlSession(
    private val lock: Any,
    private val input: ControlInputState,
    private val client: WebSocket.Factory,
    private val decoderCapabilities: suspend (Int, Int, Int) -> JSONObject = DecoderCapabilities::report,
) {
    private companion object {
        const val TAG = TouchCapture.TAG
        const val RECONNECT_DELAY_MS = TouchCapture.RECONNECT_DELAY_MS
    }

    @Volatile private var activityInbox = DisplayActivityInbox()
    val displayActivityUpdate get() = activityInbox.update
    var onDisplayActivityKnown: ((DisplayActivityUpdate) -> Unit)? = null

    @Volatile private var webSocket: WebSocket? = null
    @Volatile var connectionGeneration = 0L
        private set
    private var connectionWanted = false
    private val statistics = ControlStatistics()
    private var queueBudget = ControlCapacity.DEFAULT

    fun setQueueBudget(bytes: Int): Unit = synchronized(lock) {
        require(bytes in ControlCapacity.MIN..ControlCapacity.MAX)
        queueBudget = bytes
    }
    @Volatile private var isConnected = false
    private val calibration = MutableStateFlow(false)
    val calibrating = calibration.asStateFlow()
    private val authenticatedControl = MutableStateFlow(false)
    val controlConnected = authenticatedControl.asStateFlow()
    private val connection = MutableStateFlow(ControlConnection())
    val connectionState = connection.asStateFlow()
    private var reconnectJob: Job? = null
    private var capabilityJob: Job? = null
    private data class CapabilityRequest(val format: Triple<Int, Int, Int>, val scope: String?)
    private var capabilityRequest: CapabilityRequest? = null
    private var capabilityScope: String? = null
    private var streamFormat: DecoderFormat? = null
    private var formatReceived = false
    private var encodedDimensionsKnown = false

    /** Set from the host's greeting: it is using us as a graphics tablet for
     *  its own screen, so no video will arrive and none should be waited for. */
    @Volatile var isPenOnly = false
        private set
    var onVideoLivenessKnown: ((Boolean) -> Unit)? = null
    var onModeKnown: ((penOnly: Boolean) -> Unit)? = null
    var onCodecKnown: ((codec: String) -> Unit)? = null
    var onFpsKnown: ((fps: Int) -> Unit)? = null
    var onStreamFormat: ((DecoderFormat?) -> Unit)? = null
    var onSettingsRejected: ((RejectedStreamSettings) -> Unit)? = null
    @Volatile var settingsGeneration = 0L
        private set

    /// Attachment token from the host, delivered through the protected ADB
    /// receiver or initial token Activity. The token store updates a running
    /// session without requiring another Activity launch. It must be the first
    /// socket message; otherwise the host closes the connection unanswered.
    @Volatile private var configuredRoutes: DisplayRoutes? = AdbDisplayRoutes.create()
    private var routeRevision = 1L
    var routes: DisplayRoutes?
        get() = configuredRoutes
        set(value) = synchronized(lock) {
            if (configuredRoutes == value) return@synchronized
            require(value == null || value.revision > routeRevision)
            val restart = connectionWanted
            disconnect()
            configuredRoutes = value
            if (value != null) routeRevision = value.revision
            if (restart && value != null) connect()
        }
    var token: String?
        get() = configuredRoutes?.token
        set(value) = synchronized(lock) { configuredRoutes = configuredRoutes?.copy(token = value) }
    // Protected by lock: bind authentication to this socket attempt, including
    // tokenless startup. Publishing replacement credentials cannot retarget it.
    private var connectionRoutes: DisplayRoutes? = null

    /** Settings to (re)send to the host whenever the control channel connects */
    @Volatile private var pendingConfig: JSONObject? = null
    @Volatile private var pendingMode: JSONObject? = null

    /** Tablet's native landscape resolution, reported to the host on connect
     *  so the virtual display can match it automatically. */
    @Volatile private var nativeWidth = 0
    @Volatile private var nativeHeight = 0

    /** Physical panel size in millimetres, so the host can build an EDID that
     *  reports the true DPI and the desktop comes up at a sane scale. */
    @Volatile private var nativeWidthMm = 0
    @Volatile private var nativeHeightMm = 0

    fun setNativeResolution(width: Int, height: Int, widthMm: Int = 0, heightMm: Int = 0) {
        nativeWidth = width
        nativeHeight = height
        nativeWidthMm = widthMm
        nativeHeightMm = heightMm
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val wsListener = object : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            synchronized(lock) {
                if (isStale(webSocket)) return
                isConnected = true
                Log.i(TAG, "Connected")
                if (!sendAuthentication()) return
                if (!sendResolution()) return
                pendingConfig?.let { if (!enqueue(it)) return }
                flushPendingMode()
            }
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            synchronized(lock) {
                if (isStale(webSocket)) return
                // The host reports live stream/input metadata, requests decoder
                // capabilities and can reject unsupported settings changes.
                try {
                    val o = JSONObject(text)
                    receiveControl(webSocket, o)
                } catch (_: Exception) {}
            }
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            synchronized(lock) {
                if (isStale(webSocket)) return
                resetGreeting()
                webSocket.close(1000, null)
            }
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            synchronized(lock) {
                if (isStale(webSocket)) return
                this@ControlSession.webSocket = null
                connectionGeneration++
                isConnected = false
                resetGreeting()
                scheduleReconnect()
            }
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            synchronized(lock) {
                if (isStale(webSocket)) return
                this@ControlSession.webSocket = null
                connectionGeneration++
                isConnected = false
                resetGreeting()
                Log.w(TAG, "Connection failed: ${t.message}")
                scheduleReconnect()
            }
        }

        /**
         * A socket we already replaced or closed on purpose. Its closing
         * callbacks still arrive, and acting on them would undo what we just
         * did: after disconnect() they would schedule a reconnect in the
         * background, and during a token change they would flip isConnected
         * off and cancel the socket that replaced them.
         */
        private fun isStale(ws: WebSocket) = ws !== this@ControlSession.webSocket
    }

    // Process one original control message; hints do not grant authentication.
    private fun receiveControl(source: WebSocket, message: JSONObject) {
        if (message.optString("status") == "settings_rejected") { applySettingsRejection(message); return }
        applyInputGreeting(message)
        if (source !== webSocket) return
        val activityChanged = receiveDisplayActivity(message) ?: return
        // Retire on a valid stop even if later unrelated metadata is malformed.
        if (activityChanged) notifyDisplayActivity()
        if (message.has("calibrating")) calibration.value = message.opt("calibrating") == true
        applyVideoGreeting(message)
        applyCapabilityGreeting(message)
        applyDecoderGreeting(message)
        requestDecoderCapabilities(source, streamFormat.takeIf { encodedDimensionsKnown })
        applyModeGreeting(message)
        acceptGreeting(message)
        // Fresh authentication can now admit otherwise eligible retained intent.
        if (activityChanged) notifyDisplayActivity()
    }
    private fun receiveDisplayActivity(message: JSONObject): Boolean? = try {
        activityInbox.receive(message)
    } catch (failure: Exception) {
        Log.w(TAG, "Invalid original display activity; retiring control", failure)
        disconnect()
        null
    }
    private fun notifyDisplayActivity() {
        try { onDisplayActivityKnown?.invoke(activityInbox.update) }
        catch (_: Exception) { Log.w(TAG, "Display activity observer failed") }
    }

    private fun sendAuthentication(): Boolean {
        val currentToken = connectionRoutes?.token
        if (currentToken == null) {
            Log.w(TAG, "No session token yet — the host will send one")
            return true
        }
        return enqueue(JSONObject().apply {
            put("type", "auth")
            put("token", currentToken)
        })
    }

    private fun sendResolution(): Boolean {
        if (nativeWidth <= 0 || nativeHeight <= 0) return true
        return enqueue(JSONObject().apply {
            put("type", "resolution")
            put("width", nativeWidth)
            put("height", nativeHeight)
            if (nativeWidthMm > 0 && nativeHeightMm > 0) {
                put("width_mm", nativeWidthMm)
                put("height_mm", nativeHeightMm)
            }
        })
    }

    private fun flushPendingMode() {
        val message = pendingMode ?: return
        // Acceptance means queued, not a host acknowledgement. Preserve the
        // existing one-shot policy once accepted; rejected choices remain pending.
        if (enqueue(message)) pendingMode = null
    }

    private fun resetGreeting() {
        activityInbox.close()
        notifyDisplayActivity()
        notifyVideoLiveness(false)
        calibration.value = false
        input.setDirectInput(null)
        capabilityJob?.cancel()
        capabilityJob = null
        capabilityRequest = null
        capabilityScope = null
        streamFormat = null
        formatReceived = false
        encodedDimensionsKnown = false
        connection.value = ControlConnection()
        authenticatedControl.value = false
    }

    private fun acceptGreeting(message: JSONObject) {
        if (message.optString("status") != "connected") return
        connection.value = ControlConnection(true, StreamTransport.from(message.optString("transport")))
        authenticatedControl.value = true
    }

    // Optional presentation observers cannot interrupt original control revocation.
    private fun notifyVideoLiveness(enabled: Boolean) {
        try { onVideoLivenessKnown?.invoke(enabled) }
        catch (_: Exception) { Log.w(TAG, "Video liveness observer failed") }
    }

    private fun applyVideoGreeting(message: JSONObject) {
        if (message.optString("status") != "connected") return
        notifyVideoLiveness(VideoNegotiation.offered(message))
    }

    private fun applyInputGreeting(o: JSONObject) {
        if (o.has("direct_input")) {
            applyDirectGreeting(o)
            return
        }
        if (o.has("touch")) {
            input.setTouchEnabled(o.getBoolean("touch"))
        }
        if (o.has("pen")) input.setPenEnabled(o.getBoolean("pen"))
    }

    private fun applyDirectGreeting(o: JSONObject) {
        val direct = o.optJSONObject("direct_input")
        input.setDirectInput(direct)
        if (o.optString("status") == "connected" && direct?.optInt("protocol") == 1) {
            enqueue(JSONObject().put("type", "direct_input").put("command", JSONObject().put("type", "negotiate").put("version", 1)))
        }
    }

    private fun requestDecoderCapabilities(source: WebSocket, format: DecoderFormat?) {
        if (format == null) {
            capabilityJob?.cancel()
            capabilityRequest = null
            return
        }
        val width = format.width
        val height = format.height
        val fps = format.fps
        val request = CapabilityRequest(Triple(width, height, fps), capabilityScope)
        if (capabilityRequest == request) return
        capabilityRequest = request
        capabilityJob?.cancel()
        capabilityJob = scope.launch {
            val report = scopedCapabilities(decoderCapabilities(width, height, fps), request.scope)
            synchronized(lock) {
                if (isActive && webSocket === source && isConnected && capabilityRequest == request) {
                    enqueue(JSONObject().put("type", "decoders").put("capabilities", report))
                }
            }
        }
    }

    private fun applyCapabilityGreeting(message: JSONObject) {
        if (!message.has("decoder_protocol")) return
        capabilityScope = message.optString("decoder_scope").takeIf {
            message.optInt("decoder_protocol") == 2 && it.length in 1..96 && it.all { char -> char.code in 33..126 }
        }
    }

    private fun scopedCapabilities(report: JSONObject, scope: String?): JSONObject {
        if (scope == null) {
            report.put("protocol", 1)
            report.remove("scope"); report.remove("details"); report.remove("software")
        } else {
            report.put("protocol", 2).put("scope", scope)
                .put("software", ProfileSoftware.fingerprint(android.os.Build.FINGERPRINT, ProfileBuild.SOURCE_ID))
        }
        return report
    }

    private fun matchesPendingConfig(requested: JSONObject): Boolean {
        val pending = pendingConfig ?: return false
        return listOf("fps", "bitrate").all { field ->
            requested.isNull(field) || requested.optInt(field) == pending.optInt(field)
        }
    }

    private fun applySettingsRejection(message: JSONObject) {
        val requested = message.optJSONObject("requested")
        if (requested != null && !matchesPendingConfig(requested)) return
        val fps = message.optInt("fps")
        val bitrate = message.optInt("bitrate")
        if (fps !in 10..90 || bitrate !in 1000..60000) return
        // Reconnect must resend confirmed settings rather than the rejected request.
        pendingConfig?.put("fps", fps)?.put("bitrate", bitrate)
        onSettingsRejected?.invoke(RejectedStreamSettings(
            message.optString("error", "Unsupported stream settings"), bitrate, fps, settingsGeneration))
    }

    private fun applyDecoderGreeting(o: JSONObject) {
        if (formatReceived && listOf("codec", "fps", "video_width", "video_height").none(o::has)) return
        if (o.has("video_width") || o.has("video_height")) encodedDimensionsKnown = true
        streamFormat = StreamFormat.read(o, streamFormat, nativeWidth, nativeHeight,
            pendingConfig?.optInt("fps") ?: Prefs.DEFAULT_FPS)
        formatReceived = true
        onStreamFormat?.invoke(streamFormat)
        // Retain the public per-field notifications for independent observers.
        if (streamFormat == null) return
        if (o.has("fps")) onFpsKnown?.invoke(streamFormat!!.fps)
        if (o.has("codec")) onCodecKnown?.invoke(o.getString("codec"))
    }

    private fun applyModeGreeting(o: JSONObject) {
        if (o.has("pen_only")) {
            val pen = o.getBoolean("pen_only")
            if (pen != isPenOnly) {
                isPenOnly = pen
                Log.i(TAG, "Host mode: ${if (pen) "pen-only" else "display"}")
            }
            onModeKnown?.invoke(pen)
        }
    }

    fun connect(): Unit = synchronized(lock) {
        connectionWanted = true
        // Idempotent: a second connect() must not leave the first socket
        // alive with its listener still flipping isConnected. onStart and a
        // token delivered through onNewIntent can both call this.
        if (isConnected) return@synchronized
        // A reconnect already scheduled by onClosed would open a second
        // socket next to this one; this call supersedes it.
        reconnectJob?.cancel()
        webSocket?.cancel()
        webSocket = null
        connectWebSocket()
    }

    private fun connectWebSocket(): Unit = synchronized(lock) {
        val selected = configuredRoutes ?: return@synchronized
        connectionGeneration++
        resetGreeting()
        activityInbox = DisplayActivityInbox()
        input.reset()
        val previous = webSocket
        webSocket = null
        previous?.cancel()
        val request = Request.Builder()
            .url("ws://127.0.0.1:${selected.controlPort}")
            .build()
        connectionRoutes = selected
        webSocket = client.newWebSocket(request, wsListener)
    }

    private fun scheduleReconnect(): Unit = synchronized(lock) {
        reconnectJob?.cancel()
        val generation = connectionGeneration
        reconnectJob = scope.launch {
            delay(RECONNECT_DELAY_MS)
            synchronized(lock) {
                if (connectionWanted && generation == connectionGeneration && !isConnected) {
                    connectWebSocket()
                }
            }
        }
    }

    /**
     * Push encoder settings to the host. The host live-restarts ffmpeg with
     * the new parameters and persists them in its config file. Settings are
     * also remembered here and re-sent on every reconnect.
     */
    fun sendConfig(bitrateKbps: Int, fps: Int): Unit = synchronized(lock) {
        settingsGeneration++
        val msg = JSONObject().apply {
            put("type", "config")
            put("bitrate", bitrateKbps)
            put("fps", fps)
        }
        pendingConfig = msg
        if (enqueue(msg)) Log.i(TAG, "Queued config: $msg")
    }

    /**
     * Acknowledge the render callback for frame [seq]. The host starts timing
     * when the encoded packet is ready. Its interval includes host queueing,
     * delivery, callback scheduling and the return path, excluding capture and encoding, without
     * either side needing a shared time base.
     */
    fun sendRendered(seq: Int, decodeUs: Int, decoder: String? = null) =
        sendRendered(RenderAcknowledgement(seq, decodeUs, decoder))

    fun sendRendered(receipt: RenderAcknowledgement) {
        val generation = connectionGeneration
        if (!isConnected) return
        val msg = JSONObject().apply {
            put("type", "rendered")
            receipt.decoder?.let { put("decoder", it) }
            put("seq", receipt.sequence.toLong() and 0xFFFFFFFFL)
            if (receipt.decodeMicros >= 0) put("decode_us", receipt.decodeMicros)
        }
        synchronized(lock) {
            if (connectionGeneration == generation && receipt.current()) enqueue(msg)
        }
    }

    /**
     * Ask the host to switch between being a second screen and being a
     * graphics tablet. The host applies it and answers with its new mode, so
     * the UI follows [onModeKnown] rather than assuming this succeeded.
     */
    fun sendMode(penOnly: Boolean): Unit = synchronized(lock) {
        val msg = JSONObject().apply {
            put("type", "mode")
            put("pen_only", penOnly)
        }
        // Keep the latest choice until the transport accepts it. The host
        // remains authoritative after acceptance, so don't replay it forever.
        pendingMode = msg
        if (isConnected) flushPendingMode()
    }

    fun isControlConnected(): Boolean = isConnected

    // onOpen holds this monitor until auth and initial metadata are queued.
    // UI input and decoder acknowledgements must not overtake that handshake.
    fun sendWhenConnected(message: JSONObject, sampleTimeMs: Long? = null): Unit = synchronized(lock) {
        enqueue(message, sampleTimeMs)
    }

    // Caller holds the same lock as handshake, input translation and settings.
    private fun enqueue(message: JSONObject, sampleTimeMs: Long? = null): Boolean {
        if (!isConnected) return false
        val socket = webSocket ?: return false
        val text = message.toString()
        val age = sampleTimeMs?.let { SystemClock.uptimeMillis() - it }
        val before = socket.queueSize()
        val accepted = ControlCapacity.allows(before, text.utf8Size(), queueBudget) && socket.send(text)
        statistics.record(accepted, before, socket.queueSize(), age)
        if (accepted) return true
        // A refused ordered event makes the whole gesture uncertain. Stop using
        // this socket, causing the host to release its controller's devices.
        // Never buffer/replay a partial stroke on a replacement connection.
        Log.w(TAG, "Control send rejected; reconnecting (queued_bytes=${socket.queueSize()})")
        webSocket = null
        connectionGeneration++
        isConnected = false
        resetGreeting()
        input.forgetTouches()
        socket.cancel()
        scheduleReconnect()
        return false
    }

    fun statistics(): ControlStatisticsSnapshot = synchronized(lock) {
        statistics.snapshot(webSocket?.queueSize() ?: 0)
    }

    fun disconnect(): Unit = synchronized(lock) {
        if (webSocket != null) Log.i(TAG, "Control statistics: ${statistics()}")
        connectionWanted = false
        input.forgetTouches()
        connectionGeneration++
        reconnectJob?.cancel()
        val previous = webSocket
        webSocket = null
        isConnected = false
        resetGreeting()
        previous?.close(1000, "Client closing")
    }
}
