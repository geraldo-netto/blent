"""T1096 bounded scheduler cutoff fault; original helper restored after join."""
from pathlib import Path
import os,sys
sys.path.insert(0,'scripts/tests')
import test_secure_connection_interop as interop
base=Path('/tmp/blent-t1096-evidence')
source=Path('android/app/src/test/java/com/blent/connection/ConnectionActorScheduler.kt')
original=source.read_text()
(base/'scheduler-before-fault.kt').write_text(original)
assert original.count('fun cancel() { pending.set(false) }')==1
try:
    source.write_text(original.replace('fun cancel() { pending.set(false) }','fun cancel() {}'))
    try:
        interop.SecureConnectionInteropTest().command([
            str(Path('android/gradlew').resolve()),'-p',str(Path('android').resolve()),
            '--offline','--no-daemon','--max-workers=2','-I',str(Path('scripts/coverage/android.init.gradle').resolve()),
            ':app:testDebugUnitTest','--tests','com.blent.connection.ConnectionActorSchedulerTest',
        ],dict(os.environ),base/'scheduler-cutoff-fault-red.log')
    except AssertionError:
        log=(base/'scheduler-cutoff-fault-red.log').read_text()
        assert '4 tests completed, 2 failed' in log,log[-3000:]
        assert 't1096DisposedQueuedCallbackCannotReachRetiredViewOrReplacement FAILED' in log
        assert 't1096All64CancellationHistoriesKeepThreeOriginalTimersIndependent FAILED' in log
        print('Expected missing-cutoff control rejected by exact identity case and bounded 64-history model')
    else:
        raise AssertionError('T1096 tests accepted missing queued callback cutoff')
finally:
    source.write_text(original)
assert source.read_text()==original
print('Original helper restored with fresh mtime; no faulty code remains')
