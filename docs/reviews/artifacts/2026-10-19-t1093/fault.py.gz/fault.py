"""One bounded metadata fault; original source restored after owned child settles."""
from pathlib import Path
import os
import sys
sys.path.insert(0, 'scripts/tests')
import test_secure_connection_interop as interop

base=Path('/tmp/blent-t1093-evidence')
source=Path('android/app/src/main/java/com/blent/connection/ConnectionDeadline.kt')
original=source.read_text()
(base/'deadline-before-fault.kt').write_text(original)
assert original.count('known && other.known')==1
try:
    source.write_text(original.replace('known && other.known', 'known'))
    try:
        interop.SecureConnectionInteropTest().command([
            str(Path('android/gradlew').resolve()), '-p', str(Path('android').resolve()),
            '--offline','--no-daemon','--max-workers=2','-I',str(Path('scripts/coverage/android.init.gradle').resolve()),
            ':app:testDebugUnitTest','--tests','com.blent.connection.ConnectionDeadlineTest',
            '--tests','com.blent.connection.ConnectionTransportDeadlineTest',
        ],dict(os.environ),base/'unknown-fault-red.log')
    except AssertionError:
        log=(base/'unknown-fault-red.log').read_text()
        assert '10 tests completed, 3 failed' in log,log[-3000:]
        assert 't1093UnknownProviderPreservesOtherKnownAbsoluteBudgets FAILED' in log
        assert 't1093BoundedCompositionMatchesIndependentSortedBudgetOracle FAILED' in log
        assert 't1093RunnerPreservesKnownBudgetsAlongsideUnknownProviders FAILED' in log
        print('Expected faulty control rejected: three permanent metadata contract tests')
    else:
        raise AssertionError('T1093 tests accepted hidden unknown provider')
finally:
    source.write_text(original)
assert source.read_text()==original
print('Original source restored with fresh mtime; no fault remains')
