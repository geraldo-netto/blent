"""Offline normal-suite native collection; repository counters/assignment unchanged."""
exec(open('/tmp/blent-t1021-evidence/c_setup.py').read())
import os
import subprocess
from compiler import export_reports
from capture_check import environment
from readers import gcov_json

BASE = Path('/tmp/blent-t1025-evidence')
files = sorted(path for path in source_files(ROOT) if path.as_posix().startswith('host/evdi/') and path.suffix in {'.c', '.h'})
functions = [function for path in files for function in syntax_functions(path, path.read_text(), 'c')]
sources = {str(path): fingerprint(path) for path in files}
sources.update({str(path): fingerprint(path) for path in Path('host/tests').glob('*') if path.suffix in {'.c', '.rs'}})
output = BASE / sys.argv[1]
output.mkdir()
manifest = dict(sources=sources, functions=[asdict(function) for function in functions])
(output / 'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
command = ['cargo', 'test', '--offline', '--locked', '-p', 'blent']
focused = len(sys.argv) > 2 and sys.argv[2] == 'focused'
for target in (['evdi_helper'] if focused else ['evdi_helper', 'conversion', 'evdi_modules', 'frame_retirement', 'capture_activity']):
    command.extend(['--test', target])
if focused:
    command.extend(['--', 't1021'])
with (output / 'tests.log').open('w') as log:
    subprocess.run(command, env=environment(output), stdout=log, stderr=subprocess.STDOUT, check=True)
verify_sources(ROOT, sources)
data = {}
for path in export_reports(output / 'native'):
    gcov_json(path, ROOT, data)
rows = [result(function, data) for function in functions]
(output / 'report.json').write_text(json.dumps(dict(passes=all(row['passes'] for row in rows), functions=rows), indent=2)+'\n')
print('functions', len(rows), 'pass', sum(row['passes'] for row in rows))
for row in rows:
    if not row['passes']:
        print(row)
if not focused:
    assert all(row['passes'] for row in rows)
