import java.lang.instrument.Instrumentation;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
public final class DispatcherProbe {
    public static void agentmain(String output, Instrumentation instrumentation) throws Exception {
        try (PrintWriter log = new PrintWriter(output)) {
            for (Class<?> type : instrumentation.getAllLoadedClasses()) {
                if (type.getName().equals("androidx.compose.ui.platform.AndroidUiDispatcher")) inspect(type, log);
            }
        }
    }
    private static Object field(Class<?> type, Object owner, String name) throws Exception {
        Field value = type.getDeclaredField(name);
        value.setAccessible(true);
        return value.get(owner);
    }
    private static Object call(Object owner, String name) throws Exception {
        Method method = owner.getClass().getMethod(name);
        method.setAccessible(true);
        return method.invoke(owner);
    }
    private static void inspect(Class<?> type, PrintWriter log) throws Exception {
        log.println("dispatcher loader=" + type.getClassLoader());
        Object lazy = field(type, null, "Main$delegate");
        log.println("main initialized=" + call(lazy, "isInitialized"));
        if (!Boolean.TRUE.equals(call(lazy, "isInitialized"))) return;
        Object context = call(lazy, "getValue");
        Object dispatcher = interceptor(type.getClassLoader(), context);
        log.println("main interceptor=" + dispatcher);
        if (!type.isInstance(dispatcher)) return;
        inspectHandler(type, dispatcher, log);
    }
    private static Object interceptor(ClassLoader loader, Object context) throws Exception {
        Class<?> parent = loader.loadClass("kotlin.coroutines.CoroutineContext");
        Class<?> keyType = loader.loadClass("kotlin.coroutines.CoroutineContext$Key");
        Object key = loader.loadClass("kotlin.coroutines.ContinuationInterceptor").getField("Key").get(null);
        return parent.getMethod("get", keyType).invoke(context, key);
    }
    private static void inspectHandler(Class<?> type, Object dispatcher, PrintWriter log) throws Exception {
        Object handler = field(type, dispatcher, "handler");
        Object original = call(handler, "getLooper");
        Object current = original.getClass().getMethod("getMainLooper").invoke(null);
        log.println("original handler looper=" + original + " current main=" + current + " same=" + (original == current));
        log.println("scheduled trampoline=" + field(type, dispatcher, "scheduledTrampolineDispatch"));
        log.println("scheduled frame=" + field(type, dispatcher, "scheduledFrameDispatch"));
    }
}
