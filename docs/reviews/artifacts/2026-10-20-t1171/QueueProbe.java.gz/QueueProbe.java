import java.lang.instrument.Instrumentation;
import java.io.PrintWriter;
import java.lang.reflect.Field;
public final class QueueProbe {
    public static void agentmain(String output, Instrumentation instrumentation) throws Exception {
        try (PrintWriter log = new PrintWriter(output)) {
            for (Class<?> type : instrumentation.getAllLoadedClasses()) {
                if (type.getName().equals("android.os.Looper")) inspect(type, log);
            }
        }
    }
    private static Object field(Object owner, String name) throws Exception {
        Field value = owner.getClass().getDeclaredField(name);
        value.setAccessible(true);
        return value.get(owner);
    }
    private static void inspect(Class<?> type, PrintWriter log) throws Exception {
        Object looper = type.getMethod("getMainLooper").invoke(null);
        log.println("loader="+type.getClassLoader()+" looper="+looper);
        if (looper == null) return;
        Object message = field(field(looper, "mQueue"), "mMessages");
        for (int count = 0; message != null && count < 16; count++) {
            log.println("message="+System.identityHashCode(message)+" when="+field(message,"when")+" target="+field(message,"target")+" callback="+field(message,"callback"));
            message = field(message, "next");
        }
    }
}
