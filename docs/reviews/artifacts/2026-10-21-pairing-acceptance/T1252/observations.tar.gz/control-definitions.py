"""Local bounded production IPC diagnostic; one caller-owned socket, no media FDs."""
import json
import os
from pathlib import Path
import socket
import struct
import sys

RUNTIME = Path('/backups/disk2/blent-work/2026-10-20-media-acceptance/runtime/blent-usb')
TARGET = Path('/sys/bus/usb/devices/3-2.4.4')


def exchange(connection, request, command):
    packet = b'BLRG\x01\x05\0\0' + struct.pack('>Q', request) + command
    assert connection.send(packet) == len(packet)
    records = []
    for _ in range(128):
        reply = connection.recv(4097)
        assert 16 <= len(reply) <= 4096
        assert reply[:5] == b'BLRG\x01' and reply[6:8] == b'\0\0'
        assert struct.unpack('>Q', reply[8:16])[0] == request
        if reply[5] == 4:
            raise RuntimeError(f'broker rejected request: reason {reply[16]}')
        assert reply[5] == 6
        record = reply[16:]
        records.append(record)
        if record[0] == 4:
            return records
    raise RuntimeError('snapshot exceeds selected 128-record diagnostic capacity')


def link(record):
    assert len(record) in (20, 92)
    result = {'connection': int.from_bytes(record[9:17], 'big'), 'state': record[17]}
    if record[19]:
        assert len(record) == 92
        result.update(epoch=int.from_bytes(record[20:28], 'big'), tablet=record[28:].decode('ascii'))
    return result


def snapshot(records):
    assert records[0][0] == 0 and len(records[0]) == 73
    result = {'revision': int.from_bytes(records[0][1:9], 'big'), 'computer': records[0][9:].decode('ascii')}
    result['devices'] = [dict(target=int.from_bytes(r[9:17], 'big'), vendor=int.from_bytes(r[17:19], 'big'), product=int.from_bytes(r[19:21], 'big')) for r in records if r[0] == 1]
    result['links'] = [link(r) for r in records if r[0] == 2]
    result['resources'] = [r.hex() for r in records if r[0] == 3]
    return result


def selected_target(view):
    assert (TARGET/'serial').read_text().strip() == '8002RH1010011900'
    vendor = int((TARGET/'idVendor').read_text(), 16)
    product = int((TARGET/'idProduct').read_text(), 16)
    selected = [d for d in view['devices'] if (d['vendor'], d['product']) == (vendor, product)]
    assert len(selected) == 1, 'selected physical tablet must be unique in this snapshot'
    return selected[0]['target']


