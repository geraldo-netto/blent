"""Selected-tablet UI observation; one settled ADB subprocess per operation."""
from pathlib import Path
import subprocess
import sys
import json
import re
import time
import xml.etree.ElementTree as E

BASE = Path(__file__).resolve().parent / 'T1252'
SERIAL = '8002RH1010011900'


def device(*args):
    return subprocess.check_output(['adb', '-s', SERIAL, *args])


def observe(stem):
    destination = (BASE / (stem + '.xml')).resolve()
    assert destination.parent == BASE
    device('shell', 'uiautomator', 'dump', '/sdcard/blent-pairing-acceptance.xml')
    data = device('exec-out', 'cat', '/sdcard/blent-pairing-acceptance.xml')
    assert len(data) <= 1048576
    root = E.fromstring(data)
    destination.write_bytes(data)
    return root


def select(root, label):
    parents = {child: parent for parent in root.iter() for child in parent}
    matches = [n for n in root.iter('node') if label in (n.get('text'), n.get('content-desc'))]
    assert len(matches) == 1, (label, len(matches))
    node = matches[0]
    button = node if node.get('clickable') == 'true' else parents[node]
    assert button.get('enabled') == 'true'
    assert button.get('clickable') == 'true'
    bounds = list(map(int, re.findall(r'\d+', button.get('bounds'))))
    x1, y1, x2, y2 = bounds
    assert 0 <= x1 < x2 <= 1280
    assert 0 <= y1 < y2 <= 800
    return bounds


def click(label, stem):
    root = observe(stem + '-before')
    x1, y1, x2, y2 = select(root, label)
    record = dict(label=label, bounds=[x1, y1, x2, y2], before=time.time())
    device('shell', 'input', 'tap', str((x1+x2)//2), str((y1+y2)//2))
    record['after'] = time.time()
    (BASE / (stem + '-action.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)


def display(stem):
    root = observe(stem)
    parents = {child: parent for parent in root.iter() for child in parent}
    for n in root.iter('node'):
        if n.get('text'):
            print(n.get('text'), n.get('bounds'), parents[n].get('enabled'))


if sys.argv[1] == 'click':
    click(sys.argv[2], sys.argv[3])
else:
    assert sys.argv[1] == 'dump'
    display(sys.argv[2])
