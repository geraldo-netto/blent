import importlib.util
from pathlib import Path
import subprocess
import unittest
from unittest.mock import patch

root = Path('/backups/disk2/projects/blent')
source = root / 'scripts/benchmarks/shared-encode-producer.c'
old = Path('/tmp/blent-t793-teardown-red-producer.c')
text = source.read_text()
assert 'if (shared) finish_shared(&ring);' in text
old.write_text(text.replace('if (shared) finish_shared(&ring);',
                            'if (shared) raw_ring_close(&ring);'))
spec = importlib.util.spec_from_file_location('regression', root / 'host/tests/shared_encode_replay.py')
regression = importlib.util.module_from_spec(spec)
spec.loader.exec_module(regression)
original = subprocess.run

def old_producer_only(command, *args, **kwargs):
    if command[0] == 'cc':
        assert str(source) in command
        command = [str(old) if item == str(source) else item for item in command]
        command.extend(['-I', str(source.parent)])
    return original(command, *args, **kwargs)

with patch.object(subprocess, 'run', old_producer_only):
    for attempt in range(1, 6):
        print(f'T793 old teardown fixture, unchanged permanent regression, attempt {attempt}', flush=True)
        suite = unittest.defaultTestLoader.loadTestsFromTestCase(regression.GeneratedReplayTests)
        result = unittest.TextTestRunner(verbosity=2).run(suite)
        if not result.wasSuccessful():
            raise SystemExit(1)
raise SystemExit('Old teardown unexpectedly passed five bounded attempts')
