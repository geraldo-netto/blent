"""Join only native counters with identical authored production sources."""
exec(open('/tmp/blent-t1021-evidence/c_setup.py').read())
from readers import gcov_json
BASE = Path('/tmp/blent-t1021-evidence')
data = {}
expected = None
functions = None
for name in ['coverage', 'coverage-boundary']:
    directory = BASE / name
    manifest = json.loads((directory / 'manifest.json').read_text())
    production = {key: value for key, value in manifest['sources'].items() if key.startswith('host/evdi/')}
    verify_sources(ROOT, production)
    if expected is not None:
        assert production == expected
        assert manifest['functions'] == functions
    expected = production
    functions = manifest['functions']
    for path in sorted((directory / 'native').glob('c-*/*.gcov.json.gz')):
        gcov_json(path, ROOT, data)
rows = [result(Function(**entry), data) for entry in functions]
(BASE / 'per-function.json').write_text(json.dumps(dict(passes=all(row['passes'] for row in rows), sources=expected, functions=rows), indent=2)+'\n')
assert all(row['passes'] for row in rows), [row for row in rows if not row['passes']]
print(len(rows), 'production functions individually >=80%; minimum', min(row['percent'] for row in rows))
