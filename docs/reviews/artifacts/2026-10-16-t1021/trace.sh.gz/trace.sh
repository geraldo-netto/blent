set -o functrace
trap 'printf "%s\t%s\t%s\n" "${BASH_SOURCE[0]:-command}" "$LINENO" "$BASH_COMMAND" >> "$BLENT_T1021_SHELL_TRACE"' DEBUG
