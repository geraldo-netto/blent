"""Independent offline definition inventory and explicit source estimates, not SonarQube."""
import json
from pathlib import Path
import re
import subprocess

BASE=Path('/tmp/blent-t1120-evidence')

def clean(text):
    pattern=r'/\*[\s\S]*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\''
    return re.sub(pattern,lambda match:' '*len(match[0]),text)

def score(text):
    return 1+len(re.findall(r'\b(?:if|for|while|case|default)\b|&&|\|\||\?',clean(text)))

rows=[]
for name in ['writer','idle_control']:
    file=Path('host/evdi')/(name+'.c');text=file.read_text()
    tree=json.loads(subprocess.check_output(['clang-18','-std=c11','-Ihost/evdi','-Xclang','-ast-dump=json','-fsyntax-only',str(file)]))
    for node in tree['inner']:
        if node['kind']!='FunctionDecl' or 'includedFrom' in node.get('loc',{}):continue
        if not any(child['kind']=='CompoundStmt' for child in node.get('inner',[])):continue
        first=node['range']['begin']['offset'];last=node['range']['end']['offset']+1
        rows.append(dict(file=str(file),name=node['name'],complexity=score(text[first:last])))
for file,selected in [('host/tests/idle_capture.c',None),('host/tests/idle_recheck.c',None),('host/tests/idle_admission.c',None),('host/tests/evdi_helper_test.c',{'main','mock_pthread_cond_timedwait'})]:
    text=Path(file).read_text();source=clean(text)
    definitions=re.finditer(r'(?m)^(?:static )?(?:void|int|ssize_t)\s+(\w+)\([^;{}]*\)\s*\{',source)
    for match in definitions:
        if selected is not None and match[1] not in selected:continue
        begin=source.index('{',match.start());end=begin+1;depth=1
        while depth:
            depth+=(source[end]=='{')-(source[end]=='}');end+=1
        rows.append(dict(file=file,name=match[1],complexity=score(text[match.start():end])))
ns={};exec(compile(Path('/tmp/blent-t1118-evidence/collect.py').read_text().split('\nBASE =')[0],'cached-rust-audit','exec'),ns)
import syntax
file='host/tests/evdi_helper.rs'
rows.extend(dict(file=file,name=name,line=line,complexity=value) for line,name,value in syntax.syntax_scores(Path(file).read_text(),'rust'))
assert all(row['complexity']<=9 for row in rows)
(BASE/'complexity.json').write_text(json.dumps(dict(native_sonarqube=False,missing='T1019',tool='Clang 18.1.3 definition inventory + explicit C source count; tree-sitter-rust 0.24.2/tree-sitter 0.25.2 repository rules',functions=rows),indent=2)+'\n')
print(len(rows),'functions; max',max(row['complexity'] for row in rows))
