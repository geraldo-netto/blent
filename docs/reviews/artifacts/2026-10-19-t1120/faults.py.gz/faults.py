"""Bounded native safety controls; restore source bytes after every variant."""
from pathlib import Path
import os
import sys
sys.path.insert(0,str(Path.cwd()/'scripts/benchmarks'))
import profile_process as owned
ROOT=Path.cwd().resolve();BASE=Path('/tmp/blent-t1120-evidence')

def fault(old,new,label):
    source=ROOT/'host/evdi/idle_control.c';original=source.read_bytes()
    assert original.count(old.encode())==1,label
    (BASE/'correct-idle_control.c').write_bytes(original)
    try:
        source.write_bytes(original.replace(old.encode(),new.encode()))
        status=owned.logged(['cargo','test','--offline','--locked','-p','blent','--test','evdi_helper','t1120'],dict(os.environ),BASE/(label+'.log'),ROOT)
        assert status!=0,label+' escaped permanent regression'
        print(label,'fault rejected',flush=True)
    finally:
        source.write_bytes(original)
        assert source.read_bytes()==original

fault('return original.st_dev != current->st_dev || original.st_ino != current->st_ino;',
      'return 1;', 'fault-old-advice')
fault('return read_interval(path, source, now_ms, reader->fd);',
      'return 0;', 'fault-disable-current')
fault('    reader->fd = -1;\n    reader->admitted = 0;',
      '    /* Fault: retain released descriptor identity. */', 'fault-double-close')
