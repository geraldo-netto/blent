package com.blent

import com.blent.activity.DisplayActivityUpdate
import kotlinx.coroutines.*
import kotlin.coroutines.CoroutineContext

/** One scheduled UI drain and one latest observation across foreground epochs.
 * Stop clears borrowed views; old callbacks cannot join a replacement epoch. */
internal class DisplayActivityDelivery(
    dispatchUi: (() -> Unit) -> Unit,
    private val consume: (DisplayActivityUpdate) -> Unit,
    reportFailure: (Exception) -> Unit,
) {
    private class UiDispatch(private val dispatchUi: (() -> Unit) -> Unit) : CoroutineDispatcher() {
        override fun dispatch(context: CoroutineContext, block: Runnable) {
            // The caller may execute UI callbacks inline. Schedule first so yield
            // cannot recurse or monopolize that caller's thread.
            Dispatchers.Default.dispatch(context) { dispatchUi { block.run() } }
        }
    }
    private val scope = CoroutineScope(SupervisorJob() + UiDispatch(dispatchUi))
    private val latest = LatestDispatch(scope, reportFailure)
    @Volatile private var owner: Any? = null
    fun start() { latest.clear(); owner = Any() }
    fun submit(update: DisplayActivityUpdate) {
        val original = owner ?: return
        latest.submit { if (owner === original) consume(update) }
    }
    fun stop() { owner = null; latest.clear() }
}
