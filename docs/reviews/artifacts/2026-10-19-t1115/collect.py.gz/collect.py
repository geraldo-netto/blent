"""Scoped offline audit: cached pinned Rust grammar; repository counting functions unchanged."""
import ast
import ctypes
from dataclasses import asdict
import importlib.metadata
import json
from pathlib import Path
import sys
import types

ROOT = Path.cwd().resolve()
sys.path.insert(0, '/home/netto/.cache/uv/archive-v0/nOds33o--6Q7Ze_u')
sys.path.insert(0, str(ROOT / 'scripts/complexity'))
sys.path.insert(0, str(ROOT / 'scripts/coverage'))
from tree_sitter import Language, Parser

native = ctypes.CDLL('/tmp/blent-t1049-evidence/parsers/rust.so')
native.tree_sitter_rust.restype = ctypes.c_void_p
capsule = ctypes.pythonapi.PyCapsule_New
capsule.restype = ctypes.py_object
capsule.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_void_p]
parser = Parser(Language(capsule(native.tree_sitter_rust(), b'tree_sitter.Language', None)))
# Only Rust is in scope. Initialize its pinned cached parser directly; retain
# every source-counting definition verbatim, without unavailable C/Shell imports.
path = ROOT / 'scripts/complexity/syntax.py'
tree = ast.parse(path.read_text())
tree.body = [node for node in tree.body if not isinstance(node, (ast.Import, ast.ImportFrom))
             and not (isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'PARSERS' for t in node.targets))]
module = types.ModuleType('syntax')
module.__dict__.update(ast=ast, PARSERS={'rust': parser})
exec(compile(tree, str(path), 'exec'), module.__dict__)
sys.modules['syntax'] = module
from check import source_files
from inventory import syntax_functions
from model import Function, fingerprint, result, verify_sources
from readers import lcov
from rust_collect import Selection, collect

BASE = Path('/tmp/blent-t1115-evidence')
FILES = ['host/src/capture/idle.rs','host/src/capture/idle/directory.rs','host/src/capture/idle/staging.rs','host/src/capture/idle/policy.rs','host/src/capture/idle/subjects.rs','common/src/idle.rs','common/src/idle/unchanged.rs']

def snapshot(root):
    paths = [path for path in source_files(root) if path.suffix == '.rs']
    paths += [Path('host/tests/idle_request_probe.c'),Path('host/evdi/idle_control.c'),Path('host/evdi/idle_control.h')]
    hashes = {str(path): fingerprint(root / path) for path in paths}
    functions = [asdict(function) for name in FILES
                 for function in syntax_functions(Path(name), (root / name).read_text(), 'rust')]
    return dict(version=1, sources=hashes, build_sources=hashes, functions=functions)

output = BASE/'native-with-lib'
collect(ROOT,output,Selection(packages=('blent','blent-config'),binaries=True,library=True,features=('accessory-transport',),filter='idle'),snapshotter=snapshot)
manifest=json.loads((output/'manifest.json').read_text());verify_sources(ROOT,manifest['sources'])
data={};lcov(output/'rust.lcov',ROOT,data)
rows=[result(Function(**entry),data) for entry in manifest['functions']]
(output/'per-function.json').write_text(json.dumps(dict(passes=all(row['passes'] for row in rows),functions=rows),indent=2)+'\n')
for row in rows:
    print(row['name'],row['percent'],row['missing'],flush=True)
assert rows and all(row['passes'] for row in rows),'per-function below 80% or unmeasured'
