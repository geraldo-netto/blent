"""T1115 permanent native-boundary regressions reject deliberate reversions."""
from pathlib import Path
import json
import os
import sys
sys.path.insert(0,str(Path.cwd()/'scripts/benchmarks'))
import profile_process as owned
ROOT=Path.cwd().resolve();BASE=Path('/tmp/blent-t1115-evidence')

def fault(old,new,label,test):
    source=ROOT/'host/src/capture/idle.rs';original=source.read_bytes()
    assert original.count(old.encode())==1,label
    try:
        source.write_bytes(original.replace(old.encode(),new.encode()))
        status=owned.logged(['cargo','test','--offline','--locked','-p','blent','--bin','blent',test],dict(os.environ),BASE/(label+'.log'),ROOT)
        assert status!=0,label+' escaped permanent regression'
        assert 'test result: FAILED' in (BASE/(label+'.log')).read_text(),label+' did not fail its test'
        print(label,'fault rejected',flush=True)
    finally:
        source.write_bytes(original)
        assert source.read_bytes()==original

fault('        policy.tick(\n            subjects.current(mode, evidence, &lease.stop),\n            micros(origin, Instant::now()),\n        );',
      '        // Deliberate fault: trust receipt proof sampled before native wait.',
      'fault-expired-proof','t1115_expired_receipt_proof_during_publication_wait_cannot_renew_native_lease')
fault('        self.check_current(current)?;\n        match file.persist(&self.path) {',
      '        match file.persist(&self.path) {',
      'fault-after-staging','t1115_loss_after_staging_cannot_replace_original_advice_or_leave_temp_debt')
manifest=json.loads((BASE/'native-with-lib/manifest.json').read_text())
sys.path.insert(0,str(ROOT/'scripts/coverage'))
from model import verify_sources
verify_sources(ROOT,manifest['sources'])
print('All native input hashes restored',flush=True)
status=owned.logged(['cargo','test','--offline','--locked','-p','blent','--bin','blent','capture::idle'],dict(os.environ),BASE/'green-restored-final.log',ROOT)
assert status==0,'restored original idle tests failed'
