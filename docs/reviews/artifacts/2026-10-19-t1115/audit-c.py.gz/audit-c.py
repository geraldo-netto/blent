"""Independent offline definition inventory and explicit source estimates, not SonarQube."""
import json
from pathlib import Path
import re
import subprocess

BASE=Path('/tmp/blent-t1115-evidence')

def clean(text):
    pattern=r'/\*[\s\S]*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\''
    return re.sub(pattern,lambda match:' '*len(match[0]),text)

def score(text):
    return 1+len(re.findall(r'\b(?:if|for|while|case|default)\b|&&|\|\||\?',clean(text)))

rows=[]
file=Path('host/tests/idle_request_probe.c'); text=file.read_text()
tree=json.loads(subprocess.check_output(['clang-18','-std=c11','-Ihost/evdi','-Xclang','-ast-dump=json','-fsyntax-only',str(file)]))
for node in tree['inner']:
    if node['kind']!='FunctionDecl' or 'includedFrom' in node.get('loc',{}):continue
    if not any(child['kind']=='CompoundStmt' for child in node.get('inner',[])):continue
    first=node['range']['begin']['offset'];last=node['range']['end']['offset']+1
    rows.append(dict(file=str(file),name=node['name'],complexity=score(text[first:last])))
assert rows and all(row['complexity']<=9 for row in rows)
(BASE/'c-complexity.json').write_text(json.dumps(dict(native_sonarqube=False,missing='T1019',tool='Clang 18.1.3 definition inventory + explicit C source count',functions=rows),indent=2)+'\n')
print(rows)
